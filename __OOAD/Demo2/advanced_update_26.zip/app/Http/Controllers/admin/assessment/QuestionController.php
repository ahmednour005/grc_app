<?php

namespace App\Http\Controllers\admin\assessment;

use App\Enums\QuestionTypeEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\admin\assessment\QuestionRequest;
use App\Http\Requests\ImportQuestionRequest;
use App\Models\Assessment;
use App\Models\AssessmentQuestion;
use App\Models\Question;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class QuestionController extends Controller
{
    public function data(Request $request)
    {
        $questions = Question::query()->whereHas('assessments', function ($q) use ($request) {
            return $q->where('assessment_id', $request['assessment_id']);
        })->select('id', 'question', 'answer_type', 'file_attachment', 'question_logic', 'risk_assessment', 'compliance_assessment', 'maturity_assessment')->withCount('answers')->latest('id');
        return DataTables::eloquent($questions)
            ->addIndexColumn()
            ->addColumn('actions', 'admin.content.assessment.questions.includes.actions')
            ->addColumn('answer_type', function ($raw) {
                // return QuestionTypeEnum::getQuestionStatus($raw->answer_type);
                if ($raw->answer_type == 1) {
                    return 'Single Select';
                } elseif ($raw->answer_type == 2) {
                    return 'Multi Select';
                } else {
                    return 'Fill in the Blank';
                }
            })
            ->rawColumns(['actions'])
            ->skipTotalRecords()
            ->toJson();
    }

    public function fetch_questions_from_assessment(Request $request)
    {
        if ($request->assessment_id) {

            $data =  Assessment::find($request->assessment_id)->questions;
        } else {
            $data = Question::all();
        }
        return $data;
    }

    public function store(QuestionRequest $request)
    {
        $basicData = $request->safe()->except('assessment_id');


        DB::beginTransaction();
        try {

            $assessment = Assessment::query()->find($request->safe()->assessment_id);
            $question = Question::query()->create($basicData);
            $assessment->questions()->attach($question);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json($e->getMessage(), $e->getCode());
        }
        DB::commit();
        return response()->json('Question Added Successfully');
    }

    public function edit(Question $question)
    {
        $question->load('control:id,short_name');
        return $question;
    }

    public function update(QuestionRequest $request, Question $question)
    {
        $basicData = $request->safe()->except('assessment_id');


        DB::beginTransaction();
        try {
            $question->update($basicData);
            if (!$question->question_logic) {
                $question->answers()->each(function ($raw) {
                    $raw->sub_questions()->detach();
                });
                $question->answers()->update(['sub_question_assessment_id' => null]);
            }
            if (!$question->maturity_assessment) {
                $question->answers()->update(['maturity_control_id' => null]);
            }
            if (!$question->compliance_assessment) {
                $question->answers()->update(['fail_control' => null]);
            }
            if (!$question->risk_assessment) {
                $question->answers()->update([
                    'submit_risk' => 0,
                    'risk_subject' => null,
                    'risk_scoring_method_id' => null,
                    'likelihood_id' => null,
                    'impact_id' => null,
                    'owner_id' => null,
                    'assets_ids' => null,
                    'framework_controls_ids' => null,
                    'tags_ids' => null,
                ]);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json($e->getMessage(), $e->getCode());
        }
        DB::commit();
        return response()->json('Question Updated Successfully');
    }

    public function destroy(Request $request, Question $question)
    {
        $question->assessments()->detach($request->assessment_id);
        $related_asset =  AssessmentQuestion::where('question_id', $question->id)->count();
        if (!$related_asset) {
            $question->delete();
        }
    }

    public function importQuestions(ImportQuestionRequest $request)
    {
        $assessment = Assessment::query()->find($request->safe()->assessment_id);
        $assessmentQuestions = $assessment->questions->pluck('id')->toArray();
        foreach ($request->safe()->question_ids as $question_id) {
            if (!in_array($question_id, $assessmentQuestions)) {
                $assessment->questions()->attach($question_id);
            }
        }
    }
}
