@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.DocumentProgram'))
@section('vendor-style')
    <!-- vendor css files -->

    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{ asset(mix('css/base/pages/app-todo.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/pages/app-chat.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/pages/app-chat-list.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/quill.snow.css')) }}">
@endsection


@section('page-style')
    <!-- Page css files -->

    <style>
        html .navbar-floating.footer-static .app-content .content-area-wrapper,
        html .navbar-floating.footer-static .app-content .kanban-wrapper {
            height: auto !important;
        }

        #view_type_sorting {
            font-family: "FontAwesome";
            font-size: 14px;
        }

        #view_type_sorting::before {
            vertical-align: middle;
        }

        .tab button:hover {
            background-color: #bee9f7;
        }

        .tab button.active {
            background-color: #6398a8;
        }

        .gov_btn {
            border-color: #0097a7;
            background-color: #0097a7;
            color: #fff !important;
            /* padding: 7px; */
            border: 1px solid transparent;
            padding: 0.786rem 1.5rem;
            line-height: 1;
            border-radius: 0.358rem;
            font-weight: 500;
            font-size: 1rem;
        }

        .gov_btn_edit {
            border-color: #5388B4 !important;
            background-color: #5388B4 !important;
            color: #fff !important;
            border: 1px solid transparent;
            padding: 0.786rem 1.5rem;
            line-height: 1;
            border-radius: 0.358rem;
            font-weight: 500;
            font-size: 1rem;
        }

        .gov_btn_map {
            border-color: #6c757d !important;
            background-color: #6c757d !important;
            color: #fff !important;
            border: 1px solid transparent;
            padding: 0.786rem 1.5rem;
            line-height: 1;
            border-radius: 0.358rem;
            font-weight: 500;
            font-size: 1rem;
        }

        .gov_check {
            padding: 0.786rem 0.7rem;
            line-height: 1;
            font-weight: 500;
            font-size: 1.2rem;
        }

        .gov_err {

            color: red;
        }

        .frame .card-title {
            display: inline-block;
            color: #000;
            font-size: 1rem !important;
        }

        .frame .card-desc {
            display: inline-block;
            color: #6e6c6c;
        }

        .card-body .btn {
            margin-right: 5px;

        }

        .card-body form {
            margin-bottom: 0;

        }

        .todo-application .content-area-wrapper .content-right .todo-task-list-wrapper .todo-task-list li:not(:first-child) {
            border-top: 0 !important;
        }

        .todo-application .content-area-wrapper .content-right .todo-task-list-wrapper .todo-task-list .pagination li {
            padding: 0;
        }

        .card2 {
            padding: 0.893rem 2rem;
            margin-top: 25px;
        }

        .tab button {
            margin: 0;
        }

        .form-select {
            display: inline-block;
        }

        .dataTables_filter {
            float: right !important;
        }

        .dataTables_filter input {
            display: inline-block !important;
            width: auto !important;
        }

        .multiple-select2 {
            z-index: 99999999;
        }

        #privacy2 {
            display: none
        }

        #approval_date2 {
            display: none
        }

        #reviewer {
            display: none
        }
    </style>
@endsection
@section('content-sidebar')

    <div class="sidebar-content todo-sidebar">
        <div class="todo-app-menu">
            <div class="add-task">
                @if (auth()->user()->hasPermission('category.create'))
                    <button type="button" class="btn btn-primary w-100" data-bs-toggle="modal"
                        data-bs-target="#new-assessment-modal">
                        {{ __('locale.AddNewTemplate') }}
                    </button>
                @endif

            </div>
            <div id="paginated_data">
                @include('admin.content.assessment.paginated_data')
            </div>

        </div>
    </div>
    {{-- assessments modals --}}
    <div class="modal modal-slide-in sidebar-todo-modal fade" id="new-assessment-modal">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">
                <form id="add_assessment" class="add_assessment todo-modal needs-validation" novalidate method="POST"
                    action="{{ route('admin.assessment.store') }}">
                    @csrf

                    <div class="modal-header align-items-center mb-1">
                        <h5 class="modal-title">{{ __('locale.AddNewTemplate') }}</h5>
                        <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                            <span class="todo-item-favorite cursor-pointer me-75">
                                <i data-feather="star" class="font-medium-2"></i>
                            </span>
                            <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                        </div>
                    </div>
                    <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                        <div class="action-tags">
                            <div class="mb-1">
                                <label for="title" class="form-label">{{ __('locale.Name') }}</label>
                                <input type="text" name="name" class=" form-control" placeholder="Name" required />
                                <span class="error error-name"></span>
                            </div>
                        </div>
                        <div class="my-1">
                            <button type="submit" class="btn btn-primary add-todo-item me-1">
                                {{ __('locale.Add') }}
                            </button>
                            <button type="button" class="btn btn-outline-secondary add-todo-item" data-bs-dismiss="modal">
                                {{ __('locale.Cancel') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal modal-slide-in sidebar-todo-modal fade" id="edit-assessment-modal">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">
                <form id="edit_assessment" class="edit_assessment todo-modal needs-validation" novalidate method="POST"
                    action="">
                    @csrf
                    <input type="hidden" name="id">
                    <div class="modal-header align-items-center mb-1">
                        <h5 class="modal-title">{{ __('locale.UpdateAssessment') }}</h5>
                        <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                            <span class="todo-item-favorite cursor-pointer me-75">
                                <i data-feather="star" class="font-medium-2"></i>
                            </span>
                            <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                        </div>
                    </div>
                    <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                        <div class="action-tags">
                            <div class="mb-1">
                                <label for="title" class="form-label">{{ __('locale.Name') }}</label>
                                <input type="text" name="name" class=" form-control" placeholder="Name" required />
                                <span class="error error-name"></span>
                            </div>
                        </div>
                        <div class="my-1">
                            <button type="submit" class="btn btn-primary   add-todo-item me-1">
                                {{ __('locale.Update') }}
                            </button>
                            <button type="button" class="btn btn-outline-secondary add-todo-item "
                                data-bs-dismiss="modal">
                                {{ __('locale.Cancel') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    {{-- qeustions modals --}}
    <div class="modal modal-slide-in sidebar-todo-modal fade" id="new-question-modal">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">
                <form id="add_questions" class="add_questions todo-modal needs-validation" novalidate method="POST"
                    action="{{ route('admin.questions.store') }}">
                    @csrf

                    <div class="modal-header align-items-center mb-1">
                        <h5 class="modal-title">{{ __('locale.AddNewQuestion') }}</h5>
                        <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                            <span class="todo-item-favorite cursor-pointer me-75">
                                <i data-feather="star" class="font-medium-2"></i>
                            </span>
                            <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                        </div>
                    </div>
                    <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                        <div class="action-tags">
                            <div class="mb-1">
                                <label for="question" class="form-label">{{ __('locale.Question') }}</label>
                                <div {{-- id="question" --}} class="border-bottom-0 question"></div>
                                <div class="d-flex justify-content-end question-toolbar border-top-0">
                                    <span class="ql-formats me-0">
                                        <button class="ql-bold"></button>
                                        <button class="ql-italic"></button>
                                        <button class="ql-underline"></button>
                                        {{--                                        <button class="ql-align"></button> --}}
                                        <button class="ql-link"></button>
                                    </span>
                                </div>
                                <span class="error error-question"></span>
                            </div>
                            <div class="mb-1 controls" {{-- id="controls" --}}>
                                <label for="controls">{{ __('locale.Controls') }}</label>
                                <select name="control_id" class="form-control select2 controls">
                                    @foreach ($controls as $control)
                                        <option value="{{ $control->id }}">{{ $control->name }}</option>
                                    @endforeach

                                </select>
                            </div>

                            <div class="mb-1">
                                <label for="answer_type">{{ __('locale.AnswerType') }}</label>
                                <select name="answer_type" {{-- id="answer_type" --}} class="form-control select2 answer_type">
                                    <option value="1">Multiple Choice ( single-select )</option>
                                    <option value="2">Multiple Choice ( multiple-select )</option>
                                    <option value="3">Fill In The Blank</option>
                                </select>
                            </div>

                            <div class="options">
                                <div class="mb-1 file_attachment ">
                                    <label data-toggle="tooltip" title="Enable file uploads for this question."
                                        for="file_attachment">{{ __('locale.FileAttachment') }}
                                    </label>
                                    <input type="checkbox" id="file_attachment" name="file_attachment" value="1">
                                </div>
                                <div class="mb-1 question_logic">
                                    <label data-toggle="tooltip"
                                        title="Enable ability to ask another question
                                            based on the answer to this question."
                                        for="QuestionLogic">{{ __('locale.QuestionLogic') }}
                                    </label>
                                    <input type="checkbox" id="QuestionLogic" name="question_logic" value="1">
                                </div>
                                <div class="mb-1 risk_assessment">
                                    <label data-toggle="tooltip"
                                        title=" Enable creation of risks based on the answer to this question."
                                        for="RiskAssessment">{{ __('locale.RiskAssessment') }}
                                    </label>
                                    <input type="checkbox" id="RiskAssessment" name="risk_assessment" value="1">
                                </div>
                                <div class="mb-1 compliance_assessment">
                                    <label data-toggle="tooltip"
                                        title="Enable tracking of the pass/fail status
                                     against the mapped controls."
                                        for="ComplianceAssessment">{{ __('locale.ComplianceAssessment') }}
                                    </label>
                                    <input type="checkbox" id="ComplianceAssessment" name="compliance_assessment"
                                        value="1">
                                </div>
                                <div class="mb-1 maturity_assessment">
                                    <label data-toggle="tooltip"
                                        title="Enable tracking of the current control maturity level
                                            against our desired maturity level."
                                        for="MaturityAssessment">{{ __('locale.MaturityAssessment') }}
                                    </label>
                                    <input type="checkbox" id="MaturityAssessment" name="maturity_assessment"
                                        value="1">
                                </div>
                            </div>
                        </div>
                        <div class="my-1">
                            <button type="submit" class="btn btn-primary add-todo-item me-1">
                                {{ __('locale.Add') }}
                            </button>
                            <button type="button" class="btn btn-outline-secondary add-todo-item "
                                data-bs-dismiss="modal">
                                {{ __('locale.Cancel') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal modal-slide-in sidebar-todo-modal fade" id="edit-question-modal">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">
                <form id="edit_question_form" class="edit_question_form todo-modal needs-validation" novalidate
                    method="POST" action="{{ route('admin.questions.update', ':id') }}">
                    @csrf
                    @method('put')
                    <input type="hidden" name="question_id">
                    <div class="modal-header align-items-center mb-1">
                        <h5 class="modal-title">{{ __('locale.UpdateQuestion') }}</h5>
                        <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                            <span class="todo-item-favorite cursor-pointer me-75">
                                <i data-feather="star" class="font-medium-2"></i>
                            </span>
                            <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                        </div>
                    </div>
                    <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                        <div class="action-tags">
                            <div class="mb-1">
                                <label for="edit_question" class="form-label">{{ __('locale.Question') }}</label>
                                <div {{-- id="edit_question" --}} class="border-bottom-0 edit_question"></div>
                                <div class="d-flex justify-content-end edit_question-toolbar border-top-0">
                                    <span class="ql-formats me-0">
                                        <button class="ql-bold"></button>
                                        <button class="ql-italic"></button>
                                        <button class="ql-underline"></button>
                                        {{--                                        <button class="ql-align"></button> --}}
                                        <button class="ql-link"></button>
                                    </span>
                                </div>
                                <span class="error error-question"></span>
                            </div>
                            <div class="mb-1 controls" {{-- id="controls" --}}>
                                <label for="controls">{{ __('locale.Controls') }}</label>
                                <select name="control_id" class="form-control select2 controls">
                                    @foreach ($controls as $control)
                                        <option value="{{ $control->id }}">{{ $control->name }}</option>
                                    @endforeach

                                </select>
                            </div>

                            <div class="mb-1">
                                <label for="answer_type">{{ __('locale.AnswerType') }}</label>
                                <select name="answer_type" id="answer_type" class="form-control select2 answer_type">
                                    <option value="1">Multiple Choice ( single-select )</option>
                                    <option value="2">Multiple Choice ( multiple-select )</option>
                                    <option value="3">Fill In The Blank</option>
                                </select>
                            </div>

                            <div class="options">
                                <div class="mb-1 file_attachment ">
                                    <label data-toggle="tooltip" title="Enable file uploads for this question."
                                        for="edit_file_attachment">{{ __('locale.FileAttachment') }}
                                    </label>
                                    <input type="checkbox" id="edit_file_attachment" name="file_attachment"
                                        value="1">
                                </div>
                                <div class="mb-1 question_logic">
                                    <label data-toggle="tooltip"
                                        title="Enable ability to ask another question based
                                            on the answer to this question."
                                        for="edit_QuestionLogic">{{ __('locale.QuestionLogic') }}
                                    </label>
                                    <input type="checkbox" id="edit_QuestionLogic" name="question_logic" value="1">
                                </div>
                                <div class="mb-1 risk_assessment">
                                    <label data-toggle="tooltip"
                                        title=" Enable creation of risks based on
                                     the answer to this question."
                                        for="edit_RiskAssessment">{{ __('locale.RiskAssessment') }}
                                    </label>
                                    <input type="checkbox" id="edit_RiskAssessment" name="risk_assessment"
                                        value="1">
                                </div>
                                <div class="mb-1 compliance_assessment">
                                    <label data-toggle="tooltip"
                                        title="Enable tracking of the pass/fail status against the mapped controls."
                                        for="edit_ComplianceAssessment">{{ __('locale.ComplianceAssessment') }}
                                    </label>
                                    <input type="checkbox" id="edit_ComplianceAssessment" name="compliance_assessment"
                                        value="1">
                                </div>
                                <div class="mb-1 maturity_assessment">
                                    <label data-toggle="tooltip"
                                        title="Enable tracking of the
                                     current control maturity level
                                     against our desired maturity level."
                                        for="edit_MaturityAssessment">{{ __('locale.MaturityAssessment') }}
                                    </label>
                                    <input type="checkbox" id="edit_MaturityAssessment" name="maturity_assessment"
                                        value="1">
                                </div>
                            </div>
                        </div>
                        <div class="my-1">
                            <button type="submit" class="btn btn-primary   add-todo-item me-1">
                                {{ __('locale.Update') }}
                            </button>
                            <button type="button" class="btn btn-outline-secondary add-todo-item "
                                data-bs-dismiss="modal">
                                {{ __('locale.Cancel') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    {{-- import questions --}}
    <div class="modal modal-slide-in sidebar-todo-modal fade" id="import-questions-modal">
        <div class="modal-dialog sidebar-lg">
            <div class="modal-content p-0">
                <form id="import_questions" class="import_questions todo-modal needs-validation" novalidate
                    method="POST" action="{{ route('admin.questions.importQuestions') }}">
                    @csrf

                    <div class="modal-header align-items-center mb-1">
                        <h5 class="modal-title">{{ __('locale.QuestionsBank') }}</h5>
                        <div class="todo-item-action d-flex align-items-center justify-content-between ms-auto">
                            <span class="todo-item-favorite cursor-pointer me-75">
                                <i data-feather="star" class="font-medium-2"></i>
                            </span>
                            <i data-feather="x" class="cursor-pointer" data-bs-dismiss="modal" stroke-width="3"></i>
                        </div>
                    </div>
                    <div class="modal-body flex-grow-1 pb-sm-0 pb-3">
                        <div class="action-tags">
                            <div class="mb-1">
                                <label for="assessment_id" class="form-label">{{ __('locale.Assessment') }}</label>
                                <select name="assessment_id" id="assessment_id" class="form-control select2">
                                    <option value="">---</option>
                                    @foreach ($all_assessments as $assessment)
                                        <option value="{{ $assessment->id }}">{{ $assessment->name }}</option>
                                    @endforeach
                                </select>
                                <span class="error error-name"></span>
                            </div>

                            <div class="mb-1">
                                {{--  data-assessment_id="{{ @$question->assessments->first()->id }}"  --}}
                                <div class="mb-2">
                                    <button type="button"
                                        class="btn btn-primary btn-sm select-all-btn">{{ __('locale.SelectAll') }}</button>
                                    <button type="button"
                                        class="btn btn-primary btn-sm unselect-all-btn">{{ __('locale.UnSelectAll') }}</button>
                                </div>
                                <label for="assessments_questions"
                                    class="form-label">{{ __('locale.Questions') }}</label>
                                <select name="question_ids[]" id="assessments_questions" class="form-control select2"
                                    multiple>
                                    @foreach ($questions as $question)
                                        <option value="{{ $question->id }}">
                                            {{ $question->question }}</option>
                                    @endforeach
                                </select>
                                <span class="error error-name"></span>
                            </div>
                        </div>
                        <div class="my-1">
                            <button type="submit" class="btn btn-primary add-todo-item me-1">
                                {{ __('locale.Import') }}
                            </button>
                            <button type="button" class="btn btn-outline-secondary add-todo-item"
                                data-bs-dismiss="modal">
                                {{ __('locale.Cancel') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection

@section('content')

    <div class="body-content-overlay"></div>

    <div class="todo-app-list {{ @$assessments->first() ? 'd-block' : 'd-none' }}">
        <!-- control List starts -->
        <div class="todo-task-list-wrapper list-group">
            <ul class="todo-task-list media-list" id="todo-task-list">
                <li class="todo-item">
                    <div id="firstTab{{ $assessments->first()->id ?? '' }}" class="tabcontent">
                        <!-- Dark Tables start -->
                        <div class="row" id="dark-table">
                            <div class="col-12">

                                <div class="card2">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="frame">
                                                <h4 class="card-title"> {{ __('locale.Name') }} : </h4>
                                                <h5 class="card-desc AssessmentName">
                                                    {{ $assessments->first()->name ?? '' }}
                                                </h5>
                                            </div>

                                            <!-- <a href="#" class="card-link">Another link</a> -->
                                            @if (auth()->user()->hasPermission('category.update'))
                                                <button type="button"
                                                    class="
                                                card-link
                                                btn btn-outline-primary
                                                 updateItem"
                                                    data-id="{{ $assessments->first()->id ?? '' }}"
                                                    data-name="{{ $assessments->first()->name ?? '' }}"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#edit-modal{{ $assessments->first()->id ?? '' }}">
                                                    {{ __('locale.Edit') }}
                                                </button>
                                            @endif
                                            @if (auth()->user()->hasPermission('category.delete'))
                                                <button class="card-link btn btn-outline-danger deleteItem"
                                                    data-id="{{ $assessments->first()->id ?? '' }}"> Delete
                                                </button>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </li>
                <li class="todo-item">
                    <section id="advanced-search-datatable">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">

                                    <div class="card-header border-bottom p-1">
                                        <div class="head-label">
                                            <h4 class="card-title">{{ __('locale.Questions') }}</h4>
                                        </div>
                                        @if (auth()->user()->hasPermission('document.create'))
                                            <div class="dt-action-buttons text-end">
                                                <div class="dt-buttons d-inline-flex">

                                                    <button type="button"
                                                        class="dt-button  btn btn-primary  me-2 AddQuesBtn"
                                                        data-bs-toggle="modal" data-bs-target="#new-question-modal">
                                                        {{ __('locale.AddNewQuestion') }}
                                                    </button>

                                                    <button type="button"
                                                        class="dt-button  btn btn-primary  me-2 ImportQuestionsBTn"
                                                        data-bs-toggle="modal" data-bs-target="#import-questions-modal">
                                                        {{ __('locale.QuestionsBank') }}
                                                    </button>
                                                </div>
                                            </div>
                                        @endif
                                    </div>

                                    <!--Search Form -->

                                    <hr class="my-0" />
                                    <div class="card-datatable table-responsive mx-1 ">

                                        <table class="table QuestionTable text-center">
                                            <thead>
                                                <tr>
                                                    <th class="all">{{ __('locale.#') }}</th>
                                                    <th class="all">{{ __('locale.FileAttachment') }}</th>
                                                    <th class="all">{{ __('locale.QuestionLogic') }}</th>
                                                    <th class="all">{{ __('locale.RiskAssessment') }}</th>
                                                    <th class="all">{{ __('locale.ComplianceAssessment') }}</th>
                                                    <th class="all">{{ __('locale.MaturityAssessment') }}</th>
                                                    <th class="all">{{ __('locale.HaveAnswers') }}</th>
                                                    <th class="all">{{ __('locale.AnswerType') }}</th>
                                                    <th class="all">{{ __('locale.Question') }}</th>

                                                    <th class="all">{{ __('locale.Actions') }}</th>
                                                </tr>
                                            </thead>

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </li>


            </ul>
            <div class="no-results">
                <h5>No Items Found</h5>
            </div>
        </div>

    </div>
@endsection




@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
    {{-- <script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script> --}}
    <script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
    {{-- <script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script> --}}
    {{-- <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script> --}}
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/dragula.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/validation/jquery.validate.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/editors/quill/quill.min.js')) }}"></script>
@endsection

@section('page-script')

    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>

    <script>
        let _assessment_id = '{{ $assessments->first()->id ?? '' }}';
        let _assessment_name = '{{ $assessments->first()->name ?? '' }}';
        let _sideNavBtn = '';
        let _page = 1;

        let swal_title = "{{ __('locale.AreYouSureToDeleteThisRecord') }}";
        let swal_text = '@lang('locale.YouWontBeAbleToRevertThis')';
        let swal_confirmButtonText = "{{ __('locale.ConfirmDelete') }}";
        let swal_cancelButtonText = "{{ __('locale.Cancel') }}";
        let swal_success = "{{ __('locale.Success') }}";

        $(document).on('click', '.sideNavBtn', function() {
            _sideNavBtn = $(this);
            _sideNavBtn.addClass('active').siblings().removeClass('active');
            _assessment_id = $(this).attr('id');
            _assessment_name = $(this).data('name');
            $('.AssessmentName').text(_assessment_name);
            $('.updateItem').attr('data-bs-target', '#edit-modal' + _assessment_id + '');
            $('.deleteItem').attr('data-id', _assessment_id);
            table.draw();

        });

        // edit assessment
        $('.updateItem').on('click', function() {
            let form = $('#edit-assessment-modal form');
            let url = "{{ route('admin.assessment.update', ':id') }}";
            url = url.replace(':id', _assessment_id);
            form.find($('input[name="name"]')).val(_assessment_name);
            form.attr('action', url);
            form.find('input[name="id"]').val(_assessment_id);
            $('#edit-assessment-modal').modal('show');

        });

        $(document).on('click', '.pagination.custom  a', function(e) {
            // get paginated assessments
            e.preventDefault();
            let url = $(this).data('url');
            _page = url.split('page=')[1];
            fetchData(_page);

        });

        function fetchData(page) {
            let url = '{{ route('admin.assessment.ajax.paginated_data', ':page') }}';
            url = url.replace(':page', 'page=' + page);
            $.ajax({
                type: "Get",
                url: url,
                success: function(response) {
                    $('#paginated_data').html(response);
                    $('.sideNavBtn:first').trigger('click');

                },
                error: function(xhr) {
                    console.log(xhr)
                }
            })
        }
    </script>

    {{-- on submit add assessment form --}}
    <script>
        $('#add_assessment').on('submit', function(event) {
            event.preventDefault();
            var data = new FormData(this),
                url = $(this).attr('action');
            $.ajax({
                processData: false,
                contentType: false,
                cache: false,
                type: "POST",
                url: url,
                data: data,
                success: function(response) {
                    makeAlert('success', 'Assessment Added Successfully',
                        "{{ __('locale.Success') }}");
                    $('#new-assessment-modal').modal('hide');
                    fetchData(_page);
                    formReset();
                    $('.todo-app-list').removeClass('d-none');
                },
                error: function(xhr) {
                    if (xhr.responseJSON.errors) {
                        $.each(xhr.responseJSON.errors, function(key, value) {
                            let input = $(`input[name="${key}"]`);
                            input.addClass('is-invalid');
                            $('.error-' + key).text(value)
                        })
                    }

                }
            })
        });
        // edit form
        $('#edit_assessment').on('submit', function(event) {
            event.preventDefault();
            let url = $(this).attr('action'),
                data = new FormData(this);
            data.append('_method', 'put');
            $.ajax({
                processData: false,
                cache: false,
                contentType: false,
                type: "post",
                url: url,
                data: data,
                headers: {
                    'x-csrf-token': '{{ csrf_token() }}'
                },
                success: function(response) {
                    makeAlert('success', 'Assessment Updated Successfully',
                        "{{ __('locale.Success') }}");
                    $('#edit-assessment-modal').modal('hide');
                    fetchData(_page);
                    formReset();
                },
                error: function(xhr) {
                    if (xhr.responseJSON.errors) {
                        $.each(xhr.responseJSON.errors, function(key, value) {
                            let input = $(`input[name="${key}"]`);
                            input.addClass('is-invalid');
                            $('.error-' + key).text(value)
                        })
                    }
                }

            })

        });

        $('.deleteItem').on('click', function() {
            let url = '{{ route('admin.assessment.destroy', ':id') }}';
            url = url.replace(':id', _assessment_id);

            Swal.fire({
                title: swal_title,
                text: swal_text,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: swal_confirmButtonText,
                cancelButtonText: swal_cancelButtonText,
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then(function(result) {
                if (result.value) {
                    $.ajax({
                        type: "DELETE",
                        url: url,
                        headers: {
                            'X-CSRF-TOKEN': "{{ csrf_token() }}"
                        },
                        success: function(response) {
                            makeAlert('success', 'Assessment Deleted Successfully',
                                swal_success);
                            if ($('.sideNavBtn').length === 1) {
                                $('.todo-app-list').addClass('d-none');
                            }
                            fetchData(_page);

                        }
                    })
                }
            });

        })
    </script>

    <script>
        function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false
            });
        };

        function formReset() {
            $('.modal form').trigger('reset');
            if (quill.getLength() > 1) {
                quill.setText('')
            }
            $('.modal form select').trigger('change');
            $('.modal form div.d-none').removeClass('d-none');
        }

        $('.modal').on('hidden.bs.modal', function() {
            $('.is-invalid').removeClass('is-invalid');
            $('.error').empty();

            formReset();
        })
    </script>

    {{-- questions --}}

    <script>
        const datatable_url = '{{ route('admin.questions.list') }}';
    </script>
    <script src="{{ asset('ajax-files/assessments/assessments/questions.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>


    {{-- import questions from assessemt --}}
    <script>
        var assesment_edit = null;
        $('#assessment_id').on('change', function(e) {
            assessment_id = $(this).val();
            url = "{{ route('admin.questions.fetch_questions_from_assessment') }}";
            $.ajax({
                type: "GET",
                url,
                data: {
                    assessment_id: assessment_id
                },
                success: function(response) {
                    $('#assessments_questions').empty();
                    $.each(response, function(index, option) {
                        $('#assessments_questions').append('<option value="' + option.id + '">' + option
                            .question + ' </option>');;
                    });
                },
                error: function(xhr) {

                }
            });

        });
        $(".select-all-btn").click(function() {
            $("#assessments_questions").find("option").prop("selected", true);
            $("#assessments_questions").trigger("change");
        });

        $(".unselect-all-btn").click(function() {
            $("#assessments_questions").find("option").prop("selected", false);
            $("#assessments_questions").trigger("change");
        });

        {{--  $('#assessment_id').on('change', function () {
            var assessment_id = $(this).val();
            $('#c option').prop('selected', false);
            $('#assessments_questions option[data-assessment_id="' + assessment_id + '"]').prop('selected', true);
            //  $('#assessments_questions').trigger('change');
        });  --}}
        $('#import_questions').on('submit', function(e) {
            e.preventDefault();
            var data = new FormData(this),
                url = $(this).attr('action');
            data.append('assessment_id', _assessment_id);
            if ($('#assessments_questions').val().length === 0) {
                makeAlert('error', 'Please Select At Least one Question !');
                return;
            }

            $.ajax({
                type: "POST",
                url: url,
                data: data,
                processData: false,
                cache: false,
                contentType: false,
                success: function(response) {
                    formReset();
                    $('.modal').modal('hide');
                    table.draw();
                },
                error: function(xhr) {
                    makeAlert('error', xhr.responseJSON.message);
                }
            })
        })
    </script>
@endsection
