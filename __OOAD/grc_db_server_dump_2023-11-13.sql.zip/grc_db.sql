-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 13, 2023 at 04:08 PM
-- Server version: 10.6.7-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE `actions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`id`, `name`) VALUES
(46, 'Aduit_Comment_Add'),
(19, 'Aduit_Policy_Add'),
(59, 'Assessment_Add'),
(61, 'Assessment_Delete'),
(60, 'Assessment_Update'),
(47, 'Asset_Add'),
(49, 'Asset_Delete'),
(50, 'Asset_Group_Add'),
(52, 'Asset_Group_Delete'),
(51, 'Asset_Group_Update'),
(48, 'Asset_Update'),
(40, 'Audit_Add'),
(44, 'Audit_Main_Add'),
(45, 'Audit_Risk_Add'),
(53, 'Cateogry_Add'),
(55, 'Cateogry_Delete'),
(54, 'Cateogry_Update'),
(34, 'Control_Add'),
(36, 'Control_Delete'),
(72, 'Control_Notify_Before_Last_Test_Date'),
(41, 'Control_Objectives_Add'),
(43, 'Control_Objectives_Delete'),
(42, 'Control_Objectives_Update'),
(35, 'Control_Update'),
(22, 'Departement_Add'),
(24, 'Departement_Delete'),
(68, 'Departement_Moving'),
(69, 'Departement_Moving_Employee'),
(23, 'Departement_Update'),
(56, 'Document_Add'),
(58, 'Document_Delete'),
(57, 'Document_Update'),
(38, 'Evidence_Add'),
(39, 'Evidence_Update'),
(31, 'Framework_Add'),
(33, 'Framework_Delete'),
(32, 'Framework_Update'),
(74, 'initiate_Assessment'),
(25, 'Job_Add'),
(27, 'Job_Delete'),
(26, 'Job_Update'),
(28, 'Kpi_Add'),
(30, 'Kpi_Delete'),
(29, 'Kpi_Update'),
(12, 'MgmtReview_Add'),
(73, 'Objective_Achievement'),
(37, 'Objective_Add'),
(62, 'Question_Add'),
(64, 'Question_Delete'),
(63, 'Question_Update'),
(65, 'Questionnaire_Add'),
(67, 'Questionnaire_Delete'),
(66, 'Questionnaire_Update'),
(10, 'Risk_Add'),
(13, 'Risk_Close'),
(16, 'Risk_Delete'),
(15, 'Risk_Mitigation'),
(20, 'Risk_Reopen'),
(18, 'Risk_Reset_Mitigations'),
(17, 'Risk_Reset_Reviews'),
(14, 'Risk_Status'),
(11, 'Risk_Update'),
(21, 'Risk_Update_Subject'),
(71, 'Security_Awareness_Notify_Before_Last_Review_Date'),
(7, 'securityAwareness_add'),
(9, 'securityAwareness_delete'),
(8, 'securityAwareness_update'),
(4, 'survey_add'),
(6, 'survey_delete'),
(70, 'Survey_Notify_Before_Last_Review_Date'),
(5, 'survey_update'),
(1, 'vulnerability_add'),
(3, 'vulnerability_delete'),
(2, 'vulnerability_update');

-- --------------------------------------------------------

--
-- Table structure for table `answer_question_surveys`
--

CREATE TABLE `answer_question_surveys` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `answer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `draft` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_idOut` bigint(20) UNSIGNED DEFAULT NULL,
  `survey_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `answer_question_surveys`
--

INSERT INTO `answer_question_surveys` (`id`, `question_id`, `answer`, `user_id`, `draft`, `user_idOut`, `survey_id`, `created_at`, `updated_at`) VALUES
(1, 3, 'B', NULL, '0', 1, 9, '2023-11-13 19:00:23', '2023-11-13 19:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `answer_sub_questions`
--

CREATE TABLE `answer_sub_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `answer_id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessments`
--

CREATE TABLE `assessments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assessments`
--

INSERT INTO `assessments` (`id`, `name`, `created`) VALUES
(1, 'PCI DSS 3.2', '2018-01-09 08:15:13'),
(2, 'NIST 800-171', '2018-01-09 08:15:13'),
(3, 'HIPAA (April 2016)', '2016-03-04 05:21:27'),
(4, 'Critical Security Controls', '2016-03-04 05:21:27');

-- --------------------------------------------------------

--
-- Table structure for table `assessment_answers`
--

CREATE TABLE `assessment_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sub_question_assessment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fail_control` tinyint(1) NOT NULL DEFAULT 0,
  `maturity_control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `submit_risk` tinyint(1) NOT NULL DEFAULT 0,
  `risk_subject` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `risk_scoring_method_id` bigint(20) UNSIGNED DEFAULT NULL,
  `likelihood_id` bigint(20) UNSIGNED DEFAULT NULL,
  `impact_id` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `assets_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`assets_ids`)),
  `tags_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags_ids`)),
  `framework_controls_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`framework_controls_ids`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_answers_to_assets`
--

CREATE TABLE `assessment_answers_to_assets` (
  `assessment_answer_id` bigint(20) UNSIGNED NOT NULL,
  `asset_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_answers_to_asset_groups`
--

CREATE TABLE `assessment_answers_to_asset_groups` (
  `assessment_answer_id` bigint(20) UNSIGNED NOT NULL,
  `asset_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_questions`
--

CREATE TABLE `assessment_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assessment_questions`
--

INSERT INTO `assessment_questions` (`id`, `assessment_id`, `question_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 1, 2, NULL, NULL),
(3, 1, 3, NULL, NULL),
(4, 1, 4, NULL, NULL),
(5, 1, 5, NULL, NULL),
(6, 1, 6, NULL, NULL),
(7, 1, 7, NULL, NULL),
(8, 1, 8, NULL, NULL),
(9, 1, 9, NULL, NULL),
(10, 1, 10, NULL, NULL),
(11, 1, 11, NULL, NULL),
(12, 1, 12, NULL, NULL),
(13, 1, 13, NULL, NULL),
(14, 1, 14, NULL, NULL),
(15, 1, 15, NULL, NULL),
(16, 1, 16, NULL, NULL),
(17, 1, 17, NULL, NULL),
(18, 1, 18, NULL, NULL),
(19, 1, 19, NULL, NULL),
(20, 1, 20, NULL, NULL),
(21, 2, 21, NULL, NULL),
(22, 2, 22, NULL, NULL),
(23, 2, 23, NULL, NULL),
(24, 2, 24, NULL, NULL),
(25, 2, 25, NULL, NULL),
(26, 2, 26, NULL, NULL),
(27, 2, 27, NULL, NULL),
(28, 2, 28, NULL, NULL),
(29, 2, 29, NULL, NULL),
(30, 2, 30, NULL, NULL),
(31, 2, 31, NULL, NULL),
(32, 2, 32, NULL, NULL),
(33, 2, 33, NULL, NULL),
(34, 2, 34, NULL, NULL),
(35, 2, 35, NULL, NULL),
(36, 2, 36, NULL, NULL),
(37, 2, 37, NULL, NULL),
(38, 2, 38, NULL, NULL),
(39, 2, 39, NULL, NULL),
(40, 2, 40, NULL, NULL),
(41, 2, 41, NULL, NULL),
(42, 2, 42, NULL, NULL),
(43, 2, 43, NULL, NULL),
(44, 2, 44, NULL, NULL),
(45, 2, 45, NULL, NULL),
(46, 2, 46, NULL, NULL),
(47, 2, 47, NULL, NULL),
(48, 2, 48, NULL, NULL),
(49, 2, 49, NULL, NULL),
(50, 2, 50, NULL, NULL),
(51, 2, 51, NULL, NULL),
(52, 2, 52, NULL, NULL),
(53, 2, 53, NULL, NULL),
(54, 2, 54, NULL, NULL),
(55, 2, 55, NULL, NULL),
(56, 2, 56, NULL, NULL),
(57, 2, 57, NULL, NULL),
(58, 2, 58, NULL, NULL),
(59, 2, 59, NULL, NULL),
(60, 2, 60, NULL, NULL),
(61, 2, 61, NULL, NULL),
(62, 2, 62, NULL, NULL),
(63, 2, 63, NULL, NULL),
(64, 2, 64, NULL, NULL),
(65, 2, 65, NULL, NULL),
(66, 2, 66, NULL, NULL),
(67, 2, 67, NULL, NULL),
(68, 2, 68, NULL, NULL),
(69, 2, 69, NULL, NULL),
(70, 2, 70, NULL, NULL),
(71, 2, 71, NULL, NULL),
(72, 2, 72, NULL, NULL),
(73, 2, 73, NULL, NULL),
(74, 2, 74, NULL, NULL),
(75, 2, 75, NULL, NULL),
(76, 2, 76, NULL, NULL),
(77, 2, 77, NULL, NULL),
(78, 2, 78, NULL, NULL),
(79, 2, 79, NULL, NULL),
(80, 2, 80, NULL, NULL),
(81, 2, 81, NULL, NULL),
(82, 2, 82, NULL, NULL),
(83, 2, 83, NULL, NULL),
(84, 2, 84, NULL, NULL),
(85, 2, 85, NULL, NULL),
(86, 2, 86, NULL, NULL),
(87, 2, 87, NULL, NULL),
(88, 2, 88, NULL, NULL),
(89, 2, 89, NULL, NULL),
(90, 2, 90, NULL, NULL),
(91, 2, 91, NULL, NULL),
(92, 2, 92, NULL, NULL),
(93, 2, 93, NULL, NULL),
(94, 2, 94, NULL, NULL),
(95, 2, 95, NULL, NULL),
(96, 2, 96, NULL, NULL),
(97, 2, 97, NULL, NULL),
(98, 2, 98, NULL, NULL),
(99, 2, 99, NULL, NULL),
(100, 2, 100, NULL, NULL),
(101, 2, 101, NULL, NULL),
(102, 2, 102, NULL, NULL),
(103, 2, 103, NULL, NULL),
(104, 2, 104, NULL, NULL),
(105, 2, 105, NULL, NULL),
(106, 2, 106, NULL, NULL),
(107, 2, 107, NULL, NULL),
(108, 2, 108, NULL, NULL),
(109, 2, 109, NULL, NULL),
(110, 2, 110, NULL, NULL),
(111, 2, 111, NULL, NULL),
(112, 2, 112, NULL, NULL),
(113, 2, 113, NULL, NULL),
(114, 2, 114, NULL, NULL),
(115, 2, 115, NULL, NULL),
(116, 2, 116, NULL, NULL),
(117, 2, 117, NULL, NULL),
(118, 2, 118, NULL, NULL),
(119, 2, 119, NULL, NULL),
(120, 2, 120, NULL, NULL),
(121, 2, 121, NULL, NULL),
(122, 2, 122, NULL, NULL),
(123, 2, 123, NULL, NULL),
(124, 2, 124, NULL, NULL),
(125, 2, 125, NULL, NULL),
(126, 2, 126, NULL, NULL),
(127, 2, 127, NULL, NULL),
(128, 2, 128, NULL, NULL),
(129, 4, 129, NULL, NULL),
(130, 4, 130, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assessment_scorings`
--

CREATE TABLE `assessment_scorings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `scoring_method` int(11) NOT NULL,
  `calculated_risk` double(8,2) NOT NULL,
  `CLASSIC_likelihood` double(8,2) NOT NULL DEFAULT 5.00,
  `CLASSIC_impact` double(8,2) NOT NULL DEFAULT 5.00,
  `CVSS_AccessVector` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_AccessComplexity` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'L',
  `CVSS_Authentication` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_ConfImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_IntegImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_AvailImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_Exploitability` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_RemediationLevel` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ReportConfidence` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_CollateralDamagePotential` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_TargetDistribution` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ConfidentialityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_IntegrityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_AvailabilityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `DREAD_DamagePotential` int(11) NOT NULL DEFAULT 10,
  `DREAD_Reproducibility` int(11) NOT NULL DEFAULT 10,
  `DREAD_Exploitability` int(11) NOT NULL DEFAULT 10,
  `DREAD_AffectedUsers` int(11) NOT NULL DEFAULT 10,
  `DREAD_Discoverability` int(11) NOT NULL DEFAULT 10,
  `OWASP_SkillLevel` int(11) NOT NULL DEFAULT 10,
  `OWASP_Motive` int(11) NOT NULL DEFAULT 10,
  `OWASP_Opportunity` int(11) NOT NULL DEFAULT 10,
  `OWASP_Size` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfDiscovery` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfExploit` int(11) NOT NULL DEFAULT 10,
  `OWASP_Awareness` int(11) NOT NULL DEFAULT 10,
  `OWASP_IntrusionDetection` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfConfidentiality` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfIntegrity` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAvailability` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAccountability` int(11) NOT NULL DEFAULT 10,
  `OWASP_FinancialDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_ReputationDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_NonCompliance` int(11) NOT NULL DEFAULT 10,
  `OWASP_PrivacyViolation` int(11) NOT NULL DEFAULT 10,
  `Custom` double(8,2) NOT NULL DEFAULT 10.00,
  `Contributing_Likelihood` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_scoring_contributing_impacts`
--

CREATE TABLE `assessment_scoring_contributing_impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_scoring_id` bigint(20) UNSIGNED NOT NULL,
  `contributing_risk_id` bigint(20) UNSIGNED NOT NULL,
  `impact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_value_id` bigint(20) UNSIGNED NOT NULL,
  `location_id` bigint(20) UNSIGNED DEFAULT NULL,
  `teams` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified` tinyint(4) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `alert_period` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `ip`, `name`, `asset_value_id`, `location_id`, `teams`, `details`, `created`, `verified`, `start_date`, `expiration_date`, `alert_period`) VALUES
(1, '127.0.0.1', 'Asset1', 1, 1, '1,4', 'Details asset 1', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(2, '127.0.0.2', 'Asset2', 7, 2, '1,4', 'Details asset 2', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(3, '127.0.0.3', 'Asset3', 8, 3, '1,4', 'Details asset 3', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(4, '127.0.0.4', 'Asset4', 8, 4, '1,4', 'Details asset 4', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(5, '127.0.0.5', 'Asset5', 4, 5, '1,4', 'Details asset 5', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(6, '127.0.0.6', 'Asset6', 10, 6, '1,4', 'Details asset 6', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(7, '127.0.0.7', 'Asset7', 1, 7, '1,4', 'Details asset 7', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(8, '127.0.0.8', 'Asset8', 1, 8, '1,4', 'Details asset 8', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(9, '127.0.0.9', 'Asset9', 6, 9, '1,4', 'Details asset 9', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(10, '127.0.0.10', 'Asset10', 3, 10, '1,4', 'Details asset 10', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(11, '127.0.0.11', 'Asset11', 8, 11, '1,4', 'Details asset 11', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(12, '127.0.0.12', 'Asset12', 7, 12, '1,4', 'Details asset 12', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(13, '127.0.0.13', 'Asset13', 5, 13, '1,4', 'Details asset 13', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(14, '127.0.0.14', 'Asset14', 3, 14, '1,4', 'Details asset 14', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(15, '127.0.0.15', 'Asset15', 5, 15, '1,4', 'Details asset 15', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(16, '127.0.0.16', 'Asset16', 6, 16, '1,4', 'Details asset 16', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(17, '127.0.0.17', 'Asset17', 5, 17, '1,4', 'Details asset 17', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(18, '127.0.0.18', 'Asset18', 3, 18, '1,4', 'Details asset 18', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(19, '127.0.0.19', 'Asset19', 9, 19, '1,4', 'Details asset 19', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(20, '127.0.0.20', 'Asset20', 4, 20, '1,4', 'Details asset 20', '2019-07-01 08:32:43', 1, '0000-00-00', '0000-00-00', 30),
(22, '123.3.9.9', 'testt', 2, 2, '1,3', '2', '2023-11-13 12:02:57', 1, '2023-11-14', '2023-11-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `asset_asset_groups`
--

CREATE TABLE `asset_asset_groups` (
  `asset_id` bigint(20) UNSIGNED NOT NULL,
  `asset_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_asset_groups`
--

INSERT INTO `asset_asset_groups` (`asset_id`, `asset_group_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20);

-- --------------------------------------------------------

--
-- Table structure for table `asset_groups`
--

CREATE TABLE `asset_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_groups`
--

INSERT INTO `asset_groups` (`id`, `name`) VALUES
(1, 'Asset Group 1'),
(10, 'Asset Group 10'),
(11, 'Asset Group 11'),
(12, 'Asset Group 12'),
(13, 'Asset Group 13'),
(14, 'Asset Group 14'),
(15, 'Asset Group 15'),
(16, 'Asset Group 16'),
(17, 'Asset Group 17'),
(18, 'Asset Group 18'),
(19, 'Asset Group 19'),
(2, 'Asset Group 2'),
(20, 'Asset Group 20'),
(3, 'Asset Group 3'),
(4, 'Asset Group 4'),
(5, 'Asset Group 5'),
(6, 'Asset Group 6'),
(7, 'Asset Group 7'),
(8, 'Asset Group 8'),
(9, 'Asset Group 9');

-- --------------------------------------------------------

--
-- Table structure for table `asset_values`
--

CREATE TABLE `asset_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `min_value` int(11) NOT NULL,
  `max_value` int(11) DEFAULT NULL,
  `valuation_level_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_values`
--

INSERT INTO `asset_values` (`id`, `min_value`, `max_value`, `valuation_level_name`) VALUES
(1, 0, 100000, ''),
(2, 100001, 200000, ''),
(3, 200001, 300000, ''),
(4, 300001, 400000, ''),
(5, 400001, 500000, ''),
(6, 500001, 600000, ''),
(7, 600001, 700000, ''),
(8, 700001, 800000, ''),
(9, 800001, 900000, ''),
(10, 900001, 1000000, '');

-- --------------------------------------------------------

--
-- Table structure for table `asset_vulnerabilities`
--

CREATE TABLE `asset_vulnerabilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `asset_id` bigint(20) UNSIGNED NOT NULL,
  `vulnerability_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_vulnerabilities`
--

INSERT INTO `asset_vulnerabilities` (`id`, `asset_id`, `vulnerability_id`) VALUES
(5, 10, 5),
(6, 10, 6),
(7, 12, 7);

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `risk_id` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'This is table name'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`timestamp`, `risk_id`, `user_id`, `message`, `log_type`) VALUES
('2023-11-12 19:32:59', 21, 1, 'القسم الجديد \"Noelle Guthrie\" و مدير القسم هو \"مدير المعمارية اﻷمنية\". تم الإنشاء بواسطة \"Admin\"', 'Creating Department '),
('2023-11-12 19:33:52', 21, 1, 'قسم بهذا الاسم \"Noelle Guthrie\" هذا مدير هذا القسم \"مدير المعمارية اﻷمنية\" إلى \"مدير المعمارية اﻷمنية\" تم التحديث بواسطة \"Admin\"', 'Updating Department'),
('2023-11-12 19:34:27', 2, 1, 'إطار عمل جديد تم إنشاؤه بالاسم \"frame1\" ووصفها هو \"sss\" تم الإنشاء بواسطة \"Admin\".', 'Creating Framework'),
('2023-11-12 19:38:09', 1, 1, 'إعداد إعلام النظام مع الرسالة \"\" تمت إضافتها بواسطة اسم المستخدم \"Admin\".', 'system_notification_Setting'),
('2023-11-12 19:38:40', 1, 1, 'ثغرة اسمها \"sdsd\" تم الإنشاء بواسطة \"Admin\".', 'vulnerability'),
('2023-11-12 19:40:24', 22, 1, 'القسم الجديد \"Dep1\" و مدير القسم هو \"مدير الرئيس التنفيذى\". تم الإنشاء بواسطة \"Admin\"', 'Creating Department '),
('2023-11-12 19:40:42', 23, 1, 'القسم الجديد \"Amaya Delgado\" و مدير القسم هو \"مدير نائب المدير العام\". تم الإنشاء بواسطة \"Admin\"', 'Creating Department '),
('2023-11-12 19:42:16', 901, 1, 'A Control that name is \"co2\" Updated to \"ewrew\" Updated By \"Admin\".', 'Updating Control'),
('2023-11-12 19:43:56', 24, 1, 'New Department \"gfchuyg\" and the manager of the department is \"Admin\". Created by \"Admin\"', 'Creating Department '),
('2023-11-12 19:44:11', 24, 1, 'A Department that name is \"gfchuyg\" changed to \"gfchuygn\" to \"Admin\" Updated By \"Admin\"', 'Updating Department'),
('2023-11-12 19:44:32', 24, 1, 'A Department that name is \"gfchuygn\" That manager of This department is \"Admin\" to \"Admin\" Updated By \"Admin\"', 'Updating Department'),
('2023-11-12 19:45:42', 902, 1, 'A Control that name is \"23456\" Updated By \"Admin\".', 'Updating Control'),
('2023-11-12 19:46:01', 3, 1, 'A New Framework Created by name \"Tests\" and the Description of it is \"rest\" Created by \"Admin\".', 'Creating Framework'),
('2023-11-12 19:46:10', 3, 1, 'A Framework that name is \"Testsee\" governance.changed to \"Testsee\" governance.to \"rest\" Updated By \"Admin\".', 'Updating Framework'),
('2023-11-12 19:46:19', 3, 1, 'A Framework that name is \"Testsee\" and the Description of it is \"rest\". Deleted By \"Admin\".', 'Deleting framework'),
('2023-11-12 19:46:53', 27, 1, 'Risk details were updated for risk ID \"1027\" Created by \"Admin\".\nField name : `owner` (``=>`Admin`)', 'risk'),
('2023-11-12 20:07:07', 21, 1, 'Asset Group Create Audit Log', 'asset_group'),
('2023-11-12 20:07:18', 21, 1, 'Asset Group Delete Audit Log', 'asset_group'),
('2023-11-12 20:19:18', 2, 1, 'A vulnerability named \"Add5\" Created by \"Admin\".', 'vulnerability'),
('2023-11-12 20:20:36', 2, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:20:41', 2, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:20:56', 3, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:21:07', 4, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:21:20', 5, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:21:36', 6, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:22:16', 25, 1, 'New Department \"aaa\" and the manager of the department is \"Admin\". Created by \"Admin\"', 'Creating Department '),
('2023-11-12 20:22:29', 25, 1, 'A Department that name is \"aaa\" That manager of This department is \"Admin\" to \"Admin\" Updated By \"Admin\"', 'Updating Department'),
('2023-11-12 20:22:39', 25, 1, 'A Department that name is \"aaa\" That manager of This department is \"Admin\" The manager Changed from \"Admin\" to \"[No Name]\" Updated By \"Admin\"', 'Updating Department'),
('2023-11-12 20:22:44', 25, 1, 'hierarchy.A Department That Name is \"aaa\"and the manager of the department is \"[No Name]\". Deleted By \"Admin\"', 'Deleting Department'),
('2023-11-12 20:23:23', 13, 1, 'A New Job created with name \"qqq\"And with description is \"ww\". Created by \"Admin\"', 'Creating Job'),
('2023-11-12 20:23:34', 13, 1, 'A Job that name is \"qqq\" That Description of it is \"ww\" And the description changed from \"ww\" to \"www\" Updated By \"Admin\".', 'Updating Job'),
('2023-11-12 20:23:38', 13, 1, 'A Job that name is \"qqq\" hierarchy.and the Description of it is \"www\". Deleted By \"Admin\".', 'Deleting Job'),
('2023-11-12 20:23:59', 7, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:24:09', 8, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:24:18', 9, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:24:29', 10, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:25:00', 1, 1, 'A New Kpi created with name \"ss\". And with description is \"dd\" and department belongs to \"gfchuygn\". Created by \"Admin\".', 'Creating kpi'),
('2023-11-12 20:25:17', 1, 1, 'A Kpi that name is \"ss\" That Description of it is \"dd\" And the description changed from \"dd\" to \"gfchuygn\" Updated By \"Admin\".', 'Updating Kpi'),
('2023-11-12 20:25:21', 1, 1, 'A Kpi that name is \"ss\" That Description of it is \"dda\" and department belongs to \"gfchuygn\" Deleted By \"Admin\".', 'Updating Kpi'),
('2023-11-12 20:25:41', 2, 1, 'A New Kpi created with name \"a\". And with description is \"sa\" and department belongs to \"gfchuygn\". Created by \"Admin\".', 'Creating kpi'),
('2023-11-12 20:26:31', 11, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:26:41', 12, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:26:49', 13, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:27:10', 4, 1, 'A New Framework Created by name \"ee\" and the Description of it is \"qq\" Created by \"Admin\".', 'Creating Framework'),
('2023-11-12 20:27:20', 4, 1, 'A Framework that name is \"eeq\" governance.changed to \"eeq\" governance.to \"qq\" Updated By \"Admin\".', 'Updating Framework'),
('2023-11-12 20:27:27', 4, 1, 'A Framework that name is \"eeq\" and the Description of it is \"qq\". Deleted By \"Admin\".', 'Deleting framework'),
('2023-11-12 20:27:51', 14, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:27:55', 14, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:28:05', 15, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:28:13', 16, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:28:18', 15, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:28:27', 17, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:28:39', 18, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:28:42', 18, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:28:52', 19, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:29:01', 20, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:30:04', 905, 1, 'A Control that name is \"zaa\" Updated to \"zaas\" Updated By \"Admin\".', 'Updating Control'),
('2023-11-12 20:30:37', 1, 1, 'A Control that name is \"zaas\". Add objective to it \"Dr. Jaycee Kertzmann\". Created by \"Admin\".', 'Creating objective'),
('2023-11-12 20:31:03', 1, 1, 'A Control with name \"zaas\". Added to Aduit \"zaa(1)\" Created by \"Admin\".', 'Creating Aduit'),
('2023-11-12 20:31:13', 31, 1, 'A New Objective created with name \"sxs\". And with description is \"mdm\". CreatedBy \"Admin\".', 'Creating ControlObjective'),
('2023-11-12 20:31:21', 31, 1, 'An Objective that name is \"sxs\" The Description Changed from \"mdm\" governance.to \"mdms\". Updated By \"Admin\".', 'Updating controlObjective'),
('2023-11-12 20:31:24', 31, 1, 'An Objective that name is \"sxs\". and the Description of it is \"mdms\". Deleted By \"Admin\".', 'Deleting controlObjective'),
('2023-11-12 20:32:15', 1, 1, 'A Control Audit Objective \"1\" locale.was \"approved\" Created by \"Admin\".', 'audit'),
('2023-11-12 20:32:32', 1, 1, 'An Audit with name \"zaas\" added comment to it \"ss\" Created by \"Admin\".', 'audit'),
('2023-11-12 20:33:03', 1, 1, 'Notify Audit Updated', 'App\\Models\\FrameworkControlTestAudit'),
('2023-11-12 20:33:32', 21, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:33:38', 904, 1, 'A Control that name is \"asd123\" Updated By \"Admin\".', 'Updating Control'),
('2023-11-12 20:33:40', 22, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:33:53', 23, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:34:04', 24, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:34:14', 25, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:34:16', 897, 1, 'A Control that name is \"ECC 1-6-4\" Updated By \"Admin\".', 'Updating Control'),
('2023-11-12 20:34:38', 1, 1, 'Notify Audit Updated', 'App\\Models\\FrameworkControlTestAudit'),
('2023-11-12 20:34:59', 1, 1, 'Notify Audit Updated', 'App\\Models\\FrameworkControlTestAudit'),
('2023-11-12 20:35:17', 1, 1, 'Notify Audit Updated', 'App\\Models\\FrameworkControlTestAudit'),
('2023-11-12 20:35:53', 28, 1, 'Risk details were updated for risk ID \"1028\" Created by \"Admin\".\nField name : `reference_id` (``=>`AA`)', 'risk'),
('2023-11-12 20:36:14', 28, 1, 'A mitigation was submitted for risk ID \"1028\" Created by \"Admin\".', 'risk'),
('2023-11-12 20:36:30', 28, 1, 'A management review was submitted for risk ID \"1028\" Created by \"Admin\".', 'risk'),
('2023-11-12 20:36:41', 28, 1, 'A risk status for subject \"sss\" was changed by the \"Admin\" user.', 'risk'),
('2023-11-12 20:36:52', 28, 1, 'A comment was added to risk ID \"1028\" Created by \"Admin\".', 'risk'),
('2023-11-12 20:36:59', 28, 1, 'A mitigation was deleted for risk ID \"1028\" Created by \"Admin', 'risk'),
('2023-11-12 20:37:04', 28, 1, 'A management review was deleted for risk ID \"1028\" Created by \"Admin\".', 'risk'),
('2023-11-12 20:37:24', 26, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:37:34', 27, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:37:43', 28, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:37:54', 29, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:38:06', 30, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:38:19', 31, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:38:29', 32, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:38:39', 33, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:38:52', 34, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:39:05', 35, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:39:16', 36, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:39:30', 1, 1, 'A New Templete of Assessment Added with name \"zzzz\" CreatedBy \"Admin\".', 'Creating assessment'),
('2023-11-12 20:39:52', 1, 1, 'A Templete of Assessment with name \"zzzzz\" Updated By \"Admin\".', 'updating assessment'),
('2023-11-12 20:39:57', 1, 1, 'A Templete of Assessment with name \"zzzzz\" Deleted By \"Admin\".', 'Deleting assessment'),
('2023-11-12 20:40:19', 1, 1, 'A New Question of Assessment Added : The question is \"how\" Created by \"Admin\".', 'Creating Questions'),
('2023-11-12 20:40:51', 1, 1, 'A questionnaire Added with name \"mxmx\" assessment.and the instruction is \"xm x\" assessment.and the assessment is \"HIPAA (April 2016)\" assessment.and the contact is \"Admin\" Created by \"Admin\".', 'Creating questionnaire'),
('2023-11-12 20:41:14', 37, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:41:20', 38, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:41:26', 39, 1, 'A system notification setting with message \"\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-12 20:41:40', 1, 1, 'assessment.A questionnaire with name \"mxmx\" Updated By \"Admin\".', 'Updating questionnaire'),
('2023-11-12 20:41:45', 1, 1, 'assessment.A questionnaire with name \"mxmx\" Deleted By \"Admin\".', 'deleting questionnaire'),
('2023-11-12 20:41:56', 1, 1, 'A questionnaire Added with name \"xx\" assessment.and the instruction is \"xx\" assessment.and the assessment is \"Critical Security Controls\" assessment.and the contact is \"مدير المخاطر\" Created by \"Admin\".', 'Creating questionnaire'),
('2023-11-12 20:42:06', 1, 1, 'assessment.A questionnaire with name \"xx\" Deleted By \"Admin\".', 'deleting questionnaire'),
('2023-11-12 20:42:40', 3, 1, 'A vulnerability named \"zxx\" Created by \"Admin\".', 'vulnerability'),
('2023-11-12 20:42:48', 3, 1, 'A vulnerability named \"zxx\" Updated By \"Admin\".', 'vulnerability'),
('2023-11-12 20:42:51', 3, 1, 'A vulnerability named \"zxx\" was deleted by username \"Admin\".', 'vulnerability'),
('2023-11-12 20:43:01', 1, 1, 'An Auto notify setting with message \"{Created_By}e{Name}\" was added by username \"Admin\".', 'AutoNOtifySetting'),
('2023-11-12 20:43:11', 1, 1, 'An Auto notify setting with message \"{Created_By}e{Name}\" was added by username \"Admin\".', 'AutoNOtifySetting'),
('2023-11-12 20:43:12', 2, 1, 'A vulnerability named \"Add5\" was deleted by username \"Admin\".', 'vulnerability'),
('2023-11-12 20:44:51', 21, 1, 'An asset name \"frf\" was added by username \"Admin\".', 'asset'),
('2023-11-12 20:45:09', 21, 1, 'An asset name \"frf\" Updated By \"Admin\".', 'asset'),
('2023-11-12 20:45:12', 21, 1, 'An asset name \"frf\" Updated By \"Admin\".', 'asset'),
('2023-11-12 20:45:26', 22, 1, 'Asset Group Create Audit Log', 'asset_group'),
('2023-11-12 20:45:38', 22, 1, 'Asset Group Delete Audit Log', 'asset_group'),
('2023-11-12 20:48:37', 1, 1, 'A New Survey Added by name \"zx\" and the Description of it is \"x\" Created by \"Admin\".', 'Creating survey'),
('2023-11-12 20:49:16', 2, 1, 'A New Survey Added by name \"zs\" and the Description of it is \"z\" Created by \"Admin\".', 'Creating survey'),
('2023-11-12 20:49:35', 11, 1, 'A New Task created with name \"xx\". And with description is \"<p>zz</p>\" Created by \"Admin\".', 'Creating Task'),
('2023-11-12 20:49:48', 1, 1, 'A Task that name is \"title 1\" changed to \"title 1z\". And the description changed from \"description 1\" to \"description 1\". Updated By \"Admin\".', 'Updating task'),
('2023-11-12 20:52:19', 42, 1, 'User \"testx\" Updated By \"Admin\".', 'Updating User'),
('2023-11-12 20:52:57', 21, 1, 'A New DepartmentColor Added with name \"xxx\" Created by \"Admin\".', 'Creating'),
('2023-11-12 20:52:58', 1, 1, 'DepartmentColor \"xxx\" Updated By \"Admin\".', 'Updating'),
('2023-11-12 20:53:00', 1, 1, 'DepartmentColor Deleted item from it Deleted By \"Admin\".', 'deleting'),
('2023-11-12 20:53:10', 128, 1, 'A New Domain Added with name \"s\" and domain parent is \"[No Parent Name]\" Created by \"Admin\".', 'Creating'),
('2023-11-12 20:53:17', 128, 1, 'Domain updated with name \"sx\" and with domain parent is \"[No Parent Name]\" Updated By \"Admin\".', 'updating'),
('2023-11-12 20:53:20', 128, 1, 'Domain with name \"sx\" and with domain parent is \"[No Parent Name]\" Deleted By \"Admin\".', 'deleting'),
('2023-11-12 20:54:07', 2, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-12 21:00:13', 1, 1, 'A vulnerability named \"sdsd\" was deleted by username \"Admin\".', 'vulnerability'),
('2023-11-12 21:04:35', 3, 1, 'A New Survey Added by name \"survey1\" and the Description of it is \"sd\" Created by \"Admin\".', 'Creating survey'),
('2023-11-12 21:05:09', 2, 1, 'User \"مدير الرئيس التنفيذى\" Updated By \"Admin\".', 'Updating User'),
('2023-11-12 21:07:43', 3, 2, 'A Survey that name is \"survey1\" The Description of it is \"sd\". Updated By \"مدير الرئيس التنفيذى\".', 'Updating survey'),
('2023-11-12 21:09:29', 3, 2, 'A Survey that name is \"survey1\" The Description of it is \"sd\". Updated By \"مدير الرئيس التنفيذى\".', 'Updating survey'),
('2023-11-12 21:09:50', 3, 2, 'A Survey that name is \"survey1\" The Description of it is \"sd\". Updated By \"مدير الرئيس التنفيذى\".', 'Updating survey'),
('2023-11-12 21:11:20', 1, 2, 'A New Email Setting ConfigCreated by \"مدير الرئيس التنفيذى\".', 'Creating Email Settings'),
('2023-11-12 21:12:02', 1, 1, 'A mail setting with subject \"aasd\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-12 21:12:34', 4, 1, 'A New Survey Added by name \"survey22\" and the Description of it is \"sd\" Created by \"Admin\".', 'Creating survey'),
('2023-11-13 04:28:27', 906, 1, 'A New Control created with name \"Roth Ewing\". The owner of control is \"مدير الرئيس التنفيذى\" and the tester is \"Department17 Employee1\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 04:28:41', 2, 1, '__(hierarchy.A Department) \"اﻹدارة العامة ﻷمن المعلومات\" __(\'hierarchy.Moved To Another Department\') \"gfchuygn by \"Admin\".', 'Moving Departement'),
('2023-11-13 07:09:42', 40, 1, 'إعداد إعلام النظام مع الرسالة \"{Name}{Privacy}\" فى الحدث \"survey_add\" تمت إضافتها بواسطة اسم المستخدم \"Admin\".', 'system_notification_Setting'),
('2023-11-13 07:11:13', 1, 1, 'إعداد الإخطار التلقائي مع الرسالة \"{Created_By}e{Name}{Reviewer}{Reviewer}{Reviewer}\" فى الحدث \"Survey_Notify_Before_Last_Review_Date\" تمت إضافتها بواسطة اسم المستخدم \"Admin\".', 'mail_Setting'),
('2023-11-13 07:12:14', 1, 1, 'إعداد الإخطار التلقائي مع الرسالة \"{Created_By}e{Name}{Reviewer}{Reviewer}{Reviewer}\" فى الحدث \"Survey_Notify_Before_Last_Review_Date\" تمت إضافتها بواسطة اسم المستخدم \"Admin\".', 'mail_Setting'),
('2023-11-13 07:12:53', 24, 1, 'قسم \"gfchuygn\" تم النقل إلى قسم آخر \"الرئيس التنفيذى\" by \"Admin\".', 'Moving Departement'),
('2023-11-13 07:12:58', 24, 1, 'قسم \"gfchuygn\" تم النقل إلى قسم آخر \"[No New Department]\" by \"Admin\".', 'Moving Departement'),
('2023-11-13 07:13:23', 23, 1, 'الموظف \"Department2 Employee1\" تم النقل إلى قسم آخر \"المكتب اﻹدارى\" by \"Admin\".', 'Moving Employee'),
('2023-11-13 10:29:30', 907, 1, 'A New Control created with name \"www\". The owner of control is \"Admin\" and the tester is \"Admin\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 10:29:47', 907, 1, 'A Control that name is \"www\" Updated to \"wwww\" Updated By \"Admin\".', 'Updating Control'),
('2023-11-13 10:30:30', 4, 1, 'A vulnerability named \"frf\" Created by \"Admin\".', 'vulnerability'),
('2023-11-13 10:30:37', 4, 1, 'A vulnerability named \"frf\" Updated By \"Admin\".', 'vulnerability'),
('2023-11-13 10:30:40', 4, 1, 'A vulnerability named \"frf\" was deleted by username \"Admin\".', 'vulnerability'),
('2023-11-13 10:37:08', 5, 1, 'A New Survey Added by name \"zz\" and the Description of it is \"z\" Created by \"Admin\".', 'Creating survey'),
('2023-11-13 10:37:45', 40, 1, 'A system notification setting with message \"{Name}{Privacy}\" in the action \"survey_add\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 10:37:59', 41, 1, 'A system notification setting with message \"{Created_By}\" in the action \"survey_update\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 10:38:11', 42, 1, 'A system notification setting with message \"{Name}\" in the action \"survey_delete\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 11:29:06', 26, 1, 'New Department \"md\" and the manager of the department is \"[No Name]\". Created by \"Admin\"', 'Creating Department '),
('2023-11-13 11:29:15', 26, 1, 'A Department that name is \"md\" changed to \"mda\" to \"[No Name]\" Updated By \"Admin\"', 'Updating Department'),
('2023-11-13 11:29:20', 26, 1, 'hierarchy.A Department That Name is \"mda\"and the manager of the department is \"[No Name]\". Deleted By \"Admin\"', 'Deleting Department'),
('2023-11-13 11:29:46', 14, 1, 'A New Job created with name \"mnz\"And with description is \"mnsd\". Created by \"Admin\"', 'Creating Job'),
('2023-11-13 11:29:53', 14, 1, 'A Job that name is \"mnz\" That Description of it is \"mnsd\" to \"mnsd\" Updated By \"Admin\".', 'Updating Job'),
('2023-11-13 11:29:57', 14, 1, 'A Job that name is \"mnz\" hierarchy.and the Description of it is \"mnsd\". Deleted By \"Admin\".', 'Deleting Job'),
('2023-11-13 11:30:24', 3, 1, 'A New Kpi created with name \"mz\". And with description is \"mnx\" and department belongs to \"gfchuygn\". Created by \"Admin\".', 'Creating kpi'),
('2023-11-13 11:30:34', 3, 1, 'A Kpi that name is \"mz\" changed to \"mza\" to \"gfchuygn\" Updated By \"Admin\".', 'Updating Kpi'),
('2023-11-13 11:30:40', 3, 1, 'A Kpi that name is \"mza\" That Description of it is \"mnx\" and department belongs to \"gfchuygn\" Deleted By \"Admin\".', 'Updating Kpi'),
('2023-11-13 11:42:59', 6, 1, 'A New Survey Added by name \"wdwdw\" and the Description of it is \"wddddddddddd\" Created by \"Admin\".', 'Creating survey'),
('2023-11-13 11:52:57', 5, 1, 'A vulnerability named \"Alana Bolton\" Created by \"Admin\".', 'vulnerability'),
('2023-11-13 12:08:14', 27, 1, 'New Department \"Maile Holt\" and the manager of the department is \"Department10 Employee1\". Created by \"Admin\"', 'Creating Department '),
('2023-11-13 12:16:12', 6, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 12:16:36', 44, 1, 'User \"Ali\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 12:19:21', 7, 1, 'A New Survey Added by name \"xaxac\" and the Description of it is \"cddddddddddddddddd\" Created by \"Admin\".', 'Creating survey'),
('2023-11-13 12:19:57', 7, 1, 'A Survey that name is \"xaxac\" The Description of it is \"cddddddddddddddddd\". Updated By \"Admin\".', 'Updating survey'),
('2023-11-13 12:20:07', 7, 1, 'A Survey with name \"xaxac\" and the Description of it is \"cddddddddddddddddd\". Deleted By \"Admin\".', 'deleting survey'),
('2023-11-13 12:21:47', 2, 1, 'User \"مدير الرئيس التنفيذى\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 12:24:37', 44, 1, 'User \"Ali\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 12:32:33', 2, 1, 'User \"مدير الرئيس التنفيذى\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 12:32:55', 2, 1, 'User \"مدير الرئيس التنفيذى\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 12:33:06', 2, 1, 'User \"مدير الرئيس التنفيذى\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 12:34:26', 908, 1, 'A New Control created with name \"sssss\". The owner of control is \"مدير الرئيس التنفيذى\" and the tester is \"Admin\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 12:35:16', 908, 1, 'A Control that name is \"sssss\" Updated By \"Admin\".', 'Updating Control'),
('2023-11-13 12:37:08', 909, 1, 'A New Control created with name \"vv\". The owner of control is \"مدير الرئيس التنفيذى\" and the tester is \"مدير اﻹدارة العامة ﻷمن المعلومات\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 12:38:54', 43, 1, 'User \"Mustafa Mohammed\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 13:30:28', 8, 1, 'A New Survey Added by name \"dwwd\" and the Description of it is \"wddddddd\" Created by \"Admin\".', 'Creating survey'),
('2023-11-13 13:31:58', 2, 1, 'A Control with name \"vv\". Added to Aduit \"vv(1)\" Created by \"Admin\".', 'Creating Aduit'),
('2023-11-13 13:32:17', 32, 1, 'A New Objective created with name \"testttt\". And with description is \"test\". CreatedBy \"Admin\".', 'Creating ControlObjective'),
('2023-11-13 13:32:28', 32, 1, 'An Objective that name is \"testttt\" changed to \"testtttt\". Which the description of it \"test\". Updated By \"Admin\".', 'Updating controlObjective'),
('2023-11-13 13:32:32', 32, 1, 'An Objective that name is \"testtttt\". and the Description of it is \"test\". Deleted By \"Admin\".', 'Deleting controlObjective'),
('2023-11-13 13:35:30', 2, 1, 'Notify Audit Updated', 'App\\Models\\FrameworkControlTestAudit'),
('2023-11-13 13:37:24', 2, 1, 'Notify Audit Updated', 'App\\Models\\FrameworkControlTestAudit'),
('2023-11-13 13:38:23', 29, 1, 'A New Risk Added with name \"azzjm\" CreatedBy \"Admin\".', 'risk'),
('2023-11-13 13:38:34', 29, 1, 'Risk details were updated for risk ID \"1029\" Created by \"Admin\".\nField name : `owner` (``=>`Admin`)', 'risk'),
('2023-11-13 13:38:43', 29, 1, 'A mitigation was submitted for risk ID \"1029\" Created by \"Admin\".', 'risk'),
('2023-11-13 13:38:52', 29, 1, 'A management review was submitted for risk ID \"1029\" Created by \"Admin\".', 'risk'),
('2023-11-13 13:39:04', 29, 1, 'A risk status for subject \"azzjm\" was changed by the \"Admin\" user.', 'risk'),
('2023-11-13 13:39:17', 29, 1, 'A comment was added to risk ID \"1029\" Created by \"Admin\".', 'risk'),
('2023-11-13 13:39:26', 29, 1, 'A mitigation was deleted for risk ID \"1029\" Created by \"Admin', 'risk'),
('2023-11-13 13:39:31', 29, 1, 'A management review was deleted for risk ID \"1029\" Created by \"Admin\".', 'risk'),
('2023-11-13 13:40:09', 43, 1, 'A system notification setting with message \"test\" in the action \"Job_Add\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 13:40:17', 44, 1, 'A system notification setting with message \"{name}\" in the action \"Job_Update\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 13:40:26', 45, 1, 'A system notification setting with message \"{name}\" in the action \"Job_Delete\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 13:41:06', 2, 1, 'A mail setting with subject \"test\" in the action \"Job_Add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:41:15', 3, 1, 'A mail setting with subject \"test\" in the action \"Job_Update\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:41:24', 4, 1, 'A mail setting with subject \"test\" in the action \"Job_Delete\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:41:50', 5, 1, 'A mail setting with subject \"test\" in the action \"Departement_Add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:42:03', 6, 1, 'A mail setting with subject \"test\" in the action \"Departement_Update\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:42:14', 7, 1, 'A mail setting with subject \"test\" in the action \"Departement_Delete\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:42:26', 8, 1, 'A mail setting with subject \"test\" in the action \"Departement_Moving\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:42:44', 9, 1, 'A mail setting with subject \"test\" in the action \"Departement_Moving_Employee\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:43:04', 10, 1, 'A mail setting with subject \"test\" in the action \"Kpi_Add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:43:18', 11, 1, 'A mail setting with subject \"test\" in the action \"Kpi_Update\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:43:31', 12, 1, 'A mail setting with subject \"test\" in the action \"Kpi_Delete\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:43:42', 13, 1, 'A mail setting with subject \"test\" in the action \"initiate_Assessment\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 13:44:21', 6, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 13:44:49', 44, 1, 'User \"Ali\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 13:47:43', 2, 44, 'A Department \"اﻹدارة العامة ﻷمن المعلومات\" Moved To Another Department \"الرئيس التنفيذى\" by \"Ali\".', 'Moving Departement'),
('2023-11-13 14:25:19', 6, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 14:26:22', 6, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 14:38:53', 6, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 14:40:05', 6, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 14:40:42', 46, 1, 'A system notification setting with message \"{Name}\" in the action \"Assessment_Add\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:40:50', 47, 1, 'A system notification setting with message \"{Name}\" in the action \"Assessment_Update\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:40:57', 48, 1, 'A system notification setting with message \"{Name}\" in the action \"Assessment_Delete\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:41:05', 49, 1, 'A system notification setting with message \"{Question}\" in the action \"Question_Add\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:41:19', 50, 1, 'A system notification setting with message \"{Question}\" in the action \"Question_Update\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:41:23', 49, 1, 'A system notification setting with message \"{Question}\" in the action \"Question_Add\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:41:35', 51, 1, 'A system notification setting with message \"{Question}\" in the action \"Question_Delete\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:41:54', 14, 1, 'A mail setting with subject \"test\" in the action \"Assessment_Add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:42:08', 15, 1, 'A mail setting with subject \"test\" in the action \"Assessment_Update\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:42:19', 16, 1, 'A mail setting with subject \"test\" in the action \"Assessment_Delete\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:42:30', 17, 1, 'A mail setting with subject \"test\" in the action \"Question_Add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:42:38', 18, 1, 'A mail setting with subject \"test\" in the action \"Question_Update\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:42:48', 19, 1, 'A mail setting with subject \"test\" in the action \"Question_Delete\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:43:05', 1, 1, 'A New Templete of Assessment Added with name \"test\" CreatedBy \"Admin\".', 'Creating assessment'),
('2023-11-13 14:43:18', 1, 1, 'A Templete of Assessment with name \"test\" Updated By \"Admin\".', 'updating assessment'),
('2023-11-13 14:43:22', 1, 1, 'A Templete of Assessment with name \"test\" Deleted By \"Admin\".', 'Deleting assessment'),
('2023-11-13 14:45:04', 910, 1, 'A New Control created with name \"testing\". The owner of control is \"مدير الرئيس التنفيذى\" and the tester is \"Ali\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 14:46:19', 2, 1, 'A Control that name is \"testing\". Add objective to it \"Gladyce Johnson\". Created by \"Admin\".', 'Creating objective'),
('2023-11-13 14:49:28', 1, 1, 'A New Question of Assessment Added : The question is \"wfat\" Created by \"Admin\".', 'Creating Questions'),
('2023-11-13 14:52:36', 1, 1, 'A questionnaire Added with name \"cm\" assessment.and the instruction is \"mxx\" assessment.and the assessment is \"NIST 800-171\" assessment.and the contact is \"Ali\" Created by \"Admin\".', 'Creating questionnaire'),
('2023-11-13 14:52:58', 1, 44, 'assessment.A questionnaire with name \"cmx\" Updated By \"Ali\".', 'Updating questionnaire'),
('2023-11-13 14:53:19', 1, 44, 'assessment.A questionnaire with name \"cmx\" Updated By \"Ali\".', 'Updating questionnaire'),
('2023-11-13 14:53:54', 1, 44, 'assessment.A questionnaire with name \"cmx\" Updated By \"Ali\".', 'Updating questionnaire'),
('2023-11-13 14:54:19', 1, 44, 'assessment.A questionnaire with name \"cmx\" Updated By \"Ali\".', 'Updating questionnaire'),
('2023-11-13 14:55:11', 1, 44, 'assessment.A questionnaire with name \"cmx\" Updated By \"Ali\".', 'Updating questionnaire'),
('2023-11-13 14:55:12', 1, 44, 'assessment.A questionnaire with name \"cmx\" Updated By \"Ali\".', 'Updating questionnaire'),
('2023-11-13 14:55:18', 1, 44, 'assessment.A questionnaire with name \"cmx\" Updated By \"Ali\".', 'Updating questionnaire'),
('2023-11-13 14:55:46', 1, 1, 'A system notification setting with message \"asd {name}{name}\" in the action \"vulnerability_add\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:55:58', 52, 1, 'A system notification setting with message \"{severity}\" in the action \"vulnerability_update\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:56:09', 53, 1, 'A system notification setting with message \"{name}\" in the action \"vulnerability_delete\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:56:10', 54, 1, 'A system notification setting with message \"{name}\" in the action \"vulnerability_delete\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 14:56:30', 20, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:56:30', 21, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:56:30', 22, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:56:30', 23, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:56:31', 24, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 14:56:31', 25, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 15:01:14', 26, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_update\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 15:01:24', 27, 1, 'A mail setting with subject \"test\" in the action \"vulnerability_delete\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 15:01:58', 6, 1, 'A vulnerability named \"test\" Created by \"Admin\".', 'vulnerability'),
('2023-11-13 15:02:57', 22, 1, 'An asset name \"test\" was added by username \"Admin\".', 'asset'),
('2023-11-13 15:03:31', 6, 1, 'A vulnerability named \"testw\" Updated By \"Admin\".', 'vulnerability'),
('2023-11-13 15:03:58', 2, 2, 'User \"مدير الرئيس التنفيذى\" Updated By \"مدير الرئيس التنفيذى\".', 'Updating User'),
('2023-11-13 15:06:05', 2, 2, 'User \"مدير الرئيس التنفيذى\" Updated By \"مدير الرئيس التنفيذى\".', 'Updating User'),
('2023-11-13 15:09:04', 6, 1, 'A vulnerability named \"testw\" Updated By \"Admin\".', 'vulnerability'),
('2023-11-13 15:12:37', 22, 1, 'An asset name \"test\" Updated By \"Admin\".', 'asset'),
('2023-11-13 15:12:59', 55, 1, 'A system notification setting with message \"{Name}\" in the action \"Asset_Add\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 15:13:07', 56, 1, 'A system notification setting with message \"{Asset_Value_Max}\" in the action \"Asset_Update\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 15:13:18', 57, 1, 'A system notification setting with message \"{Start_Date}\" in the action \"Asset_Delete\" was added by username \"Admin\".', 'system_notification_Setting'),
('2023-11-13 15:13:37', 28, 1, 'A mail setting with subject \"test\" in the action \"Asset_Add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 15:13:47', 29, 1, 'A mail setting with subject \"test\" in the action \"Asset_Update\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 15:13:59', 30, 1, 'A mail setting with subject \"test\" in the action \"Asset_Delete\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 15:14:20', 22, 1, 'An asset name \"testt\" Updated By \"Admin\".', 'asset'),
('2023-11-13 15:30:14', 58, 44, 'A system notification setting with message \"{Name}\" in the action \"Cateogry_Add\" was added by username \"Ali\".', 'system_notification_Setting'),
('2023-11-13 15:40:11', 59, 44, 'A system notification setting with message \"{Name}\" in the action \"Cateogry_Update\" was added by username \"Ali\".', 'system_notification_Setting'),
('2023-11-13 15:40:40', 60, 44, 'A system notification setting with message \"{Name}\" in the action \"Cateogry_Delete\" was added by username \"Ali\".', 'system_notification_Setting'),
('2023-11-13 15:41:02', 61, 44, 'A system notification setting with message \"{Teams}\" in the action \"Document_Add\" was added by username \"Ali\".', 'system_notification_Setting'),
('2023-11-13 15:41:20', 62, 44, 'A system notification setting with message \"{Next_Review_Date}\" in the action \"Document_Update\" was added by username \"Ali\".', 'system_notification_Setting'),
('2023-11-13 15:44:17', 23, 1, 'User \"Department2 Employee1\" تم التحديث بواسطة \"Admin\".', 'Updating User'),
('2023-11-13 16:18:22', 911, 1, 'تم إنشاء عنصر تحكم جديد بالاسم \"con5\". مالك التحكم هو \"Admin\" والمختبر هو \"Admin\" تم الإنشاء بواسطة \"Admin\".', 'Creating Control'),
('2023-11-13 16:22:10', 4, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 16:22:54', 5, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 16:24:05', 45, 1, 'User \"Mohamed Elsayed\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 16:24:48', 45, 1, 'User \"Mohamed Elsayed5\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 16:26:08', 912, 1, 'A New Control created with name \"con787\". The owner of control is \"Admin\" and the tester is \"Mohamed Elsayed5\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 16:27:23', 45, 1, 'User \"Mohamed Elsayed5\" Updated By \"Admin\".', 'Updating User'),
('2023-11-13 16:29:16', 3, 1, 'A Control with name \"con787\". Added to Aduit \"con787(1)\" Created by \"Admin\".', 'Creating Aduit'),
('2023-11-13 16:33:58', 6, 1, 'A Role Of Employee have updated by \"Admin\".', 'Updating'),
('2023-11-13 16:36:08', 913, 1, 'A New Control created with name \"hjwjw\". The owner of control is \"مدير الرئيس التنفيذى\" and the tester is \"مدير اﻹدارة العامة ﻷمن المعلومات\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 16:37:46', 6, 1, 'A New Security Awareness Added by name \"jkassx\" and the Description of it is \"sd\". Created by \"Admin\".', 'Creating securityAwareness'),
('2023-11-13 17:12:26', 914, 1, 'A New Control created with name \"Kyra Mcmillan\". The owner of control is \"مدير المعمارية اﻷمنية\" and the tester is \"Department1 Employee1\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 17:49:55', 7, 1, 'A vulnerability named \"test\" Created by \"Admin\".', 'vulnerability'),
('2023-11-13 17:52:59', 7, 1, 'A vulnerability named \"testz\" Updated By \"Admin\".', 'vulnerability'),
('2023-11-13 17:53:13', 7, 1, 'A vulnerability named \"testz\" Updated By \"Admin\".', 'vulnerability'),
('2023-11-13 18:48:03', 915, 1, 'A New Control created with name \"Control 5523\". The owner of control is \"Admin\" and the tester is \"Mohamed Elsayed5\" Created by \"Admin\".', 'Creating Control'),
('2023-11-13 18:49:10', 3, 45, 'Notify Audit Updated', 'App\\Models\\FrameworkControlTestAudit'),
('2023-11-13 18:49:37', 30, 1, 'A New Risk Added with name \"Facere odit ullamco\" CreatedBy \"Admin\".', 'risk'),
('2023-11-13 18:51:13', 31, 1, 'A New Risk Added with name \"Risk663\" CreatedBy \"Admin\".', 'risk'),
('2023-11-13 18:53:07', 31, 1, 'A mail setting with subject \"sd\" in the action \"Control_Add\" was added by username \"Admin\".', 'mail_Setting'),
('2023-11-13 18:56:00', 9, 1, 'A New Survey Added by name \"survey33\" and the Description of it is \"sdd\" Created by \"Admin\".', 'Creating survey');

-- --------------------------------------------------------

--
-- Table structure for table `auto_notifies`
--

CREATE TABLE `auto_notifies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `auto_notifies`
--

INSERT INTO `auto_notifies` (`id`, `action_id`, `message`, `date`, `status`, `created_at`, `updated_at`) VALUES
(1, 70, '{Created_By}e{Name}{Reviewer}{Reviewer}{Reviewer}', '[\"1\"]', 1, '2023-11-12 20:43:01', '2023-11-13 07:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `awareness_surveys`
--

CREATE TABLE `awareness_surveys` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_stakeholder` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `team` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_review_date` date DEFAULT NULL,
  `review_frequency` int(11) DEFAULT NULL,
  `next_review_date` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `privacy` bigint(20) UNSIGNED NOT NULL,
  `filter_status` bigint(20) UNSIGNED NOT NULL,
  `approval_date` date DEFAULT NULL,
  `reviewer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `all_questions_mandatory` tinyint(1) DEFAULT NULL,
  `answer_percentage` tinyint(1) DEFAULT NULL,
  `percentage_number` tinyint(4) DEFAULT NULL,
  `specific_mandatory_questions` tinyint(1) DEFAULT NULL,
  `questions` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `awareness_surveys`
--

INSERT INTO `awareness_surveys` (`id`, `name`, `additional_stakeholder`, `owner_id`, `team`, `last_review_date`, `review_frequency`, `next_review_date`, `description`, `privacy`, `filter_status`, `approval_date`, `reviewer`, `all_questions_mandatory`, `answer_percentage`, `percentage_number`, `specific_mandatory_questions`, `questions`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'zx', '3', 2, '2', '2023-11-21', 1, '2023-11-22', 'x', 1, 1, NULL, '', 0, NULL, NULL, NULL, '', 1, '2023-11-12 20:48:37', '2023-11-12 20:48:37'),
(2, 'zs', '2', 3, '3', '2023-11-14', 1, '2023-11-15', 'z', 1, 3, '2023-11-27', '', 0, NULL, NULL, NULL, '', 1, '2023-11-12 20:49:16', '2023-11-12 20:49:16'),
(3, 'survey1', '43', 2, '3', '2023-11-13', 3, '2023-11-16', 'sd', 2, 3, '2023-11-13', '', 0, NULL, NULL, NULL, '', 1, '2023-11-12 21:04:35', '2023-11-12 21:09:50'),
(4, 'survey22', '2', 43, '4', '2023-11-12', 3, '2023-11-15', 'sd', 1, 1, NULL, '', 0, NULL, NULL, NULL, '', 1, '2023-11-12 21:12:32', '2023-11-12 21:12:32'),
(5, 'zz', '44', 2, '1', '2023-11-14', 1, '2023-11-15', 'z', 1, 3, '2023-11-28', '', 0, NULL, NULL, NULL, '', 1, '2023-11-13 10:37:07', '2023-11-13 10:37:07'),
(6, 'wdwdw', '2', 1, '1', '2023-11-13', 0, '2023-11-13', 'wddddddddddd', 1, 1, NULL, '', 0, NULL, NULL, NULL, '', 1, '2023-11-13 11:42:57', '2023-11-13 11:42:57'),
(8, 'dwwd', '2', 2, '1', '2023-11-13', 0, '2023-11-13', 'wddddddd', 1, 1, NULL, '', 0, NULL, NULL, NULL, '', 1, '2023-11-13 13:30:28', '2023-11-13 13:30:28'),
(9, 'survey33', '2', 1, '2', '2023-11-14', 2, '2023-11-16', 'sdd', 2, 3, '2023-11-15', '', 0, NULL, NULL, NULL, '', 1, '2023-11-13 18:55:59', '2023-11-13 18:55:59');

-- --------------------------------------------------------

--
-- Table structure for table `backups`
--

CREATE TABLE `backups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `random_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `app_zip_file_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `db_zip_file_name` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Gestión de Acceso'),
(2, 'La Resistencia Ambiental'),
(3, 'Vigilancia'),
(4, 'Seguridad Física'),
(5, 'Politica y Procedimiento'),
(6, 'Gestión de datos sensibles'),
(7, 'Gestión de Tecnica de Vulnerabilidades'),
(8, 'Gestión de Terceros');

-- --------------------------------------------------------

--
-- Table structure for table `change_requests`
--

CREATE TABLE `change_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_file_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unique_file_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Department-Manager-In-Review','Department-Manager-Rejected','Responsible-Department-In-Review','Responsible-Department-Accepted','Responsible-Department-Rejected') COLLATE utf8mb4_unicode_ci NOT NULL,
  `review_cycle` enum('Department-Manager-Review','Responsible-Department-Review') COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_review_cycle` enum('Department-Manager-Review','Responsible-Department-Review') COLLATE utf8mb4_unicode_ci NOT NULL,
  `rejection_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `close_reasons`
--

CREATE TABLE `close_reasons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `close_reasons`
--

INSERT INTO `close_reasons` (`id`, `name`) VALUES
(1, 'Rejected'),
(2, 'Fully Mitigated'),
(3, 'System Retired'),
(4, 'Cancelled'),
(5, 'Too Insignificant');

-- --------------------------------------------------------

--
-- Table structure for table `closures`
--

CREATE TABLE `closures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `closure_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `close_reason` int(11) DEFAULT NULL,
  `note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `closures`
--

INSERT INTO `closures` (`id`, `risk_id`, `user_id`, `closure_date`, `close_reason`, `note`) VALUES
(1, 17, 1, '2023-11-12 19:29:07', 3, 'asd'),
(2, 6, 1, '2023-11-12 19:29:07', 1, 'asd'),
(3, 20, 1, '2023-11-12 19:29:07', 4, 'asd'),
(4, 19, 1, '2023-11-12 19:29:07', 4, 'asd'),
(5, 4, 1, '2023-11-12 19:29:07', 1, 'asd'),
(6, 9, 1, '2023-11-12 19:29:07', 1, 'asd'),
(7, 7, 1, '2023-11-12 19:29:07', 2, 'asd'),
(8, 11, 1, '2023-11-12 19:29:07', 2, 'asd'),
(9, 18, 1, '2023-11-12 19:29:07', 4, 'asd'),
(10, 16, 1, '2023-11-12 19:29:07', 3, 'asd'),
(11, 2, 1, '2023-11-12 19:29:07', 1, 'asd'),
(12, 3, 1, '2023-11-12 19:29:07', 4, 'asd'),
(13, 10, 1, '2023-11-12 19:29:07', 3, 'asd'),
(14, 1, 1, '2023-11-12 19:29:07', 5, 'asd'),
(15, 5, 1, '2023-11-12 19:29:07', 2, 'asd'),
(16, 13, 1, '2023-11-12 19:29:07', 5, 'asd'),
(17, 15, 1, '2023-11-12 19:29:07', 1, 'asd'),
(18, 12, 1, '2023-11-12 19:29:07', 3, 'asd'),
(19, 8, 1, '2023-11-12 19:29:07', 2, 'asd'),
(20, 14, 1, '2023-11-12 19:29:07', 3, 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `risk_id`, `date`, `user`, `comment`) VALUES
(1, 28, '2023-11-12 20:36:52', 1, 'kjdckjkdklkxd'),
(2, 29, '2023-11-13 13:39:17', 1, 'xn x');

-- --------------------------------------------------------

--
-- Table structure for table `compliance_files`
--

CREATE TABLE `compliance_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ref_id` int(11) NOT NULL,
  `ref_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL,
  `content` longblob NOT NULL,
  `version` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_questionnaires`
--

CREATE TABLE `contact_questionnaires` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `questionnaire_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_questionnaires`
--

INSERT INTO `contact_questionnaires` (`id`, `user_id`, `questionnaire_id`, `created_at`, `updated_at`) VALUES
(3, 44, 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_questionnaire_answers`
--

CREATE TABLE `contact_questionnaire_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `asset_id` bigint(20) UNSIGNED DEFAULT NULL,
  `percentage_complete` int(11) NOT NULL DEFAULT 0,
  `approved_status` enum('yes','no') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('incomplete','complete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'incomplete',
  `submission_type` enum('draft','complete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `contact_id` bigint(20) UNSIGNED NOT NULL,
  `questionnaire_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_questionnaire_answer_results`
--

CREATE TABLE `contact_questionnaire_answer_results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contact_questionnaire_answer_id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `answer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `answer_type` enum('1','2','3') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1:single select 2:multiple select 3:fill in the blank',
  `answer` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contributing_risks`
--

CREATE TABLE `contributing_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contributing_risks`
--

INSERT INTO `contributing_risks` (`id`, `subject`, `weight`) VALUES
(1, 'Safety', 0.25),
(2, 'SLA', 0.25),
(3, 'Financial', 0.25),
(4, 'Reputation', 0.25);

-- --------------------------------------------------------

--
-- Table structure for table `contributing_risks_impacts`
--

CREATE TABLE `contributing_risks_impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contributing_risks_id` bigint(20) UNSIGNED NOT NULL,
  `value` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contributing_risks_impacts`
--

INSERT INTO `contributing_risks_impacts` (`id`, `contributing_risks_id`, `value`, `name`) VALUES
(1, 1, 1, 'Insignificante'),
(2, 2, 1, 'Insignificante'),
(3, 3, 1, 'Insignificante'),
(4, 4, 1, 'Insignificante'),
(5, 1, 2, 'Menor'),
(6, 2, 2, 'Menor'),
(7, 3, 2, 'Menor'),
(8, 4, 2, 'Menor'),
(9, 1, 3, 'Moderado'),
(10, 2, 3, 'Moderado'),
(11, 3, 3, 'Moderado'),
(12, 4, 3, 'Moderado'),
(13, 1, 4, 'Mayor'),
(14, 2, 4, 'Mayor'),
(15, 3, 4, 'Mayor'),
(16, 4, 4, 'Mayor'),
(17, 1, 5, 'Extremo/Catastrofico'),
(18, 2, 5, 'Extremo/Catastrofico'),
(19, 3, 5, 'Extremo/Catastrofico'),
(20, 4, 5, 'Extremo/Catastrofico');

-- --------------------------------------------------------

--
-- Table structure for table `contributing_risks_likelihoods`
--

CREATE TABLE `contributing_risks_likelihoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `controls_control_objectives`
--

CREATE TABLE `controls_control_objectives` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `control_id` bigint(20) UNSIGNED NOT NULL,
  `objective_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `responsible_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsible_id` bigint(20) UNSIGNED DEFAULT NULL,
  `responsible_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `due_date` date NOT NULL DEFAULT '2023-11-12'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `controls_control_objectives`
--

INSERT INTO `controls_control_objectives` (`id`, `control_id`, `objective_id`, `created_at`, `updated_at`, `responsible_type`, `responsible_id`, `responsible_team_id`, `due_date`) VALUES
(1, 905, 1, '2023-11-12 20:30:37', '2023-11-12 20:30:37', 'user', 22, NULL, '2023-11-28'),
(2, 910, 10, '2023-11-13 14:46:19', '2023-11-13 14:46:19', 'user', 44, NULL, '2023-11-14');

-- --------------------------------------------------------

--
-- Table structure for table `control_audits_evidences`
--

CREATE TABLE `control_audits_evidences` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `evidence_id` bigint(20) UNSIGNED NOT NULL,
  `framework_control_test_audit_id` bigint(20) UNSIGNED NOT NULL,
  `evidence_audit_status` enum('no_action','approved','rejected','not_relevant') COLLATE utf8mb4_unicode_ci DEFAULT 'no_action',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `control_audits_objectives`
--

CREATE TABLE `control_audits_objectives` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `control_control_objective_id` bigint(20) UNSIGNED NOT NULL,
  `framework_control_test_audit_id` bigint(20) UNSIGNED NOT NULL,
  `objective_audit_status` enum('no_action','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_action',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_audits_objectives`
--

INSERT INTO `control_audits_objectives` (`id`, `control_control_objective_id`, `framework_control_test_audit_id`, `objective_audit_status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'approved', '2023-11-12 20:31:03', '2023-11-12 20:32:15');

-- --------------------------------------------------------

--
-- Table structure for table `control_audit_policies`
--

CREATE TABLE `control_audit_policies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `document_id` bigint(20) UNSIGNED NOT NULL,
  `framework_control_test_audit_id` bigint(20) UNSIGNED NOT NULL,
  `document_audit_status` enum('no_action','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_action'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `control_classes`
--

CREATE TABLE `control_classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_classes`
--

INSERT INTO `control_classes` (`id`, `name`) VALUES
(1, 'Technical'),
(2, 'Operational'),
(3, 'Management');

-- --------------------------------------------------------

--
-- Table structure for table `control_desired_maturities`
--

CREATE TABLE `control_desired_maturities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_desired_maturities`
--

INSERT INTO `control_desired_maturities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Not Performed', '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(2, 'Performed', '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(3, 'Documented', '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(4, 'Managed', '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(5, 'Reviewed', '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(6, 'Optimizing', '2023-11-12 19:29:02', '2023-11-12 19:29:02');

-- --------------------------------------------------------

--
-- Table structure for table `control_maturities`
--

CREATE TABLE `control_maturities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_maturities`
--

INSERT INTO `control_maturities` (`id`, `name`) VALUES
(1, 'Not Performed'),
(2, 'Performed'),
(3, 'Documented'),
(4, 'Managed'),
(5, 'Reviewed'),
(6, 'Optimizing');

-- --------------------------------------------------------

--
-- Table structure for table `control_objectives`
--

CREATE TABLE `control_objectives` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_objectives`
--

INSERT INTO `control_objectives` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Dr. Jaycee Kertzmann', 'Totam enim odit voluptatem quis nihil et. Nisi assumenda id tempore rerum. Perferendis modi sit eos laudantium ut recusandae. Qui ipsa consectetur eos omnis et ut et facere. Omnis nam error voluptate fugiat et deserunt nostrum. Autem laudantium et officia', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(2, 'Jessyca Carroll', 'Fugit qui voluptate asperiores aut delectus. Aliquam quo illo vero perferendis. Illo nihil ipsa voluptate qui aut cum. Nam nisi reprehenderit qui molestiae voluptates et. Optio aliquid aut soluta tempora in. Voluptatum ut suscipit assumenda culpa necessit', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(3, 'Angeline Larkin DDS', 'Excepturi ut ab repudiandae ut. Excepturi illo voluptatem rerum. Tenetur consequatur culpa illum facere dolorem facilis accusantium. Temporibus et illo sequi maiores amet voluptatibus voluptates. A voluptatem eos molestiae soluta. Et qui amet commodi at. ', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(4, 'Neva Windler', 'Voluptatem iure delectus corporis quasi. Tenetur blanditiis id rerum laudantium earum voluptatem. Voluptatibus iure dolor est illum. Consequatur necessitatibus nam est est excepturi. Tempora omnis animi ad esse facere explicabo. Necessitatibus quidem repe', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(5, 'Dr. Jerome Fay MD', 'Vel pariatur repellendus consequatur cumque saepe. Voluptas nobis autem atque voluptatem excepturi fuga dicta. Cumque animi natus est molestias iste unde itaque. Tenetur fuga velit quisquam nam earum recusandae adipisci. Vero praesentium enim deleniti qui', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(6, 'Chance Simonis', 'Non corrupti et iusto autem voluptas nesciunt incidunt. Saepe perspiciatis commodi ad animi. Quis ut quos voluptatem est ut. Exercitationem alias mollitia earum esse repellat. Quam eum minus vel sunt quidem. Aut dignissimos architecto qui sed totam. Illo ', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(7, 'Wilhelmine Orn', 'Dolores ut quia sit debitis ad vitae blanditiis. Dolores deserunt molestias dolorem ducimus omnis omnis. Culpa sit dolor odio aut ut. Molestias maxime fugiat et dolor consectetur velit excepturi sint. Laudantium error veniam voluptatum quas delectus. Inci', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(8, 'Bernice Wolff', 'Libero ullam temporibus autem in consequatur. Qui accusantium quod occaecati eos et. Vel sed quod consequuntur est non quisquam quae. Voluptatibus veritatis perspiciatis deserunt unde quidem exercitationem. Quis quod iure dolores et ea quia in eveniet. En', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(9, 'Mr. Laurel Murazik', 'Laboriosam nisi et omnis quidem rerum et vel. Numquam nobis velit aliquam quis. In aut ipsam error voluptatem natus qui. Ut dignissimos eligendi nesciunt mollitia qui vitae incidunt. Molestias assumenda veritatis non aliquam est molestias. In molestiae vo', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(10, 'Gladyce Johnson', 'Qui et sit laudantium et et. Nesciunt et enim autem dolores labore sunt. Nam et et deleniti voluptatem sunt. Quo sed sit sed quis. Aliquam voluptatem in odit fugit. Aut consequuntur doloribus laudantium nemo quia dolores. Consectetur architecto autem veri', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(11, 'Giovanna Fritsch', 'Hic distinctio recusandae eius ut mollitia. Provident odit ab velit corporis. Consequuntur illum et aut qui dolore impedit. Illo quia perspiciatis magni. Deleniti corporis a a assumenda. Est atque ea dolor quisquam. Voluptatem iure consectetur qui dolore ', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(12, 'Mr. Milo Schmitt', 'Voluptas debitis dolores nobis. Itaque illum et quis necessitatibus nihil eaque aut rem. Quo qui atque nihil nisi eos. Nobis adipisci dolores esse et eius. Sint repellendus qui illo. Dolorem ipsam neque repellendus accusantium. Nihil officia excepturi vol', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(13, 'Mr. Torrance Rath', 'Ad nam quas est et. Expedita explicabo cum nisi sit. Consequatur inventore aut et eos porro dolorem. Tempore accusamus quod beatae ipsam delectus iure. Eum architecto et ut quis deserunt dolores. Temporibus aspernatur natus quo rerum voluptas. Cum non occ', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(14, 'Savion Connelly', 'At autem et atque molestiae facere. Sint est est impedit optio quia quia consequuntur. Consectetur quis praesentium repudiandae quo culpa architecto consequatur incidunt. Explicabo saepe voluptatem sunt dolorem. Iusto doloremque officiis nisi nam. Nemo il', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(15, 'Mr. Louie O\'Kon', 'Neque eaque id reiciendis vitae. Omnis consequuntur voluptates in aut animi id qui. Modi impedit iusto est sit distinctio. Assumenda perspiciatis non est autem architecto vitae dicta. Ut vel omnis beatae harum. Nemo sed officiis sit tempore fuga illo dign', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(16, 'Cayla Gulgowski', 'At facere fugit voluptatem velit accusantium magnam illo. Ea et dolores voluptatem. Molestiae commodi et ut sint. Facere esse delectus enim omnis. Ducimus sit et est eos nesciunt. Non omnis facilis ipsa cupiditate rerum. Est sit ea omnis et et sequi solut', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(17, 'Nickolas Von', 'Inventore modi culpa adipisci rerum. Sit ipsa dolorum sed aut quo unde quis omnis. Non voluptas qui consequatur autem tempore. Maxime omnis quidem aut dolor. Suscipit molestiae nam esse ab sunt omnis voluptatum. Quia sunt delectus ea dolores. Nisi expedit', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(18, 'Alexandro Zboncak', 'Rem nulla quos et possimus ut. Qui vitae deserunt tempora sit. Repellat libero cumque numquam eius. Perferendis nam velit ut incidunt ullam quia. Illo iste tempora tempora sed nisi. Saepe delectus fugit quisquam culpa commodi quod harum. Ab in similique d', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(19, 'Mrs. Assunta Kuphal', 'Et qui nostrum non atque debitis. Neque qui ea earum cupiditate repellendus. Et repudiandae autem corrupti. Ullam saepe molestias eos laudantium fugiat laboriosam. Dolorem ut aut repudiandae excepturi qui. Et qui ab id repellat nobis nobis reprehenderit. ', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(20, 'Mateo Harvey', 'Suscipit dolor repellat praesentium ea perspiciatis architecto. Illum voluptatem perferendis pariatur aliquid facilis iure eius. Dolorem nostrum unde consequuntur. Porro nemo nihil dolorum enim id. Vitae occaecati aut est voluptatem corporis ratione non. ', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(21, 'Prof. Elise Schoen', 'Est molestiae quam accusantium quidem consectetur. Maiores qui dignissimos ad inventore ipsam. Numquam beatae et soluta omnis id eum quia. Minima quisquam aut provident fuga. Aut et modi iure dolorem. Vel aut quis quia qui magnam beatae. Dolore odio magna', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(22, 'Taylor Schowalter IV', 'Qui beatae qui voluptas fugit quo quo tenetur. Vel ea beatae sunt cupiditate. Laudantium et voluptas et nostrum voluptates et. At quam esse explicabo sed doloremque dolorem. Modi vero et nisi sunt. Libero corporis libero sapiente cumque accusantium ex. No', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(23, 'Gene Kemmer V', 'Facere dolorem architecto labore quasi velit cum corrupti. Sequi sed dolorum harum officia ipsum explicabo. Autem veritatis ut reiciendis. Velit quam hic nihil. Magnam numquam voluptatem dolore sapiente sint. Et voluptatibus id officiis ducimus cumque. Re', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(24, 'Chester Towne DDS', 'Assumenda omnis placeat rerum quis odit. Vel voluptates unde dolores reiciendis nostrum tempora. Consequatur autem aut quo quas qui. Sint aut aut est et distinctio magnam. Voluptas aperiam est officiis nobis maxime. Sit sed odio quidem distinctio. Aut eos', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(25, 'Judy Pacocha', 'Aut nisi omnis mollitia ut. Occaecati maxime aut saepe minus cumque nihil. Id consequatur sit ea consequatur doloremque cupiditate consectetur ipsum. Beatae nesciunt quas dolores inventore non repudiandae nostrum. Eum optio eius quasi unde. Earum nobis id', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(26, 'Deangelo Davis', 'Sint qui consectetur deserunt. Dolorum doloremque deleniti nam repudiandae rerum atque. Suscipit et et eaque dolorem aut et labore. Sed libero quasi sit non alias consequatur deserunt occaecati. Voluptas et earum ullam quos sint dolores. Voluptas et quas ', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(27, 'Dr. Deangelo Berge', 'Repellendus natus facilis voluptas et rem et voluptates. Deleniti tenetur ut vero eius. Eligendi animi soluta possimus laudantium repellat aut. Id consequatur placeat quam a error repellat possimus. Voluptatem pariatur suscipit aut. Voluptatem ex ipsa nis', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(28, 'Francisco Reichel', 'Debitis earum quaerat consequatur impedit porro. Voluptatem saepe cumque aut saepe deleniti laborum et dolorem. Temporibus ea occaecati consectetur porro. Corrupti qui et sed. Id numquam modi vel quia aut omnis. Minima consectetur sunt consectetur eveniet', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(29, 'Dr. Mavis Huels', 'Assumenda rerum consequatur eum voluptates. Ducimus commodi aliquid aliquid. Delectus blanditiis occaecati repellat veritatis doloribus corrupti ex. Sequi sed et eum ut aut. Ipsa voluptatem officiis ab aliquam sit. Autem numquam et possimus nam. Earum rer', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(30, 'Prof. Morris Hahn', 'Earum qui commodi esse itaque itaque. Qui maxime mollitia vitae. Sed est rem nam aperiam tenetur totam. Qui sapiente magni culpa est harum suscipit. Eum quia corporis porro culpa quia laudantium dignissimos. Repellendus fuga neque sint perferendis. Et aut', '2023-11-12 19:29:08', '2023-11-12 19:29:08');

-- --------------------------------------------------------

--
-- Table structure for table `control_owners`
--

CREATE TABLE `control_owners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_owners`
--

INSERT INTO `control_owners` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'doloremque', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(2, 'est', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(3, 'pariatur', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(4, 'aut', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(5, 'et', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(6, 'dicta', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(7, 'eum', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(8, 'enim', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(9, 'repellat', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(10, 'tenetur', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(11, 'omnis', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(12, 'dolor', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(13, 'architecto', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(14, 'sint', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(15, 'labore', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(16, 'distinctio', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(17, 'ut', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(18, 'vitae', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(19, 'maxime', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(20, 'officia', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(21, 'magni', '2023-11-12 19:29:07', '2023-11-12 19:29:07');

-- --------------------------------------------------------

--
-- Table structure for table `control_phases`
--

CREATE TABLE `control_phases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_phases`
--

INSERT INTO `control_phases` (`id`, `name`) VALUES
(1, 'Physical'),
(2, 'Procedural'),
(3, 'Technical'),
(4, 'Legal and Regulatory or Compliance');

-- --------------------------------------------------------

--
-- Table structure for table `control_priorities`
--

CREATE TABLE `control_priorities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_priorities`
--

INSERT INTO `control_priorities` (`id`, `name`) VALUES
(1, 'P0'),
(2, 'P1'),
(3, 'P2'),
(4, 'P3');

-- --------------------------------------------------------

--
-- Table structure for table `control_types`
--

CREATE TABLE `control_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_types`
--

INSERT INTO `control_types` (`id`, `name`) VALUES
(1, 'Standalone'),
(2, 'Project'),
(3, 'Enterprise');

-- --------------------------------------------------------

--
-- Table structure for table `custom_risk_model_values`
--

CREATE TABLE `custom_risk_model_values` (
  `impact_id` bigint(20) UNSIGNED NOT NULL,
  `likelihood_id` bigint(20) UNSIGNED NOT NULL,
  `value` double(3,1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cvss_scorings`
--

CREATE TABLE `cvss_scorings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `metric_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abrv_metric_name` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric_value` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abrv_metric_value` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numeric_value` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data_classifications`
--

CREATE TABLE `data_classifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_classifications`
--

INSERT INTO `data_classifications` (`id`, `name`, `order`) VALUES
(1, 'Public', 1),
(2, 'Internal', 2),
(3, 'Confidential', 3),
(4, 'Restricted', 4);

-- --------------------------------------------------------

--
-- Table structure for table `date_formats`
--

CREATE TABLE `date_formats` (
  `value` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `date_formats`
--

INSERT INTO `date_formats` (`value`) VALUES
('DD MM YYYY'),
('DD-MM-YYYY'),
('DD.MM.YYYY'),
('DD/MM/YYYY'),
('MM DD YYYY'),
('MM-DD-YYYY'),
('MM.DD.YYYY'),
('MM/DD/YYYY'),
('YYYY DD MM'),
('YYYY MM DD'),
('YYYY-DD-MM'),
('YYYY-MM-DD'),
('YYYY.DD.MM'),
('YYYY.MM.DD'),
('YYYY/DD/MM'),
('YYYY/MM/DD');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_id` bigint(20) UNSIGNED DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `required_num_emplyees` int(11) DEFAULT NULL,
  `color_id` bigint(20) UNSIGNED NOT NULL,
  `vision` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mission` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `objectives` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsibilities` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `code`, `manager_id`, `parent_id`, `required_num_emplyees`, `color_id`, `vision`, `message`, `mission`, `objectives`, `responsibilities`, `created_at`, `updated_at`) VALUES
(1, 'الرئيس التنفيذى', '#000001', 2, NULL, NULL, 1, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(2, 'اﻹدارة العامة ﻷمن المعلومات', '#000002', 3, 1, NULL, 2, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-13 13:47:39'),
(3, 'نائب المدير العام', '#000003', 4, 2, NULL, 3, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(4, 'المكتب اﻹدارى', '#000004', 5, 2, 6, 4, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(5, 'الحوكمة والمخاطر والالتزام', '#000005', 6, 2, 21, 5, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(6, 'المراقبة اﻷمنية والاستجابة والتحليل', '#000006', 7, 2, 43, 6, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(7, 'إدارة الحلول اﻷمنية', '#000007', 8, 2, 11, 7, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(8, 'المعمارية والتخطيط', '#000008', 9, 2, 8, 8, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(9, 'الحوكمة', '#000009', 10, 5, NULL, 9, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(10, 'المخاطر', '#000010', 11, 5, NULL, 10, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(11, 'الالتزام', '#000011', 12, 5, NULL, 11, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(12, 'المراقبة اﻷمنية', '#000012', 13, 6, NULL, 12, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(13, 'التحليل الرقمى والاستجابة للحوادث', '#000013', 14, 6, NULL, 13, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(14, 'المعلومات الاستخباراتية والتهديدات', '#000014', 15, 6, NULL, 14, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(15, 'تحليل التهديدات والثغرات', '#000015', 16, 6, NULL, 15, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04');
INSERT INTO `departments` (`id`, `name`, `code`, `manager_id`, `parent_id`, `required_num_emplyees`, `color_id`, `vision`, `message`, `mission`, `objectives`, `responsibilities`, `created_at`, `updated_at`) VALUES
(16, 'إدارة الضوابط التقنية اﻷمنية', '#000016', 17, 7, NULL, 16, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(17, 'تطوير واختبار الحلول اﻷمنية', '#000017', 18, 7, NULL, 17, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:04'),
(18, 'إدارة الهويات والصلاحيات', '#000018', 19, 7, NULL, 18, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:05'),
(19, 'التخطيط والتطوير', '#000019', 20, 8, NULL, 19, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:05'),
(20, 'المعمارية اﻷمنية', '#000020', 21, 8, NULL, 20, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2023-11-12 19:29:03', '2023-11-12 19:29:05'),
(21, 'Noelle Guthrie', '456788', 21, 17, 5, 1, '{\"ops\":[{\"insert\":\"Dolorem cupidatat am.\\n\"}]}', '{\"ops\":[{\"insert\":\"Quo culpa, ut cum ea.\\n\"}]}', '{\"ops\":[{\"insert\":\"Ut eu consectetur no.\\n\"}]}', '{\"ops\":[{\"insert\":\"Aut aut irure accusa.\\n\"}]}', '{\"ops\":[{\"insert\":\"Nulla exercitationem.\\n\"}]}', '2023-11-12 19:32:59', '2023-11-12 19:33:52'),
(22, 'Dep1', '5933', 2, 3, 3, 4, '{\"ops\":[{\"insert\":\"5656\\t\\n\"}]}', '{\"ops\":[{\"insert\":\"dad\\n\"}]}', '{\"ops\":[{\"insert\":\"sdsd\\n\"}]}', '{\"ops\":[{\"insert\":\"dsdd\\n\"}]}', '{\"ops\":[{\"insert\":\"dsadad\\n\"}]}', '2023-11-12 19:40:23', '2023-11-12 19:40:23'),
(23, 'Amaya Delgado', '89', 4, 11, 6, 5, '{\"ops\":[{\"insert\":\"Dignissimos quaerat .\\n\"}]}', '{\"ops\":[{\"insert\":\"Illum, explicabo. Mo.\\n\"}]}', '{\"ops\":[{\"insert\":\"Minim sit, id sunt e.\\n\"}]}', '{\"ops\":[{\"insert\":\"Nulla et in alias a .\\n\"}]}', '{\"ops\":[{\"insert\":\"Voluptates dolorum e.\\n\"}]}', '2023-11-12 19:40:42', '2023-11-12 19:40:42'),
(24, 'gfchuygn', '12345', 1, NULL, 7, 2, NULL, NULL, NULL, NULL, NULL, '2023-11-12 19:43:56', '2023-11-13 07:12:58'),
(27, 'Maile Holt', '202231', 31, 17, 225, 1, '{\"ops\":[{\"insert\":\"Amet, quis vel qui q.\\n\"}]}', '{\"ops\":[{\"insert\":\"Quae sunt eum alias .\\n\"}]}', '{\"ops\":[{\"insert\":\"Eveniet, quaerat quo.\\n\"}]}', '{\"ops\":[{\"insert\":\"Ipsum, tenetur elit.\\n\"}]}', '{\"ops\":[{\"insert\":\"Et voluptatem iure a.\\n\"}]}', '2023-11-13 12:08:14', '2023-11-13 12:08:14');

-- --------------------------------------------------------

--
-- Table structure for table `department_colors`
--

CREATE TABLE `department_colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `department_colors`
--

INSERT INTO `department_colors` (`id`, `name`, `value`) VALUES
(1, 'الرئيس التنفيذى', '#557B83'),
(2, 'اﻹدارة العامة ﻷمن المعلومات', '#39AEA9'),
(3, 'نائب المدير العام', '#A2D5AB'),
(4, 'المكتب اﻹدارى', '#E5EFC1'),
(5, 'الحوكمة والمخاطر والالتزام', '#46244C'),
(6, 'المراقبة اﻷمنية والاستجابة والتحليل', '#C74B50'),
(7, 'إدارة الحلول اﻷمنية', '#D49B54'),
(8, 'المعمارية والتخطيط', '#712B75'),
(9, 'الحوكمة', '#332FD0'),
(10, 'المخاطر', '#F0A500'),
(11, 'الالتزام', '#874356'),
(12, 'المراقبة اﻷمنية', '#019267'),
(13, 'التحليل الرقمى والاستجابة للحوادث', '#9ADCFF'),
(14, 'المعلومات الاستخباراتية والتهديدات', '#008E89'),
(15, 'تحليل التهديدات والثغرات', '#313552'),
(16, 'إدارة الضوابط التقنية اﻷمنية', '#FF5959'),
(17, 'تطوير واختبار الحلول اﻷمنية', '#161853'),
(18, 'إدارة الهويات والصلاحيات', '#544179'),
(19, 'التخطيط والتطوير', '#125C13'),
(20, 'المعمارية اﻷمنية', '#557B83');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `document_type` bigint(20) UNSIGNED NOT NULL,
  `privacy` bigint(20) UNSIGNED DEFAULT NULL,
  `document_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `document_status` int(11) NOT NULL DEFAULT 1 COMMENT '[1 => Draft],[2=> InReview, [3 => Approved]',
  `file_id` int(11) NOT NULL,
  `creation_date` date DEFAULT NULL,
  `last_review_date` date DEFAULT NULL,
  `review_frequency` int(11) DEFAULT NULL,
  `next_review_date` date DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `control_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `framework_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_owner` bigint(20) UNSIGNED NOT NULL,
  `document_reviewer` bigint(20) UNSIGNED DEFAULT NULL,
  `additional_stakeholders` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `team_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `document_type`, `privacy`, `document_name`, `parent`, `document_status`, `file_id`, `creation_date`, `last_review_date`, `review_frequency`, `next_review_date`, `approval_date`, `control_ids`, `framework_ids`, `document_owner`, `document_reviewer`, `additional_stakeholders`, `approver`, `team_ids`, `created_by`) VALUES
(2, 2, 2, 'السياسة العامة للأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '11', '1', 1, NULL, '', NULL, '', 1),
(3, 2, 2, 'سياسة الالتزام بتشريعات وتنظيمات الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '35', '1', 1, NULL, '', NULL, '', 1),
(4, 2, 2, 'سياسة الإعدادات والتحصين', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '28,34', '1', 1, NULL, '', NULL, '', 1),
(5, 2, 2, 'سياسة الحماية من البرمجيات الضارة', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '76', '1', 1, NULL, '', NULL, '', 1),
(6, 2, 2, 'سياسة أمن الخوادم', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '76,125', '1', 1, NULL, '', NULL, '', 1),
(7, 2, 2, 'سياسة أمن الشبكات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '93,96,103', '1', 1, NULL, '', NULL, '', 1),
(8, 2, 2, 'سياسة أمن البريد الإلكتروني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '84', '1', 1, NULL, '', NULL, '', 1),
(9, 2, 2, 'سياسة أمن أجهزة المستخدمين والأجهزة المحمولة والأجهزة الشخصية', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '76,105', '1', 1, NULL, '', NULL, '', 1),
(10, 2, 2, 'سياسة الاستخدام المقبول للأصول', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '63', '1', 1, NULL, '', NULL, '', 1),
(11, 2, 2, 'سياسة مراجعة وتدقيق الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '37', '1', 1, NULL, '', NULL, '', 1),
(12, 2, 2, 'سياسة إدارة هويات الدخول والصلاحيات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '67', '1', 1, NULL, '', NULL, '', 1),
(13, 2, 2, 'سياسة الأمن السيبراني للموارد البشرية', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '40', '1', 1, NULL, '', NULL, '', 1),
(14, 2, 2, 'سياسة إدارة سجلات الأحداث ومراقبة الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '149', '1', 1, NULL, '', NULL, '', 1),
(15, 2, 2, 'سياسة إدارة حزم التحديثات والإصلاحات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '81', '1', 1, NULL, '', NULL, '', 1),
(16, 2, 2, 'سياسة الأمن السيبراني المتعلّق بالأطراف الخارجية', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '192,199', '1', 1, NULL, '', NULL, '', 1),
(17, 2, 2, 'أدوار ومسؤوليات الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '15,40', '1', 1, NULL, '', NULL, '', 1),
(18, 2, 2, 'الوثيقة المنظمة للجنة الإشرافية للأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '10', '1', 1, NULL, '', NULL, '', 1),
(19, 2, 2, 'سياسة اختبار الاختراق', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '61,143,148', '1', 1, NULL, '', NULL, '', 1),
(20, 2, 2, 'سياسة إدارة الثغرات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '134,137,141', '1', 1, NULL, '', NULL, '', 1),
(21, 2, 2, 'سياسة إدارة حوادث وتهديدات الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '157,158,161,162,163,164,165', '1', 1, NULL, '', NULL, '', 1),
(22, 2, 2, 'سياسة أمن قواعد البيانات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '12,82', '1', 1, NULL, '', NULL, '', 1),
(23, 2, 2, 'سياسة حماية تطبيقات الويب', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '100,176,179,180,182,184', '1', 1, NULL, '', NULL, '', 1),
(24, 2, 2, 'استراتيجية الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '5', '1', 1, NULL, '', NULL, '', 1),
(25, 2, 2, 'الهيكل التنظيمي للأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '8', '1', 1, NULL, '', NULL, '', 1),
(26, 2, 2, 'سياسة الأمن السيبراني لأنظمة التحكم الصناعي', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '208,212,213,215,217,218,221', '1', 1, NULL, '', NULL, '', 1),
(27, 2, 2, 'سياسة التشفير', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '120,121,123,126', '1', 1, NULL, '', NULL, '', 1),
(31, 2, 2, 'سياسة إدارة مخاطر الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '17', '1', 1, NULL, '', NULL, '', 1),
(32, 2, 2, 'سياسة الأمن السيبراني المتعلق بالحوسبة السحابية والاستضافة', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '201,204,205,206', '1', 1, NULL, '', NULL, '', 1),
(33, 2, 2, 'سياسة الأمن السيبراني ضمن استمرارية الأعمال', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '185,845', '1,5', 1, NULL, '', NULL, '', 1),
(34, 2, 2, 'سياسة الأمن السيبراني المتعلق بالأمن المادي', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '167', '1', 1, NULL, '', NULL, '', 1),
(35, 3, 2, 'معيار أمن الشبكات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '93', '1', 1, NULL, '', NULL, '', 1),
(36, 3, 2, 'معيار حماية البريد الإلكتروني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '13,84', '1', 1, NULL, '', NULL, '', 1),
(37, 3, 2, 'معيار إدارة سجلات الأحداث ومراقبة الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '13,149', '1', 1, NULL, '', NULL, '', 1),
(38, 3, 2, 'معيار الحماية من البرمجيات الضارة', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '79', '1', 1, NULL, '', NULL, '', 1),
(39, 3, 2, 'معيار أمن أجهزة المستخدمين', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '76', '1', 1, NULL, '', NULL, '', 1),
(40, 3, 2, 'معيار أمن الأجهزة المحمولة', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '13,105', '1', 1, NULL, '', NULL, '', 1),
(41, 3, 2, 'معيار أمن الخوادم', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '76', '1', 1, NULL, '', NULL, '', 1),
(42, 3, 2, 'معيار أمن قواعد البيانات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '76', '1', 1, NULL, '', NULL, '', 1),
(43, 3, 2, 'معيار إدارة الثغرات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '134', '1', 1, NULL, '', NULL, '', 1),
(44, 3, 2, 'معيار إدارة حوادث وتهديدات الأمن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '158', '1', 1, NULL, '', NULL, '', 1),
(45, 3, 2, 'معيار اختبار الاختراق', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '143', '1', 1, NULL, '', NULL, '', 1),
(46, 3, 2, 'معيار التطوير الآمن للتطبيقات', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '30', '1', 1, NULL, '', NULL, '', 1),
(47, 3, 2, 'معيار حماية تطبيقات الويب', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '176', '1', 1, NULL, '', NULL, '', 1),
(48, 3, 2, 'معيار التشفير', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '120', '1', 1, NULL, '', NULL, '', 1),
(49, 3, 2, 'معيار أمن الشبكات اللاسلكية', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '93', '1', 1, NULL, '', NULL, '', 1),
(54, 8, 1, 'لوائح صمود الامن السيبراني', NULL, 3, 0, '2023-11-12', '2023-11-12', 180, '2024-05-10', NULL, '138,284', '1,4', 1, NULL, '', NULL, '', 1),
(55, 2, 1, 'x', NULL, 1, 1, '2023-11-12', '2023-11-24', 0, '2023-11-24', NULL, '7', '1', 1, NULL, '1', NULL, '2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `document_exceptions`
--

CREATE TABLE `document_exceptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_document_id` int(11) DEFAULT NULL,
  `control_framework_id` int(11) DEFAULT NULL,
  `owner` int(11) DEFAULT NULL,
  `additional_stakeholders` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_date` date NOT NULL DEFAULT '0000-00-00',
  `review_frequency` int(11) NOT NULL DEFAULT 0,
  `next_review_date` date NOT NULL DEFAULT '0000-00-00',
  `approval_date` date NOT NULL DEFAULT '0000-00-00',
  `approver` int(11) DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `justification` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `associated_risks` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_exceptions_statuses`
--

CREATE TABLE `document_exceptions_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_notes`
--

CREATE TABLE `document_notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `document_id` bigint(20) UNSIGNED NOT NULL,
  `note` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_note_files`
--

CREATE TABLE `document_note_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `document_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_statuses`
--

CREATE TABLE `document_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `document_statuses`
--

INSERT INTO `document_statuses` (`id`, `name`) VALUES
(1, 'Draft'),
(2, 'In Review'),
(3, 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `document_types`
--

CREATE TABLE `document_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `document_types`
--

INSERT INTO `document_types` (`id`, `name`, `icon`, `created_at`, `updated_at`) VALUES
(2, 'نماذج سياسات الأمن السيبراني', 'fas  fa-lock', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(3, 'معايير الأمن السيبراني', 'fas  fa-lock', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(4, 'الاجراءات', 'fas fa-bug', '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(8, 'صمود الأمن السيبراني', 'fas fa-unlink', '2023-11-12 19:29:08', '2023-11-12 19:29:08');

-- --------------------------------------------------------

--
-- Table structure for table `dynamic_saved_selections`
--

CREATE TABLE `dynamic_saved_selections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('private','public') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_display_settings` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_selection_settings` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_column_filters` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_config`
--

CREATE TABLE `email_config` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_server` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_from_username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ssl_tls` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_auth` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_config`
--

INSERT INTO `email_config` (`id`, `email_type`, `smtp_server`, `smtp_port`, `smtp_username`, `smtp_password`, `smtp_from_username`, `ssl_tls`, `smtp_auth`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'smtp', 'smtp.gmail.com', '587', 'noreply@fpbsa.com', 'svsxwnjraqirfjdb', 'noreply', 'ssl', '', 'yes', NULL, '2023-11-12 21:11:20');

-- --------------------------------------------------------

--
-- Table structure for table `evidences`
--

CREATE TABLE `evidences` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `control_control_objective_id` bigint(20) UNSIGNED NOT NULL,
  `creator_id` bigint(20) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_unique_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `evidences`
--

INSERT INTO `evidences` (`id`, `control_control_objective_id`, `creator_id`, `description`, `file_name`, `file_unique_name`, `created_at`, `updated_at`) VALUES
(1, 2, 44, 'test', NULL, NULL, '2023-11-13 14:47:41', '2023-11-13 14:47:41');

-- --------------------------------------------------------

--
-- Table structure for table `failed_login_attempts`
--

CREATE TABLE `failed_login_attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `expired` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `families`
--

CREATE TABLE `families` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(350) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `families`
--

INSERT INTO `families` (`id`, `name`, `order`, `parent_id`) VALUES
(1, 'حوكمة الأمن السيبراني CyberSecurity Governance', 1, NULL),
(2, 'تعزيز الأمن السيبراني CyberSecurity Defense', 2, NULL),
(3, 'صمود الأمن السيبراني CyberSecurity Resilience', 3, NULL),
(4, 'الأمن السيبراني المتعلق باﻷطراف الخارجية والحوسبة السحابية Third-Party and Cloud Computing CyberSecurity', 4, NULL),
(5, 'الأمن السيبراني ﻷنظمة التحكم الصناعي ICS CyberSecurity', 5, NULL),
(6, 'Cyber Security Leadership and Governance', 6, NULL),
(7, 'Cyber Security Risk Management and Compliance', 7, NULL),
(8, 'Cyber Security Operations and Technology', 8, NULL),
(9, 'Third Party Cyber Security', 9, NULL),
(10, 'Annex A.5 – Information Security Policies', 10, NULL),
(11, 'Annex A.6 – Organisation of Information Security', 11, NULL),
(12, 'Annex A.7 – Human Resource Security', 12, NULL),
(13, 'Annex A.8 – Asset Management', 13, NULL),
(14, 'Annex A.9 – Access Control', 14, NULL),
(15, 'Annex A.10 – Cryptography', 15, NULL),
(16, 'Annex A.11 – Physical & Environmental Security', 16, NULL),
(17, 'Annex A.12 – Operations Security', 17, NULL),
(18, 'Annex A.13 – Communications Security', 18, NULL),
(19, 'Annex A.14 – System Acquisition, Development & Maintenance', 19, NULL),
(20, 'Annex A.15 – Supplier Relationships', 20, NULL),
(21, 'Annex A.16 – Information Security Incident Management', 21, NULL),
(22, 'Annex A.17 – Information Security Aspects of Business Continuity Management', 22, NULL),
(23, 'Annex A.18 – Compliance', 23, NULL),
(24, 'إستراتيجية الأمن السيبراني CyberSecurity Strategy', 1, 1),
(25, 'إدارة الأمن السيبراني CyberSecurity Management', 2, 1),
(26, 'سياسات وإجراءات الأمن السيبراني CyberSecurity Policies and Procedures', 3, 1),
(27, 'أدارة ومسئوليات الأمن السيبراني CyberSecurity Role and Responsibilities', 4, 1),
(28, 'إدارة مخاطر الأمن السيبراني CyberSecurity Risk Management', 5, 1),
(29, 'الأمن السيبراني ضمن إدارة المشاريع المعلوماتية والتقنية CyberSecurity in Information Technology Projects', 6, 1),
(30, 'اﻹلتزام بتشريعات وتنظيمات ومعايير الأمن السيبراني CyberSecurity Regulatory Compliance', 7, 1),
(31, 'المراجعة والتدقيق الدورى للأمن السيبراني CyberSecurity Periodical Assessment and Audit', 8, 1),
(32, 'الأمن السيبراني المتعلق بالموارد البشرية CyberSecurity in Human Resources', 9, 1),
(33, 'برنامج التوعية والتدريب بالأمن السيبراني CyberSecurity Awareness and Training Program', 10, 1),
(34, 'إدارة اﻷصول Asset Management', 1, 2),
(35, 'إدارة هويات الدخول والصلاحيات Identity and Access Management', 2, 2),
(36, 'حماية اﻷنظمة وأجهزة معالجة المعلومات Information System and Processing Facilities Protection', 3, 2),
(37, 'حماية البريد اﻹلكترونى Email Protection', 4, 2),
(38, 'إدارة أمن الشبكات Networks Security Management', 5, 2),
(39, 'أمن اﻷجهزة المحمولة Mobile Devices Security', 6, 2),
(40, 'حماية البيانات والمعلومات Data and Information Protection', 7, 2),
(41, 'التشفير Cryptography', 8, 2),
(42, 'إدارة النسخ الاحتياطية Backup and Recovery Management', 9, 2),
(43, 'إدارة الثغرات Vulnerabilities Management', 10, 2),
(44, 'إختبار الاختراق Penetration Testing', 11, 2),
(45, 'إدارة سجلات اﻷحداث ومراقبة اﻷمن السيبرانى CyberSecurity Event Logs and Monitoring Management', 12, 2),
(46, 'إدارة حوادث وتهديدات اﻷمن السيبراني CyberSecurity Incident and Threat Management', 13, 2),
(47, 'اﻷمن المادى Physical Security', 14, 2),
(48, 'حماية تطبيقات الويب Web Application Security', 15, 2),
(49, 'جوانب صمود اﻷمن السيبراني فى إدارة استمرارية اﻷعمال CyberSecurity Resilience aspects of Business Continuity Management (BCM)', 1, 3),
(50, 'الأمن السيبراني المتعلق باﻷطراف الخارجية Third-Party CyberSecurity', 1, 4),
(51, 'الأمن السيبراني المتعلق بالحوسبة السحابية والاستضافة Cloud Computing and hosting CyberSecurity', 2, 4),
(52, 'حماية أجمزة وأنظمة التحكم الصناعي Industrial Control Systems (ICS) Protection', 1, 5),
(53, 'Cyber Security Governance', 1, 6),
(54, 'Cyber Security Strategy', 2, 6),
(55, 'Cyber Security Policy', 3, 6),
(56, 'Cyber Security Roles and Responsibilities', 4, 6),
(57, 'Cyber Security in Project Management', 5, 6),
(58, 'Cyber Security Awareness', 6, 6),
(59, 'Cyber Security Training', 7, 6),
(60, 'Cyber Security Risk Management', 1, 7),
(61, 'Regulatory Compliance', 2, 7),
(62, 'Compliance with (inter)national industry standards', 3, 7),
(63, 'Cyber Security Review', 4, 7),
(64, 'Cyber Security Audits', 5, 7),
(65, 'Human Resources', 1, 8),
(66, 'Physical Security', 2, 8),
(67, 'Asset Management', 3, 8),
(68, 'Cyber Security Architecture', 4, 8),
(69, 'Identity and Access Management', 5, 8),
(70, 'Application Security', 6, 8),
(71, 'Change Management', 7, 8),
(72, 'Infrastructure Security', 8, 8),
(73, 'Cryptography', 9, 8),
(74, 'Bring Your Own Device (BYOD)', 10, 8),
(75, 'Secure Disposal of Information Assets', 11, 8),
(76, 'Payment Systems', 12, 8),
(77, 'Electronic Banking Services', 13, 8),
(78, 'Cyber Security Event Management', 14, 8),
(79, 'Cyber Security Incident Management', 15, 8),
(80, 'Threat Management', 16, 8),
(81, 'Vulnerability Management', 17, 8),
(82, 'Contract and Vendor Management', 1, 9),
(83, 'Outsourcing', 2, 9),
(84, 'Cloud Computing', 3, 9),
(85, 'Management direction for information Security', 1, 10),
(86, 'Internal organization', 1, 11),
(87, 'Mobile devices and teleworking', 2, 11),
(88, 'Prior to employment', 1, 12),
(89, 'During employment', 2, 12),
(90, 'Termination and change of employment', 3, 12),
(91, 'Responsibility for assets', 1, 13),
(92, 'Information classification', 2, 13),
(93, 'Media Handling', 3, 13),
(94, 'Business requirements of access Control', 1, 14),
(95, 'User access Management', 2, 14),
(96, 'User responsibilities', 3, 14),
(97, 'System and application access Control', 4, 14),
(98, 'Cryptographic Controls', 1, 15),
(99, 'Ensuring Secure Physical and Environmental Areas', 1, 16),
(100, 'Equipment', 2, 16),
(101, 'Operational Procedures and Responsibilities', 1, 17),
(102, 'Protection From Malware', 2, 17),
(103, 'Backup', 3, 17),
(104, 'Logging and Monitoring', 4, 17),
(105, 'Control of Operational Software', 5, 17),
(106, 'Technical Vulnerability Management', 6, 17),
(107, 'Information Systems and Audit Considerations', 7, 17),
(108, 'Network Security Management', 1, 18),
(109, 'Information Transfer', 2, 18),
(110, 'Security Requirements of Information Systems', 1, 19),
(111, 'Security in Development and Support Processes', 2, 19),
(112, 'Test data', 3, 19),
(113, 'Information Security in Supplier Relationships', 1, 20),
(114, 'Supplier Service Delivery Management', 2, 20),
(115, 'Management of Information Security incidents, events and Weaknesses', 1, 21),
(116, 'Information Security Continuity', 1, 22),
(117, 'Redundancies', 2, 22),
(118, 'Compliance with legal and Contractual Requirements', 1, 23),
(119, 'Information Security Reviews', 2, 23),
(120, 'الأمن السيبراني ضمن إدارة التغير Management Change in Cybersecurity', 11, 1),
(121, 'إدارة المفاتيح Key management', 16, 2),
(122, 'حماية التطبيقات Application Security', 17, 2),
(123, 'أمن تطوير الأنظمة System Development Security', 18, 2),
(124, 'أمن وسائط التخزين Storage Media Security', 19, 2),
(125, 'حمايه المنظم ومرافق المعالجة Facility Processing and System Protection', 20, 2),
(126, 'الإتلاف الآمن للبيانات secure Data Disposal', 21, 2),
(127, 'الأمن السيبراني للطابعات و الماسحات الضوئيه وآللات التصوير Cybersecurity for printers,scanners and Copy machines', 22, 2);

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED DEFAULT NULL,
  `view_type` int(11) NOT NULL DEFAULT 1,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `risk_id`, `view_type`, `name`, `unique_name`, `type`, `size`, `timestamp`, `user`) VALUES
(1, NULL, 1, 'test.pptx', 'docs/55/LCLSDogAqHTLl5xcxpjRQo4mwu2doAImRXantID3.pptx', NULL, 0, '2023-11-12 17:46:38', 0),
(2, NULL, 1, '_.pdf', 'security_awareness/1/QlHTlLgXxaThMVnEhGgBdGBjFe45H4QhC0S6Vj50.pdf', NULL, 0, '2023-11-12 18:01:13', 0),
(3, NULL, 1, '_ (3).pdf', 'security_awareness/2/eU9EYRbHMIEM7hC2z3BltSmEz5bZ1HhpRjklRml4.pdf', NULL, 0, '2023-11-12 18:02:19', 0),
(4, NULL, 1, 'test.pdf', 'security_awareness/3/8DSzcwLfxRqti3cwGkhzqAWhMXNRYTIWqhfte1rv.pdf', NULL, 0, '2023-11-13 07:35:58', 0),
(5, NULL, 1, 'test.pdf', 'security_awareness/4/4EGyQie4h4LoLjh5rFhE6z4I6YcTHU1RGrtgtHIf.pdf', NULL, 0, '2023-11-13 08:17:10', 0),
(6, NULL, 1, 'so_survey_2019 (1).pdf', 'security_awareness/5/8ZZVUWiGWgL9CijwxqxjCEnCHjXsqE7QcaJzBgtt.pdf', NULL, 0, '2023-11-13 09:37:20', 0),
(7, NULL, 1, 'test.pdf', 'security_awareness/6/vGeqCtoxkxkNCwQOuNvC8MTDemMcvADlBtjtWuYq.pdf', NULL, 0, '2023-11-13 13:37:46', 0);

-- --------------------------------------------------------

--
-- Table structure for table `file_tasks`
--

CREATE TABLE `file_tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `file_types`
--

CREATE TABLE `file_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `file_types`
--

INSERT INTO `file_types` (`id`, `name`) VALUES
(21, 'application/csv'),
(18, 'application/force-download'),
(16, 'application/msword'),
(11, 'application/octet-stream'),
(19, 'application/pdf'),
(15, 'application/vnd.ms-excel'),
(8, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
(7, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(17, 'application/x-gzip'),
(6, 'application/x-pdf'),
(9, 'application/zip'),
(1, 'image/gif'),
(5, 'image/jpeg'),
(2, 'image/jpg'),
(3, 'image/png'),
(4, 'image/x-png'),
(14, 'text/comma-separated-values'),
(20, 'text/csv'),
(12, 'text/plain'),
(10, 'text/rtf'),
(13, 'text/xml');

-- --------------------------------------------------------

--
-- Table structure for table `file_type_extensions`
--

CREATE TABLE `file_type_extensions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `file_type_extensions`
--

INSERT INTO `file_type_extensions` (`id`, `name`) VALUES
(12, 'csv'),
(14, 'doc'),
(16, 'dot'),
(6, 'dotx'),
(1, 'gif'),
(15, 'gz'),
(4, 'jpeg'),
(2, 'jpg'),
(5, 'pdf'),
(3, 'png'),
(9, 'rtf'),
(10, 'txt'),
(18, 'xla'),
(13, 'xls'),
(7, 'xlsx'),
(17, 'xlt'),
(11, 'xml'),
(8, 'zip');

-- --------------------------------------------------------

--
-- Table structure for table `frameworks`
--

CREATE TABLE `frameworks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `order` int(11) DEFAULT NULL,
  `last_audit_date` date DEFAULT NULL,
  `next_audit_date` date DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frameworks`
--

INSERT INTO `frameworks` (`id`, `parent`, `name`, `description`, `icon`, `status`, `order`, `last_audit_date`, `next_audit_date`, `desired_frequency`, `created_at`, `updated_at`) VALUES
(1, NULL, 'NCA-ECC – 1: 2018', 'The National Cybersecurity Authority “NCA” has developed the Essential Cybersecurity Controls (ECC – 1: 2018) to set the minimum cybersecurity requirements based on best practices and standards to minimize the cybersecurity risks to the information and technical assets of organizations that originate from internal and external threats. The Essential Cybersecurity Controls consist of 114 main controls, divided into five main domains.', 'fa-universal-access', 1, NULL, NULL, NULL, NULL, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(2, NULL, 'frame1', 'sss', 'fas fa-dungeon', 1, NULL, NULL, NULL, NULL, '2023-11-12 19:34:27', '2023-11-12 19:34:27');

-- --------------------------------------------------------

--
-- Table structure for table `framework_controls`
--

CREATE TABLE `framework_controls` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `short_name` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `long_name` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplemental_guidance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `control_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `control_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Not Implemented',
  `family` bigint(20) UNSIGNED NOT NULL,
  `control_owner` bigint(20) UNSIGNED DEFAULT NULL,
  `desired_maturity` bigint(20) UNSIGNED DEFAULT NULL,
  `control_priority` bigint(20) UNSIGNED DEFAULT NULL,
  `control_class` bigint(20) UNSIGNED DEFAULT NULL,
  `control_maturity` bigint(20) UNSIGNED DEFAULT 1,
  `control_phase` bigint(20) UNSIGNED DEFAULT NULL,
  `control_type` bigint(20) UNSIGNED DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_audit_date` date DEFAULT NULL,
  `next_audit_date` date DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `mitigation_percent` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `deleted` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_controls`
--

INSERT INTO `framework_controls` (`id`, `short_name`, `long_name`, `description`, `supplemental_guidance`, `control_number`, `control_status`, `family`, `control_owner`, `desired_maturity`, `control_priority`, `control_class`, `control_maturity`, `control_phase`, `control_type`, `parent_id`, `submission_date`, `last_audit_date`, `next_audit_date`, `desired_frequency`, `mitigation_percent`, `status`, `deleted`, `created_at`, `updated_at`) VALUES
(5, 'ECC 1-1-1', 'ECC 1-1-1', 'يجب تحديد وتوثيق واعتماد إستراتيجية الامـن السيبراني للجهة ودعمها من قبل رئيس الجهة أو من\r\nينيبه ويشار له في هذه الضوابط بـاسم »صاحب الصلاحية« وأن تتماشى الاهداف الاستراتيجية للامن\r\nالسيبراني للجهة مع المتطلبات التشريعية والتنظيمية ذات العلاقة', NULL, 'ECC 1-1-1', 'Not Implemented', 24, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(6, 'ECC 1-1-2', 'ECC 1-1-2', 'يجب العمل على تنفيذ خطة عمل لتطبيق إستراتيجية الامن السيبراني من قبل الجهة', NULL, 'ECC 1-1-2', 'Partially Implemented', 24, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(7, 'ECC 1-1-3', 'ECC 1-1-3', 'يجب مراجعة إستراتيجية الامن السيبراني على فترات زمنية مخطط لها أو في حالة حدوث تغييرات في\r\nالمتطلبات التشريعية والتنظيمية ذات العلاقة', NULL, 'ECC 1-1-3', 'Not Applicable', 24, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(8, 'ECC 1-2-1', 'ECC 1-2-1', 'يجب إنشاء إدارة معنية بالامن السيبراني في الجهة مستقلة عن إدارة تقنية المعلومات والاتصالات وفقا للأمر السامي الكريم  رقم 37140  وتاريخ 14 \\/ 8 \\/ 1438 هـ. ويفضل ارتباطها مباشرة برئيس (ICT\\/ IT)\r\n وفقا للجهة أو من ينيبه، مع الاخذ بالاعتبار عدم تعارض المصالح.', NULL, 'ECC 1-2-1', 'Partially Implemented', 25, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(9, 'ECC 1-2-2', 'ECC 1-2-2', 'يجب أن يشغل رئاسة الادارة المعنية بالامن السيبراني والوظائف الاشرافية والحساسة بها مواطنون\r\n متفرغون وذو كفاءة عالية في مجال الامن السيبراني.', NULL, 'ECC 1-2-2', 'Not Applicable', 25, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(10, 'ECC 1-2-3', 'ECC 1-2-3', 'يجب إنشاء لجنة إشرافية للامن السيبراني بتوجيه من صاحب الصلاحية للجهة لضمان التزام ودعم ومتابعة\r\nتطبيق برامج وتشريعات الامن السيبراني، ويتم تحديد وتوثيق واعتماد أعضاء اللجنة ومسؤولياتها وإطار\r\nحوكمة أعمالها على أن يكون رئيس الادارة المعنية بالامن السيبراني أحد أعضائها. ويفضل ارتباطها مباشرة\r\nبرئيس الجهة أو من ينيبه، مع الاخذ بالاعتبار عدم تعارض المصالح', NULL, 'ECC 1-2-3', 'Not Applicable', 25, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(11, 'ECC 1-3-1', 'ECC 1-3-1', 'يجب على الادارة المعنية بالامن السيبراني في الجهة تحديد سياسات وإجـراءات الامن السيبراني وما\r\nتشمله من ضوابط ومتطلبات الامن السيبراني، وتوثيقها واعتمادها من قبل صاحب الصلاحية في الجهة،\r\nكما يجب نشرها إلى ذوي العلاقة من العاملين في الجهة والاطراف المعنية بها.', NULL, 'ECC 1-3-1', 'Not Applicable', 26, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(12, 'ECC 1-3-2', 'ECC 1-3-2', 'يجب على الادارة المعنية بالامن السيبراني ضمان تطبيق سياسات وإجراءات الامن السيبراني في الجهة\r\nوما تشمله من ضوابط ومتطلبات.', NULL, 'ECC 1-3-2', 'Not Applicable', 26, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(13, 'ECC 1-3-3', 'ECC 1-3-3', 'يجب أن تكون سياسات وإجراءات الامن السيبراني مدعومة بمعايير تقنية أمنية )على سبيل المثال => المعايير\r\n التقنية المنية لجدار الحماية وقواعد البيانات، وأنظمة التشغيل، إلخ(', NULL, 'ECC 1-3-3', 'Not Applicable', 26, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(14, 'ECC 1-3-4', 'ECC 1-3-4', 'يجب مراجعة سياسات وإجــراءات ومعايير الامـن السيبراني وتحديثها على فترات زمنية مخطط لها )أو\r\nفي حالة حدوث تغييرات في المتطلبات التشريعية والتنظيمية والمعايير ذات العلاقة(، كما يجب توثيق\r\nالتغييرات واعتمادها.', NULL, 'ECC 1-3-4', 'Not Applicable', 26, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(15, 'ECC 1-4-1', 'ECC 1-4-1', 'يجب على صاحب الصلاحية تحديد وتوثيق واعتماد الهيكل التنظيمي للحوكمة والادوار والمسؤوليات\r\nالخاصة بالامن السيبراني للجهة، وتكليف الاشخاص المعنيين بها، كما يجب تقديم الدعم اللزم لنفاذ\r\nذلك، مع الاخذ بالاعتبار عدم تعارض المصالح', NULL, 'ECC 1-4-1', 'Not Applicable', 27, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(16, 'ECC 1-4-2', 'ECC 1-4-2', 'يجب مراجعة أدوار ومسؤوليات الامن السيبراني في الجهة وتحديثها على فترات زمنية مخطط لها )أو في\r\n حالة حدوث تغييرات في المتطلبات التشريعية والتنظيمية ذات العلقة(.', NULL, 'ECC 1-4-2', 'Not Applicable', 27, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(17, 'ECC 1-5-1', 'ECC 1-5-1', 'يجب على الادارة المعنية بالامن السيبراني في الجهة تحديد وتوثيق واعتماد منهجية وإجـراءات إدارة\r\nمخاطر الامن السيبراني في الجهة. وذلك وفقاً لعتبارات السرية وتوافر وسلامة الاصول المعلوماتية\r\nوالتقنية', NULL, 'ECC 1-5-1', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(18, 'ECC 1-5-2', 'ECC 1-5-2', 'يجب على الادارة المعنية بالامن السيبراني تطبيق منهجية وإجـراءات إدارة مخاطر الامن السيبراني في\r\nالجهة', NULL, 'ECC 1-5-2', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(19, 'ECC 1-5-3', 'ECC 1-5-3', 'يجب تنفيذ إجراءات تقييم مخاطر الامن السيبراني', NULL, 'ECC 1-5-3', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(20, 'ECC 1-5-3-1', 'ECC 1-5-3-1', 'يجب تنفيذ إجراءات تقييم مخاطر الامن السيبراني في مرحلة مبكرة من المشاريع التقنية', NULL, 'ECC 1-5-3-1', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, 19, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(21, 'ECC 1-5-3-2', 'ECC 1-5-3-2', 'يجب تنفيذ إجراءات تقييم مخاطر الامن السيبراني   قبل إجراء تغيير جوهري في البنية التقنية', NULL, 'ECC 1-5-3-2', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, 19, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(22, 'ECC 1-5-3-3', 'ECC 1-5-3-3', 'يجب تنفيذ إجراءات تقييم مخاطر الامن السيبراني عند التخطيط للحصول على خدمات طرف خارجي', NULL, 'ECC 1-5-3-3', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, 19, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(23, 'ECC 1-5-3-4', 'ECC 1-5-3-4', 'يجب تنفيذ إجراءات تقييم مخاطر الأمن السيبراني  عند التخطيط وقبل إطلق منتجات وخدمات تقنية جديدة.', NULL, 'ECC 1-5-3-4', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, 19, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(24, 'ECC 1-5-4', 'ECC 1-5-4', 'يجب مراجعة منهجية وإجراءات إدارة مخاطر الامن السيبراني وتحديثها على فترات زمنية مخطط لها )أو\r\nفي حالة حدوث تغييرات في المتطلبات التشريعية والتنظيمية والمعايير ذات العلاقة(، كما يجب توثيق\r\nالتغييرات واعتمادها.', NULL, 'ECC 1-5-4', 'Not Applicable', 28, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(25, 'ECC 1-6-1', 'ECC 1-6-1', 'يجب تضمين متطلبات الامـن السيبراني في منهجية وإجــراءات إدارة المشاريع وفي إدارة التغيير على\r\nالاصول المعلوماتية والتقنية في الجهة لضمان تحديد مخاطر الامن السيبراني ومعالجتها كجزء من دورة\r\nحياة المشروع التقني، وأن تكون متطلبات الامن السيبراني جزء أساسي من متطلبات المشاريع التقنية.', NULL, 'ECC 1-6-1', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(26, 'ECC 1-6-2', 'ECC 1-6-2', 'يجب أن تغطي متطلبات الامن السيبراني لادارة المشاريع والتغييرات على الاصول المعلوماتية والتقنية\r\nللجهة', NULL, 'ECC 1-6-2', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(27, 'ECC 1-6-2-1', 'ECC 1-6-2-1', 'يجب أن تغطي متطلبات الامن السيبراني لادارة المشاريع \r\n والتغييرات على الاصول المعلوماتية والتقنية  تقييم الثغرات ومعالجتها', NULL, 'ECC 1-6-2-1', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, 26, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(28, 'ECC 1-6-2-2', 'ECC 1-6-2-2', 'يجب أن تغطي متطلبات الامن السيبراني لادارة المشاريع والتغييرات على الاصول المعلوماتية والتقنية\r\nللجهة  وحـزم( Secure Confguration and Hardening( والتحصين لـإعـدادات مراجعة اجــراء \r\nالتحديثات قبل إطلق وتدشين المشاريع والتغييرات.', NULL, 'ECC 1-6-2-2', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, 26, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(29, 'ECC 1-6-3', 'ECC 1-6-3', 'يجب أن تغطي متطلبات الامن السيبراني لمشاريع تطوير التطبيقات والبرمجيات الخاصة للجهة', NULL, 'ECC 1-6-3', 'Not Implemented', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(30, 'ECC 1-6-3-1', 'ECC 1-6-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لمشاريع تطوير التطبيقات والبرمجيات الخاصة للجهة بحد أدنى )Secure Coding Standards( للتطبيقات الامن التطوير معايير ا', NULL, 'ECC 1-6-3-1', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, 29, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(31, 'ECC 1-6-3-2', 'ECC 1-6-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لمشاريع تطوير التطبيقات والبرمجيات الخاصة للجهة بحد أدنى استخدام مصادر مرخصة وموثوقة لادوات تطوير التطبيقات والمكتبات الخاصة بها )Libraries.)', NULL, 'ECC 1-6-3-2', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, 29, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(32, 'ECC 1-6-3-3', 'ECC 1-6-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لمشاريع تطوير التطبيقات والبرمجيات الخاصة للجهة بحد أدنى اجراء اختبار للتحقق من مدى استيفاء التطبيقات للمتطلبات الامنية السيبرانية للجهة.', NULL, 'ECC 1-6-3-3', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, 29, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(33, 'ECC 1-6-3-4', 'ECC 1-6-3-4', 'يجب أن تغطي متطلبات الامن السيبراني لمشاريع تطوير التطبيقات والبرمجيات الخاصة للجهة بحد أدنى  التطبيقات بين( Integration( التكامل أم', NULL, 'ECC 1-6-3-4', 'Not Implemented', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, 29, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(34, 'ECC 1-6-3-5', 'ECC 1-6-3-5', 'يجب أن تغطي متطلبات الامن السيبراني لمشاريع تطوير التطبيقات والبرمجيات الخاصة للجهة بحد أدنى وحـزم( Secure Confguration and Hardening( والتحصين لـإعـدادات مراجعة اج التحديثات قبل إطلق وتدشين التطبيقات', NULL, 'ECC 1-6-3-5', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, 29, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(35, 'ECC 1-7-1', 'ECC 1-7-1', 'يجب على الجهة الالتزام بالمتطلبات التشريعية والتنظيمية الوطنية المتعلقة بالامن السيبراني', NULL, 'ECC 1-7-1', 'Not Applicable', 30, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(36, 'ECC 1-7-2', 'ECC 1-7-2', 'في حال وجود اتفاقيات أو إلتزامات دولية معتمدة محلياً تتضمن متطلبات خاصة بالامن السيبراني، فيجب\r\nعلى الجهة الالتزام بتلك المتطلبات.', NULL, 'ECC 1-7-2', 'Not Applicable', 30, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(37, 'ECC 1-8-1', 'ECC 1-8-1', 'يجب على الادارة المعنية بالامن السيبراني في الجهة مراجعة تطبيق ضوابط الامن السيبراني دورياً.', NULL, 'ECC 1-8-1', 'Not Applicable', 31, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(38, 'ECC 1-8-2', 'ECC 1-8-2', 'يجب مراجعة وتدقيق تطبيق ضوابط الامن السيبراني في الجهة، من قبل أطراف مستقلة عن الادارة\r\nالمعنية بالمن السيبراني )مثل الادارة المعنية بالمراجعة في الجهة(. على أن تتم المراجعة والتدقيق\r\nبشكل مستقل يراعى فيه مبدأ عدم تعارض المصالح، وذلك وفقاً للمعايير العامة المقبولة للمراجعة\r\nوالتدقيق والمتطلبات التشريعية والتنظيمية ذات العلاقة.', NULL, 'ECC 1-8-2', 'Not Applicable', 31, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(39, 'ECC 1-8-3', 'ECC 1-8-3', 'يجب توثيق نتائج مراجعة وتدقيق الامـن السيبراني، وعرضها على اللجنة الشرافية للامن السيبراني\r\nوصاحب الصلاحية. كما يجب أن تشتمل النتائج على نطاق المراجعة والتدقيق، والملاحظات المكتشفة،\r\nوالتوصيات والجراءات التصحيحية، وخطة معالجة الملاحظات.', NULL, 'ECC 1-8-3', 'Not Applicable', 31, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(40, 'ECC 1-9-1', 'ECC 1-9-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني المتعلقة بالعاملين قبل توظيفهم وأثناء عملهم\r\nوعند انتهاء\\/إنهاء عملهم في الجهة', NULL, 'ECC 1-9-1', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(41, 'ECC 1-9-2', 'ECC 1-9-2', 'يجب تطبيق متطلبات الامن السيبراني المتعلقة بالعاملين في الجهة.', NULL, 'ECC 1-9-2', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(42, 'ECC 1-9-3', 'ECC 1-9-3', 'يجب أن تغطي متطلبات الامن السيبراني قبل بدء علاقة العاملين المهنية بالجهة', NULL, 'ECC 1-9-3', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(43, 'ECC 1-9-3-1', 'ECC 1-9-3-1', 'يجب أن تغطي متطلبات الامن السيبراني قبل بدء علاقة العاملين المهنية بالجهة تـضـمـيـن مــســؤولــيــات الامـــــن الــســيــبــرانــي وبـــنـــود الــمــحــافــظــة عــلــى ســريــة الـمـعـلـومـات\r\n)Clauses Disclosure-Non )في عقود العاملين في الجهة )لتشمل خلال وبعد انتهاء\\/إنهاء\r\nالعلقة الوظيفية مع الجهة(', NULL, 'ECC 1-9-3-1', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, 42, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(44, 'ECC 1-9-3-2', 'ECC 1-9-3-2', 'يجب أن تغطي متطلبات الامن السيبراني قبل بدء علاقة العاملين المهنية بالجهة   إجراء المسح الامني )Vetting or Screening )للعاملين في وظائف الامن السيبراني والوظائف\r\nالتقنية ذات الصلاحيات الهامة والحساسة', NULL, 'ECC 1-9-3-2', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, 42, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(45, 'ECC 1-9-4', 'ECC 1-9-4', 'يجب أن تغطي متطلبات الامن السيبراني خلل علاقة العاملين المهنية بالجهة', NULL, 'ECC 1-9-4', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(46, 'ECC 1-9-4-1', 'ECC 1-9-4-1', 'يجب أن تغطي متطلبات الامن السيبراني خلل علاقة العاملين المهنية بالجهة  التوعية بالامن السيبراني )عند بداية المهنة الوظيفية وخلالها(.', NULL, 'ECC 1-9-4-1', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, 45, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(47, 'ECC 1-9-4-2', 'ECC 1-9-4-2', 'يجب أن تغطي متطلبات الامن السيبراني خلل علاقة العاملين المهنية بالجهة  تطبيق متطلبات الامـن السيبراني والالـتـزام بها وفقاً لسياسات وإجـــراءات وعمليات الامن\r\nالسيبراني للجهة', NULL, 'ECC 1-9-4-2', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, 45, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(48, 'ECC 1-9-5', 'ECC 1-9-5', 'يجب مراجعة وإلغاء الصلاحيات للعاملين مباشرة بعد انتهاء\\/إنهاء الخدمة المهنية لهم بالجهة.', NULL, 'ECC 1-9-5', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(49, 'ECC 1-9-6', 'ECC 1-9-6', 'يجب مراجعة متطلبات الامن السيبراني المتعلقة بالعاملين في الجهة دوري', NULL, 'ECC 1-9-6', 'Not Applicable', 32, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(50, 'ECC 1-10-1', 'ECC 1-10-1', 'يجب تطوير واعتماد برنامج للتوعية بالامن السيبراني في الجهة من خلل قنوات متعددة دورياً، وذلك لتعزيز الوعي بالامن السيبراني وتهديداته ومخاطره، وبناء ثقافة إيجابية للامن السيبراني.', NULL, 'ECC 1-10-1', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(51, 'ECC 1-10-2', 'ECC 1-10-2', 'يجب تطبيق البرنامج المعتمد للتوعية بالامن السيبراني في الجهة', NULL, 'ECC 1-10-2', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(52, 'ECC 1-10-3', 'ECC 1-10-3', 'يجب أن يغطي برنامج التوعية بالامن السيبراني كيفية حماية الجهة من أهم المخاطر والتهديدات السيبرانية\r\nوما يستجد منها', NULL, 'ECC 1-10-3', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(53, 'ECC 1-10-3-1', 'ECC 1-10-3-1', 'يجب أن يغطي برنامج التوعية بالامن السيبراني كيفية حماية الجهة من أهم المخاطر والتهديدات السيبرانية\r\nوما يستجد منها بما في ذلك => التعامل الامن مع خدمات البريد اللكتروني خصوصاً مع رسائل التصيد الالكتروني', NULL, 'ECC 1-10-3-1', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, 52, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(54, 'ECC 1-10-3-2', 'ECC 1-10-3-2', 'يجب أن يغطي برنامج التوعية بالامن السيبراني كيفية حماية الجهة من أهم المخاطر والتهديدات السيبرانية\r\nوما يستجد منها، بما في ذلك التعامل الامن مع الجهزة المحمولة ووسائط التخزين.', NULL, 'ECC 1-10-3-2', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, 52, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(55, 'ECC 1-10-3-4', 'ECC 1-10-3-4', 'يجب أن يغطي برنامج التوعية بالامن السيبراني كيفية حماية الجهة من أهم المخاطر والتهديدات السيبرانية\r\nوما يستجد منها، بما في ذلك التعامل الامن مع وسائل التواصل الاجتماعي.', NULL, 'ECC 1-10-3-4', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, 52, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(56, 'ECC 1-10-4', 'ECC 1-10-4', 'يجب توفير المهارات المتخصصة والتدريب الازم للعاملين في المجلالت الوظيفية ذات العلاقة المباشرة\r\nبالامن السيبراني في الجهة، وتصنيفها بما يتماشى مع مسؤولياتهم الوظيفية فيما يتعلق بالامن\r\nالسيبراني', NULL, 'ECC 1-10-4', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(57, 'ECC 1-10-4-1', 'ECC 1-10-4-1', 'يجب توفير المهارات المتخصصة والتدريب اللزم للعاملين في المجالت الوظيفية ذات العلقة المباشرة\r\nبالامن السيبراني في الجهة، وتصنيفها بما يتماشى مع مسؤولياتهم الوظيفية فيما يتعلق بالامن\r\nالسيبراني، بما في ذلك  موظفو الادارة المعنية بالامن السيبراني', NULL, 'ECC 1-10-4-1', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, 56, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(58, 'ECC 1-10-4-3', 'ECC 1-10-4-3', 'جب توفير المهارات المتخصصة والتدريب الازم للعاملين في المجلالت الوظيفية ذات العلقة المباشرة\r\nبالامن السيبراني في الجهة، وتصنيفها بما يتماشى مع مسؤولياتهم الوظيفية فيما يتعلق بالامن\r\nالسيبراني، بما في ذلك الاشرافية الوظائف', NULL, 'ECC 1-10-4-3', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, 56, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(59, 'ECC 1-10-4-2', 'ECC 1-10-4-2', 'يجب توفير المهارات المتخصصة والتدريب اللازم للعاملين في المجالت الوظيفية ذات العلاقة المباشرة\r\nبالامن السيبراني في الجهة، وتصنيفها بما يتماشى مع مسؤولياتهم الوظيفية فيما يتعلق بالامن\r\nالسيبراني، بما في ذلك الموظفون العاملون في تطوير البرامج والتطبيقات والموظفون المشغلون للاصول المعلوماتية\r\nوالتقنية للجهة', NULL, 'ECC 1-10-4-2', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, 56, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(60, 'ECC 1-10-5', 'ECC 1-10-5', 'يجب مراجعة تطبيق برنامج التوعية بالامن السيبراني في الجهة دوريا', NULL, 'ECC 1-10-5', 'Not Applicable', 33, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(61, 'ECC 2-1-1', 'ECC 2-1-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني الادارة الاصول المعلوماتية والتقنية للجهة.', NULL, 'ECC 2-1-1', 'Not Applicable', 34, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(62, 'ECC 2-1-2', 'ECC 2-1-2', 'يجب تطبيق متطلبات الامن السيبراني الادارة الاصول المعلوماتية والتقنية للجهة', NULL, 'ECC 2-1-2', 'Not Applicable', 34, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(63, 'ECC 2-1-3', 'ECC 2-1-3', 'يجب تحديد وتوثيق واعتماد ونشر سياسة الستخدام المقبول للاصول المعلوماتية والتقنية للجهة', NULL, 'ECC 2-1-3', 'Not Applicable', 34, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(64, 'ECC 2-1-4', 'ECC 2-1-4', 'يجب تطبيق سياسة الاستخدام المقبول للاصول المعلوماتية والتقنية للجهة', NULL, 'ECC 2-1-4', 'Not Applicable', 34, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(65, 'ECC 2-1-5', 'ECC 2-1-5', 'يجب تصنيف الاصول المعلوماتية والتقنية للجهة وترميزها )Labeling )والتعامل معها وفقاً للمتطلبات\r\nالتشريعية والتنظيمية ذات العلاقة', NULL, 'ECC 2-1-5', 'Not Applicable', 34, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(66, 'ECC 2-1-6', 'ECC 2-1-6', 'يجب مراجعة متطلبات الامن السيبراني لادارة الاصول المعلوماتية والتقنية للجهة دورياً', NULL, 'ECC 2-1-6', 'Not Applicable', 34, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(67, 'ECC 2-2-1', 'ECC 2-2-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لادارة هويات الدخول والصلاحيات في الجهة', NULL, 'ECC 2-2-1', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(68, 'ECC 2-2-2', 'ECC 2-2-2', 'يجب تطبيق متطلبات الامن السيبراني لادارة هويات الدخول والصلاحيات في الجهة', NULL, 'ECC 2-2-2', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(69, 'ECC 2-2-3', 'ECC 2-2-3', 'يجب أن تغطي متطلبات الامن السيبراني المتعلقة بـإدارة هويات الدخول والصلاحيات في الجهة', NULL, 'ECC 2-2-3', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(70, 'ECC 2-2-3-1', 'ECC 2-2-3-1', 'يجب أن تغطي متطلبات الامن السيبراني المتعلقة بـإدارة هويات الدخول والصلاحيات في الجهة بحد\r\nأدنى  بناء( User Authentication( المستخدم هوية من ا  على إدارة تسجيل المستخدم وإدارة كلمة المرور', NULL, 'ECC 2-2-3-1', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, 69, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(71, 'ECC 2-2-3-2', 'ECC 2-2-3-2', 'يجب أن تغطي متطلبات الامن السيبراني المتعلقة بـإدارة هويات الدخول والصلاحيات في الجهة بحد\r\nأدنى  التحقق من الهوية متعدد العناصر )Authentication Factor-Multi )لعمليات الدخول عن بعد', NULL, 'ECC 2-2-3-2', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, 69, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(72, 'ECC 2-2-3-3', 'ECC 2-2-3-3', 'يجب أن تغطي متطلبات الامن السيبراني المتعلقة بـإدارة هويات الدخول والصلاحيات في الجهة بحد\r\nأدنى   إدارة تصاريح وصلاحيات المستخدمين )Authorization )بناء على مبادئ التحكم بالدخول ،\"Need-to-know and Need-to-use\" والستخدام المعرفة إلى الحاجة مبدأ )و  ومـبـدأ الحد الادنــى مـن الصلاحيات والامـتـيـازات \"Privilege Least ،\"ومـبـدأ فصل المهام  .)\"Segregation of Duties\"', NULL, 'ECC 2-2-3-3', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, 69, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(73, 'ECC 2-2-3-4', 'ECC 2-2-3-4', 'يجب أن تغطي متطلبات الامن السيبراني المتعلقة بـإدارة هويات الدخول والصلاحيات في الجهة بحد\r\nأدنى  .)Privileged Access Management( والحساسة الهامة الاصلاحى  .)Privileged Access Management( والحساسة الهامة الصلاحيايات الإدارة', NULL, 'ECC 2-2-3-4', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, 69, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(74, 'ECC 2-2-3-5', 'ECC 2-2-3-5', 'يجب أن تغطي متطلبات الامن السيبراني المتعلقة بـإدارة هويات الدخول والصلاحيات في الجهة بحد\r\nأدنى  المراجعة الدورية لهويات الدخول والصلاحيات', NULL, 'ECC 2-2-3-5', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, 69, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(75, 'ECC 2-2-4', 'ECC 2-2-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني لادارة هويات الدخول والصلاحيات في الجهة دورياً', NULL, 'ECC 2-2-4', 'Not Applicable', 35, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(76, 'ECC 2-3-1', 'ECC 2-3-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة', NULL, 'ECC 2-3-1', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(77, 'ECC 2-3-2', 'ECC 2-3-2', 'يجب تطبيق متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة.', NULL, 'ECC 2-3-2', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(78, 'ECC 2-3-3', 'ECC 2-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة', NULL, 'ECC 2-3-3', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(79, 'ECC 2-3-3-1', 'ECC 2-3-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة بحد أدنى  الحماية من الفيروسات والبرامج والنشطة المشبوهة والبرمجيات الضارة )Malware )على\r\nأجهزة المستخدمين والخوادم باستخدام تقنيات وآليات الحماية الحديثة والمتقدمة، وإدارتها\r\nبشكل آمن', NULL, 'ECC 2-3-3-1', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, 78, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(80, 'ECC 2-3-3-2', 'ECC 2-3-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة بحد أدنى  التقييد الحازم لستخدام أجهزة وسائط التخزين الخارجية والامن المتعلق بها.', NULL, 'ECC 2-3-3-2', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, 78, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(81, 'ECC 2-3-3-3', 'ECC 2-3-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة بحد أدنى إدارة حزم التحديثات والصلاحات للمنظمة والتطبيقات والاجهزة )Management Patch.', NULL, 'ECC 2-3-3-3', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, 78, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(82, 'ECC 2-3-3-4', 'ECC 2-3-3-4', 'يجب أن تغطي متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة بحد أدنى  مزامنة التوقيت )Synchronization Clock )مركزياً ومن مصدر دقيق وموثوق، ومن هذه\r\nالمصادر ما توفره الهيئة السعودية للمواصفات والمقاييس والجودة.', NULL, 'ECC 2-3-3-4', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, 78, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(83, 'ECC 2-3-4', 'ECC 2-3-4', 'يجب مراجعة متطلبات الامن السيبراني لحماية المنظمة وأجهزة معالجة المعلومات للجهة دورياً', NULL, 'ECC 2-3-4', 'Not Applicable', 36, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(84, 'ECC 2-4-1', 'ECC 2-4-1', 'جب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة.', NULL, 'ECC 2-4-1', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(85, 'ECC 2-4-2', 'ECC 2-4-2', 'يجب تطبيق متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة', NULL, 'ECC 2-4-2', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(86, 'ECC 2-4-3', 'ECC 2-4-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة', NULL, 'ECC 2-4-3', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(87, 'ECC 2-4-3-1', 'ECC 2-4-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة بحد أدنى  تحليل وتصفية )Filtering ) ّ رسـائـل البريد الالكتروني )وخـصـوصـاً رسـائـل التصيد الالكتروني\r\n»Emails Phishing »والرسائل القتحامية »Emails Spam )»باستخدام تقنيات وآليات\r\nالحماية الحديثة والمتقدمة للبريد الالكتروني.', NULL, 'ECC 2-4-3-1', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, 86, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(88, 'ECC 2-4-3-2', 'ECC 2-4-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة بحد أدنى التحقق من الهوية متعدد العناصر )Authentication Factor-Multi )للدخول عن بعد والدخول\r\nعن طريق صفحة موقع البريد الالكتروني )Webmail.', NULL, 'ECC 2-4-3-2', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, 86, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(89, 'ECC 2-4-3-3', 'ECC 2-4-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة بحد أدنى النسخ الاحتياطي والرشفة للبريد الالكتروني.', NULL, 'ECC 2-4-3-3', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, 86, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(90, 'ECC 2-4-3-4', 'ECC 2-4-3-4', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة بحد أدنى لحماية من التهديدات المتقدمة المستمرة )Protection APT ،)التي تستخدم عادة الفيروسات\r\nوالبرمجيات الضارة غير المعروفة مسبقاً )Malware Day-Zero ،)وإدارتها بشكل آمن', NULL, 'ECC 2-4-3-4', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, 86, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(91, 'ECC 2-4-3-5', 'ECC 2-4-3-5', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البريد الالكتروني للجهة بحد أدنى توثيق مجال البريد الالكتروني للجهة بالطرق التقنية، مثل طريقة إطار سياسة المرسل )Sender\r\n.)Policy Framework', NULL, 'ECC 2-4-3-5', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, 86, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(92, 'ECC 2-4-4', 'ECC 2-4-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني الخاصة بحماية البريد الالكتروني للجهة دورياً.', NULL, 'ECC 2-4-4', 'Not Applicable', 37, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(93, 'ECC 2-5-1', 'ECC 2-5-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لادارة أمن شبكات الجهة.', NULL, 'ECC 2-5-1', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(94, 'ECC 2-5-2', 'ECC 2-5-2', 'يجب تطبيق متطلبات الامن السيبراني لادارة أمن شبكات الجهة.', NULL, 'ECC 2-5-2', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(95, 'ECC 2-5-3', 'ECC 2-5-3', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة', NULL, 'ECC 2-5-3', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(96, 'ECC 2-5-3-1', 'ECC 2-5-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى العزل والتقسيم المادي أو المنطقي لجزاء الشبكات بشكل آمن، والالزم للسيطرة على مخاطر\r\nالامن السيبراني ذات العلاقة، باستخدام جدار الحماية )Firewall )ومبدأ الدفاع الامني متعدد\r\n.)Defense-in-Depth( الامر', NULL, 'ECC 2-5-3-1', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(97, 'ECC 2-5-3-2', 'ECC 2-5-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى  عزل شبكة بيئة النتاج عن شبكات بيئات التطوير والاختبار', NULL, 'ECC 2-5-3-2', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(98, 'ECC 2-5-3-3', 'ECC 2-5-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى أمن التصفح والاتصال بالانترنت، ويشمل ذلك التقييد الحازم للمواقع الالكترونية المشبوهة،\r\nومواقع مشاركة وتخزين الملفات، ومواقع الدخول عن بعد', NULL, 'ECC 2-5-3-3', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(99, 'ECC 2-5-3-4', 'ECC 2-5-3-4', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى أمن الشبكات الالسلكية وحمايتها باستخدام وسائل آمنة للتحقق من الهوية والتشفير، وعدم\r\nً على دراسة متكاملة للمخاطر المترتبة\r\nربط الشبكات الالسلكية بشبكة الجهة الداخلية إل بناء\r\nعلى ذلك والتعامل معها بما يضمن حماية الاصول التقنية للجهة', NULL, 'ECC 2-5-3-4', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(100, 'ECC 2-5-3-5', 'ECC 2-5-3-5', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى قيود وإدارة منافذ وبروتوكولت وخدمات الشبكة', NULL, 'ECC 2-5-3-5', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(101, 'ECC 2-5-3-6', 'ECC 2-5-3-6', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى )Intrusion Prevention Systems( الختراقات ومنع لكتشاف المتقدمة الحماية أ', NULL, 'ECC 2-5-3-6', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(102, 'ECC 2-5-3-7', 'ECC 2-5-3-7', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى .)DNS( النطاقات أسماء نظام أ', NULL, 'ECC 2-5-3-7', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(103, 'ECC 2-5-3-8', 'ECC 2-5-3-8', 'يجب أن تغطي متطلبات الامن السيبراني لادارة أمن شبكات الجهة بحد أدنى حماية قناة تصفح الانترنت من التهديدات المتقدمة المستمرة )Protection APT ،)التي\r\nتستخدم عادة الفيروسات والبرمجيات الضارة غير المعروفة مسبقاً )Malware Day-Zero ،)\r\nوإدارتها بشكل آمن.', NULL, 'ECC 2-5-3-8', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, 95, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(104, 'ECC 2-5-4', 'ECC 2-5-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني لادارة أمن شبكات الجهة دورياً.', NULL, 'ECC 2-5-4', 'Not Applicable', 38, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(105, 'ECC 2-6-1', 'ECC 2-6-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني الخاصة بأمن الجهزة المحمولة والاجهزة الشخصية\r\n للعاملين )BYOD )عند ارتباطها بشبكة الجهة.', NULL, 'ECC 2-6-1', 'Not Implemented', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(106, 'ECC 2-6-2', 'ECC 2-6-2', 'يجب تطبيق متطلبات الامن السيبراني الخاصة بأمن الجهزة المحمولة وأجهزة )BYOD )للجهة.', NULL, 'ECC 2-6-2', 'Not Applicable', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(107, 'ECC 2-6-3', 'ECC 2-6-3', 'يجب أن تغطي متطلبات الامن السيبراني الخاصة بأمن الاجهزة المحمولة وأجهزة )BYOD )للجهة', NULL, 'ECC 2-6-3', 'Not Applicable', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(108, 'ECC 2-6-3-1', 'ECC 2-6-3-1', 'يجب أن تغطي متطلبات الامن السيبراني الخاصة بأمن الاجهزة المحمولة وأجهزة )BYOD )للجهة بحد\r\nأدنى فصل وتشفير البيانات والمعلومات )الخاصة بالجهة( المخزنة على الجهزة المحمولة وأجهزة\r\n.)BYOD(', NULL, 'ECC 2-6-3-1', 'Not Applicable', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, 107, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(109, 'ECC 2-6-3-2', 'ECC 2-6-3-2', 'يجب أن تغطي متطلبات الامن السيبراني الخاصة بأمن الاجهزة المحمولة وأجهزة )BYOD )للجهة بحد\r\nأدنى  الستخدام المحدد والمقيد بناء  على ما تتطلبه مصلحة أعمال الجهة', NULL, 'ECC 2-6-3-2', 'Not Applicable', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, 107, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(110, 'ECC 2-6-3-3', 'ECC 2-6-3-3', 'يجب أن تغطي متطلبات الامن السيبراني الخاصة بأمن الاجهزة المحمولة وأجهزة )BYOD )للجهة بحد\r\nأدنى حذف البيانات والمعلومات )الخاصة بالجهة( المخزنة على الجهزة المحمولة وأجهزة )BYOD )\r\nعند فقدان الجهزة أو بعد انتهاء\\/إنهاء العلقة الوظيفية مع الجهة.', NULL, 'ECC 2-6-3-3', 'Not Applicable', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, 107, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(111, 'ECC 2-6-3-4', 'ECC 2-6-3-4', 'يجب أن تغطي متطلبات الامن السيبراني الخاصة بأمن الاجهزة المحمولة وأجهزة )BYOD )للجهة بحد\r\nأدنى  لمستخدمين الامنية ا', NULL, 'ECC 2-6-3-4', 'Not Applicable', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, 107, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(112, 'ECC 2-6-4', 'ECC 2-6-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني الخاصة لامن الاجهزة المحمولة وأجهزة )BYOD )للجهة\r\n.ًدوري', NULL, 'ECC 2-6-4', 'Not Applicable', 39, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(113, 'ECC 2-7-1', 'ECC 2-7-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لحماية بيانات ومعلومات الجهة، والتعامل معها\r\n وفقاً للمتطلبات التشريعية والتنظيمية ذات العلاقة.', NULL, 'ECC 2-7-1', 'Not Applicable', 40, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(114, 'ECC 2-7-2', 'ECC 2-7-2', 'يجب تطبيق متطلبات الامن السيبراني لحماية بيانات ومعلومات الجهة.', NULL, 'ECC 2-7-2', 'Not Applicable', 40, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(115, 'ECC 2-7-3', 'ECC 2-7-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البيانات والمعلومات', NULL, 'ECC 2-7-3', 'Not Applicable', 40, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(116, 'ECC 2-7-3-1', 'ECC 2-7-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البيانات والمعلومات بحد أدنى .والمعلومات البيانات ملكية', NULL, 'ECC 2-7-3-1', 'Not Applicable', 40, 1, NULL, NULL, NULL, 1, NULL, NULL, 115, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(117, 'ECC 2-7-3-2', 'ECC 2-7-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لحماية البيانات والمعلومات بحد أدنى )Classifcation and Labeling Mechanisms( ترميزها وآلية والمعلومات البيانات ت', NULL, 'ECC 2-7-3-2', 'Not Applicable', 40, 1, NULL, NULL, NULL, 1, NULL, NULL, 115, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(118, 'ECC 2-7-3-3', 'ECC 2-7-3-3', 'جب أن تغطي متطلبات الامن السيبراني لحماية البيانات والمعلومات بحد أدنى والمعلومات البيانات خصوصية', NULL, 'ECC 2-7-3-3', 'Not Applicable', 40, 1, NULL, NULL, NULL, 1, NULL, NULL, 115, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(119, 'ECC 2-7-4', 'ECC 2-7-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني لحماية بيانات ومعلومات الجهة دورياً.', NULL, 'ECC 2-7-4', 'Not Applicable', 40, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(120, 'ECC 2-8-1', 'ECC 2-8-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني للتشفير في الجهة.', NULL, 'ECC 2-8-1', 'Not Applicable', 41, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(121, 'ECC 2-8-2', 'ECC 2-8-2', 'يجب تطبيق متطلبات الامن السيبراني للتشفير في الجهة', NULL, 'ECC 2-8-2', 'Not Applicable', 41, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(122, 'ECC 2-8-3', 'ECC 2-8-3', 'جب أن تغطي متطلبات الامن السيبراني للتشفير', NULL, 'ECC 2-8-3', 'Not Applicable', 41, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(123, 'ECC 2-8-3-1', 'ECC 2-8-3-1', 'يجب أن تغطي متطلبات الامن السيبراني للتشفير بحد أدنى معايير حلول التشفير المعتمدة والقيود المطبقة عليها )تقنياً وتنظيمياً(.', NULL, 'ECC 2-8-3-1', 'Not Applicable', 41, 1, NULL, NULL, NULL, 1, NULL, NULL, 122, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(124, 'ECC 2-8-3-2', 'ECC 2-8-3-2', 'يجب أن تغطي متطلبات الامن السيبراني للتشفير بحد أدنى الادارة الامنة لمفاتيح التشفير خلل عمليات دورة حياتها.', NULL, 'ECC 2-8-3-2', 'Not Applicable', 41, 1, NULL, NULL, NULL, 1, NULL, NULL, 122, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(125, 'ECC 2-8-3-3', 'ECC 2-8-3-3', 'يجب أن تغطي متطلبات الامن السيبراني للتشفير بحد أدنى  تشفير البيانات أثناء النقل والتخزين بناء على تصنيفها وحسب المتطلبات التشريعية والتنظيمية\r\nذات العلاقة', NULL, 'ECC 2-8-3-3', 'Not Applicable', 41, 1, NULL, NULL, NULL, 1, NULL, NULL, 122, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(126, 'ECC 2-8-4', 'ECC 2-8-4', 'جب مراجعة تطبيق متطلبات الامن السيبراني للتشفير في الجهة دورياً.', NULL, 'ECC 2-8-4', 'Not Applicable', 41, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(127, 'ECC 2-9-1', 'ECC 2-9-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لادارة النسخ الاحتياطية للجهة', NULL, 'ECC 2-9-1', 'Not Applicable', 42, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(128, 'ECC 2-9-2', 'ECC 2-9-2', 'يجب تطبيق متطلبات الامن السيبراني لادارة النسخ الاحتياطية للجهة.', NULL, 'ECC 2-9-2', 'Not Applicable', 42, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(129, 'ECC 2-9-3', 'ECC 2-9-3', 'يجب أن تغطي متطلبات الامن السيبراني لادارة النسخ الاحتياطية', NULL, 'ECC 2-9-3', 'Not Applicable', 42, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(130, 'ECC 2-9-3-1', 'ECC 2-9-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لادارة النسخ الاحتياطية بحد أدنى  1 نطاق النسخ الااحتياطية وشموليتها للصول المعلوماتية والتقنية الحساسة.', NULL, 'ECC 2-9-3-1', 'Not Applicable', 42, 1, NULL, NULL, NULL, 1, NULL, NULL, 129, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(131, 'ECC 2-9-3-2', 'ECC 2-9-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لادارة النسخ الاحتياطية بحد أدنى  القدرة السريعة على استعادة البيانات والانظمة بعد التعرض لحوادث الامن السيبراني', NULL, 'ECC 2-9-3-2', 'Not Applicable', 42, 1, NULL, NULL, NULL, 1, NULL, NULL, 129, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(132, 'ECC 2-9-3-3', 'ECC 2-9-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لادارة النسخ الاحتياطية بحد أدنى إجراء فحص دوري لمدى فعالية استعادة النسخ الاحتياطية.', NULL, 'ECC 2-9-3-3', 'Not Applicable', 42, 1, NULL, NULL, NULL, 1, NULL, NULL, 129, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(133, 'ECC 2-9-4', 'ECC 2-9-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني لادارة النسخ الاحتياطية للجهة.', NULL, 'ECC 2-9-4', 'Not Applicable', 42, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(134, 'ECC 2-10-1', 'ECC 2-10-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لادارة الثغرات التقنية للجهة.', NULL, 'ECC 2-10-1', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(135, 'ECC 2-10-2', 'ECC 2-10-2', 'يجب تطبيق متطلبات الامن السيبراني لادارة الثغرات التقنية للجهة.', NULL, 'ECC 2-10-2', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(136, 'ECC 2-10-3', 'ECC 2-10-3', 'يجب أن تغطي متطلبات الامن السيبراني لادارة الثغرات', NULL, 'ECC 2-10-3', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(137, 'ECC 2-10-3-1', 'ECC 2-10-3-1', 'يجب أن تغطي متطلبات المن السيبراني لدارة الثغرات بحد أدنى  فحص واكتشاف الثغرات دورياً.', NULL, 'ECC 2-10-3-1', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, 136, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(138, 'ECC 2-10-3-2', 'ECC 2-10-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لادارة الثغرات بحد أدنى تصنيف الثغرات حسب خطورتها', NULL, 'ECC 2-10-3-2', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, 136, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(139, 'ECC 2-10-3-3', 'ECC 2-10-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لادارة الثغرات بحد أدنى على تصنيفها والمخاطر السيبرانية المترتبة عليها.\r\nبناء الثغرات م', NULL, 'ECC 2-10-3-3', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, 136, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(140, 'ECC 2-10-3-4', 'ECC 2-10-3-4', 'يجب أن تغطي متطلبات الامن السيبراني لادارة الثغرات بحد أدنى   إدارة حزم التحديثات والصلاحيات الامنية لمعالجة الثغرات', NULL, 'ECC 2-10-3-4', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, 136, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(141, 'ECC 2-10-3-5', 'ECC 2-10-3-5', 'يجب أن تغطي متطلبات الامن السيبراني لادارة الثغرات بحد أدنى  التواصل والاشتراك مع مصادر موثوقة فيما يتعلق بالتنبيهات المتعلقة بالثغرات الجديدة\r\nوالمحدثة.', NULL, 'ECC 2-10-3-5', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, 136, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(142, 'ECC 2-10-4', 'ECC 2-10-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني لادارة الثغرات التقنية للجهة دورياً.', NULL, 'ECC 2-10-4', 'Not Applicable', 43, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(143, 'ECC 2-11-1', 'ECC 2-11-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لعمليات اختبار الاختراق في الجهة', NULL, 'ECC 2-11-1', 'Not Applicable', 44, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(144, 'ECC 2-11-2', 'ECC 2-11-2', 'يجب تنفيذ عمليات اختبار الاختراق في الجهة', NULL, 'ECC 2-11-2', 'Not Applicable', 44, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(145, 'ECC 2-11-3', 'ECC 2-11-3', 'يجب أن تغطي متطلبات الامن السيبراني لختبار الاختراق', NULL, 'ECC 2-11-3', 'Not Applicable', 44, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(146, 'ECC 2-11-3-1', 'ECC 2-11-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لختبار الاختراق بحد أدنى نطاق عمل اختبار الاخـتـراق، ليشمل جميع الخدمات المقدمة خارجياً )عـن طريق الانترنت(\r\nومكوناتها التقنية، ومنها => البنية التحتية، المواقع الالكترونية، تطبيقات الويب، تطبيقات الهواتف\r\nالذكية والاوحية، البريد الالكتروني والدخول عن بعد.', NULL, 'ECC 2-11-3-1', 'Not Applicable', 44, 1, NULL, NULL, NULL, 1, NULL, NULL, 145, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(147, 'ECC 2-11-3-2', 'ECC 2-11-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لختبار الاختراق بحد أدنى عمل اختبار الاختراق دورياً', NULL, 'ECC 2-11-3-2', 'Not Applicable', 44, 1, NULL, NULL, NULL, 1, NULL, NULL, 145, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(148, 'ECC 2-11-4', 'ECC 2-11-4', 'يجب مراجعة تطبيق متطلبات الامن السيبراني لعمليات اختبار الاختراق في الجهة دورياً.', NULL, 'ECC 2-11-4', 'Not Applicable', 44, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(149, 'ECC 2-12-1', 'ECC 2-12-1', 'يجب تحديد وتوثيق واعتماد متطلبات إدارة سجلت الاحداث ومراقبة الامن السيبراني للجهة.', NULL, 'ECC 2-12-1', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(150, 'ECC 2-12-2', 'ECC 2-12-2', 'يجب تطبيق متطلبات إدارة سجلت الاحداث ومراقبة الامن السيبراني للجهة.', NULL, 'ECC 2-12-2', 'Not Implemented', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(151, 'ECC 2-12-3', 'ECC 2-12-3', 'يجب أن تغطي متطلبات إدارة سجلت الاحداث ومراقبة الامن السيبراني', NULL, 'ECC 2-12-3', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(152, 'ECC 2-12-3-1', 'ECC 2-12-3-1', 'يجب أن تغطي متطلبات إدارة سجلت الأحداث ومراقبة الامن السيبراني بحد أدنى', NULL, 'ECC 2-12-3-1', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, 151, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(153, 'ECC 2-12-3-2', 'ECC 2-12-3-2', 'يجب أن تغطي متطلبات إدارة سجلت الاحداث ومراقبة الامن السيبراني بحد أدنى تفعيل سجلت الاحـداث الخاصة بالحسابات ذات الصلاحيات الهامة والحساسة على الاصول\r\nالمعلوماتية وأحداث عمليات الدخول عن بعد لدى الجهة', NULL, 'ECC 2-12-3-2', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, 151, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(154, 'ECC 2-12-3-3', 'ECC 2-12-3-3', 'يجب أن تغطي متطلبات إدارة سجلات الاحداث ومراقبة الامن السيبراني بحد أدنى تحديد التقنيات الازمة )SIEM )لجمع سجلات الاحداث الخاصة بالامن السيبراني', NULL, 'ECC 2-12-3-3', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, 151, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(155, 'ECC 2-12-3-4', 'ECC 2-12-3-4', 'يجب أن تغطي متطلبات إدارة سجلات الاحداث ومراقبة الامن السيبراني بحد أدنى المراقبة المستمرة لسجلات الاحداث الخاصة بالامن السيبراني.', NULL, 'ECC 2-12-3-4', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, 151, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(156, 'ECC 2-12-3-5', 'ECC 2-12-3-5', 'يجب أن تغطي متطلبات إدارة سجلات الاحداث ومراقبة الامن السيبراني بحد أدنى مدة الاحتفاظ بسجلات الاحداث الخاصة بالامن السيبراني )على أل تقل عن 12 شهر(.', NULL, 'ECC 2-12-3-5', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, 151, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(157, 'ECC 2-12-4', 'ECC 2-12-4', 'يجب مراجعة تطبيق متطلبات إدارة سجلات الاحداث ومراقبة الامن السيبراني في الجهة دورياً.', NULL, 'ECC 2-12-4', 'Not Applicable', 45, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(158, 'ECC 2-13-1', 'ECC 2-13-1', 'يجب تحديد وتوثيق واعتماد متطلبات إدارة حوادث وتهديدات الامن السيبراني في الجهة', NULL, 'ECC 2-13-1', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(159, 'ECC 2-13-2', 'ECC 2-13-2', 'يجب تطبيق متطلبات إدارة حوادث وتهديدات الامن السيبراني في الجهة.', NULL, 'ECC 2-13-2', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(160, 'ECC 2-13-3', 'ECC 2-13-3', 'يجب أن تغطي متطلبات إدارة حوادث وتهديدات الامن السيبراني', NULL, 'ECC 2-13-3', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL);
INSERT INTO `framework_controls` (`id`, `short_name`, `long_name`, `description`, `supplemental_guidance`, `control_number`, `control_status`, `family`, `control_owner`, `desired_maturity`, `control_priority`, `control_class`, `control_maturity`, `control_phase`, `control_type`, `parent_id`, `submission_date`, `last_audit_date`, `next_audit_date`, `desired_frequency`, `mitigation_percent`, `status`, `deleted`, `created_at`, `updated_at`) VALUES
(161, 'ECC 2-13-3-1', 'ECC 2-13-3-1', 'يجب أن تغطي متطلبات إدارة حوادث وتهديدات الامن السيبراني بحد أدنى  وضع خطط الاستجابة للحوادث الامنية وآليات التصعيد.', NULL, 'ECC 2-13-3-1', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, 160, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(162, 'ECC 2-13-3-2', 'ECC 2-13-3-2', 'يجب أن تغطي متطلبات إدارة حوادث وتهديدات الامن السيبراني بحد أدنى تصنيف حوادث الامن السيبراني', NULL, 'ECC 2-13-3-2', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, 160, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(163, 'ECC 2-13-3-3', 'ECC 2-13-3-3', 'يجب أن تغطي متطلبات إدارة حوادث وتهديدات الامن السيبراني بحد أدنى  تبليغ الهيئة عند حدوث حادثة أمن سيبراني', NULL, 'ECC 2-13-3-3', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, 160, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(164, 'ECC 2-13-3-4', 'ECC 2-13-3-4', 'يجب أن تغطي متطلبات إدارة حوادث وتهديدات الامن السيبراني بحد أدنى مشاركة التنبيهات والمعلومات الستباقية ومؤشرات الاختراق وتقارير حوادث الامن السيبراني\r\nمع الهيئة', NULL, 'ECC 2-13-3-4', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, 160, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(165, 'ECC 2-13-3-5', 'ECC 2-13-3-5', 'يجب أن تغطي متطلبات إدارة حوادث وتهديدات الامن السيبراني بحد أدنى الحصول على المعلومات الاستباقية )Intelligence Threat )والتعامل معها.', NULL, 'ECC 2-13-3-5', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, 160, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(166, 'ECC 2-13-4', 'ECC 2-13-4', 'يجب مراجعة تطبيق متطلبات إدارة حوادث وتهديدات الامن السيبراني في الجهة دورياً.', NULL, 'ECC 2-13-4', 'Not Applicable', 46, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(167, 'ECC 2-14-1', 'ECC 2-14-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من\r\nالوصول المادي غير المصرح به والفقدان والسرقة والتخريب.', NULL, 'ECC 2-14-1', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(168, 'ECC 2-14-2', 'ECC 2-14-2', 'يجب تطبيق متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\nغير المصرح به والفقدان والسرقة والتخريب', NULL, 'ECC 2-14-2', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(169, 'ECC 2-14-3', 'ECC 2-14-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\nغير المصرح به والفقدان والسرقة والتخريب', NULL, 'ECC 2-14-3', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(170, 'ECC 2-14-3-1', 'ECC 2-14-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\nغير المصرح به والفقدان والسرقة والتخريب بحد أدنى  الدخول المصرح به للاماكن الحساسة في الجهة )مثل => مركز بيانات الجهة، مركز التعافي من\r\nالكوارث، أماكن معالجة المعلومات الحساسة، مركز المراقبة المنية، غرف اتصالات الشبكة،\r\nمناطق المداد الخاصة بالجهزة والاعداد التقنية، وغيرها(.', NULL, 'ECC 2-14-3-1', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, 169, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(171, 'ECC 2-14-3-2', 'ECC 2-14-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\nغير المصرح به والفقدان والسرقة والتخريب بحد أدنى  .)CCTV( والمراقبة الدخول س', NULL, 'ECC 2-14-3-2', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, 169, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(172, 'ECC 2-14-3-3', 'ECC 2-14-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\nغير المصرح به والفقدان والسرقة والتخريب بحد أدنى  حماية معلومات سجلات الدخول والمراقبة', NULL, 'ECC 2-14-3-3', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, 169, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(173, 'ECC 2-14-3-4', 'ECC 2-14-3-4', 'يجب أن تغطي متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\nغير المصرح به والفقدان والسرقة والتخريب بحد أدنى  أمن إتلف وإعادة استخدام الاصول المادية التي تحوي معلومات مصنفة )وتشمل => الوثائق\r\nالورقية ووسائط الحفظ والتخزين(.', NULL, 'ECC 2-14-3-4', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, 169, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(174, 'ECC 2-14-3-5', 'ECC 2-14-3-5', 'يجب أن تغطي متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\nغير المصرح به والفقدان والسرقة والتخريب بحد أدنى أمن الجهزة والمعدات داخل مباني الجهة وخارجها.', NULL, 'ECC 2-14-3-5', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, 169, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(175, 'ECC 2-14-4', 'ECC 2-14-4', 'جب مراجعة متطلبات الامن السيبراني لحماية الاصول المعلوماتية والتقنية للجهة من الوصول المادي\r\n غير المصرح به والفقدان والسرقة والتخريب دوريا', NULL, 'ECC 2-14-4', 'Not Applicable', 47, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(176, 'ECC 2-15-1', 'ECC 2-15-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة من المخاطر\r\nالسيبرانية', NULL, 'ECC 2-15-1', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(177, 'ECC 2-15-2', 'ECC 2-15-2', 'يجب تطبيق متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة.', NULL, 'ECC 2-15-2', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(178, 'ECC 2-15-3', 'ECC 2-15-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة', NULL, 'ECC 2-15-3', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(179, 'ECC 2-15-3-1', 'ECC 2-15-3-1', 'يجب أن تغطي متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة بحد أدنى .)Web Application Firewall( الويب لتطبيقات الحماية جدار ا', NULL, 'ECC 2-15-3-1', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, 178, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(180, 'ECC 2-15-3-2', 'ECC 2-15-3-2', 'يجب أن تغطي متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة بحد أدنى .)Multi-tier Architecture( المستويات متعددة المعمارية مبدأ ا', NULL, 'ECC 2-15-3-2', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, 178, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(181, 'ECC 2-15-3-3', 'ECC 2-15-3-3', 'يجب أن تغطي متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة بحد أدنى  استخدام بروتوكولات آمنة )مثل بروتوكول HTTPS.', NULL, 'ECC 2-15-3-3', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, 178, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(182, 'ECC 2-15-3-4', 'ECC 2-15-3-4', 'يجب أن تغطي متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة بحد أدنى توضيح سياسة الاستخدام الامن للمستخدمين.', NULL, 'ECC 2-15-3-4', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, 178, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(183, 'ECC 2-15-3-5', 'ECC 2-15-3-5', 'يجب أن تغطي متطلبات الامن السيبراني لحماية تطبيقات الويب الخارجية للجهة بحد أدنى التحقق مـن الهوية متعدد العناصر )Authentication Factor-Multi )لعمليات دخـول\r\nالمستخدمين', NULL, 'ECC 2-15-3-5', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, 178, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(184, 'ECC 2-15-4', 'ECC 2-15-4', 'يجب مراجعة متطلبات الامن السيبراني لحماية تطبيقات الويب للجهة من المخاطر السيبرانية دوريا', NULL, 'ECC 2-15-4', 'Not Applicable', 48, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(185, 'ECC 3-1-1', 'ECC 3-1-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني ضمن إدارة استمرارية أعمال الجهة', NULL, 'ECC 3-1-1', 'Not Applicable', 49, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(186, 'ECC 3-1-2', 'ECC 3-1-2', 'يجب تطبيق متطلبات الامن السيبراني ضمن إدارة استمرارية أعمال الجهة', NULL, 'ECC 3-1-2', 'Not Applicable', 49, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(187, 'ECC 3-1-3', 'ECC 3-1-3', 'يجب أن تغطي إدارة استمرارية العمال في الجهة', NULL, 'ECC 3-1-3', 'Not Applicable', 49, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(188, 'ECC 3-1-3-1', 'ECC 3-1-3-1', 'يجب أن تغطي إدارة استمرارية العمال في الجهة بحد أدنى التأكد من استمرارية الانظمة والجراءات المتعلقة بالامن السيبراني.', NULL, 'ECC 3-1-3-1', 'Not Applicable', 49, 1, NULL, NULL, NULL, 1, NULL, NULL, 187, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(189, 'ECC 3-1-3-2', 'ECC 3-1-3-2', 'يجب أن تغطي إدارة استمرارية العمال في الجهة بحد أدنى وضع خطط الستجابة لحوداث الامن السيبراني التي قد تؤثر على استمرارية أعمال الجهة.', NULL, 'ECC 3-1-3-2', 'Not Applicable', 49, 1, NULL, NULL, NULL, 1, NULL, NULL, 187, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(190, 'ECC 3-1-3-3', 'ECC 3-1-3-3', 'يجب أن تغطي إدارة استمرارية العمال في الجهة بحد أدنى .)Disaster Recovery Plan( الكوارث من التعافي خطط و', NULL, 'ECC 3-1-3-3', 'Not Applicable', 49, 1, NULL, NULL, NULL, 1, NULL, NULL, 187, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(191, 'ECC 3-1-4', 'ECC 3-1-4', 'يجب مراجعة متطلبات الامن السيبراني ضمن إدارة استمرارية أعمال الجهة دورياً.', NULL, 'ECC 3-1-4', 'Not Applicable', 49, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(192, 'ECC 4-1-1', 'ECC 4-1-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامن السيبراني ضمن العقود والتفاقيات مع الاطـراف الخارجية\r\nللجهة.', NULL, 'ECC 4-1-1', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(193, 'ECC 4-1-2', 'ECC 4-1-2', 'يجب أن تغطي متطلبات الامن السيبراني ضمن العقود والتفاقيات )مثل اتفاقية مستوى الخدمة SLA )مع\r\nالاطراف الخارجية التي قد تتأثر بإصابتها بيانات الجهة أو الخدمات المقدمة له', NULL, 'ECC 4-1-2', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(194, 'ECC 4-1-2-1', 'ECC 4-1-2-1', 'يجب أن تغطي متطلبات الامن السيبراني ضمن العقود والتفاقيات )مثل اتفاقية مستوى الخدمة SLA )مع\r\nالاطراف الخارجية التي قد تتأثر بإصابتها بيانات الجهة أو الخدمات المقدمة لها بحد أدنى   بنود المحافظة على سرية المعلومات )Clauses Disclosure-Non ) َ و الحذف الامن من قِ بل\r\nالطرف الخارجي لبيانات الجهة عند انتهاء الخدمة', NULL, 'ECC 4-1-2-1', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, 193, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(195, 'ECC 4-1-2-2', 'ECC 4-1-2-2', 'يجب أن تغطي متطلبات الامن السيبراني ضمن العقود والتفاقيات )مثل اتفاقية مستوى الخدمة SLA )مع\r\nالاطراف الخارجية التي قد تتأثر بإصابتها بيانات الجهة أو الخدمات المقدمة لها بحد أدنى   إجراءات التواصل في حال حدوث حادثة أمن سيبراني.', NULL, 'ECC 4-1-2-2', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, 193, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(196, 'ECC 4-1-2-3', 'ECC 4-1-2-3', 'يجب أن تغطي متطلبات الامن السيبراني ضمن العقود والتفاقيات )مثل اتفاقية مستوى الخدمة SLA )مع\r\nالاطراف الخارجية التي قد تتأثر بإصابتها بيانات الجهة أو الخدمات المقدمة لها بحد أدنى   إلزام الطرف الخارجي بتطبيق متطلبات وسياسات الامن السيبراني للجهة والمتطلبات التشريعية\r\nوالاتنظيمية ذات العلاقة', NULL, 'ECC 4-1-2-3', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, 193, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(197, 'ECC 4-1-3', 'ECC 4-1-3', 'يجب أن تغطي متطلبات الامن السيبراني مع الاطراف الخارجية التي تقدم خدمات إسناد لتقنية المعلومات،\r\nأو خدمات مدارة', NULL, 'ECC 4-1-3', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(198, 'ECC 4-1-3-1', 'ECC 4-1-3-1', 'يجب أن تغطي متطلبات الامن السيبراني مع الاطراف الخارجية التي تقدم خدمات إسناد لتقنية المعلومات،\r\nأو خدمات مدارة بحد أدنى  إجراء تقييم لمخاطر الامن السيبراني، والتأكد من وجود مايضمن السيطرة على تلك المخاطر، قبل\r\nتوقيع العقود والتفاقيات أو عند تغيير المتطلبات التشريعية والاتنظيمية ذات العلاقة.', NULL, 'ECC 4-1-3-1', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, 197, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(199, 'ECC 4-1-3-2', 'ECC 4-1-3-2', 'يجب أن تغطي متطلبات الامن السيبراني مع الاطراف الخارجية التي تقدم خدمات إسناد لتقنية المعلومات،\r\nأو خدمات مدارة بحد أدنى  أن تكون مراكز عمليات خدمات الامن السيبراني المدارة للتشغيل والمراقبة، والتي تستخدم طريقة\r\nالوصول عن بعد، موجودة بالكامل داخل المملكة.', NULL, 'ECC 4-1-3-2', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, 197, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(200, 'ECC 4-1-4', 'ECC 4-1-4', 'يجب مراجعة متطلبات الامن السيبراني مع الاطراف الخارجية دورياً.', NULL, 'ECC 4-1-4', 'Not Applicable', 50, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(201, 'ECC 4-2-1', 'ECC 4-2-1', 'يجب تحديد وتوثيق واعتماد متطلبات الامـن السيبراني الخاصة باستخدام خدمات الحوسبة السحابية\r\nوالاستضافة.', NULL, 'ECC 4-2-1', 'Not Applicable', 51, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(202, 'ECC 4-2-2', 'ECC 4-2-2', 'يجب تطبيق متطلبات الامن السيبراني الخاصة بخدمات الحوسبة السحابية والاستضافة للجهة.', NULL, 'ECC 4-2-2', 'Not Applicable', 51, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(203, 'ECC 4-2-3', 'ECC 4-2-3', 'بما يتوافق مع المتطلبات التشريعية والاتنظيمية ذات العالقة، وبالضافة إلى ما ينطبق من الضوابط ضمن\r\nالمكونات الرئيسية رقم )1 )و )2 )و )3 )والمكون الفرعي رقم )4-1 )الضرورية لحماية بيانات الجهة أو الخدمات\r\nالمقدمة لها، يجب أن تغطي متطلبات الامـن السيبراني الخاصة باستخدام خدمات الحوسبة السحابية\r\nوالاستضافة', NULL, 'ECC 4-2-3', 'Not Applicable', 51, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(204, 'ECC 4-2-3-1', 'ECC 4-2-3-1', 'بما يتوافق مع المتطلبات التشريعية والاتنظيمية ذات العلاقة، وبالضافة إلى ما ينطبق من الضوابط ضمن\r\nالمكونات الرئيسية رقم )1 )و )2 )و )3 )والمكون الفرعي رقم )4-1 )الضرورية لحماية بيانات الجهة أو الخدمات\r\nالمقدمة لها، يجب أن تغطي متطلبات الامـن السيبراني الخاصة باستخدام خدمات الحوسبة السحابية\r\nوالستضافة بحد أدنى   تصنيف البيانات قبل استضافتها لدى مقدمي خدمات الحوسبة السحابية والستضافة، وإعادتها\r\nللجهة )بصيغة قابلة للستخدام( عند إنتهاء الخدمة', NULL, 'ECC 4-2-3-1', 'Not Applicable', 51, 1, NULL, NULL, NULL, 1, NULL, NULL, 203, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(205, 'ECC 4-2-3-2', 'ECC 4-2-3-2', 'بما يتوافق مع المتطلبات التشريعية والاتنظيمية ذات العلاقة، وبالاضافة إلى ما ينطبق من الضوابط ضمن\r\nالمكونات الرئيسية رقم )1 )و )2 )و )3 )والمكون الفرعي رقم )4-1 )الضرورية لحماية بيانات الجهة أو الخدمات\r\nالمقدمة لها، يجب أن تغطي متطلبات الامـن السيبراني الخاصة باستخدام خدمات الحوسبة السحابية\r\nوالاستضافة بحد أدنى  فصل البيئة الخاصة بالجهة )وخصوصاً الخوادم الفتراضية( عن غيرها من البيئات التابعة لجهات\r\nأخرى في خدمات الحوسبة السحابية', NULL, 'ECC 4-2-3-2', 'Not Applicable', 51, 1, NULL, NULL, NULL, 1, NULL, NULL, 203, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(206, 'ECC 4-2-3-3', 'ECC 4-2-3-3', 'بما يتوافق مع المتطلبات التشريعية والاتنظيمية ذات العلاقة، وبالاضافة إلى ما ينطبق من الضوابط ضمن\r\nالمكونات الرئيسية رقم )1 )و )2 )و )3 )والمكون الفرعي رقم )4-1 )الضرورية لحماية بيانات الجهة أو الخدمات\r\nالمقدمة لها، يجب أن تغطي متطلبات الامـن السيبراني الخاصة باستخدام خدمات الحوسبة السحابية\r\nوالاستضافة بحد أدنى  موقع استضافة وتخزين معلومات الجهة يجب أن يكون داخل المملكة.', NULL, 'ECC 4-2-3-3', 'Not Applicable', 51, 1, NULL, NULL, NULL, 1, NULL, NULL, 203, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(207, 'ECC 4-2-4', 'ECC 4-2-4', 'يجب مراجعة متطلبات الامن السيبراني الخاصة بخدمات الحوسبة السحابية والاستضافة دورياً.', NULL, 'ECC 4-2-4', 'Not Applicable', 51, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(208, 'ECC 5-1-1', 'ECC 5-1-1', 'يجب تحديد وتـوثـيـق واعـتـمـاد متطلبات الامــن السيبراني لحماية أجـهـزة وأنـظـمـة التحكم الصناعي\r\n.للجهة( OT\\/ICS(', NULL, 'ECC 5-1-1', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(209, 'ECC 5-1-2', 'ECC 5-1-2', 'يجب تطبيق متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي )ICS\\/OT )للجهة.', NULL, 'ECC 5-1-2', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(210, 'ECC 5-1-3', 'ECC 5-1-3', 'بالضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/O', NULL, 'ECC 5-1-3', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(211, 'ECC 5-1-3-1', 'ECC 5-1-3-1', 'بالضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى  1 الـتـقـيـيـد الــحــازم والـتـقـسـيـم الــمــادي والـمـنـطـقـي عــنــد ربــــط شــبــكــات النــتــاج الـصـنـاعـيـة\r\n)ICS\\/OT )مــع الـشـبـكـات الخــــرى الـتـابـعـة لـلـجـهـة، مـثـل => شبكة الاعــمــال الـداخـلـيـة للجهة\r\n.\"Corporate Network\"', NULL, 'ECC 5-1-3-1', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(212, 'ECC 5-1-3-2', 'ECC 5-1-3-2', 'بالضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى  التقييد الحازم والتقسيم المادي والمنطقي عند ربط الانظمة أو الشبكات الصناعية مع شبكات\r\nخارجية، مثل => الانترنت أو الدخول عن بعد أو الاتصال الاسلكي', NULL, 'ECC 5-1-3-2', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(213, 'ECC 5-1-3-3', 'ECC 5-1-3-3', 'بالضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى  تفعيل سجلات الاحداث )logs Event )الخاصة بالامن السيبراني للشبكة الصناعية والاتصالت\r\nالمرتبطة بها ما أمكن ذلك، والمراقبة المستمرة لها.', NULL, 'ECC 5-1-3-3', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(214, 'ECC 5-1-3-4', 'ECC 5-1-3-4', 'بالضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى  .)Safety Instrumented System “SIS”( السلمة معدات أنظمة ع', NULL, 'ECC 5-1-3-4', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(215, 'ECC 5-1-3-5', 'ECC 5-1-3-5', 'بالاضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى  التقييد الحازم لستخدام وسائط التخزين الخارجية', NULL, 'ECC 5-1-3-5', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(216, 'ECC 5-1-3-6', 'ECC 5-1-3-6', 'الضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى   التقييد الحازم لتوصيل الجهزة المحمولة على شبكة النتاج الصناعية.', NULL, 'ECC 5-1-3-6', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(217, 'ECC 5-1-3-7', 'ECC 5-1-3-7', 'بالاضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى   مراجعة إعدادات وتحصين النظمة الصناعية، وأنظمة الدعم والاجهزة اللية الصناعية )Secure\r\n.ًدوريا( Confguration and Hardening', NULL, 'ECC 5-1-3-7', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(218, 'ECC 5-1-3-8', 'ECC 5-1-3-8', 'بالاضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى   )OT\\/ICS Vulnerability Management( الصناعية اللانظمة ثغرات إدارة', NULL, 'ECC 5-1-3-8', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(219, 'ECC 5-1-3-9', 'ECC 5-1-3-9', 'بالضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى  إدارة حــــــــــزم الـــــتـــــحـــــديـــــثـــــات والصــــــــــــلحــــــــــــات المــــــنــــــيــــــة لـــــانـــــظـــــمـــــة الــــصــــنــــاعــــيــــة\r\n.)OT\\/ICS Patch Management(', NULL, 'ECC 5-1-3-9', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(220, 'ECC 5-1-3-10', 'ECC 5-1-3-10', 'الضافة إلى ما يمكن تطبيقه من الضوابط ضمن المكونات الرئيسية رقم )1 )و )2 )و )3 )و )4 )الضرورية\r\nلحماية بيانات الجهة وخدماتها، فإن متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي\r\n)ICS\\/OT )يجب أن تغطي بحد أدنى   إدارة البرامج الخاصة بالامن السيبراني الصناعي للحماية من الفيروسات والبرمجيات المشبوهة\r\nوالضارة.', NULL, 'ECC 5-1-3-10', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, 210, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(221, 'ECC 5-1-4', 'ECC 5-1-4', 'يجب مراجعة متطلبات الامن السيبراني لحماية أجهزة وأنظمة التحكم الصناعي )ICS\\/OT )للجهة دورياً.', NULL, 'ECC 5-1-4', 'Not Applicable', 52, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(897, 'ECC 1-6-4', 'ECC 1-6-4', 'يجب مراجعة متطلبات الأمن السيبراني في إدارة المشاريع في الجهة دوريًاs', NULL, 'ECC 1-6-4', 'Not Applicable', 29, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 19:29:07', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(898, 'Con1', NULL, 'ss', NULL, 'a502', 'Not Implemented', 25, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-12 16:35:50', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(899, 'Con1', NULL, 'ss', NULL, 'a502', 'Not Implemented', 25, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-12 16:36:20', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(900, 'Con1', NULL, 'ss', NULL, 'a502', 'Not Implemented', 25, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-12 16:36:49', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(901, 'ewrew', NULL, 'klklk', NULL, '63', 'Not Implemented', 25, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-12 16:41:35', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(902, '23456', 'swedrfghj', 'seedfghjkfr', NULL, '123', 'Not Implemented', 25, 1, NULL, NULL, NULL, NULL, NULL, NULL, 898, '2023-11-12 16:45:18', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(903, 'Ira Odom', 'Ray Lynch', 'Sed facilis sequi op', 'Dolor est consequat', '881', 'Not Implemented', 39, 4, 3, 4, 2, 4, 3, 2, 105, '2023-11-12 17:04:29', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(904, 'asd123', NULL, 'ااsds', NULL, '823525524', 'Not Implemented', 24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, '2023-11-12 17:28:17', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(905, 'zaas', 'sdfwf', 'aa', NULL, '123', 'Implemented', 25, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-12 17:29:41', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(906, 'Roth Ewing', 'Peter Franklin', 'Accusamus eu rerum e', 'Cupidatat ut iusto n', '523', 'Not Implemented', 25, 2, 4, 1, 1, 4, 1, 1, 901, '2023-11-13 01:28:27', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(907, 'wwww', NULL, 'ddd', NULL, NULL, 'Not Implemented', 25, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-13 07:29:29', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(908, 'sssss', 'wrwrwe', 'ss', NULL, '123', 'Not Implemented', 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-13 09:34:26', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(909, 'vv', 'rvrv', 'ef', NULL, '11', 'Implemented', 24, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-13 09:37:08', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(910, 'testing', 'TEST', 'd', NULL, '2', 'Not Implemented', 36, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-13 11:45:04', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(911, 'con5', NULL, 'asd', NULL, NULL, 'Not Implemented', 25, 1, NULL, 2, NULL, NULL, NULL, NULL, NULL, '2023-11-13 13:18:22', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(912, 'con787', 'ee', 'asd', NULL, 'a5014', 'Implemented', 25, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-13 13:26:08', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(913, 'hjwjw', 'njxxmj', 'hshjs', NULL, '234566', 'Not Implemented', 25, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-13 13:36:08', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(914, 'Kyra Mcmillan', 'Chloe Wise', 'Et aut maiores et ma', 'Distinctio Exercita', '735', 'Not Implemented', 45, 21, 4, 3, 1, 4, 1, 1, 150, '2023-11-13 14:12:26', NULL, NULL, NULL, 0, 1, 0, NULL, NULL),
(915, 'Control 5523', NULL, 'a new control', NULL, '6363', 'Not Implemented', 25, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-13 15:48:03', NULL, NULL, NULL, 0, 1, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_mappings`
--

CREATE TABLE `framework_control_mappings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `framework_control_id` bigint(20) UNSIGNED NOT NULL,
  `framework_id` bigint(20) UNSIGNED NOT NULL,
  `reference_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_control_mappings`
--

INSERT INTO `framework_control_mappings` (`id`, `framework_control_id`, `framework_id`, `reference_name`, `created_at`, `updated_at`) VALUES
(1, 5, 1, '', NULL, NULL),
(2, 6, 1, '', NULL, NULL),
(3, 7, 1, '', NULL, NULL),
(4, 8, 1, '', NULL, NULL),
(5, 9, 1, '', NULL, NULL),
(6, 10, 1, '', NULL, NULL),
(7, 11, 1, '', NULL, NULL),
(8, 12, 1, '', NULL, NULL),
(9, 13, 1, '', NULL, NULL),
(10, 14, 1, '', NULL, NULL),
(11, 15, 1, '', NULL, NULL),
(12, 16, 1, '', NULL, NULL),
(13, 17, 1, '', NULL, NULL),
(14, 18, 1, '', NULL, NULL),
(15, 19, 1, '', NULL, NULL),
(16, 20, 1, '', NULL, NULL),
(19, 21, 1, '', NULL, NULL),
(20, 22, 1, '', NULL, NULL),
(22, 23, 1, '', NULL, NULL),
(24, 24, 1, '', NULL, NULL),
(25, 25, 1, '', NULL, NULL),
(26, 26, 1, '', NULL, NULL),
(27, 27, 1, '', NULL, NULL),
(29, 28, 1, '', NULL, NULL),
(31, 29, 1, '', NULL, NULL),
(32, 30, 1, '', NULL, NULL),
(34, 31, 1, '', NULL, NULL),
(36, 32, 1, '', NULL, NULL),
(38, 33, 1, '', NULL, NULL),
(40, 34, 1, '', NULL, NULL),
(42, 35, 1, '', NULL, NULL),
(43, 36, 1, '', NULL, NULL),
(44, 37, 1, '', NULL, NULL),
(45, 38, 1, '', NULL, NULL),
(46, 39, 1, '', NULL, NULL),
(47, 40, 1, '', NULL, NULL),
(48, 41, 1, '', NULL, NULL),
(49, 42, 1, '', NULL, NULL),
(51, 43, 1, '', NULL, NULL),
(52, 44, 1, '', NULL, NULL),
(54, 45, 1, '', NULL, NULL),
(55, 46, 1, '', NULL, NULL),
(58, 47, 1, '', NULL, NULL),
(59, 48, 1, '', NULL, NULL),
(60, 49, 1, '', NULL, NULL),
(61, 50, 1, '', NULL, NULL),
(62, 51, 1, '', NULL, NULL),
(63, 52, 1, '', NULL, NULL),
(64, 53, 1, '', NULL, NULL),
(66, 54, 1, '', NULL, NULL),
(68, 55, 1, '', NULL, NULL),
(70, 56, 1, '', NULL, NULL),
(71, 57, 1, '', NULL, NULL),
(73, 58, 1, '', NULL, NULL),
(75, 59, 1, '', NULL, NULL),
(77, 60, 1, '', NULL, NULL),
(78, 61, 1, '', NULL, NULL),
(79, 62, 1, '', NULL, NULL),
(80, 63, 1, '', NULL, NULL),
(81, 64, 1, '', NULL, NULL),
(82, 65, 1, '', NULL, NULL),
(83, 66, 1, '', NULL, NULL),
(84, 67, 1, '', NULL, NULL),
(85, 68, 1, '', NULL, NULL),
(86, 69, 1, '', NULL, NULL),
(87, 70, 1, '', NULL, NULL),
(90, 71, 1, '', NULL, NULL),
(91, 72, 1, '', NULL, NULL),
(93, 73, 1, '', NULL, NULL),
(96, 74, 1, '', NULL, NULL),
(97, 75, 1, '', NULL, NULL),
(98, 76, 1, '', NULL, NULL),
(99, 77, 1, '', NULL, NULL),
(100, 78, 1, '', NULL, NULL),
(102, 79, 1, '', NULL, NULL),
(103, 80, 1, '', NULL, NULL),
(105, 81, 1, '', NULL, NULL),
(107, 82, 1, '', NULL, NULL),
(109, 83, 1, '', NULL, NULL),
(110, 84, 1, '', NULL, NULL),
(111, 85, 1, '', NULL, NULL),
(112, 86, 1, '', NULL, NULL),
(113, 87, 1, '', NULL, NULL),
(115, 88, 1, '', NULL, NULL),
(117, 89, 1, '', NULL, NULL),
(119, 90, 1, '', NULL, NULL),
(122, 91, 1, '', NULL, NULL),
(123, 92, 1, '', NULL, NULL),
(124, 93, 1, '', NULL, NULL),
(125, 94, 1, '', NULL, NULL),
(126, 95, 1, '', NULL, NULL),
(128, 96, 1, '', NULL, NULL),
(129, 97, 1, '', NULL, NULL),
(131, 98, 1, '', NULL, NULL),
(134, 99, 1, '', NULL, NULL),
(135, 100, 1, '', NULL, NULL),
(137, 101, 1, '', NULL, NULL),
(139, 102, 1, '', NULL, NULL),
(141, 103, 1, '', NULL, NULL),
(143, 104, 1, '', NULL, NULL),
(144, 105, 1, '', NULL, NULL),
(145, 106, 1, '', NULL, NULL),
(146, 107, 1, '', NULL, NULL),
(147, 108, 1, '', NULL, NULL),
(149, 109, 1, '', NULL, NULL),
(151, 110, 1, '', NULL, NULL),
(154, 111, 1, '', NULL, NULL),
(155, 112, 1, '', NULL, NULL),
(156, 113, 1, '', NULL, NULL),
(157, 114, 1, '', NULL, NULL),
(158, 115, 1, '', NULL, NULL),
(160, 116, 1, '', NULL, NULL),
(161, 117, 1, '', NULL, NULL),
(163, 118, 1, '', NULL, NULL),
(165, 119, 1, '', NULL, NULL),
(166, 120, 1, '', NULL, NULL),
(167, 121, 1, '', NULL, NULL),
(168, 122, 1, '', NULL, NULL),
(169, 123, 1, '', NULL, NULL),
(171, 124, 1, '', NULL, NULL),
(173, 125, 1, '', NULL, NULL),
(175, 126, 1, '', NULL, NULL),
(176, 127, 1, '', NULL, NULL),
(177, 128, 1, '', NULL, NULL),
(178, 129, 1, '', NULL, NULL),
(179, 130, 1, '', NULL, NULL),
(181, 131, 1, '', NULL, NULL),
(183, 132, 1, '', NULL, NULL),
(185, 133, 1, '', NULL, NULL),
(186, 134, 1, '', NULL, NULL),
(187, 135, 1, '', NULL, NULL),
(188, 136, 1, '', NULL, NULL),
(189, 137, 1, '', NULL, NULL),
(192, 138, 1, '', NULL, NULL),
(193, 139, 1, '', NULL, NULL),
(195, 140, 1, '', NULL, NULL),
(198, 141, 1, '', NULL, NULL),
(199, 142, 1, '', NULL, NULL),
(200, 143, 1, '', NULL, NULL),
(201, 144, 1, '', NULL, NULL),
(202, 145, 1, '', NULL, NULL),
(203, 146, 1, '', NULL, NULL),
(205, 147, 1, '', NULL, NULL),
(207, 148, 1, '', NULL, NULL),
(208, 149, 1, '', NULL, NULL),
(209, 150, 1, '', NULL, NULL),
(210, 151, 1, '', NULL, NULL),
(211, 152, 1, '', NULL, NULL),
(213, 153, 1, '', NULL, NULL),
(215, 154, 1, '', NULL, NULL),
(218, 155, 1, '', NULL, NULL),
(219, 156, 1, '', NULL, NULL),
(221, 157, 1, '', NULL, NULL),
(222, 158, 1, '', NULL, NULL),
(223, 159, 1, '', NULL, NULL),
(224, 160, 1, '', NULL, NULL),
(225, 161, 1, '', NULL, NULL),
(227, 162, 1, '', NULL, NULL),
(230, 163, 1, '', NULL, NULL),
(231, 164, 1, '', NULL, NULL),
(233, 165, 1, '', NULL, NULL),
(235, 166, 1, '', NULL, NULL),
(236, 167, 1, '', NULL, NULL),
(237, 168, 1, '', NULL, NULL),
(238, 169, 1, '', NULL, NULL),
(239, 170, 1, '', NULL, NULL),
(241, 171, 1, '', NULL, NULL),
(243, 172, 1, '', NULL, NULL),
(245, 173, 1, '', NULL, NULL),
(247, 174, 1, '', NULL, NULL),
(249, 175, 1, '', NULL, NULL),
(250, 176, 1, '', NULL, NULL),
(251, 177, 1, '', NULL, NULL),
(252, 178, 1, '', NULL, NULL),
(253, 179, 1, '', NULL, NULL),
(256, 180, 1, '', NULL, NULL),
(257, 181, 1, '', NULL, NULL),
(259, 182, 1, '', NULL, NULL),
(262, 183, 1, '', NULL, NULL),
(263, 184, 1, '', NULL, NULL),
(264, 185, 1, '', NULL, NULL),
(265, 186, 1, '', NULL, NULL),
(266, 187, 1, '', NULL, NULL),
(267, 188, 1, '', NULL, NULL),
(269, 189, 1, '', NULL, NULL),
(271, 190, 1, '', NULL, NULL),
(273, 191, 1, '', NULL, NULL),
(274, 192, 1, '', NULL, NULL),
(275, 193, 1, '', NULL, NULL),
(276, 194, 1, '', NULL, NULL),
(278, 195, 1, '', NULL, NULL),
(280, 196, 1, '', NULL, NULL),
(282, 197, 1, '', NULL, NULL),
(283, 198, 1, '', NULL, NULL),
(285, 199, 1, '', NULL, NULL),
(287, 200, 1, '', NULL, NULL),
(288, 201, 1, '', NULL, NULL),
(289, 202, 1, '', NULL, NULL),
(290, 203, 1, '', NULL, NULL),
(291, 204, 1, '', NULL, NULL),
(294, 205, 1, '', NULL, NULL),
(295, 206, 1, '', NULL, NULL),
(297, 207, 1, '', NULL, NULL),
(298, 208, 1, '', NULL, NULL),
(299, 209, 1, '', NULL, NULL),
(300, 210, 1, '', NULL, NULL),
(301, 211, 1, '', NULL, NULL),
(303, 212, 1, '', NULL, NULL),
(305, 213, 1, '', NULL, NULL),
(307, 214, 1, '', NULL, NULL),
(309, 215, 1, '', NULL, NULL),
(311, 216, 1, '', NULL, NULL),
(314, 217, 1, '', NULL, NULL),
(315, 218, 1, '', NULL, NULL),
(317, 219, 1, '', NULL, NULL),
(320, 220, 1, '', NULL, NULL),
(321, 221, 1, '', NULL, NULL),
(1001, 897, 1, '', NULL, NULL),
(1002, 898, 2, '', NULL, NULL),
(1003, 899, 2, '', NULL, NULL),
(1004, 900, 1, '', NULL, NULL),
(1005, 901, 2, '', NULL, NULL),
(1006, 902, 2, '', NULL, NULL),
(1007, 903, 1, '', NULL, NULL),
(1008, 904, 1, '', NULL, NULL),
(1009, 905, 2, '', NULL, NULL),
(1010, 906, 2, '', NULL, NULL),
(1011, 907, 2, '', NULL, NULL),
(1012, 908, 1, '', NULL, NULL),
(1013, 909, 1, '', NULL, NULL),
(1014, 910, 1, '', NULL, NULL),
(1015, 911, 2, '', NULL, NULL),
(1016, 912, 2, '', NULL, NULL),
(1017, 913, 2, '', NULL, NULL),
(1018, 914, 1, '', NULL, NULL),
(1019, 915, 2, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_tests`
--

CREATE TABLE `framework_control_tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tester` bigint(20) UNSIGNED NOT NULL,
  `test_frequency` int(11) DEFAULT 0,
  `last_date` date DEFAULT NULL,
  `next_date` date DEFAULT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_steps` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approximate_time` int(11) DEFAULT NULL,
  `expected_results` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `framework_control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `additional_stakeholders` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_control_tests`
--

INSERT INTO `framework_control_tests` (`id`, `tester`, `test_frequency`, `last_date`, `next_date`, `name`, `test_steps`, `approximate_time`, `expected_results`, `framework_control_id`, `desired_frequency`, `status`, `additional_stakeholders`, `created_at`, `updated_at`) VALUES
(5, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-1-1', NULL, NULL, NULL, 5, NULL, 1, NULL, NULL, NULL),
(6, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-1-2', NULL, NULL, NULL, 6, NULL, 1, NULL, NULL, NULL),
(7, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-1-3', NULL, NULL, NULL, 7, NULL, 1, NULL, NULL, NULL),
(8, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-2-1', NULL, NULL, NULL, 8, NULL, 1, NULL, NULL, NULL),
(9, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-2-2', NULL, NULL, NULL, 9, NULL, 1, NULL, NULL, NULL),
(10, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-2-3', NULL, NULL, NULL, 10, NULL, 1, NULL, NULL, NULL),
(11, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-3-1', NULL, NULL, NULL, 11, NULL, 1, NULL, NULL, NULL),
(12, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-3-2', NULL, NULL, NULL, 12, NULL, 1, NULL, NULL, NULL),
(13, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-3-3', NULL, NULL, NULL, 13, NULL, 1, NULL, NULL, NULL),
(14, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-3-4', NULL, NULL, NULL, 14, NULL, 1, NULL, NULL, NULL),
(15, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-4-1', NULL, NULL, NULL, 15, NULL, 1, NULL, NULL, NULL),
(16, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-4-2', NULL, NULL, NULL, 16, NULL, 1, NULL, NULL, NULL),
(17, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-1', NULL, NULL, NULL, 17, NULL, 1, NULL, NULL, NULL),
(18, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-2', NULL, NULL, NULL, 18, NULL, 1, NULL, NULL, NULL),
(19, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-3', NULL, NULL, NULL, 19, NULL, 1, NULL, NULL, NULL),
(20, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-3-1', NULL, NULL, NULL, 20, NULL, 1, NULL, NULL, NULL),
(21, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-3-2', NULL, NULL, NULL, 21, NULL, 1, NULL, NULL, NULL),
(22, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-3-3', NULL, NULL, NULL, 22, NULL, 1, NULL, NULL, NULL),
(23, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-3-4', NULL, NULL, NULL, 23, NULL, 1, NULL, NULL, NULL),
(24, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-5-4', NULL, NULL, NULL, 24, NULL, 1, NULL, NULL, NULL),
(25, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-1', NULL, NULL, NULL, 25, NULL, 1, NULL, NULL, NULL),
(26, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-2', NULL, NULL, NULL, 26, NULL, 1, NULL, NULL, NULL),
(27, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-2-1', NULL, NULL, NULL, 27, NULL, 1, NULL, NULL, NULL),
(28, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-2-2', NULL, NULL, NULL, 28, NULL, 1, NULL, NULL, NULL),
(29, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-3', NULL, NULL, NULL, 29, NULL, 1, NULL, NULL, NULL),
(30, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-3-1', NULL, NULL, NULL, 30, NULL, 1, NULL, NULL, NULL),
(31, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-3-2', NULL, NULL, NULL, 31, NULL, 1, NULL, NULL, NULL),
(32, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-3-3', NULL, NULL, NULL, 32, NULL, 1, NULL, NULL, NULL),
(33, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-3-4', NULL, NULL, NULL, 33, NULL, 1, NULL, NULL, NULL),
(34, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-3-5', NULL, NULL, NULL, 34, NULL, 1, NULL, NULL, NULL),
(35, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-7-1', NULL, NULL, NULL, 35, NULL, 1, NULL, NULL, NULL),
(36, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-7-2', NULL, NULL, NULL, 36, NULL, 1, NULL, NULL, NULL),
(37, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-8-1', NULL, NULL, NULL, 37, NULL, 1, NULL, NULL, NULL),
(38, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-8-2', NULL, NULL, NULL, 38, NULL, 1, NULL, NULL, NULL),
(39, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-8-3', NULL, NULL, NULL, 39, NULL, 1, NULL, NULL, NULL),
(40, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-1', NULL, NULL, NULL, 40, NULL, 1, NULL, NULL, NULL),
(41, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-2', NULL, NULL, NULL, 41, NULL, 1, NULL, NULL, NULL),
(42, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-3', NULL, NULL, NULL, 42, NULL, 1, NULL, NULL, NULL),
(43, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-3-1', NULL, NULL, NULL, 43, NULL, 1, NULL, NULL, NULL),
(44, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-3-2', NULL, NULL, NULL, 44, NULL, 1, NULL, NULL, NULL),
(45, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-4', NULL, NULL, NULL, 45, NULL, 1, NULL, NULL, NULL),
(46, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-4-1', NULL, NULL, NULL, 46, NULL, 1, NULL, NULL, NULL),
(47, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-4-2', NULL, NULL, NULL, 47, NULL, 1, NULL, NULL, NULL),
(48, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-5', NULL, NULL, NULL, 48, NULL, 1, NULL, NULL, NULL),
(49, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-9-6', NULL, NULL, NULL, 49, NULL, 1, NULL, NULL, NULL),
(50, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-1', NULL, NULL, NULL, 50, NULL, 1, NULL, NULL, NULL),
(51, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-2', NULL, NULL, NULL, 51, NULL, 1, NULL, NULL, NULL),
(52, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-3', NULL, NULL, NULL, 52, NULL, 1, NULL, NULL, NULL),
(53, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-3-1', NULL, NULL, NULL, 53, NULL, 1, NULL, NULL, NULL),
(54, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-3-2', NULL, NULL, NULL, 54, NULL, 1, NULL, NULL, NULL),
(55, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-3-4', NULL, NULL, NULL, 55, NULL, 1, NULL, NULL, NULL),
(56, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-4', NULL, NULL, NULL, 56, NULL, 1, NULL, NULL, NULL),
(57, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-4-1', NULL, NULL, NULL, 57, NULL, 1, NULL, NULL, NULL),
(58, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-4-3', NULL, NULL, NULL, 58, NULL, 1, NULL, NULL, NULL),
(59, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-4-2', NULL, NULL, NULL, 59, NULL, 1, NULL, NULL, NULL),
(60, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-10-5', NULL, NULL, NULL, 60, NULL, 1, NULL, NULL, NULL),
(61, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-1-1', NULL, NULL, NULL, 61, NULL, 1, NULL, NULL, NULL),
(62, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-1-2', NULL, NULL, NULL, 62, NULL, 1, NULL, NULL, NULL),
(63, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-1-3', NULL, NULL, NULL, 63, NULL, 1, NULL, NULL, NULL),
(64, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-1-4', NULL, NULL, NULL, 64, NULL, 1, NULL, NULL, NULL),
(65, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-1-5', NULL, NULL, NULL, 65, NULL, 1, NULL, NULL, NULL),
(66, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-1-6', NULL, NULL, NULL, 66, NULL, 1, NULL, NULL, NULL),
(67, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-1', NULL, NULL, NULL, 67, NULL, 1, NULL, NULL, NULL),
(68, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-2', NULL, NULL, NULL, 68, NULL, 1, NULL, NULL, NULL),
(69, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-3', NULL, NULL, NULL, 69, NULL, 1, NULL, NULL, NULL),
(70, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-3-1', NULL, NULL, NULL, 70, NULL, 1, NULL, NULL, NULL),
(71, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-3-2', NULL, NULL, NULL, 71, NULL, 1, NULL, NULL, NULL),
(72, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-3-3', NULL, NULL, NULL, 72, NULL, 1, NULL, NULL, NULL),
(73, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-3-4', NULL, NULL, NULL, 73, NULL, 1, NULL, NULL, NULL),
(74, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-3-5', NULL, NULL, NULL, 74, NULL, 1, NULL, NULL, NULL),
(75, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-2-4', NULL, NULL, NULL, 75, NULL, 1, NULL, NULL, NULL),
(76, 1, 0, '2023-11-12', '2023-11-12', 'EEC 2-3-1', NULL, NULL, NULL, 76, NULL, 1, NULL, NULL, NULL),
(77, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-3-2', NULL, NULL, NULL, 77, NULL, 1, NULL, NULL, NULL),
(78, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-3-3', NULL, NULL, NULL, 78, NULL, 1, NULL, NULL, NULL),
(79, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-3-3-1', NULL, NULL, NULL, 79, NULL, 1, NULL, NULL, NULL),
(80, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-3-3-2', NULL, NULL, NULL, 80, NULL, 1, NULL, NULL, NULL),
(81, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-3-3-3', NULL, NULL, NULL, 81, NULL, 1, NULL, NULL, NULL),
(82, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-3-3-4', NULL, NULL, NULL, 82, NULL, 1, NULL, NULL, NULL),
(83, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-3-4', NULL, NULL, NULL, 83, NULL, 1, NULL, NULL, NULL),
(84, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-1', NULL, NULL, NULL, 84, NULL, 1, NULL, NULL, NULL),
(85, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-2', NULL, NULL, NULL, 85, NULL, 1, NULL, NULL, NULL),
(86, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-3', NULL, NULL, NULL, 86, NULL, 1, NULL, NULL, NULL),
(87, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-3-1', NULL, NULL, NULL, 87, NULL, 1, NULL, NULL, NULL),
(88, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-3-2', NULL, NULL, NULL, 88, NULL, 1, NULL, NULL, NULL),
(89, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-3-3', NULL, NULL, NULL, 89, NULL, 1, NULL, NULL, NULL),
(90, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-3-4', NULL, NULL, NULL, 90, NULL, 1, NULL, NULL, NULL),
(91, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-3-5', NULL, NULL, NULL, 91, NULL, 1, NULL, NULL, NULL),
(92, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-4-4', NULL, NULL, NULL, 92, NULL, 1, NULL, NULL, NULL),
(93, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-1', NULL, NULL, NULL, 93, NULL, 1, NULL, NULL, NULL),
(94, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-2', NULL, NULL, NULL, 94, NULL, 1, NULL, NULL, NULL),
(95, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3', NULL, NULL, NULL, 95, NULL, 1, NULL, NULL, NULL),
(96, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-1', NULL, NULL, NULL, 96, NULL, 1, NULL, NULL, NULL),
(97, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-2', NULL, NULL, NULL, 97, NULL, 1, NULL, NULL, NULL),
(98, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-3', NULL, NULL, NULL, 98, NULL, 1, NULL, NULL, NULL),
(99, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-4', NULL, NULL, NULL, 99, NULL, 1, NULL, NULL, NULL),
(100, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-5', NULL, NULL, NULL, 100, NULL, 1, NULL, NULL, NULL),
(101, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-6', NULL, NULL, NULL, 101, NULL, 1, NULL, NULL, NULL),
(102, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-7', NULL, NULL, NULL, 102, NULL, 1, NULL, NULL, NULL),
(103, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-3-8', NULL, NULL, NULL, 103, NULL, 1, NULL, NULL, NULL),
(104, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-5-4', NULL, NULL, NULL, 104, NULL, 1, NULL, NULL, NULL),
(105, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-1', NULL, NULL, NULL, 105, NULL, 1, NULL, NULL, NULL),
(106, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-2', NULL, NULL, NULL, 106, NULL, 1, NULL, NULL, NULL),
(107, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-3', NULL, NULL, NULL, 107, NULL, 1, NULL, NULL, NULL),
(108, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-3-1', NULL, NULL, NULL, 108, NULL, 1, NULL, NULL, NULL),
(109, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-3-2', NULL, NULL, NULL, 109, NULL, 1, NULL, NULL, NULL),
(110, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-3-3', NULL, NULL, NULL, 110, NULL, 1, NULL, NULL, NULL),
(111, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-3-4', NULL, NULL, NULL, 111, NULL, 1, NULL, NULL, NULL),
(112, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-6-4', NULL, NULL, NULL, 112, NULL, 1, NULL, NULL, NULL),
(113, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-7-1', NULL, NULL, NULL, 113, NULL, 1, NULL, NULL, NULL),
(114, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-7-2', NULL, NULL, NULL, 114, NULL, 1, NULL, NULL, NULL),
(115, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-7-3', NULL, NULL, NULL, 115, NULL, 1, NULL, NULL, NULL),
(116, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-7-3-1', NULL, NULL, NULL, 116, NULL, 1, NULL, NULL, NULL),
(117, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-7-3-2', NULL, NULL, NULL, 117, NULL, 1, NULL, NULL, NULL),
(118, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-7-3-3', NULL, NULL, NULL, 118, NULL, 1, NULL, NULL, NULL),
(119, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-7-4', NULL, NULL, NULL, 119, NULL, 1, NULL, NULL, NULL),
(120, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-8-1', NULL, NULL, NULL, 120, NULL, 1, NULL, NULL, NULL),
(121, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-8-2', NULL, NULL, NULL, 121, NULL, 1, NULL, NULL, NULL),
(122, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-8-3', NULL, NULL, NULL, 122, NULL, 1, NULL, NULL, NULL),
(123, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-8-3-1', NULL, NULL, NULL, 123, NULL, 1, NULL, NULL, NULL),
(124, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-8-3-2', NULL, NULL, NULL, 124, NULL, 1, NULL, NULL, NULL),
(125, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-8-3-3', NULL, NULL, NULL, 125, NULL, 1, NULL, NULL, NULL),
(126, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-8-4', NULL, NULL, NULL, 126, NULL, 1, NULL, NULL, NULL),
(127, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-9-1', NULL, NULL, NULL, 127, NULL, 1, NULL, NULL, NULL),
(128, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-9-2', NULL, NULL, NULL, 128, NULL, 1, NULL, NULL, NULL),
(129, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-9-3', NULL, NULL, NULL, 129, NULL, 1, NULL, NULL, NULL),
(130, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-9-3-1', NULL, NULL, NULL, 130, NULL, 1, NULL, NULL, NULL),
(131, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-9-3-2', NULL, NULL, NULL, 131, NULL, 1, NULL, NULL, NULL),
(132, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-9-3-3', NULL, NULL, NULL, 132, NULL, 1, NULL, NULL, NULL),
(133, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-9-4', NULL, NULL, NULL, 133, NULL, 1, NULL, NULL, NULL),
(134, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-1', NULL, NULL, NULL, 134, NULL, 1, NULL, NULL, NULL),
(135, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-2', NULL, NULL, NULL, 135, NULL, 1, NULL, NULL, NULL),
(136, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-3', NULL, NULL, NULL, 136, NULL, 1, NULL, NULL, NULL),
(137, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-3-1', NULL, NULL, NULL, 137, NULL, 1, NULL, NULL, NULL),
(138, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-3-2', NULL, NULL, NULL, 138, NULL, 1, NULL, NULL, NULL),
(139, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-3-3', NULL, NULL, NULL, 139, NULL, 1, NULL, NULL, NULL),
(140, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-3-4', NULL, NULL, NULL, 140, NULL, 1, NULL, NULL, NULL),
(141, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-3-5', NULL, NULL, NULL, 141, NULL, 1, NULL, NULL, NULL),
(142, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-10-4', NULL, NULL, NULL, 142, NULL, 1, NULL, NULL, NULL),
(143, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-11-1', NULL, NULL, NULL, 143, NULL, 1, NULL, NULL, NULL),
(144, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-11-2', NULL, NULL, NULL, 144, NULL, 1, NULL, NULL, NULL),
(145, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-11-3', NULL, NULL, NULL, 145, NULL, 1, NULL, NULL, NULL),
(146, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-11-3-1', NULL, NULL, NULL, 146, NULL, 1, NULL, NULL, NULL),
(147, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-11-3-2', NULL, NULL, NULL, 147, NULL, 1, NULL, NULL, NULL),
(148, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-11-4', NULL, NULL, NULL, 148, NULL, 1, NULL, NULL, NULL),
(149, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-1', NULL, NULL, NULL, 149, NULL, 1, NULL, NULL, NULL),
(150, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-2', NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL),
(151, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-3', NULL, NULL, NULL, 151, NULL, 1, NULL, NULL, NULL),
(152, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-3-1', NULL, NULL, NULL, 152, NULL, 1, NULL, NULL, NULL),
(153, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-3-2', NULL, NULL, NULL, 153, NULL, 1, NULL, NULL, NULL),
(154, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-3-3', NULL, NULL, NULL, 154, NULL, 1, NULL, NULL, NULL),
(155, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-3-4', NULL, NULL, NULL, 155, NULL, 1, NULL, NULL, NULL),
(156, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-3-5', NULL, NULL, NULL, 156, NULL, 1, NULL, NULL, NULL),
(157, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-12-4', NULL, NULL, NULL, 157, NULL, 1, NULL, NULL, NULL),
(158, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-1', NULL, NULL, NULL, 158, NULL, 1, NULL, NULL, NULL),
(159, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-2', NULL, NULL, NULL, 159, NULL, 1, NULL, NULL, NULL),
(160, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-3', NULL, NULL, NULL, 160, NULL, 1, NULL, NULL, NULL),
(161, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-3-1', NULL, NULL, NULL, 161, NULL, 1, NULL, NULL, NULL),
(162, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-3-2', NULL, NULL, NULL, 162, NULL, 1, NULL, NULL, NULL),
(163, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-3-3', NULL, NULL, NULL, 163, NULL, 1, NULL, NULL, NULL),
(164, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-3-4', NULL, NULL, NULL, 164, NULL, 1, NULL, NULL, NULL),
(165, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-3-5', NULL, NULL, NULL, 165, NULL, 1, NULL, NULL, NULL),
(166, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-13-4', NULL, NULL, NULL, 166, NULL, 1, NULL, NULL, NULL),
(167, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-1', NULL, NULL, NULL, 167, NULL, 1, NULL, NULL, NULL),
(168, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-2', NULL, NULL, NULL, 168, NULL, 1, NULL, NULL, NULL),
(169, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-3', NULL, NULL, NULL, 169, NULL, 1, NULL, NULL, NULL),
(170, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-3-1', NULL, NULL, NULL, 170, NULL, 1, NULL, NULL, NULL),
(171, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-3-2', NULL, NULL, NULL, 171, NULL, 1, NULL, NULL, NULL),
(172, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-3-3', NULL, NULL, NULL, 172, NULL, 1, NULL, NULL, NULL),
(173, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-3-4', NULL, NULL, NULL, 173, NULL, 1, NULL, NULL, NULL),
(174, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-3-5', NULL, NULL, NULL, 174, NULL, 1, NULL, NULL, NULL),
(175, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-14-4', NULL, NULL, NULL, 175, NULL, 1, NULL, NULL, NULL),
(176, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-1', NULL, NULL, NULL, 176, NULL, 1, NULL, NULL, NULL),
(177, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-2', NULL, NULL, NULL, 177, NULL, 1, NULL, NULL, NULL),
(178, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-3', NULL, NULL, NULL, 178, NULL, 1, NULL, NULL, NULL),
(179, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-3-1', NULL, NULL, NULL, 179, NULL, 1, NULL, NULL, NULL),
(180, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-3-2', NULL, NULL, NULL, 180, NULL, 1, NULL, NULL, NULL),
(181, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-3-3', NULL, NULL, NULL, 181, NULL, 1, NULL, NULL, NULL),
(182, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-3-4', NULL, NULL, NULL, 182, NULL, 1, NULL, NULL, NULL),
(183, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-3-5', NULL, NULL, NULL, 183, NULL, 1, NULL, NULL, NULL),
(184, 1, 0, '2023-11-12', '2023-11-12', 'ECC 2-15-4', NULL, NULL, NULL, 184, NULL, 1, NULL, NULL, NULL),
(185, 1, 0, '2023-11-12', '2023-11-12', 'ECC 3-1-1', NULL, NULL, NULL, 185, NULL, 1, NULL, NULL, NULL),
(186, 1, 0, '2023-11-12', '2023-11-12', 'ECC 3-1-2', NULL, NULL, NULL, 186, NULL, 1, NULL, NULL, NULL),
(187, 1, 0, '2023-11-12', '2023-11-12', 'ECC 3-1-3', NULL, NULL, NULL, 187, NULL, 1, NULL, NULL, NULL),
(188, 1, 0, '2023-11-12', '2023-11-12', 'ECC 3-1-3-1', NULL, NULL, NULL, 188, NULL, 1, NULL, NULL, NULL),
(189, 1, 0, '2023-11-12', '2023-11-12', 'ECC 3-1-3-2', NULL, NULL, NULL, 189, NULL, 1, NULL, NULL, NULL),
(190, 1, 0, '2023-11-12', '2023-11-12', 'ECC 3-1-3-3', NULL, NULL, NULL, 190, NULL, 1, NULL, NULL, NULL),
(191, 1, 0, '2023-11-12', '2023-11-12', 'ECC 3-1-4', NULL, NULL, NULL, 191, NULL, 1, NULL, NULL, NULL),
(192, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-1', NULL, NULL, NULL, 192, NULL, 1, NULL, NULL, NULL),
(193, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-2', NULL, NULL, NULL, 193, NULL, 1, NULL, NULL, NULL),
(194, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-2-1', NULL, NULL, NULL, 194, NULL, 1, NULL, NULL, NULL),
(195, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-2-2', NULL, NULL, NULL, 195, NULL, 1, NULL, NULL, NULL),
(196, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-2-3', NULL, NULL, NULL, 196, NULL, 1, NULL, NULL, NULL),
(197, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-3', NULL, NULL, NULL, 197, NULL, 1, NULL, NULL, NULL),
(198, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-3-1', NULL, NULL, NULL, 198, NULL, 1, NULL, NULL, NULL),
(199, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-3-2', NULL, NULL, NULL, 199, NULL, 1, NULL, NULL, NULL),
(200, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-1-4', NULL, NULL, NULL, 200, NULL, 1, NULL, NULL, NULL),
(201, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-2-1', NULL, NULL, NULL, 201, NULL, 1, NULL, NULL, NULL),
(202, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-2-2', NULL, NULL, NULL, 202, NULL, 1, NULL, NULL, NULL),
(203, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-2-3', NULL, NULL, NULL, 203, NULL, 1, NULL, NULL, NULL),
(204, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-2-3-1', NULL, NULL, NULL, 204, NULL, 1, NULL, NULL, NULL),
(205, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-2-3-2', NULL, NULL, NULL, 205, NULL, 1, NULL, NULL, NULL),
(206, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-2-3-3', NULL, NULL, NULL, 206, NULL, 1, NULL, NULL, NULL),
(207, 1, 0, '2023-11-12', '2023-11-12', 'ECC 4-2-4', NULL, NULL, NULL, 207, NULL, 1, NULL, NULL, NULL),
(208, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-1', NULL, NULL, NULL, 208, NULL, 1, NULL, NULL, NULL),
(209, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-2', NULL, NULL, NULL, 209, NULL, 1, NULL, NULL, NULL),
(210, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3', NULL, NULL, NULL, 210, NULL, 1, NULL, NULL, NULL),
(211, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-1', NULL, NULL, NULL, 211, NULL, 1, NULL, NULL, NULL),
(212, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-2', NULL, NULL, NULL, 212, NULL, 1, NULL, NULL, NULL),
(213, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-3', NULL, NULL, NULL, 213, NULL, 1, NULL, NULL, NULL),
(214, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-4', NULL, NULL, NULL, 214, NULL, 1, NULL, NULL, NULL),
(215, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-5', NULL, NULL, NULL, 215, NULL, 1, NULL, NULL, NULL),
(216, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-6', NULL, NULL, NULL, 216, NULL, 1, NULL, NULL, NULL),
(217, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-7', NULL, NULL, NULL, 217, NULL, 1, NULL, NULL, NULL),
(218, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-8', NULL, NULL, NULL, 218, NULL, 1, NULL, NULL, NULL),
(219, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-9', NULL, NULL, NULL, 219, NULL, 1, NULL, NULL, NULL),
(220, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-3-10', NULL, NULL, NULL, 220, NULL, 1, NULL, NULL, NULL),
(221, 1, 0, '2023-11-12', '2023-11-12', 'ECC 5-1-4', NULL, NULL, NULL, 221, NULL, 1, NULL, NULL, NULL),
(897, 1, 0, '2023-11-12', '2023-11-12', 'ECC 1-6-4', NULL, NULL, NULL, 897, NULL, 1, NULL, NULL, NULL),
(898, 1, 2, NULL, NULL, 'Con1', 'as', NULL, NULL, 898, NULL, 1, NULL, NULL, NULL),
(899, 1, 2, NULL, NULL, 'Con1', 'as', NULL, NULL, 899, NULL, 1, NULL, NULL, NULL),
(900, 1, 2, NULL, NULL, 'Con1', 'as', NULL, NULL, 900, NULL, 1, NULL, NULL, NULL),
(901, 1, 33, NULL, NULL, 'co2', 'sd', NULL, NULL, 901, NULL, 1, NULL, NULL, NULL),
(902, 1, 12, NULL, NULL, '23456', NULL, NULL, NULL, 902, NULL, 1, NULL, NULL, NULL),
(903, 14, 3, NULL, NULL, 'Ira Odom', 'Sunt veritatis do od', 66, 'Placeat est sit du', 903, NULL, 1, NULL, NULL, NULL),
(904, 25, 6, NULL, NULL, 'asd123', 'jh', 66, NULL, 904, NULL, 1, NULL, NULL, NULL),
(905, 1, 1, NULL, NULL, 'zaa', NULL, NULL, NULL, 905, NULL, 1, NULL, NULL, NULL),
(906, 38, 83, NULL, NULL, 'Roth Ewing', 'Mollitia pariatur V', 11, 'Enim velit aperiam', 906, NULL, 1, NULL, NULL, NULL),
(907, 1, 11, NULL, NULL, 'www', NULL, NULL, NULL, 907, NULL, 1, NULL, NULL, NULL),
(908, 1, 1, NULL, NULL, 'sssss', NULL, NULL, NULL, 908, NULL, 1, NULL, NULL, NULL),
(909, 3, 1, NULL, NULL, 'vv', NULL, NULL, NULL, 909, NULL, 1, NULL, NULL, NULL),
(910, 44, 1, NULL, NULL, 'testing', NULL, NULL, NULL, 910, NULL, 1, NULL, NULL, NULL),
(911, 1, 2, NULL, NULL, 'con5', NULL, NULL, NULL, 911, NULL, 1, NULL, NULL, NULL),
(912, 45, 2, NULL, NULL, 'con787', NULL, NULL, NULL, 912, NULL, 1, NULL, NULL, NULL),
(913, 3, 31, NULL, NULL, 'hjwjw', NULL, NULL, NULL, 913, NULL, 1, NULL, NULL, NULL),
(914, 22, 29, NULL, NULL, 'Kyra Mcmillan', 'Expedita qui veritat', 63, 'Animi et voluptatum', 914, NULL, 1, NULL, NULL, NULL),
(915, 45, 3, NULL, NULL, 'Control 5523', 'sd', 60, NULL, 915, NULL, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_audits`
--

CREATE TABLE `framework_control_test_audits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_id` bigint(20) UNSIGNED NOT NULL,
  `tester` bigint(20) UNSIGNED NOT NULL,
  `test_frequency` int(11) DEFAULT 0,
  `last_date` date DEFAULT NULL,
  `next_date` date DEFAULT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_steps` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approximate_time` int(11) DEFAULT NULL,
  `expected_results` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `framework_control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_control_test_audits`
--

INSERT INTO `framework_control_test_audits` (`id`, `test_id`, `tester`, `test_frequency`, `last_date`, `next_date`, `name`, `test_steps`, `approximate_time`, `expected_results`, `framework_control_id`, `desired_frequency`, `status`, `created_at`, `updated_at`) VALUES
(1, 905, 1, 1, '2023-11-27', '2023-11-13', 'zaa(1)', NULL, NULL, NULL, 905, NULL, 4, '2023-11-12 20:31:03', NULL),
(2, 909, 3, 1, '2023-11-14', '2023-11-14', 'vv(1)', NULL, NULL, NULL, 909, NULL, 3, '2023-11-13 13:31:58', NULL),
(3, 912, 45, 2, '2023-11-14', '2023-11-15', 'con787(1)', NULL, NULL, NULL, 912, NULL, 3, '2023-11-13 16:29:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_comments`
--

CREATE TABLE `framework_control_test_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_audit_id` bigint(20) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` bigint(20) UNSIGNED NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_control_test_comments`
--

INSERT INTO `framework_control_test_comments` (`id`, `test_audit_id`, `date`, `user`, `comment`) VALUES
(1, 1, '2023-11-12 20:32:32', 1, 'ss');

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_results`
--

CREATE TABLE `framework_control_test_results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_audit_id` bigint(20) UNSIGNED NOT NULL,
  `test_result` bigint(20) UNSIGNED DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `submitted_by` int(11) NOT NULL,
  `submission_date` datetime NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_control_test_results`
--

INSERT INTO `framework_control_test_results` (`id`, `test_audit_id`, `test_result`, `summary`, `test_date`, `submitted_by`, `submission_date`, `last_updated`) VALUES
(1, 1, 4, 'zzsz', '2023-11-27', 0, '2023-11-12 00:00:00', '2023-11-12 17:34:38'),
(2, 2, 4, 'test', '2023-11-14', 0, '2023-11-13 00:00:00', '2023-11-13 10:35:30'),
(3, 3, 4, 'sa', '2023-11-14', 0, '2023-11-13 00:00:00', '2023-11-13 15:49:10');

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_results_to_risks`
--

CREATE TABLE `framework_control_test_results_to_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_results_id` bigint(20) UNSIGNED DEFAULT NULL,
  `risk_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_to_frameworks`
--

CREATE TABLE `framework_control_to_frameworks` (
  `control_id` bigint(20) UNSIGNED NOT NULL,
  `framework_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_type_mappings`
--

CREATE TABLE `framework_control_type_mappings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `control_id` bigint(20) UNSIGNED NOT NULL,
  `control_type_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_families`
--

CREATE TABLE `framework_families` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `framework_id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `parent_family_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_families`
--

INSERT INTO `framework_families` (`id`, `framework_id`, `family_id`, `parent_family_id`) VALUES
(1, 1, 1, NULL),
(2, 1, 2, NULL),
(3, 1, 3, NULL),
(4, 1, 4, NULL),
(5, 1, 5, NULL),
(6, 1, 24, 1),
(7, 1, 25, 1),
(8, 1, 26, 1),
(9, 1, 27, 1),
(10, 1, 28, 1),
(11, 1, 29, 1),
(12, 1, 30, 1),
(13, 1, 31, 1),
(14, 1, 32, 1),
(15, 1, 33, 1),
(16, 1, 34, 2),
(17, 1, 35, 2),
(18, 1, 36, 2),
(19, 1, 37, 2),
(20, 1, 38, 2),
(21, 1, 39, 2),
(22, 1, 40, 2),
(23, 1, 41, 2),
(24, 1, 42, 2),
(25, 1, 43, 2),
(26, 1, 44, 2),
(27, 1, 45, 2),
(28, 1, 46, 2),
(29, 1, 47, 2),
(30, 1, 48, 2),
(31, 1, 49, 3),
(32, 1, 50, 4),
(33, 1, 51, 4),
(34, 1, 52, 5),
(35, 2, 1, NULL),
(36, 2, 25, 1);

-- --------------------------------------------------------

--
-- Table structure for table `framework_icons`
--

CREATE TABLE `framework_icons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `impacts`
--

CREATE TABLE `impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `impacts`
--

INSERT INTO `impacts` (`id`, `name`) VALUES
(1, 'Insignificant'),
(2, 'Minor'),
(3, 'Moderate'),
(4, 'Major'),
(5, 'Extreme/Catastrophic');

-- --------------------------------------------------------

--
-- Table structure for table `items_to_teams`
--

CREATE TABLE `items_to_teams` (
  `item_id` int(11) NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items_to_teams`
--

INSERT INTO `items_to_teams` (`item_id`, `team_id`, `type`) VALUES
(1, 7, 'test'),
(2, 10, 'test'),
(3, 4, 'test'),
(4, 8, 'test'),
(5, 2, 'test'),
(6, 4, 'test'),
(7, 2, 'test'),
(8, 4, 'test'),
(9, 6, 'test'),
(10, 1, 'test'),
(11, 6, 'test'),
(12, 3, 'test'),
(13, 7, 'test'),
(14, 4, 'test'),
(15, 3, 'test'),
(16, 4, 'test'),
(17, 10, 'test'),
(18, 9, 'test'),
(19, 10, 'test'),
(20, 7, 'test'),
(905, 18, 'test'),
(909, 3, 'test'),
(912, 2, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `name`, `description`, `code`, `created_at`, `updated_at`) VALUES
(1, 'CEO', 'This job for CEO', '#00001', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(2, 'Department manager', 'This job for department manager', '#00003', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(3, 'Job1', 'Job description1', '#11111', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(4, 'Job2', 'Job description2', '#22222', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(5, 'Job3', 'Job description3', '#33333', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(6, 'Job4', 'Job description4', '#44444', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(7, 'Job5', 'Job description5', '#55555', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(8, 'Job6', 'Job description6', '#66666', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(9, 'Job7', 'Job description7', '#77777', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(10, 'Job8', 'Job description8', '#88888', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(11, 'Job9', 'Job description9', '#99999', '2023-11-12 19:29:03', '2023-11-12 19:29:03'),
(12, 'Job10', 'Job description10', '#101010101', '2023-11-12 19:29:03', '2023-11-12 19:29:03');

-- --------------------------------------------------------

--
-- Table structure for table `kpis`
--

CREATE TABLE `kpis` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `department_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `value_type` enum('Time','Percentage','Number') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_of_assessment` enum('3','6','9','12') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Period in months',
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kpis`
--

INSERT INTO `kpis` (`id`, `department_id`, `title`, `description`, `value_type`, `value`, `period_of_assessment`, `created_by`, `created_at`, `updated_at`) VALUES
(2, 24, 'a', 'sa', 'Percentage', '11', '3', 1, '2023-11-12 20:25:41', '2023-11-12 20:25:41');

-- --------------------------------------------------------

--
-- Table structure for table `kpi_assessments`
--

CREATE TABLE `kpi_assessments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kpi_id` bigint(20) UNSIGNED NOT NULL,
  `assessment_value` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `action_by` bigint(20) UNSIGNED DEFAULT NULL,
  `assessment_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kpi_assessments`
--

INSERT INTO `kpi_assessments` (`id`, `kpi_id`, `assessment_value`, `created_by`, `action_by`, `assessment_date`, `created_at`, `updated_at`) VALUES
(1, 2, '11', 1, 1, '2023-11-12 20:26:08', '2023-11-12 20:25:56', '2023-11-12 20:26:08'),
(2, 2, 'm', 1, 1, '2023-11-13 11:31:17', '2023-11-13 11:31:07', '2023-11-13 11:31:17'),
(3, 2, 'bv', 1, 1, '2023-11-13 15:58:11', '2023-11-13 15:57:01', '2023-11-13 15:58:11'),
(4, 2, 'hgf', 1, 1, '2023-11-13 16:13:01', '2023-11-13 16:12:49', '2023-11-13 16:13:01');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `language`, `created_at`, `updated_at`) VALUES
(1, NULL, 'en', '2023-11-12 19:28:55', '2023-11-12 19:28:55');

-- --------------------------------------------------------

--
-- Table structure for table `likelihoods`
--

CREATE TABLE `likelihoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likelihoods`
--

INSERT INTO `likelihoods` (`id`, `name`) VALUES
(1, 'Remote'),
(2, 'Unlikely'),
(3, 'Credible'),
(4, 'Likely'),
(5, 'Almost Certain');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`) VALUES
(1, 'Location 1'),
(2, 'Location 2'),
(3, 'Location 3'),
(4, 'Location 4'),
(5, 'Location 5'),
(6, 'Location 6'),
(7, 'Location 7'),
(8, 'Location 8'),
(9, 'Location 9'),
(10, 'Location 10'),
(11, 'Location 11'),
(12, 'Location 12'),
(13, 'Location 13'),
(14, 'Location 14'),
(15, 'Location 15'),
(16, 'Location 16'),
(17, 'Location 17'),
(18, 'Location 18'),
(19, 'Location 19'),
(20, 'Location 20');

-- --------------------------------------------------------

--
-- Table structure for table `mail_auto_notfies`
--

CREATE TABLE `mail_auto_notfies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mail_auto_notfies`
--

INSERT INTO `mail_auto_notfies` (`id`, `action_id`, `subject`, `message`, `date`, `status`, `created_at`, `updated_at`) VALUES
(1, 70, 'Notify From Cyber Mode', '{Created_By}e{Name}{Reviewer}{Reviewer}{Reviewer}', '[\"1\"]', 1, '2023-11-12 20:43:01', '2023-11-13 07:11:13');

-- --------------------------------------------------------

--
-- Table structure for table `mail_settings`
--

CREATE TABLE `mail_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mail_settings`
--

INSERT INTO `mail_settings` (`id`, `action_id`, `subject`, `body`, `status`, `created_at`, `updated_at`) VALUES
(1, 4, 'aasd', 'ddsd{Name}v sdf', 1, '2023-11-12 21:12:02', '2023-11-12 21:12:02'),
(2, 25, 'test', 'test', 1, '2023-11-13 13:41:06', '2023-11-13 13:41:06'),
(3, 26, 'test', 'test', 1, '2023-11-13 13:41:15', '2023-11-13 13:41:15'),
(4, 27, 'test', 'test', 1, '2023-11-13 13:41:24', '2023-11-13 13:41:24'),
(5, 22, 'test', '{name}', 1, '2023-11-13 13:41:50', '2023-11-13 13:41:50'),
(6, 23, 'test', '{name}', 1, '2023-11-13 13:42:03', '2023-11-13 13:42:03'),
(7, 24, 'test', '{name}', 1, '2023-11-13 13:42:14', '2023-11-13 13:42:14'),
(8, 68, 'test', '{New_Manager}', 1, '2023-11-13 13:42:26', '2023-11-13 13:42:26'),
(9, 69, 'test', '{New_Manager}', 1, '2023-11-13 13:42:44', '2023-11-13 13:42:44'),
(10, 28, 'test', '{value_type}', 1, '2023-11-13 13:43:04', '2023-11-13 13:43:04'),
(11, 29, 'test', '{description}', 1, '2023-11-13 13:43:18', '2023-11-13 13:43:18'),
(12, 30, 'test', '{title}', 1, '2023-11-13 13:43:31', '2023-11-13 13:43:31'),
(13, 74, 'test', '{Title}', 1, '2023-11-13 13:43:42', '2023-11-13 13:43:42'),
(14, 59, 'test', '{Name}', 1, '2023-11-13 14:41:54', '2023-11-13 14:41:54'),
(15, 60, 'test', '{Name}', 1, '2023-11-13 14:42:08', '2023-11-13 14:42:08'),
(16, 61, 'test', '{Name}', 1, '2023-11-13 14:42:19', '2023-11-13 14:42:19'),
(17, 62, 'test', '{Question}', 1, '2023-11-13 14:42:30', '2023-11-13 14:42:30'),
(18, 63, 'test', '{Question}', 1, '2023-11-13 14:42:38', '2023-11-13 14:42:38'),
(19, 64, 'test', '{Question}', 1, '2023-11-13 14:42:48', '2023-11-13 14:42:48'),
(20, 1, 'test', '{name}', 1, '2023-11-13 14:56:30', '2023-11-13 14:56:30'),
(21, 1, 'test', '{name}', 1, '2023-11-13 14:56:30', '2023-11-13 14:56:30'),
(22, 1, 'test', '{name}', 1, '2023-11-13 14:56:30', '2023-11-13 14:56:30'),
(23, 1, 'test', '{name}', 1, '2023-11-13 14:56:30', '2023-11-13 14:56:30'),
(24, 1, 'test', '{name}', 1, '2023-11-13 14:56:30', '2023-11-13 14:56:30'),
(25, 1, 'test', '{name}', 1, '2023-11-13 14:56:31', '2023-11-13 14:56:31'),
(26, 2, 'test', '{name}', 1, '2023-11-13 15:01:14', '2023-11-13 15:01:14'),
(27, 3, 'test', '{name}', 1, '2023-11-13 15:01:24', '2023-11-13 15:01:24'),
(28, 47, 'test', '{Location}', 1, '2023-11-13 15:13:37', '2023-11-13 15:13:37'),
(29, 48, 'test', '{Alert_Period}', 1, '2023-11-13 15:13:47', '2023-11-13 15:13:47'),
(30, 49, 'test', '{Alert_Period}', 1, '2023-11-13 15:13:59', '2023-11-13 15:13:59'),
(31, 34, 'sd', 'dds', 1, '2023-11-13 18:53:07', '2023-11-13 18:53:07');

-- --------------------------------------------------------

--
-- Table structure for table `mgmt_reviews`
--

CREATE TABLE `mgmt_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `review` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewer` bigint(20) UNSIGNED DEFAULT NULL,
  `next_step_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comments` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_review` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mgmt_reviews`
--

INSERT INTO `mgmt_reviews` (`id`, `risk_id`, `submission_date`, `review`, `reviewer`, `next_step_id`, `comments`, `next_review`) VALUES
(1, 1, '1990-05-07 16:24:26', 2, 1, 1, 'Recusandae commodi recusandae aut sequi eaque modi.', '2005-04-11'),
(2, 2, '1981-02-07 19:03:25', 1, 1, 3, 'Est a maiores sunt molestiae.', '1996-08-13'),
(3, 3, '1985-10-27 22:16:20', 2, 1, 3, 'Doloremque quos aspernatur natus autem blanditiis ipsam vel.', '1973-08-11'),
(4, 4, '2017-10-02 08:12:17', 1, 1, 3, 'Labore consequatur consequuntur earum.', '2022-02-21'),
(5, 5, '2007-10-15 10:18:28', 1, 1, 1, 'Nulla quia quo voluptatum cupiditate quas tempore.', '1982-05-30'),
(6, 6, '1976-03-05 20:09:06', 1, 1, 3, 'Qui dolores cupiditate aut aut optio.', '1992-03-19'),
(7, 7, '1991-05-03 13:10:56', 2, 1, 3, 'Autem et nobis maiores nobis voluptas.', '2020-09-08'),
(8, 8, '2005-12-27 08:15:08', 1, 1, 3, 'Neque sit velit id optio.', '2000-09-14'),
(9, 9, '1991-10-31 09:05:30', 1, 1, 1, 'Autem officia dolores accusantium et nam ipsa.', '1975-01-13'),
(10, 10, '1994-08-10 08:26:49', 1, 1, 1, 'Distinctio tempora labore repellendus dolores ipsum.', '1980-02-15'),
(11, 11, '2000-04-25 23:48:16', 2, 1, 3, 'Optio totam eius non quo nisi.', '2017-02-21'),
(12, 12, '1994-09-11 06:06:18', 2, 1, 3, 'Minus laborum dolore totam provident totam corrupti.', '2011-09-08'),
(13, 13, '2021-01-18 14:55:18', 1, 1, 1, 'Quaerat beatae tenetur et alias ex ea ut.', '2019-12-06'),
(14, 14, '2011-02-04 10:36:54', 1, 1, 3, 'Laudantium deleniti voluptatum nihil voluptatem veritatis dolor.', '2020-07-27'),
(15, 15, '2023-07-04 21:34:00', 2, 1, 3, 'Vel voluptas illo dignissimos voluptatem ipsam rerum saepe.', '2023-02-09'),
(16, 16, '1995-01-14 11:18:04', 1, 1, 1, 'Quia qui necessitatibus hic voluptas a non neque doloribus.', '2020-03-02'),
(17, 17, '1999-08-15 16:30:20', 2, 1, 1, 'Quibusdam repellendus aut nisi sed corrupti nobis.', '2005-08-27'),
(18, 18, '1994-04-11 03:41:27', 2, 1, 3, 'Dolor quam voluptate quia dicta nostrum eligendi voluptatem.', '1983-03-08'),
(19, 19, '2011-01-11 14:33:13', 2, 1, 1, 'Expedita consequatur ut et non dolor ducimus earum officia.', '1974-06-10'),
(20, 20, '1972-01-24 11:19:56', 1, 1, 1, 'Cum dolorem dolorem non corrupti.', '1986-08-20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_08_29_200844_create_languages_table', 1),
(2, '2018_08_29_205156_create_translations_table', 1),
(3, '2021_04_04_122425_create_notifications_table', 1),
(4, '2021_04_04_122525_create_user_notifications_table', 1),
(5, '2022_02_15_091906_create_control_maturities_table', 1),
(6, '2022_02_15_091909_create_impacts_table', 1),
(7, '2022_02_15_091909_create_likelihoods_table', 1),
(8, '2022_02_15_114216_create_questions_table', 1),
(9, '2022_02_16_001499_create_permission_groups_table', 1),
(10, '2022_02_16_001500_create_subgroups_table', 1),
(11, '2022_02_16_001501_create_permissions_table', 1),
(12, '2022_02_16_001503_create_permission_to_permission_groups_table', 1),
(13, '2022_02_16_001504_create_permission_to_users_table', 1),
(14, '2022_02_16_001509_create_roles_table', 1),
(15, '2022_02_16_001510_create_role_responsibilities_table', 1),
(16, '2022_02_16_001601_create_department_colors_table', 1),
(17, '2022_02_16_001602_create_departments_table', 1),
(18, '2022_02_16_001603_create_jobs_table', 1),
(19, '2022_02_16_001700_create_users_table', 1),
(20, '2022_02_16_001702_add_manager_id_to_departments', 1),
(21, '2022_02_16_001703_add_user_id_to_permission_to_users', 1),
(22, '2022_02_16_001800_create_assessments_table', 1),
(23, '2022_02_16_001810_create_assessment_questions_table', 1),
(24, '2022_02_16_001811_create_contributing_risks_likelihood_table', 1),
(25, '2022_02_16_001811_remove_old_assessment_questions_table', 1),
(26, '2022_02_16_001812_create_scoring_methods_table', 1),
(27, '2022_02_16_001819_create_assessment_scorings_table', 1),
(28, '2022_02_16_001820_create_assessment_answers_table', 1),
(29, '2022_02_16_001830_create_asset_groups_table', 1),
(30, '2022_02_16_001840_create_assessment_answers_to_asset_groups_table', 1),
(31, '2022_02_16_001840_create_asset_values_table', 1),
(32, '2022_02_16_001840_create_locations_table', 1),
(33, '2022_02_16_001841_create_assets_table', 1),
(34, '2022_02_16_001850_create_assessment_answers_to_assets_table', 1),
(35, '2022_02_16_001851_create_contributing_risks_table', 1),
(36, '2022_02_16_001860_create_assessment_scoring_contributing_impacts_table', 1),
(37, '2022_02_16_091810_create_asset_asset_groups_table', 1),
(38, '2022_02_16_091811_create_projects_table', 1),
(39, '2022_02_16_091812_create_close_reasons_table', 1),
(40, '2022_02_16_091813_create_sources_table', 1),
(41, '2022_02_16_091814_create_categories_table', 1),
(42, '2022_02_16_091815_create_mitigation_efforts_table', 1),
(43, '2022_02_16_091815_create_planning_strategies_table', 1),
(44, '2022_02_16_091816_create_mitigations_table', 1),
(45, '2022_02_16_091820_create_audit_logs_table', 1),
(46, '2022_02_16_091830_create_backups_table', 1),
(47, '2022_02_16_091880_create_compliance_files_table', 1),
(48, '2022_02_16_091890_create_contributing_risks_impact_table', 1),
(49, '2022_02_16_091905_create_control_classes_table', 1),
(50, '2022_02_16_091907_create_control_phases_table', 1),
(51, '2022_02_16_091908_create_control_priorities_table', 1),
(52, '2022_02_16_091910_create_custom_risk_model_values_table', 1),
(53, '2022_02_16_091911_create_cvss_scorings_table', 1),
(54, '2022_02_16_091912_create_data_classifications_table', 1),
(55, '2022_02_16_091913_create_date_formats_table', 1),
(56, '2022_02_16_091914_create_document_exceptions_table', 1),
(57, '2022_02_16_091915_create_document_exceptions_statuses_table', 1),
(58, '2022_02_16_091916_create_document_statuses_table', 1),
(59, '2022_02_16_091916_create_document_types_table', 1),
(60, '2022_02_16_091918_create_dynamic_saved_selections_table', 1),
(61, '2022_02_16_091919_create_failed_login_attempts_table', 1),
(62, '2022_02_16_091920_create_families_table', 1),
(63, '2022_02_16_091921_create_fields_table', 1),
(64, '2022_02_16_091922_create_file_type_extensions_table', 1),
(65, '2022_02_16_091923_create_control_desired_maturities_table', 1),
(66, '2022_02_16_091923_create_control_owners_table', 1),
(67, '2022_02_16_091923_create_control_types_table', 1),
(68, '2022_02_16_091923_create_file_types_table', 1),
(69, '2022_02_16_091924_create_framework_controls_table', 1),
(70, '2022_02_16_091924_create_frameworks_table', 1),
(71, '2022_02_16_091925_create_framework_control_mappings_table', 1),
(72, '2022_02_16_091925_create_framework_control_tests_table', 1),
(73, '2022_02_16_091925_create_risks_table', 1),
(74, '2022_02_16_091926_add_risk_id_to_mitigations_table', 1),
(75, '2022_02_16_091926_create_closures_table', 1),
(76, '2022_02_16_091926_create_comments_table', 1),
(77, '2022_02_16_091926_create_files_table', 1),
(78, '2022_02_16_091926_create_framework_control_test_audits_table', 1),
(79, '2022_02_16_091926_create_privacies_table', 1),
(80, '2022_02_16_091927_create_documents_table', 1),
(81, '2022_02_16_091927_create_framework_control_test_comments_table', 1),
(82, '2022_02_16_091927_create_test_results_table', 1),
(83, '2022_02_16_091928_create_framework_control_test_results_table', 1),
(84, '2022_02_16_091929_create_framework_control_test_results_to_risks_table', 1),
(85, '2022_02_16_091931_create_framework_control_to_frameworks_table', 1),
(86, '2022_02_16_091932_create_framework_control_type_mappings_table', 1),
(87, '2022_02_16_091935_create_teams_table', 1),
(88, '2022_02_16_091936_create_items_to_teams_table', 1),
(89, '2022_02_16_091939_create_next_steps_table', 1),
(90, '2022_02_16_091939_create_reviews_table', 1),
(91, '2022_02_16_091940_create_mgmt_reviews_table', 1),
(92, '2022_02_16_091941_create_mitigation_accept_users_table', 1),
(93, '2022_02_16_091943_create_mitigation_to_controls_table', 1),
(94, '2022_02_16_091944_create_mitigation_to_teams_table', 1),
(95, '2022_02_16_091947_create_password_resets_table', 1),
(96, '2022_02_16_091948_create_pending_risks_table', 1),
(97, '2022_02_16_091955_create_questionnaire_pending_risks_table', 1),
(98, '2022_02_16_091956_create_regulations_table', 1),
(99, '2022_02_16_091957_create_residual_risk_scoring_histories_table', 1),
(100, '2022_02_16_091959_create_review_levels_table', 1),
(101, '2022_02_16_092000_create_risk_functions_table', 1),
(102, '2022_02_16_092001_create_risk_groupings_table', 1),
(103, '2022_02_16_092002_create_risk_catalogs_table', 1),
(104, '2022_02_16_092003_create_risk_levels_table', 1),
(105, '2022_02_16_092004_create_risk_models_table', 1),
(106, '2022_02_16_092005_create_risk_scorings_table', 1),
(107, '2022_02_16_092006_create_risk_scoring_contributing_impacts_table', 1),
(108, '2022_02_16_092007_create_risk_scoring_histories_table', 1),
(109, '2022_02_16_092008_create_risk_to_additional_stakeholders_table', 1),
(110, '2022_02_16_092009_create_risk_to_locations_table', 1),
(111, '2022_02_16_092010_create_risk_to_teams_table', 1),
(112, '2022_02_16_092010_create_technologies_table', 1),
(113, '2022_02_16_092011_create_risk_to_technologies_table', 1),
(114, '2022_02_16_092013_create_risks_to_asset_groups_table', 1),
(115, '2022_02_16_092014_create_risks_to_assets_table', 1),
(116, '2022_02_16_092018_create_sessions_table', 1),
(117, '2022_02_16_092019_create_settings_table', 1),
(118, '2022_02_16_092021_create_statuses_table', 1),
(119, '2022_02_16_092022_create_tags_table', 1),
(120, '2022_02_16_092023_create_taggables_table', 1),
(121, '2022_02_16_092027_create_test_statuses_table', 1),
(122, '2022_02_16_092027_create_threat_groupings_table', 1),
(123, '2022_02_16_092028_create_threat_catalogs_table', 1),
(124, '2022_02_16_092031_create_user_pass_histories_table', 1),
(125, '2022_02_16_092032_create_user_pass_reuse_histories_table', 1),
(126, '2022_02_16_092033_create_user_to_teams_table', 1),
(127, '2022_02_16_092034_create_validation_files_table', 1),
(128, '2022_03_13_065913_create_tests_table', 1),
(129, '2022_05_17_122632_create_framework_icons_table', 1),
(130, '2022_06_16_123929_create_tasks_table', 1),
(131, '2022_06_16_132507_create_file_tasks_table', 1),
(132, '2022_07_26_145432_create_document_notes_table', 1),
(133, '2022_07_26_145432_create_task_notes_table', 1),
(134, '2022_07_28_105734_create_document_note_files_table', 1),
(135, '2022_07_28_105734_create_task_note_files_table', 1),
(136, '2022_09_22_111859_create_vulnerabilities_table', 1),
(137, '2022_09_22_113422_create_asset_vulnerabilities_table', 1),
(138, '2022_09_22_113907_create_team_vulnerabilities_table', 1),
(139, '2022_09_22_163247_create_service_descriptions_table', 1),
(140, '2022_09_25_134316_create_change_requests_table', 1),
(141, '2022_09_27_113124_create_kpis_table', 1),
(142, '2022_09_28_092653_create_kpi_assessments_table', 1),
(143, '2022_10_10_135818_create_security_awarenesses_table', 1),
(144, '2022_10_10_135953_create_security_awareness_exams_table', 1),
(145, '2022_10_10_141920_create_security_awareness_note_files_table', 1),
(146, '2022_10_10_141931_create_security_awareness_notes_table', 1),
(147, '2022_10_12_124510_create_security_awareness_exam_questions_table', 1),
(148, '2022_10_12_143854_create_security_awareness_exam_answers_table', 1),
(149, '2022_11_07_085943_create_framework_families_table', 1),
(150, '2022_12_01_072257_create_control_audit_policies_table', 1),
(151, '2023_05_21_081556_control_questions_table', 1),
(152, '2023_05_23_113959_create_answer_sub_questions_table', 1),
(153, '2023_05_29_151235_create_control_objectives_table', 1),
(154, '2023_06_07_122411_create_questionnaires_table', 1),
(155, '2023_06_14_115110_create_actions_table', 1),
(156, '2023_06_14_115507_create_system_notifications_settings_table', 1),
(157, '2023_06_14_115528_create_mail_settings_table', 1),
(158, '2023_06_14_115540_create_sms_settings_table', 1),
(159, '2023_06_14_120948_create_notifiables_table', 1),
(160, '2023_07_02_152100_create_contact_questionnaires_table', 1),
(161, '2023_07_02_152119_create_questionnaire_questions_table', 1),
(162, '2023_07_04_164210_create_notifications_roles_table', 1),
(163, '2023_07_10_161349_add_phone_number_to_users_table', 1),
(164, '2023_07_31_130446_create_contact_questionnaire_answers_table', 1),
(165, '2023_07_31_143822_create_contact_questionnaire_answer_results_table', 1),
(166, '2023_08_01_153353_create_controls_control_objectives_table', 1),
(167, '2023_08_07_074507_create_questionnaire_risks_table', 1),
(168, '2023_08_10_132918_create_awareness_surveys_table', 1),
(169, '2023_08_15_160546_create_evidences_table', 1),
(170, '2023_08_21_205235_edit_framework_controls_ids_in_questionnaire_risks_table', 1),
(171, '2023_08_21_205755_add_framework_controls_ids_to_questionnaire_risks', 1),
(172, '2023_08_22_211827_add_control_id_to_questions_table', 1),
(173, '2023_08_23_164048_add_responsible_id_to_controls_control_objectives_table', 1),
(174, '2023_08_23_190533_edit_staus_column_in_contact_questionnaire_answers_table', 1),
(175, '2023_08_24_205218_create_survey_questions_table', 1),
(176, '2023_08_27_152318_add_responsible_type_and_responsible_team_id_to_controls_control_objectives_table', 1),
(177, '2023_08_29_161117_remove_objective_from_framework_control_tests_and_framework_control_test_audits_tables', 1),
(178, '2023_09_06_104900_create_control_audits_objectives_table', 1),
(179, '2023_09_06_105200_create_control_audits_evidences_table', 1),
(180, '2023_09_21_114747_add_due_date_column_to_controls_control_objectives_table', 1),
(181, '2023_09_25_012648_create_user_out_side_cybers_table', 1),
(182, '2023_09_29_135744_create_answer_question_surveys_table', 1),
(183, '2023_10_26_145629_create_auto_notifies_table', 1),
(184, '2023_10_30_180229_create_notify_at_date_models_table', 1),
(185, '2023_11_01_171933_create_mail_auto_notfies', 1),
(186, '2023_11_05_143043_update_framework_control_test_comments_table', 1),
(187, '2023_11_06_154215_change_default_status_of_control', 1),
(188, '2023_11_07_150142_update_evidence_audit_status_column_in_control_audits_evidences_table', 1),
(189, '2023_11_07_154012_create_email_config_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mitigations`
--

CREATE TABLE `mitigations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_update` timestamp NULL DEFAULT NULL,
  `planning_strategy` bigint(20) UNSIGNED DEFAULT NULL,
  `mitigation_effort` bigint(20) UNSIGNED DEFAULT NULL,
  `mitigation_cost` int(11) DEFAULT NULL,
  `mitigation_owner` bigint(20) UNSIGNED DEFAULT NULL,
  `current_solution` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_requirements` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_recommendations` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_by` int(11) NOT NULL DEFAULT 1,
  `planning_date` date NOT NULL,
  `mitigation_percent` int(11) NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mitigations`
--

INSERT INTO `mitigations` (`id`, `submission_date`, `last_update`, `planning_strategy`, `mitigation_effort`, `mitigation_cost`, `mitigation_owner`, `current_solution`, `security_requirements`, `security_recommendations`, `submitted_by`, `planning_date`, `mitigation_percent`, `risk_id`) VALUES
(1, '1981-06-12 16:17:06', '1992-01-21 23:16:34', 3, 4, 47, 1, 'qui', 'corrupti', 'atque', 1, '2015-05-13', 15, 14),
(2, '1988-09-11 00:46:42', '1992-08-07 19:58:36', 2, 2, 67, 1, 'earum', 'neque', 'cum', 1, '1970-01-15', 60, 13),
(3, '1980-08-13 22:08:05', '2014-03-27 11:20:56', 3, 5, 85, 1, 'voluptatem', 'est', 'praesentium', 1, '2013-07-08', 30, 16),
(4, '1980-08-07 23:50:45', '1979-03-01 12:09:46', 3, 3, 4, 1, 'in', 'facilis', 'et', 1, '2004-04-19', 25, 11),
(5, '2002-01-25 23:38:02', '2009-01-12 01:07:11', 3, 4, 54, 1, 'velit', 'maiores', 'eligendi', 1, '1982-11-14', 78, 13),
(6, '1978-03-30 04:04:06', '1979-07-19 13:28:55', 3, 5, 25, 1, 'dolorem', 'nobis', 'aut', 1, '1974-08-04', 47, 10),
(7, '2018-12-14 01:19:19', '2015-02-26 09:27:23', 4, 4, 1, 1, 'aperiam', 'illum', 'vitae', 1, '2022-05-08', 5, 1),
(8, '1971-08-09 00:00:35', '1980-01-13 14:00:29', 4, 3, 75, 1, 'autem', 'sed', 'expedita', 1, '1979-12-02', 14, 8),
(9, '1984-07-15 13:54:13', '1989-05-24 20:58:50', 5, 3, 12, 1, 'voluptate', 'totam', 'reiciendis', 1, '1977-05-09', 89, 18),
(10, '1976-06-08 21:33:16', '1996-08-28 17:54:44', 3, 2, 98, 1, 'aliquam', 'corporis', 'nostrum', 1, '2001-07-15', 52, 13),
(11, '1983-10-11 06:29:16', '2019-01-17 08:54:40', 1, 2, 66, 1, 'at', 'adipisci', 'alias', 1, '2002-04-08', 13, 9),
(12, '2018-09-15 19:15:37', '2000-08-09 21:16:33', 1, 4, 46, 1, 'at', 'magni', 'cum', 1, '1991-01-15', 24, 8),
(13, '2007-08-18 13:36:54', '2000-05-15 04:08:02', 5, 5, 40, 1, 'quia', 'voluptas', 'quo', 1, '1974-02-10', 13, 16),
(14, '2015-05-19 19:42:49', '1990-02-05 21:13:53', 3, 3, 82, 1, 'nobis', 'exercitationem', 'dolore', 1, '2014-03-27', 61, 16),
(15, '1971-12-22 03:37:11', '2000-11-20 07:37:38', 3, 5, 34, 1, 'optio', 'velit', 'velit', 1, '1996-04-21', 40, 6),
(16, '1990-07-05 07:49:57', '2001-03-23 13:24:45', 3, 2, 94, 1, 'rem', 'iure', 'sit', 1, '2018-12-01', 86, 15),
(17, '1984-07-07 19:51:50', '2001-01-12 20:09:23', 2, 4, 57, 1, 'amet', 'quisquam', 'aliquam', 1, '1988-04-04', 60, 17),
(18, '1977-12-31 23:48:32', '2019-07-26 15:57:40', 5, 1, 27, 1, 'in', 'et', 'consectetur', 1, '2015-08-15', 47, 1),
(19, '2016-10-05 14:19:08', '1975-11-27 23:12:14', 1, 5, 33, 1, 'enim', 'distinctio', 'dicta', 1, '2021-08-18', 93, 7),
(20, '2005-12-24 07:01:19', '1988-07-23 04:31:09', 3, 2, 61, 1, 'impedit', 'ea', 'perferendis', 1, '1982-01-01', 57, 20);

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_accept_users`
--

CREATE TABLE `mitigation_accept_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_efforts`
--

CREATE TABLE `mitigation_efforts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mitigation_efforts`
--

INSERT INTO `mitigation_efforts` (`id`, `name`) VALUES
(1, 'Insignificante'),
(2, 'Menor'),
(3, 'Considerable'),
(4, 'Significante'),
(5, 'Excepcional');

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_to_controls`
--

CREATE TABLE `mitigation_to_controls` (
  `mitigation_id` bigint(20) UNSIGNED NOT NULL,
  `control_id` bigint(20) UNSIGNED NOT NULL,
  `validation_details` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_owner` int(11) NOT NULL,
  `validation_mitigation_percent` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_to_teams`
--

CREATE TABLE `mitigation_to_teams` (
  `mitigation_id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `next_steps`
--

CREATE TABLE `next_steps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `next_steps`
--

INSERT INTO `next_steps` (`id`, `name`) VALUES
(1, 'Accept Until Next Review'),
(3, 'Submit as a Production Issue');

-- --------------------------------------------------------

--
-- Table structure for table `notifiables`
--

CREATE TABLE `notifiables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `notifiable_id` int(11) NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifiables`
--

INSERT INTO `notifiables` (`id`, `user_id`, `notifiable_id`, `notifiable_type`) VALUES
(1, 1, 1, 'App\\Models\\SystemNotificationSetting'),
(2, 1, 2, 'App\\Models\\SystemNotificationSetting'),
(3, 1, 3, 'App\\Models\\SystemNotificationSetting'),
(4, 1, 7, 'App\\Models\\SystemNotificationSetting'),
(5, 1, 11, 'App\\Models\\SystemNotificationSetting'),
(6, 1, 12, 'App\\Models\\SystemNotificationSetting'),
(7, 1, 13, 'App\\Models\\SystemNotificationSetting'),
(8, 1, 14, 'App\\Models\\SystemNotificationSetting'),
(9, 1, 15, 'App\\Models\\SystemNotificationSetting'),
(10, 1, 17, 'App\\Models\\SystemNotificationSetting'),
(11, 1, 18, 'App\\Models\\SystemNotificationSetting'),
(12, 1, 19, 'App\\Models\\SystemNotificationSetting'),
(13, 1, 20, 'App\\Models\\SystemNotificationSetting'),
(14, 1, 21, 'App\\Models\\SystemNotificationSetting'),
(15, 1, 22, 'App\\Models\\SystemNotificationSetting'),
(16, 1, 23, 'App\\Models\\SystemNotificationSetting'),
(17, 1, 24, 'App\\Models\\SystemNotificationSetting'),
(18, 1, 25, 'App\\Models\\SystemNotificationSetting'),
(19, 1, 26, 'App\\Models\\SystemNotificationSetting'),
(20, 1, 27, 'App\\Models\\SystemNotificationSetting'),
(21, 1, 28, 'App\\Models\\SystemNotificationSetting'),
(22, 1, 29, 'App\\Models\\SystemNotificationSetting'),
(23, 1, 30, 'App\\Models\\SystemNotificationSetting'),
(24, 1, 31, 'App\\Models\\SystemNotificationSetting'),
(25, 1, 32, 'App\\Models\\SystemNotificationSetting'),
(26, 1, 33, 'App\\Models\\SystemNotificationSetting'),
(27, 1, 34, 'App\\Models\\SystemNotificationSetting'),
(28, 1, 35, 'App\\Models\\SystemNotificationSetting'),
(29, 1, 37, 'App\\Models\\SystemNotificationSetting'),
(30, 1, 1, 'App\\Models\\AutoNotify'),
(31, 1, 1, 'App\\Models\\MailAutoNotify'),
(32, 43, 1, 'App\\Models\\MailSetting'),
(34, 1, 41, 'App\\Models\\SystemNotificationSetting'),
(35, 1, 43, 'App\\Models\\SystemNotificationSetting'),
(36, 1, 44, 'App\\Models\\SystemNotificationSetting'),
(37, 1, 45, 'App\\Models\\SystemNotificationSetting'),
(38, 1, 2, 'App\\Models\\MailSetting'),
(39, 1, 3, 'App\\Models\\MailSetting'),
(40, 1, 4, 'App\\Models\\MailSetting'),
(41, 1, 5, 'App\\Models\\MailSetting'),
(42, 1, 6, 'App\\Models\\MailSetting'),
(43, 1, 7, 'App\\Models\\MailSetting'),
(44, 1, 8, 'App\\Models\\MailSetting'),
(45, 1, 10, 'App\\Models\\MailSetting'),
(46, 1, 11, 'App\\Models\\MailSetting'),
(47, 1, 12, 'App\\Models\\MailSetting'),
(48, 1, 46, 'App\\Models\\SystemNotificationSetting'),
(49, 1, 47, 'App\\Models\\SystemNotificationSetting'),
(50, 1, 48, 'App\\Models\\SystemNotificationSetting'),
(51, 1, 49, 'App\\Models\\SystemNotificationSetting'),
(52, 1, 50, 'App\\Models\\SystemNotificationSetting'),
(53, 1, 51, 'App\\Models\\SystemNotificationSetting'),
(54, 1, 14, 'App\\Models\\MailSetting'),
(55, 1, 15, 'App\\Models\\MailSetting'),
(56, 1, 16, 'App\\Models\\MailSetting'),
(57, 1, 52, 'App\\Models\\SystemNotificationSetting'),
(58, 1, 53, 'App\\Models\\SystemNotificationSetting'),
(59, 1, 54, 'App\\Models\\SystemNotificationSetting'),
(60, 1, 20, 'App\\Models\\MailSetting'),
(61, 1, 21, 'App\\Models\\MailSetting'),
(62, 1, 22, 'App\\Models\\MailSetting'),
(63, 1, 23, 'App\\Models\\MailSetting'),
(64, 1, 24, 'App\\Models\\MailSetting'),
(65, 1, 25, 'App\\Models\\MailSetting'),
(66, 1, 27, 'App\\Models\\MailSetting'),
(67, 1, 55, 'App\\Models\\SystemNotificationSetting'),
(68, 1, 56, 'App\\Models\\SystemNotificationSetting'),
(69, 1, 57, 'App\\Models\\SystemNotificationSetting'),
(70, 1, 28, 'App\\Models\\MailSetting'),
(71, 1, 29, 'App\\Models\\MailSetting'),
(72, 1, 30, 'App\\Models\\MailSetting'),
(73, 1, 58, 'App\\Models\\SystemNotificationSetting'),
(74, 1, 59, 'App\\Models\\SystemNotificationSetting'),
(75, 1, 60, 'App\\Models\\SystemNotificationSetting'),
(76, 1, 62, 'App\\Models\\SystemNotificationSetting'),
(77, 1, 31, 'App\\Models\\MailSetting');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `message`, `notification_type`, `meta`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'asd sdsd', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-12 19:38:40', NULL),
(2, 'asd Add5', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-12 20:19:18', NULL),
(3, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-12 20:22:16', NULL),
(4, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-12 20:22:16', NULL),
(5, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-12 20:22:29', NULL),
(6, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-12 20:22:29', NULL),
(7, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-12 20:22:39', NULL),
(8, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-12 20:22:39', NULL),
(9, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-12 20:22:44', NULL),
(10, 'ss', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-12 20:25:00', NULL),
(11, 'ss', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-12 20:25:17', NULL),
(12, 'ee', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-12 20:25:21', NULL),
(13, 'ss', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-12 20:25:41', NULL),
(14, 'cc', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-12 20:25:56', NULL),
(15, 'a', 'notification', 'a:1:{s:4:\"link\";s:59:\"https://www.advancedcontrols.sa/grc/public/admin/governance\";}', NULL, '2023-11-12 20:27:10', NULL),
(16, 'we', 'notification', 'a:1:{s:4:\"link\";s:59:\"https://www.advancedcontrols.sa/grc/public/admin/governance\";}', NULL, '2023-11-12 20:27:20', NULL),
(17, 'eeq', 'notification', 'a:1:{s:4:\"link\";s:59:\"https://www.advancedcontrols.sa/grc/public/admin/governance\";}', NULL, '2023-11-12 20:27:27', NULL),
(18, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:30:04', NULL),
(19, 'Department1 Employee1', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:30:37', NULL),
(20, 'Department1 Employee1', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:30:37', NULL),
(21, '{Control_class}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:31:03', NULL),
(22, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:33:38', NULL),
(23, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:33:38', NULL),
(24, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:33:38', NULL),
(25, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-12 20:34:16', NULL),
(26, 'zaa(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-12 20:34:38', NULL),
(27, 'zaa(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-12 20:34:59', NULL),
(28, 'zaa(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-12 20:35:17', NULL),
(29, 'HIPAA (April 2016)', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-12 20:41:40', NULL),
(30, 'HIPAA (April 2016)', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-12 20:41:45', NULL),
(31, 'Critical Security Controls', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-12 20:41:56', NULL),
(32, 'Critical Security Controls', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-12 20:41:56', NULL),
(33, 'Critical Security Controls', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-12 20:42:06', NULL),
(34, 'asd zxx', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-12 20:42:40', NULL),
(35, 'Employee Admin create and assign task (xx) to you', 'notification', 'a:1:{s:4:\"link\";s:68:\"https://www.advancedcontrols.sa/grc/public/admin/task/assigned-to-me\";}', 12, '2023-11-12 20:49:35', NULL),
(36, 'Employee Admin update task (title 1z)', 'notification', 'a:1:{s:4:\"link\";s:68:\"https://www.advancedcontrols.sa/grc/public/admin/task/assigned-to-me\";}', 12, '2023-11-12 20:49:48', NULL),
(37, 'Employee Admin update status of task (title 4) from Open to Completed', 'notification', 'a:1:{s:4:\"link\";s:53:\"https://www.advancedcontrols.sa/grc/public/admin/task\";}', 12, '2023-11-12 20:50:09', NULL),
(38, 'Roth Ewing', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 04:28:27', NULL),
(39, 'Roth Ewing', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 04:28:27', NULL),
(40, 'Roth Ewing', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 04:28:27', NULL),
(41, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 04:28:41', NULL),
(42, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 04:28:41', NULL),
(43, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 07:12:53', NULL),
(44, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 07:12:53', NULL),
(45, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 07:12:58', NULL),
(46, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 07:13:23', NULL),
(47, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 07:13:23', NULL),
(48, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 07:13:23', NULL),
(49, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 07:13:23', NULL),
(50, 'www', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 10:29:29', NULL),
(51, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 10:29:47', NULL),
(52, 'asd frf', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 10:30:30', NULL),
(53, 'zzPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 10:37:07', NULL),
(54, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 11:29:06', NULL),
(55, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 11:29:06', NULL),
(56, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 11:29:15', NULL),
(57, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 11:29:15', NULL),
(58, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 11:29:20', NULL),
(59, 'ss', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-13 11:30:24', NULL),
(60, 'ss', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-13 11:30:34', NULL),
(61, 'ee', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-13 11:30:40', NULL),
(62, 'cc', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-13 11:31:07', NULL),
(63, 'wdwdwPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 11:42:57', NULL),
(64, 'wdwdwPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 11:42:57', NULL),
(65, 'wdwdwPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 11:42:57', NULL),
(66, 'asd Alana Bolton', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 11:52:57', NULL),
(67, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 12:08:14', NULL),
(68, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 12:08:14', NULL),
(69, 'test', 'notification', 'a:1:{s:4:\"link\";s:69:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy/department\";}', NULL, '2023-11-13 12:08:14', NULL),
(70, 'xaxacPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:19:20', NULL),
(71, 'xaxacPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:19:20', NULL),
(72, 'xaxacPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:19:20', NULL),
(73, 'Admin', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:19:57', NULL),
(74, 'Admin', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:19:57', NULL),
(75, 'Admin', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:19:57', NULL),
(76, 'xaxac', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:20:07', NULL),
(77, 'xaxac', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:20:07', NULL),
(78, 'xaxac', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 12:20:07', NULL),
(79, 'sssss', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 12:34:26', NULL),
(80, 'sssss', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 12:34:26', NULL),
(81, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 12:35:16', NULL),
(82, '{Expected_Results}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 12:35:16', NULL),
(83, 'vv', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 12:37:08', NULL),
(84, 'vv', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 12:37:08', NULL),
(85, 'vv', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 12:37:08', NULL),
(86, 'dwwdPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 13:30:28', NULL),
(87, 'dwwdPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 13:30:28', NULL),
(88, 'dwwdPrivate', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 13:30:28', NULL),
(89, '{Control_class}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 13:31:58', NULL),
(90, '{Control_class}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 13:31:58', NULL),
(91, '{Control_class}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 13:31:58', NULL),
(92, 'vv(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 13:35:30', NULL),
(93, 'vv(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 13:35:30', NULL),
(94, 'vv(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 13:35:30', NULL),
(95, 'vv(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 13:37:24', NULL),
(96, 'vv(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 13:37:24', NULL),
(97, 'vv(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 13:37:24', NULL),
(98, '{Owner}', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:38:23', NULL),
(99, '{Owner}', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:38:23', NULL),
(100, '()', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:38:34', NULL),
(101, '()', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:38:34', NULL),
(102, '{Mitigation_Coast}', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:38:43', NULL),
(103, '{NextStep}', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:38:52', NULL),
(104, '{status}', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:39:04', NULL),
(105, 'azzjm', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:39:26', NULL),
(106, 'azzjm', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/29\";}', NULL, '2023-11-13 13:39:31', NULL),
(107, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 13:47:39', NULL),
(108, 'test', 'notification', 'a:1:{s:4:\"link\";s:58:\"https://www.advancedcontrols.sa/grc/public/admin/hierarchy\";}', NULL, '2023-11-13 13:47:39', NULL),
(109, 'test', 'notification', 'a:1:{s:4:\"link\";s:60:\"https://www.advancedcontrols.sa/grc/public/admin/assessments\";}', NULL, '2023-11-13 14:43:05', NULL),
(110, 'test', 'notification', 'a:1:{s:4:\"link\";s:60:\"https://www.advancedcontrols.sa/grc/public/admin/assessments\";}', NULL, '2023-11-13 14:43:17', NULL),
(111, 'test', 'notification', 'a:1:{s:4:\"link\";s:60:\"https://www.advancedcontrols.sa/grc/public/admin/assessments\";}', NULL, '2023-11-13 14:43:21', NULL),
(112, 'testing', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:45:04', NULL),
(113, 'testing', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:45:04', NULL),
(114, 'testing', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:45:04', NULL),
(115, 'Ali', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:46:19', NULL),
(116, 'Ali', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:46:19', NULL),
(117, 'Ali', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:46:19', NULL),
(118, 'Ali', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:47:41', NULL),
(119, 'Ali', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:47:41', NULL),
(120, 'Ali', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 14:47:41', NULL),
(121, 'wfat', 'notification', 'a:1:{s:4:\"link\";s:60:\"https://www.advancedcontrols.sa/grc/public/admin/assessments\";}', NULL, '2023-11-13 14:49:27', NULL),
(122, 'wfat', 'notification', 'a:1:{s:4:\"link\";s:60:\"https://www.advancedcontrols.sa/grc/public/admin/assessments\";}', NULL, '2023-11-13 14:49:27', NULL),
(123, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:52:36', NULL),
(124, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:52:36', NULL),
(125, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:52:58', NULL),
(126, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:53:19', NULL),
(127, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:53:54', NULL),
(128, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:54:19', NULL),
(129, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:55:11', NULL),
(130, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:55:12', NULL),
(131, 'NIST 800-171', 'notification', 'a:1:{s:4:\"link\";s:63:\"https://www.advancedcontrols.sa/grc/public/admin/questionnaires\";}', NULL, '2023-11-13 14:55:18', NULL),
(132, 'asd testtest', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:01:58', NULL),
(133, 'asd testtest', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:01:58', NULL),
(134, 'asd testtest', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:01:58', NULL),
(135, 'Medium', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:03:31', NULL),
(136, 'Medium', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:03:31', NULL),
(137, 'Medium', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:03:31', NULL),
(138, 'Medium', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:09:04', NULL),
(139, 'Medium', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:09:04', NULL),
(140, 'Medium', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:09:04', NULL),
(141, 'Medium', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 15:09:04', NULL),
(142, '200000', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/asset-management\";}', NULL, '2023-11-13 15:14:20', NULL),
(143, '200000', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/asset-management\";}', NULL, '2023-11-13 15:14:20', NULL),
(144, '200000', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/asset-management\";}', NULL, '2023-11-13 15:14:20', NULL),
(145, 'cc', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-13 15:57:01', NULL),
(146, 'cc', 'notification', 'a:1:{s:4:\"link\";s:52:\"https://www.advancedcontrols.sa/grc/public/admin/KPI\";}', NULL, '2023-11-13 16:12:49', NULL),
(147, 'con5', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:18:22', NULL),
(148, 'con787', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:26:08', NULL),
(149, 'con787', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:26:08', NULL),
(150, '{Control_class}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:29:16', NULL),
(151, '{Control_class}', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:29:16', NULL),
(152, 'hjwjw', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:36:08', NULL),
(153, 'hjwjw', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:36:08', NULL),
(154, 'hjwjw', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 16:36:08', NULL),
(155, 'Kyra Mcmillan', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 17:12:26', NULL),
(156, 'Kyra Mcmillan', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 17:12:26', NULL),
(157, 'Kyra Mcmillan', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 17:12:26', NULL),
(158, 'asd testtest', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:49:55', NULL),
(159, 'asd testtest', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:49:55', NULL),
(160, 'asd testtest', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:49:55', NULL),
(161, 'Low', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:52:59', NULL),
(162, 'Low', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:52:59', NULL),
(163, 'Low', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:52:59', NULL),
(164, 'Low', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:53:13', NULL),
(165, 'Low', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:53:13', NULL),
(166, 'Low', 'notification', 'a:1:{s:4:\"link\";s:73:\"https://www.advancedcontrols.sa/grc/public/admin/vulnerability-management\";}', NULL, '2023-11-13 17:53:13', NULL),
(167, 'Control 5523', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 18:48:03', NULL),
(168, 'Control 5523', 'notification', 'a:1:{s:4:\"link\";s:72:\"https://www.advancedcontrols.sa/grc/public/admin/governance/control/list\";}', NULL, '2023-11-13 18:48:03', NULL),
(169, 'con787(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 18:49:10', NULL),
(170, 'con787(1)', 'notification', 'a:1:{s:4:\"link\";s:65:\"https://www.advancedcontrols.sa/grc/public/admin/compliance/audit\";}', NULL, '2023-11-13 18:49:10', NULL),
(171, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(172, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(173, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(174, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(175, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(176, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(177, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(178, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(179, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(180, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(181, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(182, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(183, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(184, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(185, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(186, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(187, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(188, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(189, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(190, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(191, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(192, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(193, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(194, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(195, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(196, 'مدير إدارة الهويات والصلاحيات', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/30\";}', NULL, '2023-11-13 18:49:36', NULL),
(197, '{Owner}', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/31\";}', NULL, '2023-11-13 18:51:13', NULL),
(198, '{Owner}', 'notification', 'a:1:{s:4:\"link\";s:67:\"https://www.advancedcontrols.sa/grc/public/admin/risk-management/31\";}', NULL, '2023-11-13 18:51:13', NULL),
(199, 'survey33Public', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 18:55:59', NULL),
(200, 'survey33Public', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 18:55:59', NULL),
(201, 'survey33Public', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 18:55:59', NULL),
(202, 'survey33Public', 'notification', 'a:1:{s:4:\"link\";s:71:\"https://www.advancedcontrols.sa/grc/public/admin/awarness-survey/survey\";}', NULL, '2023-11-13 18:55:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notifications_roles`
--

CREATE TABLE `notifications_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` int(11) NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications_roles`
--

INSERT INTO `notifications_roles` (`id`, `role`, `notifiable_id`, `notifiable_type`) VALUES
(4, 'manager', 2, 'App\\Models\\SystemNotificationSetting'),
(5, 'parent', 2, 'App\\Models\\SystemNotificationSetting'),
(6, 'manager', 3, 'App\\Models\\SystemNotificationSetting'),
(7, 'parent', 3, 'App\\Models\\SystemNotificationSetting'),
(8, 'manager', 4, 'App\\Models\\SystemNotificationSetting'),
(9, 'parent', 4, 'App\\Models\\SystemNotificationSetting'),
(10, 'MainManager', 5, 'App\\Models\\SystemNotificationSetting'),
(11, 'NewManager', 5, 'App\\Models\\SystemNotificationSetting'),
(12, 'ParentManager', 5, 'App\\Models\\SystemNotificationSetting'),
(13, 'MainManager', 6, 'App\\Models\\SystemNotificationSetting'),
(14, 'NewManager', 6, 'App\\Models\\SystemNotificationSetting'),
(15, 'ParentManager', 6, 'App\\Models\\SystemNotificationSetting'),
(16, 'NewParentManager', 6, 'App\\Models\\SystemNotificationSetting'),
(17, 'Employee', 6, 'App\\Models\\SystemNotificationSetting'),
(18, 'manager', 7, 'App\\Models\\SystemNotificationSetting'),
(19, 'creator', 7, 'App\\Models\\SystemNotificationSetting'),
(20, 'manager', 8, 'App\\Models\\SystemNotificationSetting'),
(21, 'creator', 8, 'App\\Models\\SystemNotificationSetting'),
(22, 'manager', 9, 'App\\Models\\SystemNotificationSetting'),
(23, 'creator', 9, 'App\\Models\\SystemNotificationSetting'),
(24, 'manager', 10, 'App\\Models\\SystemNotificationSetting'),
(25, 'creator', 10, 'App\\Models\\SystemNotificationSetting'),
(28, 'Control-Owner', 14, 'App\\Models\\SystemNotificationSetting'),
(29, 'Control-Tester', 14, 'App\\Models\\SystemNotificationSetting'),
(32, 'Control-Owner', 16, 'App\\Models\\SystemNotificationSetting'),
(33, 'Control-Tester', 16, 'App\\Models\\SystemNotificationSetting'),
(34, 'Control-Owner', 15, 'App\\Models\\SystemNotificationSetting'),
(35, 'Control-Tester', 15, 'App\\Models\\SystemNotificationSetting'),
(36, 'Control-Owner', 17, 'App\\Models\\SystemNotificationSetting'),
(37, 'Responsible_Person', 17, 'App\\Models\\SystemNotificationSetting'),
(38, 'Control-Tester', 17, 'App\\Models\\SystemNotificationSetting'),
(43, 'Control-Owner', 18, 'App\\Models\\SystemNotificationSetting'),
(44, 'Responsible_Person', 18, 'App\\Models\\SystemNotificationSetting'),
(45, 'Control-Tester', 18, 'App\\Models\\SystemNotificationSetting'),
(46, 'Evidence-Creator', 18, 'App\\Models\\SystemNotificationSetting'),
(47, 'Control-Owner', 19, 'App\\Models\\SystemNotificationSetting'),
(48, 'Responsible_Person', 19, 'App\\Models\\SystemNotificationSetting'),
(49, 'Control-Tester', 19, 'App\\Models\\SystemNotificationSetting'),
(50, 'Evidence-Creator', 19, 'App\\Models\\SystemNotificationSetting'),
(51, 'Control-Owner', 20, 'App\\Models\\SystemNotificationSetting'),
(52, 'Control-Tester', 20, 'App\\Models\\SystemNotificationSetting'),
(53, 'Control-Owner', 21, 'App\\Models\\SystemNotificationSetting'),
(54, 'Control-Tester', 21, 'App\\Models\\SystemNotificationSetting'),
(55, 'Document-Owner', 21, 'App\\Models\\SystemNotificationSetting'),
(56, 'Document-Stakeholder', 21, 'App\\Models\\SystemNotificationSetting'),
(57, 'Document-Teams', 21, 'App\\Models\\SystemNotificationSetting'),
(58, 'Control-Owner', 22, 'App\\Models\\SystemNotificationSetting'),
(59, 'Control-Tester', 22, 'App\\Models\\SystemNotificationSetting'),
(60, 'Control-Owner', 23, 'App\\Models\\SystemNotificationSetting'),
(61, 'Control-Tester', 23, 'App\\Models\\SystemNotificationSetting'),
(62, 'creator', 23, 'App\\Models\\SystemNotificationSetting'),
(63, 'Team-teams', 23, 'App\\Models\\SystemNotificationSetting'),
(64, 'Stakeholder-teams', 23, 'App\\Models\\SystemNotificationSetting'),
(65, 'Control-Owner', 24, 'App\\Models\\SystemNotificationSetting'),
(66, 'Control-Tester', 24, 'App\\Models\\SystemNotificationSetting'),
(67, 'Control-Owner', 25, 'App\\Models\\SystemNotificationSetting'),
(68, 'Control-Tester', 25, 'App\\Models\\SystemNotificationSetting'),
(69, 'Responsible_Person', 25, 'App\\Models\\SystemNotificationSetting'),
(70, 'creator', 26, 'App\\Models\\SystemNotificationSetting'),
(71, 'Team-teams', 26, 'App\\Models\\SystemNotificationSetting'),
(72, 'Stakeholder-teams', 26, 'App\\Models\\SystemNotificationSetting'),
(73, 'creator', 27, 'App\\Models\\SystemNotificationSetting'),
(74, 'Team-teams', 27, 'App\\Models\\SystemNotificationSetting'),
(75, 'Stakeholder-teams', 27, 'App\\Models\\SystemNotificationSetting'),
(76, 'creator', 28, 'App\\Models\\SystemNotificationSetting'),
(77, 'Team-teams', 28, 'App\\Models\\SystemNotificationSetting'),
(78, 'Stakeholder-teams', 28, 'App\\Models\\SystemNotificationSetting'),
(79, 'creator', 29, 'App\\Models\\SystemNotificationSetting'),
(80, 'Team-teams', 29, 'App\\Models\\SystemNotificationSetting'),
(81, 'Stakeholder-teams', 29, 'App\\Models\\SystemNotificationSetting'),
(82, 'creator', 30, 'App\\Models\\SystemNotificationSetting'),
(83, 'Team-teams', 30, 'App\\Models\\SystemNotificationSetting'),
(84, 'Stakeholder-teams', 30, 'App\\Models\\SystemNotificationSetting'),
(85, 'creator', 31, 'App\\Models\\SystemNotificationSetting'),
(86, 'Team-teams', 31, 'App\\Models\\SystemNotificationSetting'),
(87, 'Stakeholder-teams', 31, 'App\\Models\\SystemNotificationSetting'),
(88, 'creator', 32, 'App\\Models\\SystemNotificationSetting'),
(89, 'Team-teams', 32, 'App\\Models\\SystemNotificationSetting'),
(90, 'Stakeholder-teams', 32, 'App\\Models\\SystemNotificationSetting'),
(91, 'creator', 33, 'App\\Models\\SystemNotificationSetting'),
(92, 'Team-teams', 33, 'App\\Models\\SystemNotificationSetting'),
(93, 'Stakeholder-teams', 33, 'App\\Models\\SystemNotificationSetting'),
(94, 'creator', 34, 'App\\Models\\SystemNotificationSetting'),
(95, 'Team-teams', 34, 'App\\Models\\SystemNotificationSetting'),
(96, 'Stakeholder-teams', 34, 'App\\Models\\SystemNotificationSetting'),
(97, 'creator', 35, 'App\\Models\\SystemNotificationSetting'),
(98, 'Team-teams', 35, 'App\\Models\\SystemNotificationSetting'),
(99, 'Stakeholder-teams', 35, 'App\\Models\\SystemNotificationSetting'),
(100, 'creator', 36, 'App\\Models\\SystemNotificationSetting'),
(101, 'Team-teams', 36, 'App\\Models\\SystemNotificationSetting'),
(102, 'Stakeholder-teams', 36, 'App\\Models\\SystemNotificationSetting'),
(103, 'Questionnaire-contact', 37, 'App\\Models\\SystemNotificationSetting'),
(104, 'Questionnaire-contact', 38, 'App\\Models\\SystemNotificationSetting'),
(105, 'Questionnaire-contact', 39, 'App\\Models\\SystemNotificationSetting'),
(113, 'creator', 1, 'App\\Models\\AutoNotify'),
(114, 'creator', 1, 'App\\Models\\MailAutoNotify'),
(115, 'creator', 40, 'App\\Models\\SystemNotificationSetting'),
(116, 'Team-teams', 40, 'App\\Models\\SystemNotificationSetting'),
(117, 'Stakeholder-teams', 40, 'App\\Models\\SystemNotificationSetting'),
(118, 'creator', 41, 'App\\Models\\SystemNotificationSetting'),
(119, 'Team-teams', 41, 'App\\Models\\SystemNotificationSetting'),
(120, 'Stakeholder-teams', 41, 'App\\Models\\SystemNotificationSetting'),
(121, 'reviewers-teams', 41, 'App\\Models\\SystemNotificationSetting'),
(122, 'creator', 42, 'App\\Models\\SystemNotificationSetting'),
(123, 'Team-teams', 42, 'App\\Models\\SystemNotificationSetting'),
(124, 'Stakeholder-teams', 42, 'App\\Models\\SystemNotificationSetting'),
(125, 'reviewers-teams', 42, 'App\\Models\\SystemNotificationSetting'),
(126, 'manager', 5, 'App\\Models\\MailSetting'),
(127, 'parent', 5, 'App\\Models\\MailSetting'),
(128, 'manager', 6, 'App\\Models\\MailSetting'),
(129, 'parent', 6, 'App\\Models\\MailSetting'),
(130, 'manager', 7, 'App\\Models\\MailSetting'),
(131, 'parent', 7, 'App\\Models\\MailSetting'),
(132, 'MainManager', 8, 'App\\Models\\MailSetting'),
(133, 'NewManager', 8, 'App\\Models\\MailSetting'),
(134, 'ParentManager', 8, 'App\\Models\\MailSetting'),
(135, 'MainManager', 9, 'App\\Models\\MailSetting'),
(136, 'NewManager', 9, 'App\\Models\\MailSetting'),
(137, 'ParentManager', 9, 'App\\Models\\MailSetting'),
(138, 'NewParentManager', 9, 'App\\Models\\MailSetting'),
(139, 'Employee', 9, 'App\\Models\\MailSetting'),
(140, 'manager', 10, 'App\\Models\\MailSetting'),
(141, 'creator', 10, 'App\\Models\\MailSetting'),
(142, 'manager', 11, 'App\\Models\\MailSetting'),
(143, 'creator', 11, 'App\\Models\\MailSetting'),
(144, 'manager', 12, 'App\\Models\\MailSetting'),
(145, 'creator', 12, 'App\\Models\\MailSetting'),
(146, 'manager', 13, 'App\\Models\\MailSetting'),
(147, 'creator', 13, 'App\\Models\\MailSetting'),
(148, 'Control-Owner', 50, 'App\\Models\\SystemNotificationSetting'),
(149, 'Control-Owner', 49, 'App\\Models\\SystemNotificationSetting'),
(150, 'Control-Owner', 51, 'App\\Models\\SystemNotificationSetting'),
(151, 'Control-Owner', 17, 'App\\Models\\MailSetting'),
(152, 'Control-Owner', 18, 'App\\Models\\MailSetting'),
(153, 'Control-Owner', 19, 'App\\Models\\MailSetting'),
(154, 'creator', 1, 'App\\Models\\SystemNotificationSetting'),
(155, 'Team-teams', 1, 'App\\Models\\SystemNotificationSetting'),
(156, 'creator', 52, 'App\\Models\\SystemNotificationSetting'),
(157, 'Team-teams', 52, 'App\\Models\\SystemNotificationSetting'),
(158, 'creator', 20, 'App\\Models\\MailSetting'),
(159, 'Team-teams', 20, 'App\\Models\\MailSetting'),
(160, 'creator', 21, 'App\\Models\\MailSetting'),
(161, 'Team-teams', 21, 'App\\Models\\MailSetting'),
(162, 'creator', 22, 'App\\Models\\MailSetting'),
(163, 'Team-teams', 22, 'App\\Models\\MailSetting'),
(164, 'creator', 23, 'App\\Models\\MailSetting'),
(165, 'Team-teams', 23, 'App\\Models\\MailSetting'),
(166, 'creator', 24, 'App\\Models\\MailSetting'),
(167, 'Team-teams', 24, 'App\\Models\\MailSetting'),
(168, 'creator', 25, 'App\\Models\\MailSetting'),
(169, 'Team-teams', 25, 'App\\Models\\MailSetting'),
(170, 'creator', 26, 'App\\Models\\MailSetting'),
(171, 'Team-teams', 26, 'App\\Models\\MailSetting'),
(172, 'Team-teams', 55, 'App\\Models\\SystemNotificationSetting'),
(173, 'Team-teams', 56, 'App\\Models\\SystemNotificationSetting'),
(174, 'Team-teams', 57, 'App\\Models\\SystemNotificationSetting'),
(175, 'Team-teams', 28, 'App\\Models\\MailSetting'),
(176, 'Team-teams', 29, 'App\\Models\\MailSetting'),
(177, 'Team-teams', 30, 'App\\Models\\MailSetting'),
(178, 'Document-Owner', 61, 'App\\Models\\SystemNotificationSetting'),
(179, 'Team-teams', 61, 'App\\Models\\SystemNotificationSetting'),
(180, 'Stakeholder-teams', 61, 'App\\Models\\SystemNotificationSetting'),
(181, 'Document-Creator', 61, 'App\\Models\\SystemNotificationSetting'),
(182, 'Document-Owner', 62, 'App\\Models\\SystemNotificationSetting'),
(183, 'Team-teams', 62, 'App\\Models\\SystemNotificationSetting'),
(184, 'Stakeholder-teams', 62, 'App\\Models\\SystemNotificationSetting'),
(185, 'Document-Creator', 62, 'App\\Models\\SystemNotificationSetting'),
(186, 'reviewers-teams', 62, 'App\\Models\\SystemNotificationSetting'),
(187, 'Control-Owner', 31, 'App\\Models\\MailSetting');

-- --------------------------------------------------------

--
-- Table structure for table `notify_at_date_models`
--

CREATE TABLE `notify_at_date_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`model`)),
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`roles`)),
  `action_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `proccess` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_date` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`notification_date`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notify_at_date_models`
--

INSERT INTO `notify_at_date_models` (`id`, `model`, `roles`, `action_id`, `model_id`, `model_type`, `link`, `proccess`, `notification_date`, `created_at`, `updated_at`) VALUES
(1, '{\"name\":\"zx\",\"additional_stakeholder\":\"3\",\"owner_id\":\"2\",\"team\":\"2\",\"last_review_date\":\"2023-11-21\",\"review_frequency\":\"1\",\"next_review_date\":\"2023-11-22\",\"filter_status\":\"1\",\"reviewer\":\"\",\"approval_date\":null,\"privacy\":\"1\",\"description\":\"x\",\"created_by\":1,\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"updated_at\":\"2023-11-12T17:48:37.000000Z\",\"created_at\":\"2023-11-12T17:48:37.000000Z\",\"id\":1,\"Name\":\"zx\",\"Status\":\"Draft\",\"Description\":\"x\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 2)\",\"Additional_Stakeholder\":\"(\\u0645\\u062f\\u064a\\u0631 \\u0627\\ufef9\\u062f\\u0627\\u0631\\u0629 \\u0627\\u0644\\u0639\\u0627\\u0645\\u0629 \\ufef7\\u0645\\u0646 \\u0627\\u0644\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062a)\",\"Privacy\":\"Private\",\"status\":{\"id\":1,\"name\":\"Draft\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":1,\"title\":\"Private\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"2\"],\"Stakeholder-teams\":[\"3\"]}', 70, 1, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'create', '[\"2023-11-21\"]', '2023-11-12 20:48:37', '2023-11-12 20:48:37'),
(2, '{\"name\":\"zs\",\"additional_stakeholder\":\"2\",\"owner_id\":\"3\",\"team\":\"3\",\"last_review_date\":\"2023-11-14\",\"review_frequency\":\"1\",\"next_review_date\":\"2023-11-15\",\"filter_status\":\"3\",\"reviewer\":\"\",\"approval_date\":\"2023-11-27\",\"privacy\":\"1\",\"description\":\"z\",\"created_by\":1,\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"updated_at\":\"2023-11-12T17:49:16.000000Z\",\"created_at\":\"2023-11-12T17:49:16.000000Z\",\"id\":2,\"Name\":\"zs\",\"Status\":\"Approved\",\"Description\":\"z\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 3)\",\"Additional_Stakeholder\":\"(\\u0645\\u062f\\u064a\\u0631 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633 \\u0627\\u0644\\u062a\\u0646\\u0641\\u064a\\u0630\\u0649)\",\"Privacy\":\"Private\",\"status\":{\"id\":3,\"name\":\"Approved\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":1,\"title\":\"Private\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"3\"],\"Stakeholder-teams\":[\"2\"]}', 70, 2, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'create', '[\"2023-11-14\"]', '2023-11-12 20:49:16', '2023-11-12 20:49:16'),
(3, '{\"id\":3,\"name\":\"survey1\",\"additional_stakeholder\":\"43\",\"owner_id\":2,\"team\":\"3\",\"last_review_date\":\"2023-11-13\",\"review_frequency\":\"3\",\"next_review_date\":\"2023-11-16\",\"description\":\"sd\",\"privacy\":\"2\",\"filter_status\":\"3\",\"approval_date\":\"2023-11-13\",\"reviewer\":\"\",\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"created_by\":1,\"created_at\":\"2023-11-12T18:04:35.000000Z\",\"updated_at\":\"2023-11-12T18:09:50.000000Z\",\"Name\":\"survey1\",\"Status\":\"Approved\",\"Description\":\"sd\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 3)\",\"Additional_Stakeholder\":\"(Mustafa Mohammed)\",\"Privacy\":\"Public\",\"Reviewer\":\"\",\"status\":{\"id\":3,\"name\":\"Approved\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":2,\"title\":\"Public\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"3\"],\"Stakeholder-teams\":[\"43\"],\"reviewers-teams\":[]}', 70, 3, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'update', '[\"2023-11-15\"]', '2023-11-12 21:04:35', '2023-11-12 21:09:50'),
(4, '{\"name\":\"survey22\",\"additional_stakeholder\":\"2\",\"owner_id\":\"43\",\"team\":\"4\",\"last_review_date\":\"2023-11-12\",\"review_frequency\":\"3\",\"next_review_date\":\"2023-11-15\",\"filter_status\":\"1\",\"reviewer\":\"\",\"approval_date\":null,\"privacy\":\"1\",\"description\":\"sd\",\"created_by\":1,\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"updated_at\":\"2023-11-12T18:12:32.000000Z\",\"created_at\":\"2023-11-12T18:12:32.000000Z\",\"id\":4,\"Name\":\"survey22\",\"Status\":\"Draft\",\"Description\":\"sd\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 4)\",\"Additional_Stakeholder\":\"(\\u0645\\u062f\\u064a\\u0631 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633 \\u0627\\u0644\\u062a\\u0646\\u0641\\u064a\\u0630\\u0649)\",\"Privacy\":\"Private\",\"status\":{\"id\":1,\"name\":\"Draft\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":1,\"title\":\"Private\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"4\"],\"Stakeholder-teams\":[\"2\"]}', 70, 4, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'create', '[\"2023-11-14\"]', '2023-11-12 21:12:34', '2023-11-12 21:12:34'),
(5, '{\"name\":\"zz\",\"additional_stakeholder\":\"44\",\"owner_id\":\"2\",\"team\":\"1\",\"last_review_date\":\"2023-11-14\",\"review_frequency\":\"1\",\"next_review_date\":\"2023-11-15\",\"filter_status\":\"3\",\"reviewer\":\"\",\"approval_date\":\"2023-11-28\",\"privacy\":\"1\",\"description\":\"z\",\"created_by\":1,\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"updated_at\":\"2023-11-13T07:37:07.000000Z\",\"created_at\":\"2023-11-13T07:37:07.000000Z\",\"id\":5,\"Name\":\"zz\",\"Status\":\"Approved\",\"Description\":\"z\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 1)\",\"Additional_Stakeholder\":\"(Ali)\",\"Privacy\":\"Private\",\"Next_Review_Date\":\"2023-11-15\",\"status\":{\"id\":3,\"name\":\"Approved\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":1,\"title\":\"Private\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"1\"],\"Stakeholder-teams\":[\"44\"]}', 70, 5, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'create', '[\"2023-11-14\"]', '2023-11-13 10:37:08', '2023-11-13 10:37:08'),
(6, '{\"name\":\"wdwdw\",\"additional_stakeholder\":\"2\",\"owner_id\":1,\"team\":\"1\",\"last_review_date\":\"2023-11-13\",\"review_frequency\":\"0\",\"next_review_date\":\"2023-11-13\",\"filter_status\":\"1\",\"reviewer\":\"\",\"approval_date\":null,\"privacy\":\"1\",\"description\":\"wddddddddddd\",\"created_by\":1,\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"updated_at\":\"2023-11-13T08:42:57.000000Z\",\"created_at\":\"2023-11-13T08:42:57.000000Z\",\"id\":6,\"Name\":\"wdwdw\",\"Status\":\"Draft\",\"Description\":\"wddddddddddd\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 1)\",\"Additional_Stakeholder\":\"(\\u0645\\u062f\\u064a\\u0631 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633 \\u0627\\u0644\\u062a\\u0646\\u0641\\u064a\\u0630\\u0649)\",\"Privacy\":\"Private\",\"Next_Review_Date\":\"2023-11-13\",\"status\":{\"id\":1,\"name\":\"Draft\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":1,\"title\":\"Private\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"1\"],\"Stakeholder-teams\":[\"2\"]}', 70, 6, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'create', '[\"2023-11-12\"]', '2023-11-13 11:42:59', '2023-11-13 11:42:59'),
(7, '{\"id\":7,\"name\":\"xaxac\",\"additional_stakeholder\":\"2\",\"owner_id\":1,\"team\":\"1\",\"last_review_date\":\"2023-11-13\",\"review_frequency\":0,\"next_review_date\":\"2023-11-13\",\"description\":\"cddddddddddddddddd\",\"privacy\":1,\"filter_status\":1,\"approval_date\":null,\"reviewer\":\"\",\"all_questions_mandatory\":0,\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"created_by\":1,\"created_at\":\"2023-11-13T09:19:20.000000Z\",\"updated_at\":\"2023-11-13T09:19:57.000000Z\",\"Name\":\"xaxac\",\"Status\":\"Draft\",\"Description\":\"cddddddddddddddddd\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 1)\",\"Additional_Stakeholder\":\"(\\u0645\\u062f\\u064a\\u0631 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633 \\u0627\\u0644\\u062a\\u0646\\u0641\\u064a\\u0630\\u0649)\",\"Privacy\":\"Private\",\"Reviewer\":\"\",\"status\":{\"id\":1,\"name\":\"Draft\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":1,\"title\":\"Private\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"1\"],\"Stakeholder-teams\":[\"2\"],\"reviewers-teams\":[]}', 70, 7, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'delete', '[\"2023-11-12\"]', '2023-11-13 12:19:21', '2023-11-13 12:20:07'),
(8, '{\"name\":\"dwwd\",\"additional_stakeholder\":\"2\",\"owner_id\":\"2\",\"team\":\"1\",\"last_review_date\":\"2023-11-13\",\"review_frequency\":\"0\",\"next_review_date\":\"2023-11-13\",\"filter_status\":\"1\",\"reviewer\":\"\",\"approval_date\":null,\"privacy\":\"1\",\"description\":\"wddddddd\",\"created_by\":1,\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"updated_at\":\"2023-11-13T10:30:28.000000Z\",\"created_at\":\"2023-11-13T10:30:28.000000Z\",\"id\":8,\"Name\":\"dwwd\",\"Status\":\"Draft\",\"Description\":\"wddddddd\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 1)\",\"Additional_Stakeholder\":\"(\\u0645\\u062f\\u064a\\u0631 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633 \\u0627\\u0644\\u062a\\u0646\\u0641\\u064a\\u0630\\u0649)\",\"Privacy\":\"Private\",\"Next_Review_Date\":\"2023-11-13\",\"status\":{\"id\":1,\"name\":\"Draft\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":1,\"title\":\"Private\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"1\"],\"Stakeholder-teams\":[\"2\"]}', 70, 8, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'create', '[\"2023-11-12\"]', '2023-11-13 13:30:28', '2023-11-13 13:30:28'),
(9, '{\"name\":\"survey33\",\"additional_stakeholder\":\"2\",\"owner_id\":1,\"team\":\"2\",\"last_review_date\":\"2023-11-14\",\"review_frequency\":\"2\",\"next_review_date\":\"2023-11-16\",\"filter_status\":\"3\",\"reviewer\":\"\",\"approval_date\":\"2023-11-15\",\"privacy\":\"2\",\"description\":\"sdd\",\"created_by\":1,\"all_questions_mandatory\":\"on\",\"answer_percentage\":null,\"percentage_number\":null,\"specific_mandatory_questions\":null,\"questions\":\"\",\"updated_at\":\"2023-11-13T15:55:59.000000Z\",\"created_at\":\"2023-11-13T15:55:59.000000Z\",\"id\":9,\"Name\":\"survey33\",\"Status\":\"Approved\",\"Description\":\"sdd\",\"Created_By\":\"Admin\",\"Teams\":\"(Team 2)\",\"Additional_Stakeholder\":\"(\\u0645\\u062f\\u064a\\u0631 \\u0627\\u0644\\u0631\\u0626\\u064a\\u0633 \\u0627\\u0644\\u062a\\u0646\\u0641\\u064a\\u0630\\u0649)\",\"Privacy\":\"Public\",\"Next_Review_Date\":\"2023-11-16\",\"status\":{\"id\":3,\"name\":\"Approved\"},\"created_by_user\":{\"id\":1,\"enabled\":1,\"lockout\":0,\"type\":\"grc\",\"username\":\"admin\",\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"salt\":\"qCJpnAe5S6k61Pqh3SFG\",\"last_login\":\"2022-01-17 09:00:33\",\"last_password_change_date\":\"2017-01-08 09:58:20\",\"role_id\":1,\"lang\":null,\"admin\":1,\"multi_factor\":1,\"ldap_department\":null,\"change_password\":0,\"custom_display_settings\":\"[\\\\\\\"id\\\\\\\",\\\\\\\"subject\\\\\\\",\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"submission_date\\\\\\\",\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"management_review\\\\\\\"]\",\"department_id\":24,\"manager_id\":null,\"job_id\":null,\"custom_plan_mitigation_display_settings\":\"{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\",\"custom_perform_reviews_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"submission_date\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"mitigation_colums\\\\\\\":[[\\\\\\\"mitigation_planned\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"1\\\\\\\"]]}\\\\n\",\"custom_reviewregularly_display_settings\":\"{\\\\\\\"risk_colums\\\\\\\":[[\\\\\\\"id\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"risk_status\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"subject\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"calculated_risk\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"days_open\\\\\\\",\\\\\\\"1\\\\\\\"]],\\\\\\\"review_colums\\\\\\\":[[\\\\\\\"management_review\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"review_date\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_step\\\\\\\",\\\\\\\"0\\\\\\\"],[\\\\\\\"next_review_date\\\\\\\",\\\\\\\"1\\\\\\\"],[\\\\\\\"comments\\\\\\\",\\\\\\\"0\\\\\\\"]]}\",\"phone_number\":null},\"test_priv\":{\"id\":2,\"title\":\"Public\",\"created_at\":\"2023-11-12T16:29:02.000000Z\",\"updated_at\":\"2023-11-12T16:29:02.000000Z\"}}', '{\"creator\":[1],\"Team-teams\":[\"2\"],\"Stakeholder-teams\":[\"2\"]}', 70, 9, 'survey', '{\"link\":\"https:\\/\\/www.advancedcontrols.sa\\/grc\\/public\\/admin\\/awarness-survey\\/survey\"}', 'create', '[\"2023-11-15\"]', '2023-11-13 18:56:00', '2023-11-13 18:56:00');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `username` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pending_risks`
--

CREATE TABLE `pending_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_id` bigint(20) UNSIGNED NOT NULL,
  `assessment_answer_id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` double(8,2) NOT NULL,
  `owner` int(11) DEFAULT NULL,
  `affected_assets` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subgroup_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `name`, `subgroup_id`, `created_at`, `updated_at`) VALUES
(1, 'framework.list', 'list', 1, NULL, NULL),
(2, 'framework.view', 'view', 1, NULL, NULL),
(3, 'framework.create', 'create', 1, NULL, NULL),
(4, 'framework.update', 'update', 1, NULL, NULL),
(5, 'framework.delete', 'delete', 1, NULL, NULL),
(6, 'framework.print', 'print', 1, NULL, NULL),
(7, 'framework.export', 'export', 1, NULL, NULL),
(8, 'control.list', 'list', 2, NULL, NULL),
(9, 'control.view', 'view', 2, NULL, NULL),
(10, 'control.create', 'create', 2, NULL, NULL),
(11, 'control.update', 'update', 2, NULL, NULL),
(12, 'control.delete', 'delete', 2, NULL, NULL),
(13, 'control.print', 'print', 2, NULL, NULL),
(14, 'control.export', 'export', 2, NULL, NULL),
(15, 'document.create', 'create', 3, NULL, NULL),
(16, 'document.print', 'print', 3, NULL, NULL),
(17, 'document.export', 'export', 3, NULL, NULL),
(18, 'document.download', 'download', 3, NULL, NULL),
(19, 'riskmanagement.list', 'list', 5, NULL, NULL),
(20, 'riskmanagement.view', 'view', 5, NULL, NULL),
(21, 'riskmanagement.create', 'create', 5, NULL, NULL),
(22, 'riskmanagement.update', 'update', 5, NULL, NULL),
(23, 'riskmanagement.delete', 'delete', 5, NULL, NULL),
(24, 'riskmanagement.print', 'print', 5, NULL, NULL),
(25, 'riskmanagement.export', 'export', 5, NULL, NULL),
(26, 'riskmanagement.AbleToCommentRiskManagement', 'AbleToCommentRiskManagement', 5, NULL, NULL),
(27, 'riskmanagement.AbleToCloseRisks', 'AbleToCloseRisks', 5, NULL, NULL),
(28, 'audits.list', 'list', 9, NULL, NULL),
(29, 'audits.create', 'create', 9, NULL, NULL),
(30, 'audits.delete', 'delete', 9, NULL, NULL),
(31, 'audits.result', 'result', 9, NULL, NULL),
(32, 'audits.export', 'export', 9, NULL, NULL),
(33, 'asset.list', 'list', 10, NULL, NULL),
(34, 'asset.view', 'view', 10, NULL, NULL),
(35, 'asset.create', 'create', 10, NULL, NULL),
(36, 'asset.update', 'update', 10, NULL, NULL),
(37, 'asset.delete', 'delete', 10, NULL, NULL),
(38, 'asset.print', 'print', 10, NULL, NULL),
(39, 'asset.export', 'export', 10, NULL, NULL),
(40, 'roles.list', 'list', 12, NULL, NULL),
(41, 'roles.view', 'view', 12, NULL, NULL),
(42, 'roles.create', 'create', 12, NULL, NULL),
(43, 'roles.update', 'update', 12, NULL, NULL),
(44, 'roles.delete', 'delete', 12, NULL, NULL),
(45, 'roles.print', 'print', 12, NULL, NULL),
(46, 'roles.export', 'export', 12, NULL, NULL),
(47, 'values.list', 'list', 13, NULL, NULL),
(48, 'values.view', 'view', 13, NULL, NULL),
(49, 'values.create', 'create', 13, NULL, NULL),
(50, 'values.update', 'update', 13, NULL, NULL),
(51, 'values.delete', 'delete', 13, NULL, NULL),
(52, 'values.print', 'print', 13, NULL, NULL),
(53, 'values.export', 'export', 13, NULL, NULL),
(54, 'logs.list', 'list', 14, NULL, NULL),
(55, 'logs.view', 'view', 14, NULL, NULL),
(56, 'logs.create', 'create', 14, NULL, NULL),
(57, 'logs.update', 'update', 14, NULL, NULL),
(58, 'logs.delete', 'delete', 14, NULL, NULL),
(59, 'logs.print', 'print', 14, NULL, NULL),
(60, 'logs.export', 'export', 14, NULL, NULL),
(61, 'hierarchy.list', 'view', 15, NULL, NULL),
(62, 'hierarchy.view', 'view', 15, NULL, NULL),
(63, 'hierarchy.update', 'update', 15, NULL, NULL),
(64, 'department.list', 'list', 16, NULL, NULL),
(65, 'department.view', 'view', 16, NULL, NULL),
(66, 'department.create', 'create', 16, NULL, NULL),
(67, 'department.update', 'update', 16, NULL, NULL),
(68, 'department.delete', 'delete', 16, NULL, NULL),
(69, 'department.print', 'print', 16, NULL, NULL),
(70, 'department.export', 'export', 16, NULL, NULL),
(71, 'job.list', 'list', 17, NULL, NULL),
(72, 'job.view', 'view', 17, NULL, NULL),
(73, 'job.create', 'create', 17, NULL, NULL),
(74, 'job.update', 'update', 17, NULL, NULL),
(75, 'job.delete', 'delete', 17, NULL, NULL),
(76, 'job.print', 'print', 17, NULL, NULL),
(77, 'job.export', 'export', 17, NULL, NULL),
(78, 'plan_mitigation.create', 'create', 19, NULL, NULL),
(79, 'plan_mitigation.accept', 'accept', 19, NULL, NULL),
(80, 'perform_reviews.create', 'create', 20, NULL, NULL),
(81, 'asset_group.list', 'list', 21, NULL, NULL),
(82, 'asset_group.view', 'view', 21, NULL, NULL),
(83, 'asset_group.create', 'create', 21, NULL, NULL),
(84, 'asset_group.update', 'update', 21, NULL, NULL),
(85, 'asset_group.delete', 'delete', 21, NULL, NULL),
(86, 'asset_group.print', 'print', 21, NULL, NULL),
(87, 'asset_group.export', 'export', 21, NULL, NULL),
(88, 'category.list', 'list', 22, NULL, NULL),
(89, 'category.view', 'view', 22, NULL, NULL),
(90, 'category.create', 'create', 22, NULL, NULL),
(91, 'category.update', 'update', 22, NULL, NULL),
(92, 'category.delete', 'delete', 22, NULL, NULL),
(93, 'category.print', 'print', 22, NULL, NULL),
(94, 'category.export', 'export', 22, NULL, NULL),
(95, 'user_management.list', 'list', 23, NULL, NULL),
(96, 'user_management.view', 'view', 23, NULL, NULL),
(97, 'user_management.create', 'create', 23, NULL, NULL),
(98, 'user_management.update', 'update', 23, NULL, NULL),
(99, 'user_management.delete', 'delete', 23, NULL, NULL),
(100, 'user_management.print', 'print', 23, NULL, NULL),
(101, 'user_management.export', 'export', 23, NULL, NULL),
(102, 'settings.list', 'list', 24, NULL, NULL),
(103, 'settings.view', 'view', 24, NULL, NULL),
(104, 'settings.create', 'create', 24, NULL, NULL),
(105, 'settings.update', 'update', 24, NULL, NULL),
(106, 'settings.delete', 'delete', 24, NULL, NULL),
(107, 'settings.print', 'print', 24, NULL, NULL),
(108, 'settings.export', 'export', 24, NULL, NULL),
(109, 'classic_risk_formula.list', 'list', 25, NULL, NULL),
(110, 'classic_risk_formula.view', 'view', 25, NULL, NULL),
(111, 'classic_risk_formula.create', 'create', 25, NULL, NULL),
(112, 'classic_risk_formula.update', 'update', 25, NULL, NULL),
(113, 'classic_risk_formula.delete', 'delete', 25, NULL, NULL),
(114, 'classic_risk_formula.print', 'print', 25, NULL, NULL),
(115, 'classic_risk_formula.export', 'export', 25, NULL, NULL),
(116, 'import_and_export.list', 'list', 26, NULL, NULL),
(117, 'import_and_export.import', 'import', 26, NULL, NULL),
(118, 'import_and_export.export', 'export', 26, NULL, NULL),
(119, 'LDAP.list', 'list', 27, NULL, NULL),
(120, 'LDAP.test', 'test', 27, NULL, NULL),
(121, 'LDAP.update', 'update', 27, NULL, NULL),
(122, 'reporting.Overview', 'Overview', 28, NULL, NULL),
(123, 'reporting.Risk Dashboard', 'Risk Dashboard', 28, NULL, NULL),
(124, 'reporting.Control Gap Analysis', 'Control Gap Analysis', 28, NULL, NULL),
(125, 'reporting.Likelihood And Impact', 'Likelihood And Impact', 28, NULL, NULL),
(126, 'reporting.All Open Risks Assigne To Me', 'All Open Risks Assigne To Me', 28, NULL, NULL),
(127, 'reporting.Dynamic Risk Report', 'Dynamic Risk Report', 28, NULL, NULL),
(128, 'reporting.Risks and Controls', 'Risks and Controls', 28, NULL, NULL),
(129, 'reporting.Risks and Assets', 'Risks and Assets', 28, NULL, NULL),
(130, 'reporting.framewrok_control_compliance_status', 'Framewrok control compliance status', 28, NULL, NULL),
(131, 'reporting.summary_of_results_for_evaluation_and_compliance', 'Summary of results for evaluation and compliance', 28, NULL, NULL),
(132, 'reporting.security-awareness-exam', 'Security awareness exam', 28, NULL, NULL),
(133, 'reporting.awareness-survey-info', '	Awareness Survey', 28, NULL, NULL),
(134, 'reporting.objectives', 'Objectives', 28, NULL, NULL),
(135, 'task.list', 'list', 29, NULL, NULL),
(136, 'task.create', 'create', 29, NULL, NULL),
(137, 'task.export', 'export', 29, NULL, NULL),
(138, 'about.update', 'update', 30, NULL, NULL),
(139, 'vulnerability_management.list', 'list', 31, NULL, NULL),
(140, 'vulnerability_management.view', 'view', 31, NULL, NULL),
(141, 'vulnerability_management.create', 'create', 31, NULL, NULL),
(142, 'vulnerability_management.update', 'update', 31, NULL, NULL),
(143, 'vulnerability_management.delete', 'delete', 31, NULL, NULL),
(144, 'vulnerability_management.print', 'print', 31, NULL, NULL),
(145, 'vulnerability_management.export', 'export', 31, NULL, NULL),
(146, 'general-setting.update', 'update', 32, NULL, NULL),
(147, 'services-description.update', 'update', 33, NULL, NULL),
(148, 'email-setting.list', 'list', 45, NULL, NULL),
(149, 'email-setting.create', 'create', 45, NULL, NULL),
(150, 'change-request.create', 'create', 34, NULL, NULL),
(151, 'change-request.export', 'export', 34, NULL, NULL),
(152, 'change-request-department.update', 'update', 35, NULL, NULL),
(153, 'KPI.list', 'list', 36, NULL, NULL),
(154, 'KPI.create', 'create', 36, NULL, NULL),
(155, 'KPI.update', 'update', 36, NULL, NULL),
(156, 'KPI.delete', 'delete', 36, NULL, NULL),
(157, 'KPI.Initiate assessment', 'Initiate assessment', 36, NULL, NULL),
(158, 'KPI.export', 'export', 36, NULL, NULL),
(159, 'security-awareness.list', 'list', 37, NULL, NULL),
(160, 'security-awareness.create', 'create', 37, NULL, NULL),
(161, 'security-awareness.print', 'print', 37, NULL, NULL),
(162, 'security-awareness.export', 'export', 37, NULL, NULL),
(163, 'security-awareness.download', 'download', 37, NULL, NULL),
(164, 'awareness-survey.list', 'list', 44, NULL, NULL),
(165, 'awareness-survey.create', 'create', 44, NULL, NULL),
(166, 'awareness-survey.edit', 'create', 44, NULL, NULL),
(167, 'awareness-survey.delete', 'create', 44, NULL, NULL),
(168, 'awareness-survey.add_questions', 'add question', 44, NULL, NULL),
(169, 'awareness-survey.list_questions', 'list questions', 44, NULL, NULL),
(170, 'domain.list', 'list', 40, NULL, NULL),
(171, 'domain.view', 'view', 40, NULL, NULL),
(172, 'domain.create', 'create', 40, NULL, NULL),
(173, 'domain.update', 'update', 40, NULL, NULL),
(174, 'domain.delete', 'delete', 40, NULL, NULL),
(175, 'domain.print', 'print', 40, NULL, NULL),
(176, 'domain.export', 'export', 40, NULL, NULL),
(177, 'control-objective.list', 'list', 43, NULL, NULL),
(178, 'control-objective.view', 'view', 43, NULL, NULL),
(179, 'control-objective.create', 'create', 43, NULL, NULL),
(180, 'control-objective.delete', 'delete', 43, NULL, NULL),
(181, 'control-objective.update', 'update', 43, NULL, NULL),
(182, 'control-objective.print', 'print', 43, NULL, NULL),
(183, 'control-objective.export', 'export', 43, NULL, NULL),
(184, 'assessment.list', 'list', 39, NULL, NULL),
(185, 'assessment.create', 'create', 39, NULL, NULL),
(186, 'assessment.edit', 'edit', 39, NULL, NULL),
(187, 'assessment.delete', 'delete', 39, NULL, NULL),
(188, 'assessment.questions', 'questions', 39, NULL, NULL),
(189, 'control.list_objectives', 'list objectives', 2, NULL, NULL),
(190, 'control.add_objectives', 'add objectives', 2, NULL, NULL),
(191, 'control.all', 'all', 2, NULL, NULL),
(192, 'audits.all', 'all', 9, NULL, NULL),
(193, 'risks.all', 'all', 5, NULL, NULL),
(194, 'vulnerability_management.all', 'all', 31, NULL, NULL),
(195, 'asset.all', 'all', 10, NULL, NULL),
(196, 'security-awareness.all', 'all', 37, NULL, NULL),
(197, 'document.all', 'all', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_groups`
--

CREATE TABLE `permission_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_groups`
--

INSERT INTO `permission_groups` (`id`, `name`, `description`, `order`) VALUES
(1, 'Governance', '', 1),
(2, 'Risk Management', '', 2),
(3, 'Compliance', '', 3),
(4, 'Asset Management', '', 4),
(5, 'Assessments', '', 5),
(6, 'Configure', '', 6),
(7, 'Hierarchy', '', 7),
(8, 'Reporting', '', 8),
(9, 'Task', '', 9),
(10, 'Vulnerability Management', '', 10),
(11, 'Change Request', '', 11),
(12, 'KPI', '', 12),
(13, 'Security Awareness Mgmt', '', 13),
(14, 'Assessment', 'Assessment', 14);

-- --------------------------------------------------------

--
-- Table structure for table `permission_to_permission_groups`
--

CREATE TABLE `permission_to_permission_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `permission_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_to_permission_groups`
--

INSERT INTO `permission_to_permission_groups` (`id`, `permission_id`, `permission_group_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(9, 9, 1),
(10, 10, 1),
(11, 11, 1),
(12, 12, 1),
(13, 13, 1),
(14, 14, 1),
(15, 15, 1),
(16, 16, 2),
(17, 17, 2),
(18, 18, 2),
(19, 19, 2),
(20, 20, 2),
(21, 21, 2),
(22, 22, 2),
(23, 23, 2),
(24, 24, 2),
(25, 25, 2),
(26, 26, 2),
(27, 27, 2),
(28, 28, 2),
(29, 29, 2),
(30, 30, 2),
(31, 31, 3),
(32, 32, 3),
(33, 33, 3),
(34, 34, 3),
(35, 35, 3),
(36, 36, 3),
(37, 37, 3),
(38, 38, 3),
(39, 39, 3),
(40, 40, 4),
(41, 41, 5);

-- --------------------------------------------------------

--
-- Table structure for table `permission_to_users`
--

CREATE TABLE `permission_to_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_to_users`
--

INSERT INTO `permission_to_users` (`id`, `permission_id`, `user_id`) VALUES
(1, 1, 42),
(2, 2, 42),
(3, 3, 42),
(4, 4, 42),
(5, 5, 42),
(6, 6, 42),
(7, 7, 42),
(8, 8, 42),
(9, 9, 42),
(10, 10, 42),
(11, 11, 42),
(12, 12, 42),
(13, 13, 42),
(14, 14, 42),
(15, 15, 42),
(16, 16, 42),
(17, 17, 42),
(18, 18, 42),
(19, 19, 42),
(20, 20, 42),
(21, 21, 42),
(22, 22, 42),
(23, 23, 42),
(24, 24, 42),
(25, 25, 42),
(26, 26, 42),
(27, 27, 42),
(28, 28, 42),
(29, 29, 42),
(30, 30, 42),
(31, 31, 42),
(32, 32, 42),
(33, 33, 42),
(34, 34, 42),
(35, 35, 42),
(36, 36, 42),
(37, 37, 42),
(38, 38, 42),
(39, 39, 42),
(40, 40, 42),
(41, 41, 42),
(42, 42, 42),
(43, 43, 42),
(44, 44, 42),
(45, 45, 42),
(46, 46, 42),
(47, 47, 42),
(48, 48, 42),
(49, 49, 42),
(50, 50, 42),
(51, 51, 42),
(52, 52, 42),
(53, 53, 42),
(54, 54, 42),
(55, 55, 42),
(56, 56, 42),
(57, 57, 42),
(58, 58, 42),
(59, 59, 42),
(60, 60, 42),
(61, 61, 42),
(62, 62, 42),
(63, 63, 42),
(64, 64, 42),
(65, 65, 42),
(66, 66, 42),
(67, 67, 42),
(68, 68, 42),
(69, 69, 42),
(70, 70, 42),
(71, 71, 42),
(72, 72, 42),
(73, 73, 42),
(74, 74, 42),
(75, 75, 42),
(76, 76, 42),
(77, 77, 42),
(78, 78, 42),
(79, 79, 42),
(80, 80, 42),
(81, 81, 42),
(82, 82, 42),
(83, 83, 42),
(84, 84, 42),
(85, 85, 42),
(86, 86, 42),
(87, 87, 42),
(88, 88, 42),
(89, 89, 42),
(90, 90, 42),
(91, 91, 42),
(92, 92, 42),
(93, 93, 42),
(94, 94, 42),
(95, 95, 42),
(96, 96, 42),
(97, 97, 42),
(98, 98, 42),
(99, 99, 42),
(100, 100, 42),
(101, 101, 42),
(102, 102, 42),
(103, 103, 42),
(104, 104, 42),
(105, 105, 42),
(106, 106, 42),
(107, 107, 42),
(108, 108, 42),
(109, 109, 42),
(110, 110, 42),
(111, 111, 42),
(112, 112, 42),
(113, 113, 42),
(114, 114, 42),
(115, 115, 42),
(116, 116, 42),
(117, 117, 42),
(118, 118, 42),
(119, 119, 42),
(120, 120, 42),
(121, 121, 42),
(122, 122, 42),
(123, 123, 42),
(124, 124, 42),
(125, 125, 42),
(126, 126, 42),
(127, 127, 42),
(128, 128, 42),
(129, 129, 42),
(130, 130, 42),
(131, 131, 42),
(132, 132, 42),
(133, 133, 42),
(134, 134, 42),
(135, 135, 42),
(136, 136, 42),
(137, 137, 42),
(138, 138, 42),
(139, 139, 42),
(140, 140, 42),
(141, 141, 42),
(142, 142, 42),
(143, 143, 42),
(144, 144, 42),
(145, 145, 42),
(146, 146, 42),
(147, 147, 42),
(148, 150, 42),
(149, 151, 42),
(150, 152, 42),
(151, 153, 42),
(152, 154, 42),
(153, 155, 42),
(154, 156, 42),
(155, 157, 42),
(156, 158, 42),
(157, 159, 42),
(158, 160, 42),
(159, 161, 42),
(160, 162, 42),
(161, 163, 42),
(162, 184, 42),
(163, 185, 42),
(164, 186, 42),
(165, 187, 42),
(166, 188, 42),
(167, 170, 42),
(168, 171, 42),
(169, 172, 42),
(170, 173, 42),
(171, 174, 42),
(172, 175, 42),
(173, 176, 42),
(174, 177, 42),
(175, 178, 42),
(176, 179, 42),
(177, 180, 42),
(178, 181, 42),
(179, 182, 42),
(180, 183, 42),
(181, 164, 42),
(182, 165, 42),
(183, 166, 42),
(184, 167, 42),
(185, 168, 42),
(186, 169, 42),
(187, 148, 42),
(188, 149, 42),
(189, 189, 42),
(190, 190, 42),
(191, 191, 42),
(192, 192, 42),
(193, 193, 42),
(194, 194, 42),
(195, 195, 42),
(196, 196, 42),
(197, 197, 42),
(198, 1, 43),
(199, 2, 43),
(200, 3, 43),
(201, 4, 43),
(202, 5, 43),
(203, 6, 43),
(204, 7, 43),
(205, 8, 43),
(206, 9, 43),
(207, 10, 43),
(208, 11, 43),
(209, 12, 43),
(210, 13, 43),
(211, 14, 43),
(212, 15, 43),
(213, 16, 43),
(214, 17, 43),
(215, 18, 43),
(216, 19, 43),
(217, 20, 43),
(218, 21, 43),
(219, 22, 43),
(220, 23, 43),
(221, 24, 43),
(222, 25, 43),
(223, 26, 43),
(224, 27, 43),
(225, 28, 43),
(226, 29, 43),
(227, 30, 43),
(228, 31, 43),
(229, 32, 43),
(230, 33, 43),
(231, 34, 43),
(232, 35, 43),
(233, 36, 43),
(234, 37, 43),
(235, 38, 43),
(236, 39, 43),
(237, 40, 43),
(238, 41, 43),
(239, 42, 43),
(240, 43, 43),
(241, 44, 43),
(242, 45, 43),
(243, 46, 43),
(244, 47, 43),
(245, 48, 43),
(246, 49, 43),
(247, 50, 43),
(248, 51, 43),
(249, 52, 43),
(250, 53, 43),
(251, 54, 43),
(252, 55, 43),
(253, 56, 43),
(254, 57, 43),
(255, 58, 43),
(256, 59, 43),
(257, 60, 43),
(258, 61, 43),
(259, 62, 43),
(260, 63, 43),
(261, 64, 43),
(262, 65, 43),
(263, 66, 43),
(264, 67, 43),
(265, 68, 43),
(266, 69, 43),
(267, 70, 43),
(268, 71, 43),
(269, 72, 43),
(270, 73, 43),
(271, 74, 43),
(272, 75, 43),
(273, 76, 43),
(274, 77, 43),
(275, 78, 43),
(276, 79, 43),
(277, 80, 43),
(278, 81, 43),
(279, 82, 43),
(280, 83, 43),
(281, 84, 43),
(282, 85, 43),
(283, 86, 43),
(284, 87, 43),
(285, 88, 43),
(286, 89, 43),
(287, 90, 43),
(288, 91, 43),
(289, 92, 43),
(290, 93, 43),
(291, 94, 43),
(292, 95, 43),
(293, 96, 43),
(294, 97, 43),
(295, 98, 43),
(296, 99, 43),
(297, 100, 43),
(298, 101, 43),
(299, 102, 43),
(300, 103, 43),
(301, 104, 43),
(302, 105, 43),
(303, 106, 43),
(304, 107, 43),
(305, 108, 43),
(306, 109, 43),
(307, 110, 43),
(308, 111, 43),
(309, 112, 43),
(310, 113, 43),
(311, 114, 43),
(312, 115, 43),
(313, 116, 43),
(314, 117, 43),
(315, 118, 43),
(316, 119, 43),
(317, 120, 43),
(318, 121, 43),
(319, 122, 43),
(320, 123, 43),
(321, 124, 43),
(322, 125, 43),
(323, 126, 43),
(324, 127, 43),
(325, 128, 43),
(326, 129, 43),
(327, 130, 43),
(328, 131, 43),
(329, 132, 43),
(330, 133, 43),
(331, 134, 43),
(332, 135, 43),
(333, 136, 43),
(334, 137, 43),
(335, 138, 43),
(336, 139, 43),
(337, 140, 43),
(338, 141, 43),
(339, 142, 43),
(340, 143, 43),
(341, 144, 43),
(342, 145, 43),
(343, 146, 43),
(344, 147, 43),
(345, 150, 43),
(346, 151, 43),
(347, 152, 43),
(348, 153, 43),
(349, 154, 43),
(350, 155, 43),
(351, 156, 43),
(352, 157, 43),
(353, 158, 43),
(354, 159, 43),
(355, 160, 43),
(356, 161, 43),
(357, 162, 43),
(358, 163, 43),
(359, 184, 43),
(360, 185, 43),
(361, 186, 43),
(362, 187, 43),
(363, 188, 43),
(364, 170, 43),
(365, 171, 43),
(366, 172, 43),
(367, 173, 43),
(368, 174, 43),
(369, 175, 43),
(370, 176, 43),
(371, 177, 43),
(372, 178, 43),
(373, 179, 43),
(374, 180, 43),
(375, 181, 43),
(376, 182, 43),
(377, 183, 43),
(378, 164, 43),
(379, 165, 43),
(380, 166, 43),
(381, 167, 43),
(382, 168, 43),
(383, 169, 43),
(384, 148, 43),
(385, 149, 43),
(386, 189, 43),
(387, 190, 43),
(388, 191, 43),
(389, 192, 43),
(390, 193, 43),
(391, 194, 43),
(392, 195, 43),
(393, 196, 43),
(394, 197, 43),
(402, 8, 2),
(403, 9, 2),
(599, 8, 44),
(600, 9, 44),
(789, 1, 44),
(790, 2, 44),
(791, 3, 44),
(792, 4, 44),
(793, 5, 44),
(794, 6, 44),
(795, 7, 44),
(796, 10, 44),
(797, 11, 44),
(798, 12, 44),
(799, 13, 44),
(800, 14, 44),
(801, 189, 44),
(802, 190, 44),
(803, 191, 44),
(804, 15, 44),
(805, 16, 44),
(806, 17, 44),
(807, 18, 44),
(808, 197, 44),
(809, 19, 44),
(810, 20, 44),
(811, 21, 44),
(812, 22, 44),
(813, 23, 44),
(814, 24, 44),
(815, 25, 44),
(816, 26, 44),
(817, 27, 44),
(818, 193, 44),
(819, 28, 44),
(820, 29, 44),
(821, 30, 44),
(822, 31, 44),
(823, 32, 44),
(824, 192, 44),
(825, 33, 44),
(826, 34, 44),
(827, 35, 44),
(828, 36, 44),
(829, 37, 44),
(830, 38, 44),
(831, 39, 44),
(832, 195, 44),
(833, 40, 44),
(834, 41, 44),
(835, 42, 44),
(836, 43, 44),
(837, 44, 44),
(838, 45, 44),
(839, 46, 44),
(840, 47, 44),
(841, 48, 44),
(842, 49, 44),
(843, 50, 44),
(844, 51, 44),
(845, 52, 44),
(846, 53, 44),
(847, 54, 44),
(848, 55, 44),
(849, 56, 44),
(850, 57, 44),
(851, 58, 44),
(852, 59, 44),
(853, 60, 44),
(854, 61, 44),
(855, 62, 44),
(856, 63, 44),
(857, 64, 44),
(858, 65, 44),
(859, 66, 44),
(860, 67, 44),
(861, 68, 44),
(862, 69, 44),
(863, 70, 44),
(864, 71, 44),
(865, 72, 44),
(866, 73, 44),
(867, 74, 44),
(868, 75, 44),
(869, 76, 44),
(870, 77, 44),
(871, 78, 44),
(872, 79, 44),
(873, 80, 44),
(874, 81, 44),
(875, 82, 44),
(876, 83, 44),
(877, 84, 44),
(878, 85, 44),
(879, 86, 44),
(880, 87, 44),
(881, 88, 44),
(882, 89, 44),
(883, 90, 44),
(884, 91, 44),
(885, 92, 44),
(886, 93, 44),
(887, 94, 44),
(888, 95, 44),
(889, 96, 44),
(890, 97, 44),
(891, 98, 44),
(892, 99, 44),
(893, 100, 44),
(894, 101, 44),
(895, 102, 44),
(896, 103, 44),
(897, 104, 44),
(898, 105, 44),
(899, 106, 44),
(900, 107, 44),
(901, 108, 44),
(902, 109, 44),
(903, 110, 44),
(904, 111, 44),
(905, 112, 44),
(906, 113, 44),
(907, 114, 44),
(908, 115, 44),
(909, 116, 44),
(910, 117, 44),
(911, 118, 44),
(912, 119, 44),
(913, 120, 44),
(914, 121, 44),
(915, 122, 44),
(916, 123, 44),
(917, 124, 44),
(918, 125, 44),
(919, 126, 44),
(920, 127, 44),
(921, 128, 44),
(922, 129, 44),
(923, 130, 44),
(924, 131, 44),
(925, 132, 44),
(926, 133, 44),
(927, 134, 44),
(928, 135, 44),
(929, 136, 44),
(930, 137, 44),
(931, 138, 44),
(932, 139, 44),
(933, 140, 44),
(934, 141, 44),
(935, 142, 44),
(936, 143, 44),
(937, 144, 44),
(938, 145, 44),
(939, 194, 44),
(940, 146, 44),
(941, 147, 44),
(942, 150, 44),
(943, 151, 44),
(944, 152, 44),
(945, 153, 44),
(946, 154, 44),
(947, 155, 44),
(948, 156, 44),
(949, 157, 44),
(950, 158, 44),
(951, 159, 44),
(952, 160, 44),
(953, 161, 44),
(954, 162, 44),
(955, 163, 44),
(956, 196, 44),
(957, 184, 44),
(958, 185, 44),
(959, 186, 44),
(960, 187, 44),
(961, 188, 44),
(962, 170, 44),
(963, 171, 44),
(964, 172, 44),
(965, 173, 44),
(966, 174, 44),
(967, 175, 44),
(968, 176, 44),
(969, 177, 44),
(970, 178, 44),
(971, 179, 44),
(972, 180, 44),
(973, 181, 44),
(974, 182, 44),
(975, 183, 44),
(976, 164, 44),
(977, 165, 44),
(978, 166, 44),
(979, 167, 44),
(980, 168, 44),
(981, 169, 44),
(982, 148, 44),
(983, 149, 44),
(984, 11, 2),
(985, 40, 2),
(986, 41, 2),
(987, 47, 2),
(988, 48, 2),
(989, 54, 2),
(990, 55, 2),
(991, 95, 2),
(992, 96, 2),
(993, 102, 2),
(994, 103, 2),
(995, 109, 2),
(996, 110, 2),
(997, 116, 2),
(998, 119, 2),
(999, 1, 2),
(1000, 2, 2),
(1001, 3, 2),
(1002, 4, 2),
(1003, 5, 2),
(1004, 6, 2),
(1005, 7, 2),
(1006, 10, 2),
(1007, 12, 2),
(1008, 13, 2),
(1009, 14, 2),
(1010, 189, 2),
(1011, 190, 2),
(1012, 191, 2),
(1013, 15, 2),
(1014, 16, 2),
(1015, 17, 2),
(1016, 18, 2),
(1017, 197, 2),
(1018, 88, 2),
(1019, 89, 2),
(1020, 90, 2),
(1021, 91, 2),
(1022, 92, 2),
(1023, 93, 2),
(1024, 94, 2),
(1025, 177, 2),
(1026, 178, 2),
(1027, 179, 2),
(1028, 180, 2),
(1029, 181, 2),
(1030, 182, 2),
(1031, 183, 2),
(1032, 19, 2),
(1033, 20, 2),
(1034, 21, 2),
(1035, 22, 2),
(1036, 23, 2),
(1037, 24, 2),
(1038, 25, 2),
(1039, 26, 2),
(1040, 27, 2),
(1041, 193, 2),
(1042, 78, 2),
(1043, 79, 2),
(1044, 80, 2),
(1045, 28, 2),
(1046, 29, 2),
(1047, 30, 2),
(1048, 31, 2),
(1049, 32, 2),
(1050, 192, 2),
(1051, 33, 2),
(1052, 34, 2),
(1053, 35, 2),
(1054, 36, 2),
(1055, 37, 2),
(1056, 38, 2),
(1057, 39, 2),
(1058, 195, 2),
(1059, 81, 2),
(1060, 82, 2),
(1061, 83, 2),
(1062, 84, 2),
(1063, 85, 2),
(1064, 86, 2),
(1065, 87, 2),
(1066, 42, 2),
(1067, 43, 2),
(1068, 44, 2),
(1069, 45, 2),
(1070, 46, 2),
(1071, 49, 2),
(1072, 50, 2),
(1073, 51, 2),
(1074, 52, 2),
(1075, 53, 2),
(1076, 56, 2),
(1077, 57, 2),
(1078, 58, 2),
(1079, 59, 2),
(1080, 60, 2),
(1081, 97, 2),
(1082, 98, 2),
(1083, 99, 2),
(1084, 100, 2),
(1085, 101, 2),
(1086, 104, 2),
(1087, 105, 2),
(1088, 106, 2),
(1089, 107, 2),
(1090, 108, 2),
(1091, 111, 2),
(1092, 112, 2),
(1093, 113, 2),
(1094, 114, 2),
(1095, 115, 2),
(1096, 117, 2),
(1097, 118, 2),
(1098, 120, 2),
(1099, 121, 2),
(1100, 138, 2),
(1101, 146, 2),
(1102, 147, 2),
(1103, 152, 2),
(1104, 148, 2),
(1105, 149, 2),
(1106, 61, 2),
(1107, 62, 2),
(1108, 63, 2),
(1109, 64, 2),
(1110, 65, 2),
(1111, 66, 2),
(1112, 67, 2),
(1113, 68, 2),
(1114, 69, 2),
(1115, 70, 2),
(1116, 71, 2),
(1117, 72, 2),
(1118, 73, 2),
(1119, 74, 2),
(1120, 75, 2),
(1121, 76, 2),
(1122, 77, 2),
(1123, 122, 2),
(1124, 123, 2),
(1125, 124, 2),
(1126, 125, 2),
(1127, 126, 2),
(1128, 127, 2),
(1129, 128, 2),
(1130, 129, 2),
(1131, 130, 2),
(1132, 131, 2),
(1133, 132, 2),
(1134, 133, 2),
(1135, 134, 2),
(1136, 135, 2),
(1137, 136, 2),
(1138, 137, 2),
(1139, 139, 2),
(1140, 140, 2),
(1141, 141, 2),
(1142, 142, 2),
(1143, 143, 2),
(1144, 144, 2),
(1145, 145, 2),
(1146, 194, 2),
(1147, 150, 2),
(1148, 151, 2),
(1149, 153, 2),
(1150, 154, 2),
(1151, 155, 2),
(1152, 156, 2),
(1153, 157, 2),
(1154, 158, 2),
(1155, 159, 2),
(1156, 160, 2),
(1157, 161, 2),
(1158, 162, 2),
(1159, 163, 2),
(1160, 196, 2),
(1161, 164, 2),
(1162, 165, 2),
(1163, 166, 2),
(1164, 167, 2),
(1165, 168, 2),
(1166, 169, 2),
(1167, 184, 2),
(1168, 185, 2),
(1169, 186, 2),
(1170, 187, 2),
(1171, 188, 2),
(1172, 170, 2),
(1173, 171, 2),
(1174, 172, 2),
(1175, 173, 2),
(1176, 174, 2),
(1177, 175, 2),
(1178, 176, 2),
(1179, 28, 45),
(1180, 29, 45),
(1181, 30, 45),
(1182, 31, 45),
(1183, 32, 45);

-- --------------------------------------------------------

--
-- Table structure for table `planning_strategies`
--

CREATE TABLE `planning_strategies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `planning_strategies`
--

INSERT INTO `planning_strategies` (`id`, `name`) VALUES
(1, 'Investigate'),
(2, 'Accepted'),
(3, 'Mitigated'),
(4, 'To see'),
(5, 'Transfer');

-- --------------------------------------------------------

--
-- Table structure for table `privacies`
--

CREATE TABLE `privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `privacies`
--

INSERT INTO `privacies` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Private', '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(2, 'Public', '2023-11-12 19:29:02', '2023-11-12 19:29:02');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_date` timestamp NULL DEFAULT NULL,
  `consultant` int(11) DEFAULT NULL,
  `business_owner` int(11) DEFAULT NULL,
  `data_classification` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 999999,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `due_date`, `consultant`, `business_owner`, `data_classification`, `order`, `status`) VALUES
(1, 'Project 1', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(2, 'Project 2', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(3, 'Project 3', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(4, 'Project 4', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(5, 'Project 5', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(6, 'Project 6', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(7, 'Project 7', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(8, 'Project 8', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(9, 'Project 9', '0000-00-00 00:00:00', 0, 0, 0, 0, 0),
(10, 'Project 10', '0000-00-00 00:00:00', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `questionnaires`
--

CREATE TABLE `questionnaires` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instructions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assessment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `all_questions_mandatory` tinyint(1) NOT NULL DEFAULT 0,
  `answer_percentage` tinyint(1) NOT NULL DEFAULT 0,
  `percentage_number` tinyint(4) NOT NULL DEFAULT 0,
  `specific_mandatory_questions` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questionnaires`
--

INSERT INTO `questionnaires` (`id`, `name`, `instructions`, `assessment_id`, `all_questions_mandatory`, `answer_percentage`, `percentage_number`, `specific_mandatory_questions`, `created_at`, `updated_at`) VALUES
(3, 'cmx', 'mxx', 2, 0, 1, 10, 0, '2023-11-13 14:52:36', '2023-11-13 14:55:10');

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire_pending_risks`
--

CREATE TABLE `questionnaire_pending_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `questionnaire_tracking_id` int(11) NOT NULL,
  `questionnaire_scoring_id` int(11) NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` int(11) DEFAULT NULL,
  `asset` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire_questions`
--

CREATE TABLE `questionnaire_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `questionnaire_id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire_risks`
--

CREATE TABLE `questionnaire_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `questionnaire_id` bigint(20) UNSIGNED NOT NULL,
  `answer_id` bigint(20) UNSIGNED NOT NULL,
  `risk_subject` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `risk_scoring_method_id` bigint(20) UNSIGNED DEFAULT NULL,
  `likelihood_id` bigint(20) UNSIGNED DEFAULT NULL,
  `impact_id` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `framework_controls_ids` bigint(20) UNSIGNED NOT NULL,
  `assets_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`assets_ids`)),
  `tags_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags_ids`)),
  `status` enum('pending','rejected','added') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_type` tinyint(4) NOT NULL DEFAULT 1,
  `control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `file_attachment` tinyint(1) NOT NULL DEFAULT 0,
  `question_logic` tinyint(1) NOT NULL DEFAULT 0,
  `risk_assessment` tinyint(1) NOT NULL DEFAULT 0,
  `compliance_assessment` tinyint(1) NOT NULL DEFAULT 0,
  `maturity_assessment` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `answer_type`, `control_id`, `file_attachment`, `question_logic`, `risk_assessment`, `compliance_assessment`, `maturity_assessment`, `created_at`, `updated_at`) VALUES
(1, 'Do you actively manage (inventory, track, and correct) all hardware devices on the network so that only authorized devices are given access, and unauthorized and unmanaged devices are found a', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(2, 'Do you actively manage (inventory, track, and correct) all software on the network so that only authorized software is installed and can execute, and that unauthorized and unmanaged software ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(3, 'Do you establish, implement, and actively manage (track, report on, correct) the security configuration of laptops, servers, and workstations using a rigorous configuration management and cha', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(4, 'Do you continuously acquire, assess, and take action on new information in order to identify vulnerabilities, remediate, and minimize the window of opportunity for attackers?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(5, 'Do you have processes and tools to track/control/prevent/correct the use, assignment, and configuration of administrative privileges on computers, networks, and applications?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(6, 'Do you collect, manage, and analyze audit logs of events that could help detect, understand, or recover from an attack?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(7, 'Do you minimize the attack surface and the opportunities for attackers to manipulate human behavior through their interaction with web browsers and emails systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(8, 'Do you control the installation, spread, and execution of malicious code at multiple points in the enterprise, while optimizing the use of automation to enable rapid updating of defense, data', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(9, 'Do you manage (track/control/correct) the ongoing operational use of ports, protocols, and services on networked devices in order to minimize windows of vulnerability available to attackers?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(10, 'Do you have processes and tools to properly back up critical information with a proven methodology for timely recovery of it?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(11, 'Do you establish, implement, and actively manage (track, report on, correct) the security configuration of network infrastructure devices using a rigorous configuration management and change ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(12, 'Do you detect/prevent/correct the flow of information transferring networks of different trust levels with a focus on security-damaging data?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(13, 'Do you have processes and tools to prevent data exfiltration, mitigate the effects of exfiltrated data, and ensure the privacy and integrity of sensitive information?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(14, 'Do you have processes and tools to track/control/prevent/correct secure access to critical assets (e.g., information, resources, systems) according to the formal determination of which person', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(15, 'Do you have processes and tools to track/control/prevent/correct the security use of wireless local area networks (LANS), access points, and wireless client systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(16, 'Do you actively manage the life cycle of system and application accounts - their creation, use, dormancy, deletion - in order to minimize opportunities for attackers to leverage them?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(17, 'Do all functional roles in the organization (prioritizing those mission-critical to the business and its security) identiy the specific knowledge, skills, and abilities needed to support defe', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(18, 'Do you manage the security life cycle of all in-house developed and acquired software in order to prevent, detect, and correct security weaknesses?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(19, 'Do you protect the organization\'s information, as well as its reputation, by developing and implementing an incident response infrastructure (e.g., plans, defined roles, training, communicati', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(20, 'Do you test the overall strength of your organization\'s defenses (the technology, the processes, and the people) by simulating the objectives and actions of an attacker?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(21, '(3.1.1) Do we limit information system access to authorized users, processes acting on behalf of authorized users, or devices? (including other information systems)', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(22, '(3.1.2) Do we limit access to the types of transactions and functions that authorized users are permitted to execute?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(23, '(3.1.3.) Do we control CUI in accordance with approved authorizations?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(24, '(3.1.4) Do we keep duties of individuals separated to reduce the risk of malevolent activity without collusion?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(25, '(3.1.5) Do we employ the principle of least privilege, including specific security functions and privileged accounts?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(26, '(3.1.6) Do we disallow the organization to use non-privileged accounts or roles when accessing non-security functions?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(27, '(3.1.7) Do we prevent non-privileged users from executing privileged functions and audit the execution of such functions?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(28, '(3.1.8) Do we limit unsuccessful logon attempts?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(29, '(3.1.9) Do we provide privacy and security notices consistent with applicable CUI rules?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(30, '(3.1.10) Do we use session lock with pattern hiding displays to prevent access/viewing of data after a period of inactivity?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(31, '(3.1.11) Do we terminate a user session after a defined condition or time?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(32, '(3.1.12) Do we monitor and control remote access sessions?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(33, '(3.1.13) Do we employ cryptographic mechanisms to protect the confidentiality of remote access sessions?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(34, '(3.1.14) Do we route remote access through managed access control points?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(35, '(3.1.15) Does the system require authorization of remote execution of privileged commands and remote access to security relevant information?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(36, '(3.1.16) Do we authorize wireless access prior to allowing such connections?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(37, '(3.1.17) Do we protect wireless access using authentication and encryption?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:06', '2023-11-12 19:29:06'),
(38, '(3.1.18) Do we have guidelines and procedures in place to restrict the operation and connection of mobile devices?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(39, '(3.1.19) Do we encrypt CUI on mobile devices?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(40, '(3.1.20) Do we verify and control/limit connections to and use of external information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(41, '(3.1.21) Do we limit use of organizational portable storage devices on external information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(42, '(3.1.22) Do we prohibit posting or processing control information on publicly accessible information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(43, '(3.2.1) Do we ensure that managers, systems administrators, and users of organizational information systems are made aware of the security risks associated with their activities and of the ap', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(44, '(3.2.2) Do we Ensure that organizational personnel are adequately trained to carry out their assigned information security-related duties and responsibilities?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(45, '(3.2.3) Do we provide security awareness training on recognizing and reporting potential indicators of insider threats?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(46, '(3.3.1) Do you create, protect, and retain information system audit records to the extent needed to enable the monitoring, analysis, investigations, and reporting of unlawful, unauthorized, o', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(47, '(3.3.2) Do we ensure that the actions of individual information system users can be uniquely traced to those users so they can be held accountable for their actions?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(48, '(3.3.3) Do we review and update audited events?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(49, '(3.3.4) Do we have alerts in the event of an audit process failure?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(50, '(3.3.5) Do we use automated mechanisms to integrate and correlate audit review, analysis, and reporting processes for investigation and response to indications of inappropriate, suspicious, o', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(51, '(3.3.6) Do we provide audit reduction and report generation to support on-demand analysis and reporting?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(52, '(3.3.7) Do we provide an information system capability that compares and synchronizes internal system clocks with an authoritative source to generate time stamps for audit records?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(53, '(3.3.8) Do we protect audit information and audit tools from unauthorized access, modification, and deletion?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(54, '(3.3.9) Do we limit management of audit functionality to a subset of privileged users?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(55, '(3.4.1) Do we establish and maintain baseline configurations and inventories of organizational information systems (including hardware, software, firmware, and documentation) throughout the r', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(56, '(3.4.2) Do we establish and enforce security configuration settings for information technology products employed in organizational information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(57, '(3.4.3) Do we track, review, approve/disapprove, and audit changes to information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(58, '(3.4.4) Do we analyze the security impact of changes prior to implementation?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(59, '(3.4.5) Do we define, document, approve, and enforce physical and logical access restrictions associated with changes to the information system?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(60, '(3.4.6) Do we employ the principle of least functionality by configuring the information system to provide only essential capabilities? ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(61, '(3.4.7) Do we restrict, disable, and prevent the use of nonessential programs, functions, ports, protocols, and services?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(62, '(3.4.8) Do we apply deny-by-exception (blacklist) policy to prevent the use of unauthorized software or deny-all, permit-by-exception (whitelisting) policy to allow the execution of authorize', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(63, '(3.4.9) Do we control and monitor user-installed software?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(64, '(3.5.1) Do we identify information system users, processes acting on behalf of users, or devices?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(65, '(3.5.2) Do we authenticate (or verify) the identities of those users, processes, or devices, as a prerequisite to allowing access to organizational information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(66, '(3.5.3) Do we use multi-factor authentication for local and network access to privileged accounts and for network access to non-privileged accounts?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(67, '(3.5.4) Do we employ replay-resistant authentication mechanisms for network access to privileged and non-privileged accounts?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(68, '(3.5.5) Do we prevent the reuse of identifiers for a defined period?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(69, '(3.5.6) Do we disable identifiers after a defined period of inactivity?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(70, '(3.5.7) Do we enforce a minimum password complexity and change of characters when new passwords are created?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(71, '(3.5.8) Do we prohibit password reuse for a specified number of generations?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(72, '(3.5.9) Do we allow temporary password use for system logons with an immediate change to a permanent password?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(73, '(3.5.10) Do we store and transmit only encrypted representation of passwords?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(74, '(3.5.11) Do we obscure feedback of authentication information?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(75, '(3.6.1) Have we established an operational incident handling capability for organizational information systems that includes adequate preparation, detection, analysis, containment, recovery, ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(76, '(3.6.2) Do we track, document, and report incidents to appropriate officials and/or authorities both internal and external to the organizations? ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(77, '(3.6.3) Do we test the organizational incident response capability? ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(78, '(3.7.1) Do we perform maintenance on organizational information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(79, '(3.7.2) Do we provide effective controls on the tools, techniques, mechanisms, and personnel used to conduct information system maintenance?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(80, '(3.7.3) Do we ensure equipment removed for off-site maintenance is sanitized of any CUI?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(81, '(3.7.4) Do we check media containing diagnostic and test programs for malicious code before the media are used in the information system?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(82, '(3.7.5) Do we require multifaction authentication to establish non-local maintenance sessions via external network connections when non-local maintenance is complete? ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(83, '(3.7.6) Do we supervise the maintenance activities of maintenance personnel without required access authorization?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(84, '(3.8.1) Do we protect (i.e., physically control and securely store) information system media  containing CUI, both paper and digital?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(85, '(3.8.2) Do we limit access to CUI on information system media to authorized users?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(86, '(3.8.3) Do we sanitize or destroy information system media containing CUI before disposal or release for reuse?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(87, '(3.8.4) Do we mark media with the necessary CUI markings and distribution limitations?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(88, '(3.8.5) Do we control access to media containing CUI and maintain accountability for media during transport outside of controlled areas?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(89, '(3.8.6) Do we implement cryptographic mechanisms to protect the confidentiality of CUI stored on digital media during transport unless otherwise protected by alternative physical safeguards?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(90, '(3.8.7) Do we control the use of removable media on information system components?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(91, '(3.8.8) Do we prohibit the use of portable storage devices when such devices have no identifiable owner?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(92, '(3.8.9) Do we protect the confidentiality of backup CUI as storage locations?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(93, '(3.9.1) Do we screen individuals prior to authorizing access to information systems containing CUI?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(94, '(3.9.2) Do we ensure that CUI and information systems containing CUI are protected during and after personnel actions such as terminations and transfers?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(95, '(3.10.1) Do we limit physical access to organizational information systems, equipment, and the respective operating environments to authorized individuals?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(96, '(3.10.2) Do we protect and monitor the physical facility and support infrastructure for those information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(97, '(3.10.3) Do we escort visitors and monitor visitor activity?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(98, '(3.10.4) Do we maintain audit logs of physical access?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(99, '(3.10.5) Do we control and manage physical access devices?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(100, '(3.10.6) Do we enforce safeguarding measures for CUI at alternate work sites? (e.g. telework sites)', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(101, '(3.11.1) Do we periodically assess the risk to organizational operations (including mission, functions, image, or reputation), organizational assets, and individuals, resulting from the opera', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(102, '(3.11.2) Do we scan for vulnerabilities in the information system and applications periodically and when new vulnerabilities affecting the system are identified?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(103, '(3.11.3) Do we remediate vulnerabilities in accordance with assessments of risk?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(104, '(3.12.1) Do we periodically assess the security controls in organizational information systems to determine if the controls are effective in their application?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(105, '(3.12.2) Do we develop and implement plans of action designed to correct deficiencies and reduce or eliminate vulnerabilities in organizational information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(106, '(3.12.3) Do we monitor information system security controls on an ongoing basis to ensure the continued effectiveness of the controls?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(107, '(3.13.1) Do we monitor, control, and protect organizational communications (i.e. information transmitted or received by organizational information systems) at the external boundaries and key ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(108, '(3.13.2) Do we employ architectural designs, software development techniques, and systems engineering principles that promote effective information security within organizations information s', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(109, '(3.13.3) Do we separate user functionality from information system management functionality?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(110, '(3.13.4) Do we prevent unauthorized and unintended information transfer via shared system resources?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(111, '(3.13.5) Do we implement subnetworks for publicly accessible system components that are physically or logically separated from internal networks?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(112, '(3.13.6) Do we deny network communications traffic by default and allow network communications by exception?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(113, '(3.13.7) Do we prevent remote devices from simultaneously establishing non-remote connections with the information system and communicating via some other connection to resources in external ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(114, '(3.13.8) Do we implement cryptographic mechanisms to prevent unauthorized disclosure of CUI during transmission unless otherwise protected by alternative physical safeguards?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(115, '(3.13.9) Do we terminate network connections associated with communications sessions at the end of the sessions or after a defined period of inactivity?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(116, '(3.13.10) Do we establish and manage cryptographic keys for cryptography employed in the information system?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(117, '(3.13.12) Do we prohibit remote activation of collaborative computing devices and provide indication of devices in use to users present at the device?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(118, '(3.13.13) Do we control and monitor the use of mobile code? ', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(119, '(3.13.14) Do we control and monitor the use of voice over internet protocol (VOIP) technologies?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(120, '(3.13.15) Do we protect the authenticity of communications sessions?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(121, '(3.13.16) Do we protect the confidentiality of CUI at rest?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(122, '(3.14.1) Do we identify, report, and correct information and information system flaws in a timely manner?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(123, '(3.14.2) Do we provide protection from malicious code at appropriate locations within organizational information systems?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(124, '(3.14.3) Do we monitor information system security alerts and advisories and take appropriate actions in response?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(125, '(3.14.4) Do we update malicious code protection mechanisms when new releases are available?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(126, '(3.14.5) Do we perform periodic scans of the information system and real-time scans of files from external sources as files are downloaded, opened, or executed?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(127, '(3.14.6) Do we monitor the information system including inbound and outbound communications traffic, to detect attacks and indicators of potential attacks?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(128, '(3.14.7) Do we identify unauthorized use of the information system?', 1, NULL, 0, 0, 0, 0, 0, '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(129, 'how', 3, NULL, 0, 0, 0, 0, 0, '2023-11-12 20:40:19', '2023-11-12 20:40:19'),
(130, 'wfat', 1, 909, 0, 0, 0, 0, 0, '2023-11-13 14:49:27', '2023-11-13 14:49:27');

-- --------------------------------------------------------

--
-- Table structure for table `regulations`
--

CREATE TABLE `regulations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regulations`
--

INSERT INTO `regulations` (`id`, `name`) VALUES
(1, 'PCI DSS 3.2'),
(2, 'Sarbanes-Oxley (SOX)'),
(3, 'HIPAA'),
(4, 'ISO 27001');

-- --------------------------------------------------------

--
-- Table structure for table `residual_risk_scoring_histories`
--

CREATE TABLE `residual_risk_scoring_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `residual_risk` double(8,2) NOT NULL,
  `last_update` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `residual_risk_scoring_histories`
--

INSERT INTO `residual_risk_scoring_histories` (`id`, `risk_id`, `residual_risk`, `last_update`) VALUES
(1, 1, 1.20, '2023-11-12 19:29:07'),
(2, 2, 1.20, '2023-11-12 19:29:07'),
(3, 3, 1.20, '2023-11-12 19:29:07'),
(4, 4, 1.20, '2023-11-12 19:29:07'),
(5, 5, 1.20, '2023-11-12 19:29:07'),
(6, 6, 1.20, '2023-11-12 19:29:07'),
(7, 7, 1.20, '2023-11-12 19:29:07'),
(8, 8, 1.20, '2023-11-12 19:29:07'),
(9, 9, 1.20, '2023-11-12 19:29:07'),
(10, 10, 1.20, '2023-11-12 19:29:07'),
(11, 11, 1.20, '2023-11-12 19:29:07'),
(12, 12, 1.20, '2023-11-12 19:29:07'),
(13, 13, 1.20, '2023-11-12 19:29:07'),
(14, 14, 1.20, '2023-11-12 19:29:07'),
(15, 15, 1.20, '2023-11-12 19:29:07'),
(16, 16, 1.20, '2023-11-12 19:29:07'),
(17, 17, 1.20, '2023-11-12 19:29:07'),
(18, 18, 1.20, '2023-11-12 19:29:07'),
(19, 19, 1.20, '2023-11-12 19:29:07'),
(20, 20, 1.20, '2023-11-12 19:29:07'),
(21, 21, 0.40, '2023-11-12 19:29:07'),
(22, 22, 1.60, '2023-11-12 19:29:07'),
(23, 23, 3.60, '2023-11-12 19:29:07'),
(24, 24, 6.40, '2023-11-12 19:29:07'),
(25, 25, 10.00, '2023-11-12 19:29:07'),
(26, 26, 1.60, '2023-11-12 19:43:40'),
(27, 27, 10.00, '2023-11-12 19:46:35'),
(28, 28, 10.00, '2023-11-12 20:35:41'),
(29, 29, 10.00, '2023-11-13 13:38:23'),
(30, 30, 2.00, '2023-11-13 18:49:36'),
(31, 31, 10.00, '2023-11-13 18:51:13');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `name`) VALUES
(1, 'Approve Risk'),
(2, 'Reject Risk and Close');

-- --------------------------------------------------------

--
-- Table structure for table `review_levels`
--

CREATE TABLE `review_levels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `review_levels`
--

INSERT INTO `review_levels` (`id`, `value`, `name`) VALUES
(1, 360, 'Insignificant'),
(2, 360, 'Low'),
(3, 180, 'Medium'),
(4, 90, 'High'),
(5, 90, 'Very High');

-- --------------------------------------------------------

--
-- Table structure for table `risks`
--

CREATE TABLE `risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'New',
  `subject` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regulation` int(11) DEFAULT NULL,
  `control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `source_id` bigint(20) UNSIGNED DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `manager_id` bigint(20) UNSIGNED DEFAULT NULL,
  `assessment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mitigation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `mgmt_review` int(11) DEFAULT NULL,
  `project_id` bigint(20) UNSIGNED DEFAULT NULL,
  `close_id` int(11) DEFAULT NULL,
  `submitted_by` int(11) NOT NULL DEFAULT 1,
  `risk_catalog_mapping` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `threat_catalog_mapping` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_group_id` int(11) NOT NULL DEFAULT 1,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risks`
--

INSERT INTO `risks` (`id`, `status`, `subject`, `reference_id`, `regulation`, `control_id`, `source_id`, `category_id`, `owner_id`, `manager_id`, `assessment`, `notes`, `review_date`, `mitigation_id`, `mgmt_review`, `project_id`, `close_id`, `submitted_by`, `risk_catalog_mapping`, `threat_catalog_mapping`, `template_group_id`, `submission_date`, `created_at`, `updated_at`) VALUES
(1, 'Closed', 'ipsam', NULL, NULL, NULL, 2, 3, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 1, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(2, 'Opened', 'quae', NULL, NULL, NULL, 1, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 2, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(3, 'Closed', 'occaecati', NULL, NULL, NULL, 2, 4, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 3, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(4, 'Closed', 'labore', NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 4, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(5, 'Opened', 'facere', NULL, NULL, NULL, 4, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 5, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(6, 'Opened', 'nam', NULL, NULL, NULL, 4, 3, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 6, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(7, 'Opened', 'voluptas', NULL, NULL, NULL, 3, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 7, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(8, 'Opened', 'eos', NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 8, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(9, 'Opened', 'natus', NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 9, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(10, 'Closed', 'dolores', NULL, NULL, NULL, 3, 3, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 10, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(11, 'Closed', 'nemo', NULL, NULL, NULL, 2, 7, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 11, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(12, 'Closed', 'et', NULL, NULL, NULL, 2, 2, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 12, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(13, 'Closed', 'hic', NULL, NULL, NULL, 2, 3, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 13, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(14, 'Opened', 'magni', NULL, NULL, NULL, 1, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 14, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(15, 'Closed', 'esse', NULL, NULL, NULL, 2, 5, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 15, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(16, 'Opened', 'hic', NULL, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 16, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(17, 'Closed', 'quo', NULL, NULL, NULL, 2, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 17, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(18, 'Closed', 'aut', NULL, NULL, NULL, 1, 5, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 18, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(19, 'Opened', 'atque', NULL, NULL, NULL, 3, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 19, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(20, 'Closed', 'vel', NULL, NULL, NULL, 3, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 20, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(21, 'New', 'Risk 1 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(22, 'New', 'Risk 2 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(23, 'New', 'Risk 3 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(24, 'New', 'Risk 4 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(25, 'New', 'Risk 5 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2023-11-12 16:29:07', '2023-11-12 19:29:07', '2023-11-12 19:29:07'),
(26, 'New', 'Risk 99', NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, '1', '2', 0, '2023-11-12 16:43:40', '2023-11-12 19:43:40', '2023-11-12 19:43:40'),
(27, 'New', 'erfe', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, '', '', 0, '2023-11-12 16:46:35', '2023-11-12 19:46:35', '2023-11-12 19:46:53'),
(28, 'Reopened', 'sss', 'AA', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-12 20:37:04', NULL, NULL, NULL, NULL, 1, '', '', 0, '2023-11-12 17:35:41', '2023-11-12 20:35:41', '2023-11-12 20:37:04'),
(29, '', 'azzjm', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2023-11-13 13:39:31', NULL, NULL, NULL, NULL, 1, '', '', 0, '2023-11-13 10:38:23', '2023-11-13 13:38:23', '2023-11-13 13:39:31'),
(30, 'New', 'Facere odit ullamco', 'Assumenda amet maxi', 1, 159, 3, 8, 19, 8, 'Tempora pariatur Ad', 'Optio qui illo dele', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, '3,5', '3,4,8,12,13,15,17,20', 0, '2023-11-13 15:49:36', '2023-11-13 18:49:36', '2023-11-13 18:49:36'),
(31, 'New', 'Risk663', NULL, 1, NULL, 1, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, '3', '3', 0, '2023-11-13 15:51:13', '2023-11-13 18:51:13', '2023-11-13 18:51:13');

-- --------------------------------------------------------

--
-- Table structure for table `risks_to_assets`
--

CREATE TABLE `risks_to_assets` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `asset_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risks_to_assets`
--

INSERT INTO `risks_to_assets` (`risk_id`, `asset_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20),
(30, 4),
(30, 5),
(30, 13),
(30, 15),
(30, 18),
(30, 19);

-- --------------------------------------------------------

--
-- Table structure for table `risks_to_asset_groups`
--

CREATE TABLE `risks_to_asset_groups` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `asset_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risks_to_asset_groups`
--

INSERT INTO `risks_to_asset_groups` (`risk_id`, `asset_group_id`) VALUES
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(30, 2),
(30, 3),
(30, 4),
(30, 5),
(30, 6),
(30, 7),
(30, 9),
(30, 11),
(30, 16),
(30, 17),
(30, 19),
(30, 20);

-- --------------------------------------------------------

--
-- Table structure for table `risk_catalogs`
--

CREATE TABLE `risk_catalogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `risk_grouping_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `risk_function_id` bigint(20) UNSIGNED NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_catalogs`
--

INSERT INTO `risk_catalogs` (`id`, `number`, `risk_grouping_id`, `name`, `description`, `risk_function_id`, `order`) VALUES
(1, 'R-AC-1', 1, 'Inability to maintain individual accountability', 'There is a failure to maintain asset ownership and it is not possible to have non-repudiation of actions or inactions.', 2, 1),
(2, 'R-AC-2', 1, 'Improper assignment of privileged risk_function_ids', 'There is a failure to implement least privileges.', 2, 2),
(3, 'R-AC-3', 1, 'Privilege escalation', 'Access to privileged risk_function_ids is inadequate or cannot be controlled.', 2, 3),
(4, 'R-AC-4', 1, 'Unauthorized access', 'Access is granted to unauthorized individuals, groups or services.', 2, 4),
(5, 'R-AM-1', 2, 'Lost, damaged or stolen asset(s)', 'Asset(s) is/are lost, damaged or stolen.', 2, 5),
(6, 'R-AM-2', 2, 'Loss of integrity through unauthorized changes ', 'Unauthorized changes corrupt the integrity of the system / application / service.', 2, 6),
(7, 'R-BC-1', 3, 'Business interruption ', 'There is increased latency or a service outage that negatively impacts business operations.', 5, 7),
(8, 'R-BC-2', 3, 'Data loss / corruption ', 'There is a failure to maintain the confidentiality of the data (compromise) or data is corrupted (loss).', 5, 8),
(12, 'R-BC-3', 3, 'Reduction in productivity', 'User productivity is negatively affected by the incident.', 2, 12),
(13, 'R-EX-1', 4, 'Loss of revenue ', 'A financial loss occures from either a loss of clients or inability to generate future revenue.', 5, 13),
(14, 'R-EX-2', 4, 'Cancelled contract', 'A contract is cancelled due to a violation of a contract clause.', 5, 14),
(15, 'R-EX-3', 4, 'Diminished competitive advantage', 'The competitive advantage of the organization is jeapordized.', 5, 15),
(16, 'R-EX-4', 4, 'Diminished reputation ', 'Negative publicity tarnishes the organization\'s reputation.', 5, 16),
(17, 'R-EX-5', 4, 'Fines and judgements', 'Legal and/or financial damages result from statutory / regulatory / contractual non-compliance.', 5, 17),
(18, 'R-EX-6', 4, 'Unmitigated vulnerabilities', 'Umitigated technical vulnerabilities exist without compensating controls or other mitigation actions.', 2, 18),
(19, 'R-EX-7', 4, 'System compromise', 'System / application / service is compromised affects its confidentiality, integrity,  availability and/or safety.', 2, 19),
(20, 'R-BC-4', 3, 'Information loss / corruption or system compromise due to technical attack', 'Malware, phishing, hacking or other technical attacks compromise data, systems, applications or services.', 2, 20),
(21, 'R-BC-5', 3, 'Information loss / corruption or system compromise due to non‐technical attack ', 'Social engineering, sabotage or other non-technical attack compromises data, systems, applications or services.', 2, 21),
(22, 'R-GV-1', 5, 'Inability to support business processes', 'Implemented security /privacy practices are insufficient to support the organization\'s secure technologies & processes requirements.', 2, 1),
(24, 'R-GV-4', 5, 'Inadequate internal practices ', 'Internal practices do not exist or are inadequate. Procedures fail to meet \\\"reasonable practices\\\" expected by industry standards.', 2, 4),
(25, 'R-GV-5', 5, 'Inadequate third-party practices', 'Third-party practices do not exist or are inadequate. Procedures fail to meet \\\"reasonable practices\\\" expected by industry standards.', 2, 5),
(26, 'R-GV-3', 5, 'Lack of roles & responsibilities', 'Documented security / privacy roles & responsibilities do not exist or are inadequate.', 1, 3),
(27, 'R-GV-2', 5, 'Incorrect controls scoping', 'There is incorrect or inadequate controls scoping, which leads to a potential gap or lapse in security / privacy controls coverage.', 1, 2),
(28, 'R-GV-8', 5, 'Illegal content or abusive action', 'There is abusive content / harmful speech / threats of violence / illegal content that negatively affect business operations.', 1, 8),
(29, 'R-SA-1', 6, 'Inability to maintain situational awareness', 'There is an inability to detect incidents.', 3, 29),
(30, 'R-SA-2', 6, 'Lack of a security-minded workforce', 'The workforce lacks user-level understanding about security & privacy principles.', 2, 30),
(31, 'R-GV-6', 5, 'Lack of oversight of internal controls', 'There is a lack of due diligence / due care in overseeing the organization\'s internal security / privacy controls.', 1, 6),
(32, 'R-GV-7', 5, 'Lack of oversight of third-party controls', 'There is a lack of due diligence / due care in overseeing security / privacy controls operated by third-party service providers.', 1, 7),
(33, 'R-IR-1', 7, 'Inability to investigate / prosecute incidents', 'Response actions either corrupt evidence or impede the ability to prosecute incidents.', 4, 1),
(34, 'R-IR-2', 7, 'Improper response to incidents', 'Response actions fail to act appropriately in a timely manner to properly address the incident.', 4, 2),
(35, 'R-IR-3', 7, 'Ineffective remediation actions', 'There is no oversight to ensure remediation actions are correct and/or effective.', 2, 3),
(36, 'R-IR-4', 7, 'Expense associated with managing a loss event', 'There are financial repercussions from responding to an incident or loss.', 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `risk_functions`
--

CREATE TABLE `risk_functions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_functions`
--

INSERT INTO `risk_functions` (`id`, `name`) VALUES
(1, 'Identify'),
(2, 'Protect'),
(3, 'Detect'),
(4, 'Respond'),
(5, 'Recover');

-- --------------------------------------------------------

--
-- Table structure for table `risk_groupings`
--

CREATE TABLE `risk_groupings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_groupings`
--

INSERT INTO `risk_groupings` (`id`, `name`) VALUES
(1, 'Access Control'),
(2, 'Asset Management'),
(3, 'Business Continuity'),
(4, 'Exposure'),
(5, 'Governance'),
(6, 'Situational Awareness'),
(7, 'Incident Response');

-- --------------------------------------------------------

--
-- Table structure for table `risk_levels`
--

CREATE TABLE `risk_levels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` decimal(3,1) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_level_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_levels`
--

INSERT INTO `risk_levels` (`id`, `value`, `name`, `color`, `display_name`, `review_level_id`) VALUES
(1, '0.0', 'Low', '#ffffff', 'Low', 2),
(2, '4.0', 'Medium', '#ffa500', 'Medium', 3),
(3, '7.0', 'High', '#ff4500', 'High', 4),
(4, '10.1', 'Very High', '#ff0000', 'Very High', 5);

-- --------------------------------------------------------

--
-- Table structure for table `risk_models`
--

CREATE TABLE `risk_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_models`
--

INSERT INTO `risk_models` (`id`, `name`) VALUES
(1, 'Likelihood x Impact + 2(Impact)'),
(2, 'Likelihood x Impact + Impact'),
(3, 'Likelihood x Impact'),
(4, 'Likelihood x Impact + Likelihood'),
(5, 'Likelihood x Impact + 2(Likelihood)');

-- --------------------------------------------------------

--
-- Table structure for table `risk_scorings`
--

CREATE TABLE `risk_scorings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `scoring_method` int(11) NOT NULL,
  `calculated_risk` double(8,2) NOT NULL,
  `CLASSIC_likelihood` double(8,2) NOT NULL DEFAULT 5.00,
  `CLASSIC_impact` double(8,2) NOT NULL DEFAULT 5.00,
  `CVSS_AccessVector` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_AccessComplexity` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'L',
  `CVSS_Authentication` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_ConfImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_IntegImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_AvailImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_Exploitability` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_RemediationLevel` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ReportConfidence` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_CollateralDamagePotential` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_TargetDistribution` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ConfidentialityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_IntegrityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_AvailabilityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `DREAD_DamagePotential` int(11) NOT NULL DEFAULT 10,
  `DREAD_Reproducibility` int(11) NOT NULL DEFAULT 10,
  `DREAD_Exploitability` int(11) NOT NULL DEFAULT 10,
  `DREAD_AffectedUsers` int(11) NOT NULL DEFAULT 10,
  `DREAD_Discoverability` int(11) NOT NULL DEFAULT 10,
  `OWASP_SkillLevel` int(11) NOT NULL DEFAULT 10,
  `OWASP_Motive` int(11) NOT NULL DEFAULT 10,
  `OWASP_Opportunity` int(11) NOT NULL DEFAULT 10,
  `OWASP_Size` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfDiscovery` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfExploit` int(11) NOT NULL DEFAULT 10,
  `OWASP_Awareness` int(11) NOT NULL DEFAULT 10,
  `OWASP_IntrusionDetection` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfConfidentiality` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfIntegrity` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAvailability` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAccountability` int(11) NOT NULL DEFAULT 10,
  `OWASP_FinancialDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_ReputationDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_NonCompliance` int(11) NOT NULL DEFAULT 10,
  `OWASP_PrivacyViolation` int(11) NOT NULL DEFAULT 10,
  `Custom` double(8,2) NOT NULL DEFAULT 10.00,
  `Contributing_Likelihood` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_scorings`
--

INSERT INTO `risk_scorings` (`id`, `scoring_method`, `calculated_risk`, `CLASSIC_likelihood`, `CLASSIC_impact`, `CVSS_AccessVector`, `CVSS_AccessComplexity`, `CVSS_Authentication`, `CVSS_ConfImpact`, `CVSS_IntegImpact`, `CVSS_AvailImpact`, `CVSS_Exploitability`, `CVSS_RemediationLevel`, `CVSS_ReportConfidence`, `CVSS_CollateralDamagePotential`, `CVSS_TargetDistribution`, `CVSS_ConfidentialityRequirement`, `CVSS_IntegrityRequirement`, `CVSS_AvailabilityRequirement`, `DREAD_DamagePotential`, `DREAD_Reproducibility`, `DREAD_Exploitability`, `DREAD_AffectedUsers`, `DREAD_Discoverability`, `OWASP_SkillLevel`, `OWASP_Motive`, `OWASP_Opportunity`, `OWASP_Size`, `OWASP_EaseOfDiscovery`, `OWASP_EaseOfExploit`, `OWASP_Awareness`, `OWASP_IntrusionDetection`, `OWASP_LossOfConfidentiality`, `OWASP_LossOfIntegrity`, `OWASP_LossOfAvailability`, `OWASP_LossOfAccountability`, `OWASP_FinancialDamage`, `OWASP_ReputationDamage`, `OWASP_NonCompliance`, `OWASP_PrivacyViolation`, `Custom`, `Contributing_Likelihood`) VALUES
(1, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(2, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(3, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(4, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(5, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(6, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(7, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(8, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(9, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(10, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(11, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(12, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(13, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(14, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(15, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(16, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(17, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(18, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(19, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(20, 1, 2.00, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(21, 1, 0.70, 1.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(22, 1, 2.00, 2.00, 2.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(23, 1, 4.00, 3.00, 3.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(24, 1, 6.70, 4.00, 4.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(25, 1, 10.00, 5.00, 5.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(26, 1, 2.00, 2.00, 2.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(27, 1, 10.00, 5.00, 5.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(28, 1, 10.00, 5.00, 5.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(29, 1, 10.00, 5.00, 5.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(30, 1, 2.00, 1.00, 3.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(31, 1, 10.00, 5.00, 5.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `risk_scoring_contributing_impacts`
--

CREATE TABLE `risk_scoring_contributing_impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_scoring_id` bigint(20) UNSIGNED NOT NULL,
  `contributing_risk_id` bigint(20) UNSIGNED NOT NULL,
  `impact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `risk_scoring_histories`
--

CREATE TABLE `risk_scoring_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `calculated_risk` double(8,2) NOT NULL,
  `last_update` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_scoring_histories`
--

INSERT INTO `risk_scoring_histories` (`id`, `risk_id`, `calculated_risk`, `last_update`) VALUES
(1, 1, 1.20, '2023-11-12 19:29:07'),
(2, 2, 1.20, '2023-11-12 19:29:07'),
(3, 3, 1.20, '2023-11-12 19:29:07'),
(4, 4, 1.20, '2023-11-12 19:29:07'),
(5, 5, 1.20, '2023-11-12 19:29:07'),
(6, 6, 1.20, '2023-11-12 19:29:07'),
(7, 7, 1.20, '2023-11-12 19:29:07'),
(8, 8, 1.20, '2023-11-12 19:29:07'),
(9, 9, 1.20, '2023-11-12 19:29:07'),
(10, 10, 1.20, '2023-11-12 19:29:07'),
(11, 11, 1.20, '2023-11-12 19:29:07'),
(12, 12, 1.20, '2023-11-12 19:29:07'),
(13, 13, 1.20, '2023-11-12 19:29:07'),
(14, 14, 1.20, '2023-11-12 19:29:07'),
(15, 15, 1.20, '2023-11-12 19:29:07'),
(16, 16, 1.20, '2023-11-12 19:29:07'),
(17, 17, 1.20, '2023-11-12 19:29:07'),
(18, 18, 1.20, '2023-11-12 19:29:07'),
(19, 19, 1.20, '2023-11-12 19:29:07'),
(20, 20, 1.20, '2023-11-12 19:29:07'),
(21, 21, 0.40, '2023-11-12 19:29:07'),
(22, 22, 1.60, '2023-11-12 19:29:07'),
(23, 23, 3.60, '2023-11-12 19:29:07'),
(24, 24, 6.40, '2023-11-12 19:29:07'),
(25, 25, 10.00, '2023-11-12 19:29:07'),
(26, 26, 1.60, '2023-11-12 19:43:40'),
(27, 27, 10.00, '2023-11-12 19:46:35'),
(28, 28, 10.00, '2023-11-12 20:35:41'),
(29, 29, 10.00, '2023-11-13 13:38:23'),
(30, 30, 2.00, '2023-11-13 18:49:36'),
(31, 31, 10.00, '2023-11-13 18:51:13');

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_additional_stakeholders`
--

CREATE TABLE `risk_to_additional_stakeholders` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_to_additional_stakeholders`
--

INSERT INTO `risk_to_additional_stakeholders` (`risk_id`, `user_id`) VALUES
(28, 1),
(30, 2),
(30, 4),
(30, 7),
(30, 8),
(30, 12),
(30, 13),
(30, 14),
(30, 16),
(30, 18),
(30, 19),
(30, 20),
(30, 21),
(30, 24),
(30, 25),
(30, 26),
(30, 28),
(30, 31),
(30, 32),
(30, 35),
(30, 37),
(30, 39),
(30, 41),
(30, 43),
(30, 47);

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_locations`
--

CREATE TABLE `risk_to_locations` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `location_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_to_locations`
--

INSERT INTO `risk_to_locations` (`risk_id`, `location_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20),
(30, 2),
(30, 4),
(30, 8),
(30, 10),
(30, 13),
(30, 14),
(30, 16),
(30, 17),
(30, 18),
(30, 19);

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_teams`
--

CREATE TABLE `risk_to_teams` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_to_teams`
--

INSERT INTO `risk_to_teams` (`risk_id`, `team_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(30, 7),
(30, 10),
(30, 11),
(30, 12),
(30, 13),
(30, 15),
(30, 17),
(30, 19);

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_technologies`
--

CREATE TABLE `risk_to_technologies` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `technology_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_to_technologies`
--

INSERT INTO `risk_to_technologies` (`risk_id`, `technology_id`) VALUES
(2, 9),
(3, 15),
(4, 12),
(5, 16),
(6, 5),
(8, 3),
(9, 10),
(10, 4),
(11, 17),
(12, 11),
(13, 13),
(14, 1),
(15, 18),
(16, 8),
(17, 10),
(18, 6),
(19, 18),
(20, 3),
(30, 6),
(30, 8),
(30, 9),
(30, 10),
(30, 12),
(30, 14),
(30, 15),
(30, 16),
(30, 17),
(30, 19);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'Administrator'),
(2, 'Employee'),
(3, 'z'),
(4, 'm.sayed (manager)'),
(5, 'Auditor'),
(6, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `role_responsibilities`
--

CREATE TABLE `role_responsibilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_responsibilities`
--

INSERT INTO `role_responsibilities` (`id`, `role_id`, `permission_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 1, 12),
(13, 1, 13),
(14, 1, 14),
(15, 1, 15),
(16, 1, 16),
(17, 1, 17),
(18, 1, 18),
(19, 1, 19),
(20, 1, 20),
(21, 1, 21),
(22, 1, 22),
(23, 1, 23),
(24, 1, 24),
(25, 1, 25),
(26, 1, 26),
(27, 1, 27),
(28, 1, 28),
(29, 1, 29),
(30, 1, 30),
(31, 1, 31),
(32, 1, 32),
(33, 1, 33),
(34, 1, 34),
(35, 1, 35),
(36, 1, 36),
(37, 1, 37),
(38, 1, 38),
(39, 1, 39),
(40, 1, 40),
(41, 1, 41),
(42, 1, 42),
(43, 1, 43),
(44, 1, 44),
(45, 1, 45),
(46, 1, 46),
(47, 1, 47),
(48, 1, 48),
(49, 1, 49),
(50, 1, 50),
(51, 1, 51),
(52, 1, 52),
(53, 1, 53),
(54, 1, 54),
(55, 1, 55),
(56, 1, 56),
(57, 1, 57),
(58, 1, 58),
(59, 1, 59),
(60, 1, 60),
(61, 1, 61),
(62, 1, 62),
(63, 1, 63),
(64, 1, 64),
(65, 1, 65),
(66, 1, 66),
(67, 1, 67),
(68, 1, 68),
(69, 1, 69),
(70, 1, 70),
(71, 1, 71),
(72, 1, 72),
(73, 1, 73),
(74, 1, 74),
(75, 1, 75),
(76, 1, 76),
(77, 1, 77),
(78, 1, 78),
(79, 1, 79),
(80, 1, 80),
(81, 1, 81),
(82, 1, 82),
(83, 1, 83),
(84, 1, 84),
(85, 1, 85),
(86, 1, 86),
(87, 1, 87),
(88, 1, 88),
(89, 1, 89),
(90, 1, 90),
(91, 1, 91),
(92, 1, 92),
(93, 1, 93),
(94, 1, 94),
(95, 1, 95),
(96, 1, 96),
(97, 1, 97),
(98, 1, 98),
(99, 1, 99),
(100, 1, 100),
(101, 1, 101),
(102, 1, 102),
(103, 1, 103),
(104, 1, 104),
(105, 1, 105),
(106, 1, 106),
(107, 1, 107),
(108, 1, 108),
(109, 1, 109),
(110, 1, 110),
(111, 1, 111),
(112, 1, 112),
(113, 1, 113),
(114, 1, 114),
(115, 1, 115),
(116, 1, 116),
(117, 1, 117),
(118, 1, 118),
(119, 1, 119),
(120, 1, 120),
(121, 1, 121),
(122, 1, 122),
(123, 1, 123),
(124, 1, 124),
(125, 1, 125),
(126, 1, 126),
(127, 1, 127),
(128, 1, 128),
(129, 1, 129),
(130, 1, 130),
(131, 1, 131),
(132, 1, 132),
(133, 1, 133),
(134, 1, 134),
(135, 1, 135),
(136, 1, 136),
(137, 1, 137),
(138, 1, 138),
(139, 1, 139),
(140, 1, 140),
(141, 1, 141),
(142, 1, 142),
(143, 1, 143),
(144, 1, 144),
(145, 1, 145),
(146, 1, 146),
(147, 1, 147),
(148, 1, 150),
(149, 1, 151),
(150, 1, 152),
(151, 1, 153),
(152, 1, 154),
(153, 1, 155),
(154, 1, 156),
(155, 1, 157),
(156, 1, 158),
(157, 1, 159),
(158, 1, 160),
(159, 1, 161),
(160, 1, 162),
(161, 1, 163),
(162, 1, 184),
(163, 1, 185),
(164, 1, 186),
(165, 1, 187),
(166, 1, 188),
(167, 1, 170),
(168, 1, 171),
(169, 1, 172),
(170, 1, 173),
(171, 1, 174),
(172, 1, 175),
(173, 1, 176),
(174, 1, 177),
(175, 1, 178),
(176, 1, 179),
(177, 1, 180),
(178, 1, 181),
(179, 1, 182),
(180, 1, 183),
(181, 1, 164),
(182, 1, 165),
(183, 1, 166),
(184, 1, 167),
(185, 1, 168),
(186, 1, 169),
(187, 1, 148),
(188, 1, 149),
(234, 1, 189),
(235, 1, 190),
(236, 1, 191),
(237, 1, 192),
(238, 1, 193),
(239, 1, 194),
(240, 1, 195),
(241, 1, 196),
(242, 1, 197),
(807, 6, 159),
(808, 6, 160),
(831, 4, 1),
(832, 4, 2),
(833, 4, 3),
(834, 4, 4),
(835, 4, 5),
(836, 4, 6),
(837, 4, 7),
(838, 4, 8),
(839, 4, 9),
(840, 4, 10),
(841, 4, 11),
(842, 4, 12),
(843, 4, 13),
(844, 4, 14),
(845, 4, 189),
(846, 4, 190),
(847, 4, 15),
(848, 4, 16),
(849, 4, 17),
(850, 4, 18),
(851, 4, 197),
(852, 4, 88),
(853, 4, 89),
(854, 4, 90),
(855, 4, 91),
(856, 4, 92),
(857, 4, 93),
(858, 4, 94),
(859, 4, 177),
(860, 4, 178),
(861, 4, 179),
(862, 4, 180),
(863, 4, 181),
(864, 4, 182),
(865, 4, 183),
(866, 4, 19),
(867, 4, 20),
(868, 4, 21),
(869, 4, 22),
(870, 4, 23),
(871, 4, 24),
(872, 4, 25),
(873, 4, 26),
(874, 4, 27),
(875, 4, 78),
(876, 4, 79),
(877, 4, 80),
(878, 4, 28),
(879, 4, 29),
(880, 4, 30),
(881, 4, 31),
(882, 4, 32),
(883, 4, 33),
(884, 4, 34),
(885, 4, 35),
(886, 4, 36),
(887, 4, 37),
(888, 4, 38),
(889, 4, 39),
(890, 4, 81),
(891, 4, 82),
(892, 4, 83),
(893, 4, 84),
(894, 4, 85),
(895, 4, 86),
(896, 4, 87),
(897, 4, 40),
(898, 4, 41),
(899, 4, 42),
(900, 4, 43),
(901, 4, 44),
(902, 4, 45),
(903, 4, 46),
(904, 4, 47),
(905, 4, 48),
(906, 4, 49),
(907, 4, 50),
(908, 4, 51),
(909, 4, 52),
(910, 4, 53),
(911, 4, 54),
(912, 4, 55),
(913, 4, 56),
(914, 4, 57),
(915, 4, 58),
(916, 4, 59),
(917, 4, 60),
(918, 4, 95),
(919, 4, 96),
(920, 4, 97),
(921, 4, 98),
(922, 4, 99),
(923, 4, 100),
(924, 4, 101),
(925, 4, 102),
(926, 4, 103),
(927, 4, 104),
(928, 4, 105),
(929, 4, 106),
(930, 4, 107),
(931, 4, 108),
(932, 4, 109),
(933, 4, 110),
(934, 4, 111),
(935, 4, 112),
(936, 4, 113),
(937, 4, 114),
(938, 4, 115),
(939, 4, 116),
(940, 4, 117),
(941, 4, 118),
(942, 4, 119),
(943, 4, 120),
(944, 4, 121),
(945, 4, 138),
(946, 4, 146),
(947, 4, 147),
(948, 4, 152),
(949, 4, 148),
(950, 4, 149),
(951, 4, 61),
(952, 4, 62),
(953, 4, 63),
(954, 4, 64),
(955, 4, 65),
(956, 4, 66),
(957, 4, 67),
(958, 4, 68),
(959, 4, 69),
(960, 4, 70),
(961, 4, 71),
(962, 4, 72),
(963, 4, 73),
(964, 4, 74),
(965, 4, 75),
(966, 4, 76),
(967, 4, 77),
(968, 4, 122),
(969, 4, 123),
(970, 4, 124),
(971, 4, 125),
(972, 4, 126),
(973, 4, 127),
(974, 4, 128),
(975, 4, 129),
(976, 4, 130),
(977, 4, 131),
(978, 4, 132),
(979, 4, 133),
(980, 4, 134),
(981, 4, 135),
(982, 4, 136),
(983, 4, 137),
(984, 4, 139),
(985, 4, 140),
(986, 4, 141),
(987, 4, 142),
(988, 4, 143),
(989, 4, 144),
(990, 4, 145),
(991, 4, 150),
(992, 4, 151),
(993, 4, 153),
(994, 4, 154),
(995, 4, 155),
(996, 4, 156),
(997, 4, 157),
(998, 4, 158),
(999, 4, 159),
(1000, 4, 160),
(1001, 4, 161),
(1002, 4, 162),
(1003, 4, 163),
(1004, 4, 164),
(1005, 4, 165),
(1006, 4, 166),
(1007, 4, 167),
(1008, 4, 168),
(1009, 4, 169),
(1010, 4, 184),
(1011, 4, 185),
(1012, 4, 186),
(1013, 4, 187),
(1014, 4, 188),
(1015, 4, 170),
(1016, 4, 171),
(1017, 4, 172),
(1018, 4, 173),
(1019, 4, 174),
(1020, 4, 175),
(1021, 4, 176),
(1022, 5, 28),
(1023, 5, 29),
(1024, 5, 30),
(1025, 5, 31),
(1026, 5, 32);

-- --------------------------------------------------------

--
-- Table structure for table `scoring_methods`
--

CREATE TABLE `scoring_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `scoring_methods`
--

INSERT INTO `scoring_methods` (`id`, `name`) VALUES
(1, 'Classic');

-- --------------------------------------------------------

--
-- Table structure for table `security_awarenesses`
--

CREATE TABLE `security_awarenesses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_stakeholders` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `privacy` bigint(20) UNSIGNED DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '[1 => Draft],[2=> InReview, [3 => Approved]',
  `file_id` bigint(20) UNSIGNED DEFAULT NULL,
  `last_review_date` date DEFAULT NULL,
  `review_frequency` int(11) DEFAULT NULL,
  `next_review_date` date DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `owner` bigint(20) UNSIGNED NOT NULL,
  `reviewer` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `opened` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `security_awarenesses`
--

INSERT INTO `security_awarenesses` (`id`, `title`, `description`, `team_ids`, `additional_stakeholders`, `privacy`, `status`, `file_id`, `last_review_date`, `review_frequency`, `next_review_date`, `approval_date`, `owner`, `reviewer`, `created_by`, `opened`, `created_at`, `updated_at`) VALUES
(1, 'asd', 'd', '3', '2', NULL, 1, 2, '2023-11-13', 2, '2023-11-15', NULL, 2, NULL, 1, 1, '2023-11-12 21:01:13', '2023-11-12 21:01:13'),
(2, 'qqqqqwewee', 'sd', '3', '2', 1, 1, 3, '2023-11-14', 3, '2023-11-17', NULL, 1, NULL, 1, 1, '2023-11-12 21:02:19', '2023-11-12 21:02:40'),
(3, 'aaa', 'q', '2', '44', 1, 2, 4, '2023-11-14', 2, '2023-11-16', NULL, 1, 44, 1, 1, '2023-11-13 10:35:58', '2023-11-13 11:24:13'),
(4, 'aq', 'd', '3', '44', 1, 3, 5, '2023-11-15', 1, '2023-11-16', '2023-11-28', 1, NULL, 1, 1, '2023-11-13 11:17:10', '2023-11-13 11:17:10'),
(5, 'ffffffffffffffff', 'sscscscs', '3', '2', NULL, 1, 6, '2023-11-13', 0, '2023-11-13', NULL, 1, NULL, 1, 0, '2023-11-13 12:37:20', '2023-11-13 12:37:20'),
(6, 'jkassx', 'sd', '3', '2', NULL, 1, 7, '2023-11-14', 1, '2023-11-15', NULL, 1, NULL, 1, 1, '2023-11-13 16:37:46', '2023-11-13 16:37:46');

-- --------------------------------------------------------

--
-- Table structure for table `security_awareness_exams`
--

CREATE TABLE `security_awareness_exams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `security_awareness_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `security_awareness_exams`
--

INSERT INTO `security_awareness_exams` (`id`, `security_awareness_id`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `security_awareness_exam_answers`
--

CREATE TABLE `security_awareness_exam_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `security_awareness_exams_id` bigint(20) UNSIGNED NOT NULL,
  `examinee` bigint(20) UNSIGNED DEFAULT NULL,
  `success_answers` tinyint(4) NOT NULL,
  `fail_answers` tinyint(4) NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `security_awareness_exam_questions`
--

CREATE TABLE `security_awareness_exam_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `security_awareness_exams_id` bigint(20) UNSIGNED NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_a` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_b` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_c` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_d` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_e` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` enum('A','B','C','D','E') COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `security_awareness_exam_questions`
--

INSERT INTO `security_awareness_exam_questions` (`id`, `security_awareness_exams_id`, `question`, `option_a`, `option_b`, `option_c`, `option_d`, `option_e`, `answer`) VALUES
(1, 1, 'qwee?', 'ww', 'we', '20', '30', '0', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `security_awareness_notes`
--

CREATE TABLE `security_awareness_notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `security_awareness_id` bigint(20) UNSIGNED NOT NULL,
  `note` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `security_awareness_note_files`
--

CREATE TABLE `security_awareness_note_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `security_awareness_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service_descriptions`
--

CREATE TABLE `service_descriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_descriptions`
--

INSERT INTO `service_descriptions` (`id`, `route`, `key`, `name_key`, `description`) VALUES
(1, 'admin.governance.index', 'admin_governance_index', 'Define Control Frameworks', '{\"ops\":[{\"insert\":\"To Define frameworks\\n\"}]}'),
(2, 'admin.governance.control.list', 'admin_governance_control_list', 'Define Controls', '{\"ops\":[{\"insert\":\"To Define controls\\n\"}]}'),
(3, 'admin.governance.category', 'admin_governance_category', 'Documentation', NULL),
(4, 'admin.risk_management.index', 'admin_risk_management_index', 'Navbar Risk Management', NULL),
(5, 'admin.compliance.audit.index', 'admin_compliance_audit_index', 'Active Audits', NULL),
(6, 'admin.compliance.past-audits', 'admin_compliance_past-audits', 'Past Audits', NULL),
(7, 'admin.asset_management.index', 'admin_asset_management_index', 'Assets', NULL),
(8, 'admin.asset_management.asset_group.index', 'admin_asset_management_asset_group_index', 'AssetGroups', NULL),
(9, 'admin.reporting.overviewReport', 'admin_reporting_overviewReport', 'Overview', NULL),
(10, 'admin.reporting.riskDashboardReport', 'admin_reporting_riskDashboardReport', 'Risk Dashboard', NULL),
(11, 'admin.reporting.controlGapAnalysis', 'admin_reporting_controlGapAnalysis', 'Control Gap Analysis', NULL),
(12, 'admin.reporting.likelhoodImpactReport', 'admin_reporting_likelhoodImpactReport', 'Likelihood And Impact', NULL),
(13, 'admin.reporting.MyopenRiskReport', 'admin_reporting_MyopenRiskReport', 'All Open Risks Assigned to Me', NULL),
(14, 'admin.reporting.dynamicRiskReport', 'admin_reporting_dynamicRiskReport', 'Dynamic Risk Report', NULL),
(15, 'admin.reporting.GetRiskByControl', 'admin_reporting_GetRiskByControl', 'Risks and Controls', NULL),
(16, 'admin.reporting.GetRiskByAsset', 'admin_reporting_GetRiskByAsset', 'Risks and Assets', NULL),
(17, 'admin.reporting.framewrok_control_compliance_status', 'admin_reporting_framewrok_control_compliance_status', 'framewrok_control_compliance_status', NULL),
(18, 'admin.reporting.summary_of_results_for_evaluation_and_compliance', 'admin_reporting_summary_of_results_for_evaluation_and_compliance', 'summary_of_results_for_evaluation_and_compliance', NULL),
(19, 'admin.reporting.security_awareness_exam', 'admin_reporting_security_awareness_exam', 'SecurityAwarenessExam', NULL),
(20, 'admin.configure.user.index', 'admin_configure_user_index', 'Navbar User Management', NULL),
(21, 'admin.configure.add_values', 'admin_configure_add_values', 'Add and Remove Values', NULL),
(22, 'admin.configure.roles.index', 'admin_configure_roles_index', 'Navbar Role Management', NULL),
(23, 'admin.configure.riskmodels.show', 'admin_configure_riskmodels_show', 'ClassicRiskFormula', NULL),
(24, 'admin.configure.logs.index', 'admin_configure_logs_index', 'Audit Trail', NULL),
(25, 'admin.configure.import.index', 'admin_configure_import_index', 'Import/Export', NULL),
(26, 'admin.configure.extras.LDAP-Configuration', 'admin_configure_extras_LDAP-Configuration', 'LDAP Authentication', NULL),
(27, 'admin.configure.about.edit', 'admin_configure_about_edit', 'About', NULL),
(28, 'admin.configure.general_setting.edit', 'admin_configure_general_setting_edit', 'GeneralSettings', NULL),
(29, 'admin.configure.service_description.edit', 'admin_configure_service_description_edit', 'ServicesDescription', NULL),
(30, 'admin.configure.change_request_department.edit', 'admin_configure_change_request_department_edit', 'ChangeRequestsResponsibleDepartment', NULL),
(31, 'admin.hierarchy.index', 'admin_hierarchy_index', 'Hierarchy', NULL),
(32, 'admin.hierarchy.org_chart', 'admin_hierarchy_org_chart', 'Organization Chart', NULL),
(33, 'admin.hierarchy.department.index', 'admin_hierarchy_department_index', 'Department', NULL),
(34, 'admin.hierarchy.job.index', 'admin_hierarchy_job_index', 'Job', NULL),
(35, 'admin.task.index', 'admin_task_index', 'CreatedTasks', NULL),
(36, 'admin.task.assigned_to_me', 'admin_task_assigned_to_me', 'MyTasks', NULL),
(37, 'admin.vulnerability_management.index', 'admin_vulnerability_management_index', 'Navbar Vulnerability Management', NULL),
(38, 'admin.change_request.index', 'admin_change_request_index', 'ChangeRequest', NULL),
(39, 'admin.KPI.index', 'admin_KPI_index', 'KPI', NULL),
(40, 'admin.security_awareness.index', 'admin_security_awareness_index', 'SecurityAwareness', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` int(10) UNSIGNED DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`) VALUES
(1, 'alert_timeout', '5'),
(2, 'allow_ownermanager_to_risk', '1'),
(3, 'allow_owner_to_risk', '1'),
(4, 'allow_stakeholder_to_risk', '1'),
(5, 'allow_submitter_to_risk', '1'),
(6, 'allow_team_member_to_risk', '1'),
(7, 'auto_verify_new_assets', '0'),
(8, 'backup_auto', 'true'),
(9, 'backup_remove', '1'),
(10, 'backup_schedule', 'daily'),
(11, 'bootstrap_delivery_method', 'cdn'),
(12, 'closed_audit_status', '5'),
(13, 'content_security_policy', '0'),
(14, 'currency', '$'),
(15, 'db_version', '20211115-001'),
(16, 'debug_logging', '0'),
(17, 'debug_log_file', '/tmp/debug_log'),
(18, 'default_asset_valuation', '5'),
(19, 'default_current_maturity', '0'),
(20, 'default_date_format', 'MM/DD/YYYY'),
(21, 'default_desired_maturity', '3'),
(22, 'default_language', 'en'),
(23, 'default_risk_score', '10'),
(24, 'default_timezone', 'Asia/Riyadh'),
(25, 'highcharts_delivery_method', 'cdn'),
(26, 'instance_id', 'WtrZ7UYyt7XdoRsTKftzHI9uv5mdXFKPCRcZf83ZoUYRu0pxXZ'),
(27, 'jquery_delivery_method', 'cdn'),
(28, 'maximum_risk_subject_length', '300'),
(29, 'max_upload_size', '5120000'),
(30, 'next_review_date_uses', 'InherentRisk'),
(31, 'NOTIFY_ADDITIONAL_STAKEHOLDERS', 'true'),
(32, 'pass_policy_alpha_required', '1'),
(33, 'pass_policy_attempt_lockout', '0'),
(34, 'pass_policy_attempt_lockout_time', '10'),
(35, 'pass_policy_digits_required', '1'),
(36, 'pass_policy_enabled', '1'),
(37, 'pass_policy_lower_required', '1'),
(38, 'pass_policy_max_age', '0'),
(39, 'pass_policy_min_age', '0'),
(40, 'pass_policy_min_chars', '8'),
(41, 'pass_policy_reuse_limit', '0'),
(42, 'pass_policy_re_use_tracking', '0'),
(43, 'pass_policy_special_required', '1'),
(44, 'pass_policy_upper_required', '1'),
(45, 'phpmailer_from_email', 'noreply@simplerisk.it'),
(46, 'phpmailer_from_name', 'SimpleRisk'),
(47, 'phpmailer_host', 'smtp1.example.com'),
(48, 'phpmailer_password', 'secret'),
(49, 'phpmailer_port', '587'),
(50, 'phpmailer_prepend', '[SIMPLERISK]'),
(51, 'phpmailer_replyto_email', 'noreply@simplerisk.it'),
(52, 'phpmailer_replyto_name', 'SimpleRisk'),
(53, 'phpmailer_smtpauth', 'false'),
(54, 'phpmailer_smtpautotls', 'true'),
(55, 'phpmailer_smtpsecure', 'none'),
(56, 'phpmailer_transport', 'sendmail'),
(57, 'phpmailer_username', 'user@example.com'),
(58, 'plan_projects_show_all', '0'),
(59, 'registration_registered', '0'),
(60, 'risk_appetite', '0'),
(61, 'risk_mapping_required', '0'),
(62, 'risk_model', '4'),
(63, 'session_absolute_timeout', '28800'),
(64, 'session_activity_timeout', '3600'),
(65, 'simplerisk_base_url', 'http://localhost:8000'),
(66, 'strict_user_validation', '1'),
(67, 'LDAP_DEFAULT_HOSTS', 'www.zflexldap.com'),
(68, 'LDAP_DEFAULT_PORT', '389'),
(69, 'LDAP_DEFAULT_BASE_DN', 'dc=zflexsoftware,dc=com'),
(70, 'LDAP_DEFAULT_USERNAME', 'cn=ro_admin,ou=sysadmins,dc=zflexsoftware,dc=com'),
(71, 'LDAP_USER_FLITER', ''),
(72, 'LDAP_DEFAULT_PASSWORD', 'zflexpass'),
(73, 'LDAP_DEFAULT_SSL', 'false'),
(74, 'LDAP_DEFAULT_TLS', 'false'),
(75, 'LDAP_DEFAULT_VSERSION', '3'),
(76, 'LDAP_DEFAULT_TIMEOUT', '5'),
(77, 'LDAP_DEFAULT_Follow', 'false'),
(78, 'LDAP_name', ''),
(79, 'LDAP_email', ''),
(80, 'LDAP_username', ''),
(81, 'LDAP_password', ''),
(82, 'LDAP_dapartment', ''),
(83, 'APP_NAME', 'Cyber Mode'),
(84, 'APP_AUTHOR_EN', 'Cyber Mode'),
(85, 'APP_AUTHOR_AR', 'Cyber Mode'),
(86, 'APP_AUTHOR_ABBR_EN', 'Cyber Mode'),
(87, 'APP_AUTHOR_ABBR_AR', 'Cyber Mode'),
(88, 'APP_AUTHOR_WEBSITE', 'https://www.pksaudi.com'),
(89, 'APP_OWNER_EN', 'Cyber Mode'),
(90, 'APP_OWNER_AR', 'دقة المعرفة للأنظمة التقنية'),
(91, 'APP_LOGO', 'images/logo/1667651514.png'),
(92, 'APP_FAVICON', 'images/ico/favicon.ico'),
(93, 'change_requests_responsible_department_id', '');

-- --------------------------------------------------------

--
-- Table structure for table `sms_settings`
--

CREATE TABLE `sms_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sources`
--

CREATE TABLE `sources` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sources`
--

INSERT INTO `sources` (`id`, `name`) VALUES
(1, 'People'),
(2, 'Process'),
(3, 'System'),
(4, 'External');

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`) VALUES
(1, 'New'),
(2, 'Mitigation Planned'),
(3, 'Mgmt Reviewed'),
(4, 'Closed'),
(5, 'Reopened'),
(6, 'Untreated'),
(7, 'Treated');

-- --------------------------------------------------------

--
-- Table structure for table `subgroups`
--

CREATE TABLE `subgroups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_group_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subgroups`
--

INSERT INTO `subgroups` (`id`, `name`, `permission_group_id`, `created_at`, `updated_at`) VALUES
(1, 'Frameworks', 1, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(2, 'Controls', 1, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(3, 'Document', 1, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(4, 'Exception', 1, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(5, 'Risks', 2, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(6, 'Projects', 2, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(7, 'Compliance', 3, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(8, 'Tests', 3, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(9, 'Audits', 3, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(10, 'Assets', 4, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(11, 'Assessments', 5, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(12, 'RoleManagement', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(13, 'Add Values', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(14, 'Audit Logs', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(15, 'Hierarchy', 7, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(16, 'Department', 7, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(17, 'Job', 7, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(18, 'Employee', 7, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(19, 'Plan Mitigation', 2, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(20, 'Perform Reviews', 2, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(21, 'AssetGroups', 4, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(22, 'Categories', 1, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(23, 'User Management', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(24, 'Settings', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(25, 'ClassicRiskFormula', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(26, 'Import And Export', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(27, 'LDAP', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(28, 'Reporting', 8, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(29, 'Task', 9, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(30, 'About', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(31, 'Vulnerability Management', 10, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(32, 'General Setting', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(33, 'Services Description', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(34, 'Change Request', 11, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(35, 'Change Request Department', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(36, 'KPI', 12, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(37, 'Security Awareness', 13, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(38, 'Domain', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(39, 'Assessments', 14, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(40, 'Questions', 14, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(41, 'Answers', 14, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(42, 'Questionnaires', 14, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(43, 'Control Objectives', 1, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(44, 'AwarenessSurvey', 13, '2023-11-12 19:29:02', '2023-11-12 19:29:02'),
(45, 'Email Setting', 6, '2023-11-12 19:29:02', '2023-11-12 19:29:02');

-- --------------------------------------------------------

--
-- Table structure for table `survey_questions`
--

CREATE TABLE `survey_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `survey_id` bigint(20) UNSIGNED NOT NULL,
  `answer_type` int(11) NOT NULL DEFAULT 1,
  `option_A` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_B` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_C` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_D` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_E` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survey_questions`
--

INSERT INTO `survey_questions` (`id`, `question`, `survey_id`, `answer_type`, `option_A`, `option_B`, `option_C`, `option_D`, `option_E`, `created_at`, `updated_at`) VALUES
(1, 'eee  ?', 3, 1, '5', '2', '20', '4', '0', '2023-11-12 21:07:26', '2023-11-12 21:07:26'),
(2, 'wwe', 3, 1, '11', '22', '33', '44', '55', '2023-11-12 21:07:26', '2023-11-12 21:07:26'),
(3, 'ww?', 9, 1, '5', '2', '20', '4', '0', '2023-11-13 18:56:54', '2023-11-13 18:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `system_notifications_settings`
--

CREATE TABLE `system_notifications_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_notifications_settings`
--

INSERT INTO `system_notifications_settings` (`id`, `action_id`, `message`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'asd {name}{name}', 1, '2023-11-12 19:38:09', '2023-11-13 14:55:46'),
(2, 22, 'test', 1, '2023-11-12 20:20:36', '2023-11-12 20:20:41'),
(3, 23, 'test', 1, '2023-11-12 20:20:56', '2023-11-12 20:20:56'),
(4, 24, 'test', 1, '2023-11-12 20:21:07', '2023-11-12 20:21:07'),
(5, 68, 'test', 1, '2023-11-12 20:21:19', '2023-11-12 20:21:19'),
(6, 69, 'test', 1, '2023-11-12 20:21:36', '2023-11-12 20:21:36'),
(7, 28, 'ss', 1, '2023-11-12 20:23:59', '2023-11-12 20:23:59'),
(8, 29, 'ss', 1, '2023-11-12 20:24:09', '2023-11-12 20:24:09'),
(9, 30, 'ee', 1, '2023-11-12 20:24:18', '2023-11-12 20:24:18'),
(10, 74, 'cc', 1, '2023-11-12 20:24:29', '2023-11-12 20:24:29'),
(11, 31, 'a', 1, '2023-11-12 20:26:31', '2023-11-12 20:26:31'),
(12, 32, 'we', 1, '2023-11-12 20:26:41', '2023-11-12 20:26:41'),
(13, 33, '{name}', 1, '2023-11-12 20:26:49', '2023-11-12 20:26:49'),
(14, 34, '{short_name}', 1, '2023-11-12 20:27:51', '2023-11-12 20:27:55'),
(15, 35, '{Expected_Results}', 1, '2023-11-12 20:28:05', '2023-11-12 20:28:18'),
(16, 36, '{description}', 1, '2023-11-12 20:28:13', '2023-11-12 20:28:13'),
(17, 37, '{Responsible}', 1, '2023-11-12 20:28:27', '2023-11-12 20:28:27'),
(18, 38, '{Control_Objective_Responsible}', 1, '2023-11-12 20:28:39', '2023-11-12 20:28:42'),
(19, 39, '{description}', 1, '2023-11-12 20:28:52', '2023-11-12 20:28:52'),
(20, 40, '{Control_class}', 1, '2023-11-12 20:29:01', '2023-11-12 20:29:01'),
(21, 19, '{Document_Audit_Status}', 1, '2023-11-12 20:33:32', '2023-11-12 20:33:32'),
(22, 44, '{Test_Name}', 1, '2023-11-12 20:33:40', '2023-11-12 20:33:40'),
(23, 45, '{Control_Phase}', 1, '2023-11-12 20:33:53', '2023-11-12 20:33:53'),
(24, 46, '{Expected_Results}', 1, '2023-11-12 20:34:04', '2023-11-12 20:34:04'),
(25, 73, '{Control_Objective_Name}', 1, '2023-11-12 20:34:14', '2023-11-12 20:34:14'),
(26, 10, '{Owner}', 1, '2023-11-12 20:37:24', '2023-11-12 20:37:24'),
(27, 11, '{Additional_Stakeholder}', 1, '2023-11-12 20:37:34', '2023-11-12 20:37:34'),
(28, 12, '{NextStep}', 1, '2023-11-12 20:37:43', '2023-11-12 20:37:43'),
(29, 13, '{Note}', 1, '2023-11-12 20:37:54', '2023-11-12 20:37:54'),
(30, 14, '{status}', 1, '2023-11-12 20:38:06', '2023-11-12 20:38:06'),
(31, 15, '{Mitigation_Coast}', 1, '2023-11-12 20:38:19', '2023-11-12 20:38:19'),
(32, 16, '{subject}', 1, '2023-11-12 20:38:29', '2023-11-12 20:38:29'),
(33, 17, '{subject}', 1, '2023-11-12 20:38:39', '2023-11-12 20:38:39'),
(34, 18, '{subject}', 1, '2023-11-12 20:38:52', '2023-11-12 20:38:52'),
(35, 20, '{subject}', 1, '2023-11-12 20:39:05', '2023-11-12 20:39:05'),
(36, 21, '{subject}', 1, '2023-11-12 20:39:16', '2023-11-12 20:39:16'),
(37, 65, '{Assessment}', 1, '2023-11-12 20:41:14', '2023-11-12 20:41:14'),
(38, 66, '{Assessment}', 1, '2023-11-12 20:41:20', '2023-11-12 20:41:20'),
(39, 67, '{Assessment}', 1, '2023-11-12 20:41:26', '2023-11-12 20:41:26'),
(40, 4, '{Name}{Privacy}', 1, '2023-11-13 07:09:42', '2023-11-13 10:37:45'),
(41, 5, '{Created_By}', 1, '2023-11-13 10:37:59', '2023-11-13 10:37:59'),
(42, 6, '{Name}', 1, '2023-11-13 10:38:11', '2023-11-13 10:38:11'),
(43, 25, 'test', 1, '2023-11-13 13:40:09', '2023-11-13 13:40:09'),
(44, 26, '{name}', 1, '2023-11-13 13:40:17', '2023-11-13 13:40:17'),
(45, 27, '{name}', 1, '2023-11-13 13:40:26', '2023-11-13 13:40:26'),
(46, 59, '{Name}', 1, '2023-11-13 14:40:42', '2023-11-13 14:40:42'),
(47, 60, '{Name}', 1, '2023-11-13 14:40:50', '2023-11-13 14:40:50'),
(48, 61, '{Name}', 1, '2023-11-13 14:40:57', '2023-11-13 14:40:57'),
(49, 62, '{Question}', 1, '2023-11-13 14:41:05', '2023-11-13 14:41:23'),
(50, 63, '{Question}', 1, '2023-11-13 14:41:19', '2023-11-13 14:41:19'),
(51, 64, '{Question}', 1, '2023-11-13 14:41:35', '2023-11-13 14:41:35'),
(52, 2, '{severity}', 1, '2023-11-13 14:55:58', '2023-11-13 14:55:58'),
(53, 3, '{name}', 1, '2023-11-13 14:56:09', '2023-11-13 14:56:09'),
(54, 3, '{name}', 1, '2023-11-13 14:56:10', '2023-11-13 14:56:10'),
(55, 47, '{Name}', 1, '2023-11-13 15:12:59', '2023-11-13 15:12:59'),
(56, 48, '{Asset_Value_Max}', 1, '2023-11-13 15:13:07', '2023-11-13 15:13:07'),
(57, 49, '{Start_Date}', 1, '2023-11-13 15:13:18', '2023-11-13 15:13:18'),
(58, 53, '{Name}', 1, '2023-11-13 15:30:14', '2023-11-13 15:30:14'),
(59, 54, '{Name}', 1, '2023-11-13 15:40:10', '2023-11-13 15:40:10'),
(60, 55, '{Name}', 1, '2023-11-13 15:40:40', '2023-11-13 15:40:40'),
(61, 56, '{Teams}', 1, '2023-11-13 15:41:02', '2023-11-13 15:41:02'),
(62, 57, '{Next_Review_Date}', 1, '2023-11-13 15:41:20', '2023-11-13 15:41:20');

-- --------------------------------------------------------

--
-- Table structure for table `taggables`
--

CREATE TABLE `taggables` (
  `tag_id` bigint(20) UNSIGNED NOT NULL,
  `taggable_id` bigint(20) UNSIGNED NOT NULL,
  `taggable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `taggables`
--

INSERT INTO `taggables` (`tag_id`, `taggable_id`, `taggable_type`) VALUES
(1, 22, 'App\\Models\\Asset'),
(10, 30, 'App\\Models\\Risk'),
(2, 30, 'App\\Models\\Risk'),
(3, 30, 'App\\Models\\Risk'),
(5, 30, 'App\\Models\\Risk'),
(6, 30, 'App\\Models\\Risk'),
(9, 30, 'App\\Models\\Risk');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tag` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `tag`) VALUES
(1, 'Tag 1'),
(10, 'Tag 10'),
(2, 'Tag 2'),
(3, 'Tag 3'),
(4, 'Tag 4'),
(5, 'Tag 5'),
(6, 'Tag 6'),
(7, 'Tag 7'),
(8, 'Tag 8'),
(9, 'Tag 9');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` enum('Urgent','High','Normal','Low','No Priority') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Open','In Progress','Completed','Accepted','Closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `completed_date` timestamp NULL DEFAULT NULL,
  `accepted_date` timestamp NULL DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT 0,
  `assignable_id` bigint(20) UNSIGNED NOT NULL,
  `assignable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `action_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `description`, `priority`, `status`, `start_date`, `due_date`, `completed_date`, `accepted_date`, `completed`, `assignable_id`, `assignable_type`, `created_by`, `action_by`, `created_at`, `updated_at`) VALUES
(2, 'title 2', 'description 2', 'Low', 'Open', '2022-06-02', '2022-06-04', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(3, 'title 3', 'description 3', 'Normal', 'Open', '2022-06-03', '2022-06-06', NULL, NULL, 1, 1, 'App\\Models\\Team', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(4, 'title 4', 'description 4', 'High', 'Completed', '2022-06-04', '2022-06-08', '2023-11-12 20:50:09', NULL, 1, 1, 'App\\Models\\User', 1, 1, '2023-11-12 19:29:08', '2023-11-12 20:50:09'),
(5, 'title 5', 'description 5', 'Urgent', 'Open', '2022-06-05', '2022-06-10', NULL, NULL, 1, 1, 'App\\Models\\User', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(6, 'title 6', 'description 6', 'No Priority', 'Open', '2022-06-06', '2022-06-12', NULL, NULL, 0, 1, 'App\\Models\\Team', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(7, 'title 7', 'description 7', 'Low', 'Open', '2022-06-07', '2022-06-14', NULL, NULL, 1, 1, 'App\\Models\\User', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(8, 'title 8', 'description 8', 'Normal', 'Open', '2022-06-08', '2022-06-16', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(9, 'title 9', 'description 9', 'High', 'Open', '2022-06-09', '2022-06-18', NULL, NULL, 1, 1, 'App\\Models\\Team', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(10, 'title 10', 'description 10', 'Urgent', 'Open', '2022-06-10', '2022-06-20', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2023-11-12 19:29:08', '2023-11-12 19:29:08'),
(11, 'xx', '<p>zz</p>', 'High', 'Open', '2023-11-12', '2023-11-22', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2023-11-12 20:49:35', '2023-11-12 20:49:35');

-- --------------------------------------------------------

--
-- Table structure for table `task_notes`
--

CREATE TABLE `task_notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `note` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task_note_files`
--

CREATE TABLE `task_note_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`) VALUES
(1, 'Team 1'),
(2, 'Team 2'),
(3, 'Team 3'),
(4, 'Team 4'),
(5, 'Team 5'),
(6, 'Team 6'),
(7, 'Team 7'),
(8, 'Team 8'),
(9, 'Team 9'),
(10, 'Team 10'),
(11, 'Team 11'),
(12, 'Team 12'),
(13, 'Team 13'),
(14, 'Team 14'),
(15, 'Team 15'),
(16, 'Team 16'),
(17, 'Team 17'),
(18, 'Team 18'),
(19, 'Team 19');

-- --------------------------------------------------------

--
-- Table structure for table `team_vulnerabilities`
--

CREATE TABLE `team_vulnerabilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `vulnerability_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_vulnerabilities`
--

INSERT INTO `team_vulnerabilities` (`id`, `team_id`, `vulnerability_id`) VALUES
(5, 2, 5),
(6, 4, 5),
(7, 8, 5),
(8, 10, 5),
(9, 14, 5),
(10, 17, 5),
(11, 19, 5),
(12, 2, 6),
(13, 1, 6),
(14, 2, 7),
(15, 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `technologies`
--

CREATE TABLE `technologies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `technologies`
--

INSERT INTO `technologies` (`id`, `name`) VALUES
(1, 'Todos'),
(2, 'Anti-Virus'),
(3, 'Backups'),
(4, 'Blackberry'),
(5, 'Citrix'),
(6, 'Datacenter'),
(7, 'Mail Routing'),
(8, 'Live Collaboration'),
(9, 'Mesajeria'),
(10, 'Mobile'),
(11, 'Network'),
(12, 'Power'),
(13, 'Remote Access'),
(14, 'SAN'),
(15, 'Telecom'),
(16, 'Unix'),
(17, 'VMWare'),
(18, 'Web'),
(19, 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_results`
--

CREATE TABLE `test_results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `background_class` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `test_results`
--

INSERT INTO `test_results` (`id`, `name`, `background_class`) VALUES
(1, 'Not Applicable', '#d0d0d0'),
(2, 'Not Implemented', '#FFA1A1'),
(3, 'Partially Implemented', '#ffe700'),
(4, 'Implemented', '#00d4bd');

-- --------------------------------------------------------

--
-- Table structure for table `test_statuses`
--

CREATE TABLE `test_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `test_statuses`
--

INSERT INTO `test_statuses` (`id`, `name`) VALUES
(1, 'Pending Evidence from Control Owner'),
(2, 'Evidence Submitted / Pending Review'),
(3, 'Passed Internal QA'),
(4, 'Remediation Required'),
(5, 'Closed');

-- --------------------------------------------------------

--
-- Table structure for table `threat_catalogs`
--

CREATE TABLE `threat_catalogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `threat_grouping_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `threat_catalogs`
--

INSERT INTO `threat_catalogs` (`id`, `number`, `threat_grouping_id`, `name`, `description`, `order`) VALUES
(1, 'NT-1', 1, 'Drought & Water Shortage', 'Regardless of geographic location, periods of reduced rainfall are expected. For non-agricultural industries, drought may not be impactful to operations until it reaches the extent of water rationing.', 1),
(2, 'NT-2', 1, 'Earthquakes', 'Earthquakes are sudden rolling or shaking events caused by movement under the earth’s surface. Although earthquakes usually last less than one minute, the scope of devastation can be widespread and have long-lasting impact.', 2),
(3, 'NT-3', 1, 'Fire & Wildfires', 'Regardless of geographic location or even building material, fire is a concern for every business. When thinking of a fire in a building, envision a total loss to all technology hardware, including backup tapes, and all paper files being consumed in the fire.', 3),
(4, 'NT-4', 1, 'Floods', 'Flooding is the most common of natural hazards and requires an understanding of the local environment, including floodplains and the frequency of flooding events. Location of critical technologies should be considered (e.g., server room is in the basement or first floor of the facility).', 4),
(5, 'NT-5', 1, 'Hurricanes & Tropical Storms', 'Hurricanes and tropical storms are among the most powerful natural disasters because of their size and destructive potential. In addition to high winds, regional flooding and infrastructure damage should be considered when assessing hurricanes and tropical storms.', 5),
(6, 'NT-6', 1, 'Landslides & Debris Flow', 'Landslides occur throughout the world and can be caused by a variety of factors including earthquakes, storms, volcanic eruptions, fire, and by human modification of land. Landslides can occur quickly, often with little notice. Location of critical technologies should be considered (e.g., server room is in the basement or first floor of the facility).', 6),
(7, 'NT-7', 1, 'Pandemic (Disease) Outbreaks', 'Due to the wide variety of possible scenarios, consideration should be given both to the magnitude of what can reasonably happen during a pandemic outbreak (e.g., COVID-19, Influenza, SARS, Ebola, etc.) and what actions the business can be taken to help lessen the impact of a  pandemic on operations.', 7),
(8, 'NT-8', 1, 'Severe Weather', 'Severe weather is a broad category of meteorological events that include events that range from damaging winds to hail.', 8),
(9, 'NT-9', 1, 'Space Weather', 'Space weather includes natural events in space that can affect the near-earth environment and satellites. Most commonly, this is associated with solar flares from the Sun, so an understanding of how solar flares may impact the business is of critical importance in assessing this threat.', 9),
(10, 'NT-10', 1, 'Thunderstorms & Lightning', 'Thunderstorms are most prevalent in the spring and summer months and generally occur during the afternoon and evening hours, but they can occur year-round and at all hours. Many hazardous weather events are associated with thunderstorms. Under the right conditions, rainfall from thunderstorms causes flash flooding and lightning is responsible for equipment damage, fires and fatalities.', 10),
(11, 'NT-11', 1, 'Tornadoes', 'Tornadoes occur in many parts of the world, including the US, Australia, Europe, Africa, Asia, and South America. Tornadoes can happen at any time of year and occur at any time of day or night, but most tornadoes occur between 4–9 p.m. Tornadoes (with winds up to about 300 mph) can destroy all but the best-built man-made structures.', 11),
(12, 'NT-12', 1, 'Tsunamis', 'All tsunamis are potentially dangerous, even though they may not damage every coastline they strike. A tsunami can strike anywhere along most of the US coastline. The most destructive tsunamis have occurred along the coasts of California, Oregon, Washington, Alaska and Hawaii.', 12),
(13, 'NT-13', 1, 'Volcanoes', 'While volcanoes are geographically fixed objects, volcanic fallout can have significant downwind impacts for thousands of miles. Far outside of the blast zone, volcanoes can significantly damage or degrade transportation systems and also cause electrical grids to fail.', 13),
(14, 'NT-14', 1, 'Winter Storms & Extreme Cold', 'Winter storms is a broad category of meteorological events that include events that range from ice storms, to heavy snowfall, to unseasonably (e.g., record breaking) cold temperatures. Winter storms can significantly impact business operations and transportation systems over a wide geographic region.', 14),
(15, 'MT-1', 2, 'Civil or Political Unrest', 'Civil or political unrest can be singular or wide-spread events that can be unexpected and unpredictable. These events can occur anywhere, at any time.', 15),
(16, 'MT-2', 2, 'Hacking & Other Cybersecurity Crimes', 'Unlike physical threats that prompt immediate action (e.g., \\\"stop, drop, and roll\\\" in the event of a fire), cyber incidents are often difficult to identify as the incident is occurring. Detection generally occurs after the incident has occurred, with the exception of \\\"denial of service\\\" attacks. The spectrum of cybersecurity risks is limitless and threats can have wide-ranging effects on the individual, organizational, geographic, and national levels.', 16),
(17, 'MT-3', 2, 'Hazardous Materials Emergencies', 'Hazardous materials emergencies are focused on accidental disasters that occur in industrialized nations. These incidents can range from industrial chemical spills to groundwater contamination.', 17),
(18, 'MT-4', 2, 'Nuclear, Biological and Chemical (NBC) Weapons', 'The use of NBC weapons are in the possible arsenals of international terrorists and it must be a consideration. Terrorist use of a “dirty bomb” — is considered far more likely than use of a traditional nuclear explosive device. This may be a combination a conventional explosive device with radioactive / chemical / biological material and be designed to scatter lethal and sub-lethal amounts of material over a wide area.', 18),
(19, 'MT-5', 2, 'Physical Crime', 'Physical crime includes \\\"traditional\\\" crimes of opportunity. These incidents can range from theft, to vandalism, riots, looting, arson and other forms of criminal activities.', 19),
(20, 'MT-6', 2, 'Terrorism & Armed Attacks', 'Armed attacks, regardless of the motivation of the attacker, can impact a businesses. Scenarios can range from single actors (e.g., \\\"disgruntled\\\" employee) all the way to a coordinated terrorist attack by multiple assailants. These incidents can range from the use of blade weapons (e.g., knives), blunt objects (e.g., clubs), to firearms and explosives.', 20),
(21, 'MT-7', 2, 'Utility Service Disruption', 'Utility service disruptions are focused on the sustained loss of electricity, Internet, natural gas, water, and/or sanitation services. These incidents can have a variety of causes but  directly impact the fulfillment of utility services that your business needs to operate.', 21);

-- --------------------------------------------------------

--
-- Table structure for table `threat_groupings`
--

CREATE TABLE `threat_groupings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `threat_groupings`
--

INSERT INTO `threat_groupings` (`id`, `name`) VALUES
(1, 'Natural Threat'),
(2, 'Man-Made Threat');

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

CREATE TABLE `translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `language_id` int(10) UNSIGNED NOT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `lockout` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'grc',
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salt` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `lang` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `multi_factor` int(11) NOT NULL DEFAULT 1,
  `ldap_department` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_password` tinyint(1) NOT NULL DEFAULT 0,
  `custom_display_settings` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `manager_id` bigint(20) UNSIGNED DEFAULT NULL,
  `job_id` bigint(20) UNSIGNED DEFAULT NULL,
  `custom_plan_mitigation_display_settings` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{"risk_colums":[["id","1"],["risk_status","1"],["subject","1"],["calculated_risk","1"],["submission_date","1"]],"mitigation_colums":[["mitigation_planned","1"]],"review_colums":[["management_review","1"]]}\n',
  `custom_perform_reviews_display_settings` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{"risk_colums":[["id","1"],["risk_status","1"],["subject","1"],["calculated_risk","1"],["submission_date","1"]],"mitigation_colums":[["mitigation_planned","1"]],"review_colums":[["management_review","1"]]}\n',
  `custom_reviewregularly_display_settings` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{"risk_colums":[["id","1"],["risk_status","1"],["subject","1"],["calculated_risk","1"],["days_open","1"]],"review_colums":[["management_review","0"],["review_date","0"],["next_step","0"],["next_review_date","1"],["comments","0"]]}',
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `enabled`, `lockout`, `type`, `username`, `name`, `email`, `salt`, `password`, `last_login`, `last_password_change_date`, `role_id`, `lang`, `admin`, `multi_factor`, `ldap_department`, `change_password`, `custom_display_settings`, `department_id`, `manager_id`, `job_id`, `custom_plan_mitigation_display_settings`, `custom_perform_reviews_display_settings`, `custom_reviewregularly_display_settings`, `phone_number`) VALUES
(1, 1, 0, 'grc', 'admin', 'Admin', 'admin@gmail.com', 'qCJpnAe5S6k61Pqh3SFG', '$2y$10$evkw7vE8vYWAmGoRZiS.dujo1NV8yakZ.jh4vPujpV4veP8NrEB8u', '2022-01-17 09:00:33', '2017-01-08 09:58:20', 1, NULL, 1, 1, NULL, 0, '[\\\"id\\\",\\\"subject\\\",\\\"calculated_risk\\\",\\\"submission_date\\\",\\\"mitigation_planned\\\",\\\"management_review\\\"]', 24, NULL, NULL, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}', '{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\\n', '{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"days_open\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"0\\\"],[\\\"review_date\\\",\\\"0\\\"],[\\\"next_step\\\",\\\"0\\\"],[\\\"next_review_date\\\",\\\"1\\\"],[\\\"comments\\\",\\\"0\\\"]]}', NULL),
(2, 1, 0, 'grc', 'department1manager', 'مدير الرئيس التنفيذى', 'department1manager@mail.com', NULL, '$2y$10$q.jHsSYLgMLGDmVQsVLLd.S.B7aA0IgYiahq66wccjif1YsklxtSm', NULL, '2023-11-12 16:29:03', 6, NULL, 0, 1, NULL, 0, '', 1, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(3, 1, 0, 'grc', 'department2manager', 'مدير اﻹدارة العامة ﻷمن المعلومات', 'department2manager@mail.com', NULL, '$2y$10$nmrcrKMhIh1pX.jithaPT.QSJvgp6D0BPUmw5Hnaqjlmhsr3qV3Z6', NULL, '2023-11-12 16:29:03', 1, NULL, 0, 1, NULL, 0, '', 2, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(4, 1, 0, 'grc', 'department3manager', 'مدير نائب المدير العام', 'department3manager@mail.com', NULL, '$2y$10$nNeLW/PFDDi/kS/aE4T9eug3eCyfFimTgQ8KEGOVldcqZO.CehMNe', NULL, '2023-11-12 16:29:03', 1, NULL, 0, 1, NULL, 0, '', 3, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(5, 1, 0, 'grc', 'department4manager', 'مدير المكتب اﻹدارى', 'department4manager@mail.com', NULL, '$2y$10$54KiViT3s1o8YqukwoOVM../dtiS/209yR5mCLq.R9UctDc053iHy', NULL, '2023-11-12 16:29:03', 1, NULL, 0, 1, NULL, 0, '', 4, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(6, 1, 0, 'grc', 'department5manager', 'مدير الحوكمة والمخاطر والالتزام', 'department5manager@mail.com', NULL, '$2y$10$RNlIzcB68YyAnludSgVvy.3oyGnXhaXQJjIwgOj4gIrLporwxa9NG', NULL, '2023-11-12 16:29:03', 1, NULL, 0, 1, NULL, 0, '', 5, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(7, 1, 0, 'grc', 'department6manager', 'مدير المراقبة اﻷمنية والاستجابة والتحليل', 'department6manager@mail.com', NULL, '$2y$10$9UeNMBX9jAdK9bpOnc8g7eBejUQ/awk//YwmtGWQ0QlJLtERr6xpm', NULL, '2023-11-12 16:29:03', 1, NULL, 0, 1, NULL, 0, '', 6, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(8, 1, 0, 'grc', 'department7manager', 'مدير إدارة الحلول اﻷمنية', 'department7manager@mail.com', NULL, '$2y$10$6ppOwH9A3oArIbpqiukB5e.tqoAwKYCpfg58I3WG32AvgWgjUBAQu', NULL, '2023-11-12 16:29:03', 1, NULL, 0, 1, NULL, 0, '', 7, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(9, 1, 0, 'grc', 'department8manager', 'مدير المعمارية والتخطيط', 'department8manager@mail.com', NULL, '$2y$10$fs77sUGI7pdpnmvdI1f3teKoMKH/9Gdm2e7HC5vwRbxF5FyYtuoYG', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 8, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(10, 1, 0, 'grc', 'department9manager', 'مدير الحوكمة', 'department9manager@mail.com', NULL, '$2y$10$c8Tsmz.hP4RGzXrRXpMhRuqePJdWpgGRjwMJxxiVVfuMn084fLu5e', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 9, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(11, 1, 0, 'grc', 'department10manager', 'مدير المخاطر', 'department10manager@mail.com', NULL, '$2y$10$zp3vrepPYdFctzQRGH.0qOQrCFBBSoPDw3ziqLFBqqv0XONawpLce', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 10, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(12, 1, 0, 'grc', 'department11manager', 'مدير الالتزام', 'department11manager@mail.com', NULL, '$2y$10$qy.akZbz5DnGWmqEMXkSZOdvEpS4mO5TV0DKubnHa76Iv58nTciFa', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 11, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(13, 1, 0, 'grc', 'department12manager', 'مدير المراقبة اﻷمنية', 'department12manager@mail.com', NULL, '$2y$10$NCQ65qgv6kjLsYoo.uqDPOhOZ96mqgrYc.67zuTDC8Brkld5muho2', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 12, 2, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(14, 1, 0, 'grc', 'department13manager', 'مدير التحليل الرقمى والاستجابة للحوادث', 'department13manager@mail.com', NULL, '$2y$10$T.Iev5LTo8iVcGFJ0YKbne5UIlfEPJzx6N521poQQc/YFjKRTJEq2', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 13, 3, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(15, 1, 0, 'grc', 'department14manager', 'مدير المعلومات الاستخباراتية والتهديدات', 'department14manager@mail.com', NULL, '$2y$10$9zcS60Gq3sfy8crk6EFeQ.MW4XQa72Xo00pBH68cMvGCfbp9lHx.S', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 14, 4, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(16, 1, 0, 'grc', 'department15manager', 'مدير تحليل التهديدات والثغرات', 'department15manager@mail.com', NULL, '$2y$10$46adU8f8Gv1IhoFspl1sYuVR46/ppjmJSrWmJhvj.hHo8WIma0p5S', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 15, 5, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(17, 1, 0, 'grc', 'department16manager', 'مدير إدارة الضوابط التقنية اﻷمنية', 'department16manager@mail.com', NULL, '$2y$10$hmExlpU/4QBXoBI6hhQAHOxZ6.9TRrbPLP4FgfufYeXq5muphZdOG', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 16, 6, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(18, 1, 0, 'grc', 'department17manager', 'مدير تطوير واختبار الحلول اﻷمنية', 'department17manager@mail.com', NULL, '$2y$10$CC5Qbeu2CBtp85rG3ts4ieYVXd1X3uuHuROgbUFK1TkcdN0KPQwCy', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 17, 7, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(19, 1, 0, 'grc', 'department18manager', 'مدير إدارة الهويات والصلاحيات', 'department18manager@mail.com', NULL, '$2y$10$8gBbU2GqhDzaWjumHPWd6.nHQwJgAx94Y/bXJ6C1qtYTatmh2i3vm', NULL, '2023-11-12 16:29:04', 1, NULL, 0, 1, NULL, 0, '', 18, 8, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(20, 1, 0, 'grc', 'department19manager', 'مدير التخطيط والتطوير', 'department19manager@mail.com', NULL, '$2y$10$E9nWQ/23Bun1c8A4QYThguXQhYJEXPuTEuup/opejD6mf0C/0.9i.', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 19, 9, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(21, 1, 0, 'grc', 'department20manager', 'مدير المعمارية اﻷمنية', 'department20manager@mail.com', NULL, '$2y$10$LH4B.g6CkXBADGL2mX9tDefmkv5z2zwH9Pub7N7Q/BU.YYj4JKzhi', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 20, 10, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(22, 1, 0, 'grc', 'department1employee1', 'Department1 Employee1', 'employee1@mail.com', NULL, '$2y$10$4nvXiJeeR8oRUZHyuXQYaOXo5bQo5mpbPcx0uFiUdxSlkG7529Oem', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 2, 2, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(23, 1, 0, 'grc', 'department2employee1', 'Department2 Employee1', 'employee2@mail.com', NULL, '$2y$10$XnLSfKM6KfnrCjUl/iesgeLzGtjgeNaXho8ChYpUevG8UPtNtPZmi', NULL, '2023-11-12 16:29:05', 2, NULL, 0, 1, NULL, 0, '', 4, NULL, 10, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(24, 1, 0, 'grc', 'department3employee1', 'Department3 Employee1', 'employee3@mail.com', NULL, '$2y$10$1jsi7FZatnNlIILeL9lWu.V4JH3KYY6Tcwot8kb/ldcKGwl/sjOLG', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 3, 4, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(25, 1, 0, 'grc', 'department4employee1', 'Department4 Employee1', 'employee4@mail.com', NULL, '$2y$10$4h3.VIr01N9vS9SUx/c0N.ZEuTzd0ZCwoPPAwwbkUmgCNtefdvlN2', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 4, 5, 3, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(26, 1, 0, 'grc', 'department5employee1', 'Department5 Employee1', 'employee5@mail.com', NULL, '$2y$10$Ca6gZzTNw/KKrZU2sxA91.nmJsL89m1WKDfHZWmXneqLn2uTpTUjS', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 5, 6, 8, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(27, 1, 0, 'grc', 'department6employee1', 'Department6 Employee1', 'employee6@mail.com', NULL, '$2y$10$uQQEuTQl0mbCSxQ1JP4kQu08xddJ1zh16sIzPTrSHIWL7TyXnqeJ2', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 6, 7, 12, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(28, 1, 0, 'grc', 'department7employee1', 'Department7 Employee1', 'employee7@mail.com', NULL, '$2y$10$w3XFh8WcPI/f4DQJR5nSJ.VlwvGat2VsZCwhEQZ.pyP2DDEf0Nqn2', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 7, 8, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(29, 1, 0, 'grc', 'department8employee1', 'Department8 Employee1', 'employee8@mail.com', NULL, '$2y$10$gzppVCJumMfPx5soe6S2O.xPcTlhE4toDQr3dEGAYXXYzihI08Vlm', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 8, 9, 9, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(30, 1, 0, 'grc', 'department9employee1', 'Department9 Employee1', 'employee9@mail.com', NULL, '$2y$10$.qFnL2POLyqp7LJDmTlcx.ASJmE/uyphfvZdpF6DcZRfYnNKu9Dxe', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 9, 10, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(31, 1, 0, 'grc', 'department10employee1', 'Department10 Employee1', 'employee10@mail.com', NULL, '$2y$10$pmX1fQYIkpA6XhJOX82hzu9gQuv9KyYXv.ZNhYYd0S1tM2X5Ybmom', NULL, '2023-11-12 16:29:05', 1, NULL, 0, 1, NULL, 0, '', 10, 11, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(32, 1, 0, 'grc', 'department11employee1', 'Department11 Employee1', 'employee11@mail.com', NULL, '$2y$10$nTAWY9YXcWj6y.PFn9XTQeATrIJDRjFrpQzcwuhZTCb8K6Py.1mRi', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 11, 12, 3, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(33, 1, 0, 'grc', 'department12employee1', 'Department12 Employee1', 'employee12@mail.com', NULL, '$2y$10$1/tH2FeaSiGXqaVhJGV2CuoTulhvibEU9b33HFlFC7GViYrEZHTzu', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 12, 13, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(34, 1, 0, 'grc', 'department13employee1', 'Department13 Employee1', 'employee13@mail.com', NULL, '$2y$10$271mt2J46TjIzqwKxBAwh.O/d4yB3kMWByBeXMjFciCz4b5krTbAS', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 13, 14, 12, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(35, 1, 0, 'grc', 'department14employee1', 'Department14 Employee1', 'employee14@mail.com', NULL, '$2y$10$t/4dzrM9WxRWuulJzDCwy...P0pzLhPy3k1zcDpHZU5wPDmuOKzbW', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 14, 15, 11, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(36, 1, 0, 'grc', 'department15employee1', 'Department15 Employee1', 'employee15@mail.com', NULL, '$2y$10$I6R6ALj3d5B4B6vtBAzSOuXuq6FMjd53ZgiqYSy.OtmvoV.LK4evq', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 15, 16, 11, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(37, 1, 0, 'grc', 'department16employee1', 'Department16 Employee1', 'employee16@mail.com', NULL, '$2y$10$615cIxIBFoe3AdIu2mI7NepGdrCdG2jYpY88Se1TYu.nnQq1Wmqw6', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 16, 17, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(38, 1, 0, 'grc', 'department17employee1', 'Department17 Employee1', 'employee17@mail.com', NULL, '$2y$10$Mm./G1OZUsa1xM4hnZA/XuNOk3G7d4XM9YUkPlPJmOIHs3DkRZewG', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 17, 18, 8, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(39, 1, 0, 'grc', 'department18employee1', 'Department18 Employee1', 'employee18@mail.com', NULL, '$2y$10$heDr7OugDVsWcyvueTmrsuPRGcn7jJWIIuxmmL.q40GPtn7yKK.m6', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 18, 19, 9, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(40, 1, 0, 'grc', 'department19employee1', 'Department19 Employee1', 'employee19@mail.com', NULL, '$2y$10$hSKZan9lSdFG9N.egN4xle2bZUJ4VNOE2t/MIn4NQGhgUffs.dSVK', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 19, 20, 10, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(41, 1, 0, 'grc', 'department20employee1', 'Department20 Employee1', 'employee20@mail.com', NULL, '$2y$10$63wSlmLHEiufUFBZ1SJRwe6/XlEpqTgzRYlK2XjgpF1cvzVQVBOxe', NULL, '2023-11-12 16:29:06', 1, NULL, 0, 1, NULL, 0, '', 20, 21, 9, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(42, 0, 0, 'grc', 'test', 'testx', 'test@zflexsoftware.com', '5sISWRcXK6zFoyUAbfQR', '$2y$10$mSaCKnSLxEo2IOUAU7lBAug7O14xmxUp9ex385ERTl5HBMc0caqT.', NULL, '2023-11-12 17:51:20', 1, NULL, 0, 1, NULL, 0, '[\"id\",\"subject\",\"calculated_risk\",\"submission_date\",\"mitigation_planned\",\"management_review\"]', NULL, NULL, NULL, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL),
(43, 1, 0, 'grc', 'Guest000', 'Mustafa Mohammed', 'pksaudi10@gmail.com', 'vv3JoU2JMXv9t0WduYC9', '$2y$10$XnV0Waluilxu6uj8CncD7eddpB8HHV3MZyRaZkbr6qrwwtvCUr80e', NULL, '2023-11-12 17:59:30', 1, NULL, 0, 1, NULL, 0, '[\"id\",\"subject\",\"calculated_risk\",\"submission_date\",\"mitigation_planned\",\"management_review\"]', NULL, NULL, NULL, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', '+201211575558'),
(44, 1, 0, 'grc', 'Ali', 'Ali', 'voiddragon03@gmail.com', 'nB5hDmR8xpBNwqdZHkGi', '$2y$10$JuylLidwJ3Ij/rU7hf49zuajlAYXiGg/H4/7TPYn9VmMmLNMMWaeq', NULL, '2023-11-13 07:32:57', 6, NULL, 1, 1, NULL, 0, '[\"id\",\"subject\",\"calculated_risk\",\"submission_date\",\"mitigation_planned\",\"management_review\"]', NULL, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', '+201002239207'),
(45, 1, 0, 'grc', 'Guest', 'Mohamed Elsayed5', 'guest11@yahoo.com', '2zBLuMLLr3N6N8xtRmQd', '$2y$10$a/IU4mIaUjuPnPANh6RTcOu1OfLzCyg65CAqpYGpmMYDZw7S821Wm', NULL, '2023-11-13 08:10:47', 5, NULL, 0, 1, NULL, 0, '[\"id\",\"subject\",\"calculated_risk\",\"submission_date\",\"mitigation_planned\",\"management_review\"]', 1, NULL, NULL, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', '+201009213707'),
(46, 0, 0, 'grc', 'iiiiiiiiiiiiiiiiiii', 'Mohamed Elsayed', 'guest117@yahoo.com', 'iXhJsCKODCnm1FG7Qu2F', '$2y$10$uBbZvgRoSB/h0lromLmR3.dzG1QnE6qUwA5wjl96jNo7CmiY96WR6', NULL, '2023-11-13 08:24:27', 2, NULL, 0, 1, NULL, 0, '[\"id\",\"subject\",\"calculated_risk\",\"submission_date\",\"mitigation_planned\",\"management_review\"]', 1, NULL, NULL, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', '+201009213707'),
(47, 1, 0, 'grc', 'hjghgfyujst', 'jhjsks', 'guesnnnt1@zflexsoftware.com', 'X84S4ajjyRhhTCZITs4n', '$2y$10$T0mpEqEURxvFW67Vb38Yd.ipwETD1.3sK5Rq1cFEGbT5YmiK4Qjve', NULL, '2023-11-13 13:38:46', 3, NULL, 0, 1, NULL, 0, '[\"id\",\"subject\",\"calculated_risk\",\"submission_date\",\"mitigation_planned\",\"management_review\"]', NULL, NULL, NULL, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `is_read` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_notifications`
--

INSERT INTO `user_notifications` (`id`, `user_id`, `notification_id`, `is_read`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, NULL, '2023-11-12 19:38:50'),
(2, 1, 2, 0, NULL, NULL),
(3, 1, 3, 0, NULL, NULL),
(4, 0, 4, 0, NULL, NULL),
(5, 1, 5, 0, NULL, NULL),
(6, 0, 6, 0, NULL, NULL),
(7, 0, 7, 0, NULL, NULL),
(8, 1, 8, 0, NULL, NULL),
(9, 0, 9, 0, NULL, NULL),
(10, 1, 10, 0, NULL, NULL),
(11, 1, 11, 0, NULL, NULL),
(12, 1, 12, 0, NULL, NULL),
(13, 1, 13, 0, NULL, NULL),
(14, 1, 14, 0, NULL, NULL),
(15, 1, 15, 0, NULL, NULL),
(16, 1, 16, 0, NULL, NULL),
(17, 1, 17, 0, NULL, NULL),
(18, 1, 18, 0, NULL, NULL),
(19, 1, 19, 0, NULL, NULL),
(20, 22, 20, 0, NULL, NULL),
(21, 1, 21, 0, NULL, NULL),
(22, 0, 22, 0, NULL, NULL),
(23, 25, 23, 0, NULL, NULL),
(24, 1, 24, 0, NULL, NULL),
(25, 1, 25, 0, NULL, NULL),
(26, 1, 26, 0, NULL, NULL),
(27, 1, 27, 0, NULL, NULL),
(28, 1, 28, 0, NULL, NULL),
(29, 1, 29, 0, NULL, NULL),
(30, 1, 30, 0, NULL, NULL),
(31, 11, 31, 0, NULL, NULL),
(32, 1, 32, 0, NULL, NULL),
(33, 11, 33, 0, NULL, NULL),
(34, 1, 34, 0, NULL, NULL),
(35, 1, 35, 0, NULL, NULL),
(36, 1, 36, 0, NULL, NULL),
(37, 1, 37, 0, NULL, NULL),
(38, 2, 38, 0, NULL, NULL),
(39, 38, 39, 0, NULL, NULL),
(40, 1, 40, 0, NULL, NULL),
(41, 3, 41, 0, NULL, NULL),
(42, 1, 42, 0, NULL, NULL),
(43, 1, 43, 0, NULL, NULL),
(44, 2, 44, 0, NULL, NULL),
(45, 1, 45, 0, NULL, NULL),
(46, 3, 46, 0, NULL, NULL),
(47, 5, 47, 0, NULL, NULL),
(48, 1, 48, 0, NULL, NULL),
(49, 23, 49, 1, NULL, '2023-11-13 15:44:46'),
(50, 1, 50, 0, NULL, NULL),
(51, 1, 51, 0, NULL, NULL),
(52, 1, 52, 0, NULL, NULL),
(53, 1, 53, 0, NULL, NULL),
(54, 0, 54, 0, NULL, NULL),
(55, 1, 55, 0, NULL, NULL),
(56, 0, 56, 0, NULL, NULL),
(57, 1, 57, 0, NULL, NULL),
(58, 0, 58, 0, NULL, NULL),
(59, 1, 59, 0, NULL, NULL),
(60, 1, 60, 0, NULL, NULL),
(61, 1, 61, 0, NULL, NULL),
(62, 1, 62, 0, NULL, NULL),
(63, 1, 63, 0, NULL, NULL),
(64, 44, 64, 0, NULL, NULL),
(65, 2, 65, 0, NULL, NULL),
(66, 1, 66, 0, NULL, NULL),
(67, 31, 67, 0, NULL, NULL),
(68, 18, 68, 0, NULL, NULL),
(69, 1, 69, 0, NULL, NULL),
(70, 1, 70, 0, NULL, NULL),
(71, 44, 71, 0, NULL, NULL),
(72, 2, 72, 0, NULL, NULL),
(73, 1, 73, 0, NULL, NULL),
(74, 44, 74, 0, NULL, NULL),
(75, 2, 75, 0, NULL, NULL),
(76, 1, 76, 0, NULL, NULL),
(77, 44, 77, 0, NULL, NULL),
(78, 2, 78, 0, NULL, NULL),
(79, 2, 79, 0, NULL, NULL),
(80, 1, 80, 0, NULL, NULL),
(81, 0, 81, 0, NULL, NULL),
(82, 1, 82, 0, NULL, NULL),
(83, 2, 83, 0, NULL, NULL),
(84, 3, 84, 0, NULL, NULL),
(85, 1, 85, 0, NULL, NULL),
(86, 1, 86, 0, NULL, NULL),
(87, 44, 87, 0, NULL, NULL),
(88, 2, 88, 0, NULL, NULL),
(89, 2, 89, 0, NULL, NULL),
(90, 3, 90, 0, NULL, NULL),
(91, 1, 91, 0, NULL, NULL),
(92, 2, 92, 0, NULL, NULL),
(93, 3, 93, 0, NULL, NULL),
(94, 1, 94, 0, NULL, NULL),
(95, 2, 95, 0, NULL, NULL),
(96, 3, 96, 0, NULL, NULL),
(97, 1, 97, 0, NULL, NULL),
(98, 0, 98, 0, NULL, NULL),
(99, 1, 99, 0, NULL, NULL),
(100, 0, 100, 0, NULL, NULL),
(101, 1, 101, 0, NULL, NULL),
(102, 1, 102, 0, NULL, NULL),
(103, 1, 103, 0, NULL, NULL),
(104, 1, 104, 0, NULL, NULL),
(105, 1, 105, 0, NULL, NULL),
(106, 1, 106, 0, NULL, NULL),
(107, 3, 107, 0, NULL, NULL),
(108, 2, 108, 0, NULL, NULL),
(109, 1, 109, 0, NULL, NULL),
(110, 1, 110, 0, NULL, NULL),
(111, 1, 111, 0, NULL, NULL),
(112, 2, 112, 0, NULL, NULL),
(113, 44, 113, 1, NULL, '2023-11-13 14:46:45'),
(114, 1, 114, 0, NULL, NULL),
(115, 2, 115, 0, NULL, NULL),
(116, 44, 116, 0, NULL, NULL),
(117, 1, 117, 0, NULL, NULL),
(118, 2, 118, 0, NULL, NULL),
(119, 44, 119, 0, NULL, NULL),
(120, 1, 120, 1, NULL, '2023-11-13 14:48:09'),
(121, 2, 121, 1, NULL, '2023-11-13 14:51:54'),
(122, 1, 122, 0, NULL, NULL),
(123, 44, 123, 1, NULL, '2023-11-13 14:52:48'),
(124, 1, 124, 0, NULL, NULL),
(125, 44, 125, 0, NULL, NULL),
(126, 44, 126, 0, NULL, NULL),
(127, 44, 127, 0, NULL, NULL),
(128, 44, 128, 0, NULL, NULL),
(129, 44, 129, 0, NULL, NULL),
(130, 44, 130, 0, NULL, NULL),
(131, 44, 131, 0, NULL, NULL),
(132, 1, 132, 0, NULL, NULL),
(133, 43, 133, 0, NULL, NULL),
(134, 44, 134, 0, NULL, NULL),
(135, 1, 135, 0, NULL, NULL),
(136, 43, 136, 0, NULL, NULL),
(137, 44, 137, 0, NULL, NULL),
(138, 1, 138, 0, NULL, NULL),
(139, 2, 139, 1, NULL, '2023-11-13 15:09:27'),
(140, 44, 140, 0, NULL, NULL),
(141, 43, 141, 0, NULL, NULL),
(142, 1, 142, 0, NULL, NULL),
(143, 2, 143, 1, NULL, '2023-11-13 15:14:53'),
(144, 44, 144, 0, NULL, NULL),
(145, 1, 145, 0, NULL, NULL),
(146, 1, 146, 0, NULL, NULL),
(147, 1, 147, 0, NULL, NULL),
(148, 1, 148, 0, NULL, NULL),
(149, 45, 149, 0, NULL, NULL),
(150, 1, 150, 0, NULL, NULL),
(151, 45, 151, 0, NULL, NULL),
(152, 2, 152, 1, NULL, '2023-11-13 17:53:57'),
(153, 3, 153, 0, NULL, NULL),
(154, 1, 154, 0, NULL, NULL),
(155, 21, 155, 0, NULL, NULL),
(156, 22, 156, 0, NULL, NULL),
(157, 1, 157, 0, NULL, NULL),
(158, 1, 158, 0, NULL, NULL),
(159, 43, 159, 0, NULL, NULL),
(160, 44, 160, 0, NULL, NULL),
(161, 1, 161, 0, NULL, NULL),
(162, 43, 162, 0, NULL, NULL),
(163, 44, 163, 0, NULL, NULL),
(164, 1, 164, 0, NULL, NULL),
(165, 43, 165, 0, NULL, NULL),
(166, 44, 166, 1, NULL, '2023-11-13 17:54:22'),
(167, 1, 167, 0, NULL, NULL),
(168, 45, 168, 0, NULL, NULL),
(169, 1, 169, 0, NULL, NULL),
(170, 45, 170, 0, NULL, NULL),
(171, 1, 171, 0, NULL, NULL),
(172, 44, 172, 0, NULL, NULL),
(173, 19, 173, 0, NULL, NULL),
(174, 2, 174, 0, NULL, NULL),
(175, 4, 175, 0, NULL, NULL),
(176, 7, 176, 0, NULL, NULL),
(177, 8, 177, 0, NULL, NULL),
(178, 12, 178, 0, NULL, NULL),
(179, 13, 179, 0, NULL, NULL),
(180, 14, 180, 0, NULL, NULL),
(181, 16, 181, 0, NULL, NULL),
(182, 18, 182, 0, NULL, NULL),
(183, 20, 183, 0, NULL, NULL),
(184, 21, 184, 0, NULL, NULL),
(185, 24, 185, 0, NULL, NULL),
(186, 25, 186, 0, NULL, NULL),
(187, 26, 187, 0, NULL, NULL),
(188, 28, 188, 0, NULL, NULL),
(189, 31, 189, 0, NULL, NULL),
(190, 32, 190, 0, NULL, NULL),
(191, 35, 191, 0, NULL, NULL),
(192, 37, 192, 0, NULL, NULL),
(193, 39, 193, 0, NULL, NULL),
(194, 41, 194, 0, NULL, NULL),
(195, 43, 195, 0, NULL, NULL),
(196, 47, 196, 0, NULL, NULL),
(197, 0, 197, 0, NULL, NULL),
(198, 1, 198, 0, NULL, NULL),
(199, 1, 199, 1, NULL, '2023-11-13 19:07:15'),
(200, 43, 200, 0, NULL, NULL),
(201, 44, 201, 0, NULL, NULL),
(202, 2, 202, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_out_side_cybers`
--

CREATE TABLE `user_out_side_cybers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_out_side_cybers`
--

INSERT INTO `user_out_side_cybers` (`id`, `email`, `username`, `created_at`, `updated_at`) VALUES
(1, 'mostafasayed204060@gmail.com', 'sddd', '2023-11-13 19:00:23', '2023-11-13 19:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `user_pass_histories`
--

CREATE TABLE `user_pass_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `salt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_pass_reuse_histories`
--

CREATE TABLE `user_pass_reuse_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `counts` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_to_teams`
--

CREATE TABLE `user_to_teams` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_to_teams`
--

INSERT INTO `user_to_teams` (`user_id`, `team_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(2, 1),
(43, 2),
(44, 1),
(44, 2),
(44, 3),
(44, 4),
(44, 5),
(44, 6),
(44, 7),
(44, 8),
(44, 9),
(44, 10),
(44, 11),
(44, 12),
(44, 13),
(44, 14),
(44, 15),
(44, 16),
(44, 17),
(44, 18),
(44, 19),
(45, 4),
(46, 4);

-- --------------------------------------------------------

--
-- Table structure for table `validation_files`
--

CREATE TABLE `validation_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `mitigation_id` bigint(20) UNSIGNED NOT NULL,
  `control_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL,
  `content` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vulnerabilities`
--

CREATE TABLE `vulnerabilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cve` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` enum('Critical','High','Medium','Low','Informational') COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommendation` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Open','In Progress','Closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `update_status_date` timestamp NULL DEFAULT NULL,
  `update_status_user` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vulnerabilities`
--

INSERT INTO `vulnerabilities` (`id`, `name`, `cve`, `description`, `severity`, `recommendation`, `plan`, `status`, `update_status_date`, `update_status_user`, `created_by`, `created_at`, `updated_at`) VALUES
(5, 'Alana Bolton', 'Nulla sit quaerat al', 'Sed qui rerum aut te', 'High', 'Incididunt sed offic', 'Aut inventore autem', 'Closed', NULL, NULL, 1, '2023-11-13 11:52:57', '2023-11-13 11:52:57'),
(6, 'testw', 'test', 'aaa', 'Medium', 'a', 'a', 'In Progress', '2023-11-13 15:09:04', 1, 1, '2023-11-13 15:01:58', '2023-11-13 15:09:04'),
(7, 'testz', '12', 'dre', 'Low', 'dert', 'dret', 'Open', NULL, NULL, 1, '2023-11-13 17:49:55', '2023-11-13 17:52:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `actions_name_unique` (`name`);

--
-- Indexes for table `answer_question_surveys`
--
ALTER TABLE `answer_question_surveys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `answer_question_surveys_question_id_foreign` (`question_id`),
  ADD KEY `answer_question_surveys_user_id_foreign` (`user_id`),
  ADD KEY `answer_question_surveys_user_idout_foreign` (`user_idOut`),
  ADD KEY `answer_question_surveys_survey_id_foreign` (`survey_id`);

--
-- Indexes for table `answer_sub_questions`
--
ALTER TABLE `answer_sub_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `answer_sub_questions_answer_id_foreign` (`answer_id`),
  ADD KEY `answer_sub_questions_question_id_foreign` (`question_id`);

--
-- Indexes for table `assessments`
--
ALTER TABLE `assessments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assessment_answers`
--
ALTER TABLE `assessment_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_answers_assessment_id_foreign` (`assessment_id`),
  ADD KEY `assessment_answers_sub_question_assessment_id_foreign` (`sub_question_assessment_id`),
  ADD KEY `assessment_answers_question_id_foreign` (`question_id`),
  ADD KEY `assessment_answers_maturity_control_id_foreign` (`maturity_control_id`),
  ADD KEY `assessment_answers_risk_scoring_method_id_foreign` (`risk_scoring_method_id`),
  ADD KEY `assessment_answers_likelihood_id_foreign` (`likelihood_id`),
  ADD KEY `assessment_answers_impact_id_foreign` (`impact_id`),
  ADD KEY `assessment_answers_owner_id_foreign` (`owner_id`);

--
-- Indexes for table `assessment_answers_to_assets`
--
ALTER TABLE `assessment_answers_to_assets`
  ADD UNIQUE KEY `assessment_answer_asset_unique` (`assessment_answer_id`,`asset_id`),
  ADD KEY `assessment_answers_to_assets_asset_id_foreign` (`asset_id`);

--
-- Indexes for table `assessment_answers_to_asset_groups`
--
ALTER TABLE `assessment_answers_to_asset_groups`
  ADD UNIQUE KEY `assessment_answer_asset_group_unique` (`assessment_answer_id`,`asset_group_id`),
  ADD KEY `assessment_answers_to_asset_groups_asset_group_id_foreign` (`asset_group_id`);

--
-- Indexes for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_questions_assessment_id_foreign` (`assessment_id`),
  ADD KEY `assessment_questions_question_id_foreign` (`question_id`);

--
-- Indexes for table `assessment_scorings`
--
ALTER TABLE `assessment_scorings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assessment_scoring_contributing_impacts`
--
ALTER TABLE `assessment_scoring_contributing_impacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `A_S_C_I_A_S_id_foreign` (`assessment_scoring_id`),
  ADD KEY `A_S_C_I_C_R_id_foreign` (`contributing_risk_id`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `assets_asset_value_id_foreign` (`asset_value_id`),
  ADD KEY `assets_location_id_foreign` (`location_id`);

--
-- Indexes for table `asset_asset_groups`
--
ALTER TABLE `asset_asset_groups`
  ADD UNIQUE KEY `asset_asset_group_unique` (`asset_id`,`asset_group_id`),
  ADD KEY `asset_asset_groups_asset_group_id_foreign` (`asset_group_id`);

--
-- Indexes for table `asset_groups`
--
ALTER TABLE `asset_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- Indexes for table `asset_values`
--
ALTER TABLE `asset_values`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asset_vulnerabilities`
--
ALTER TABLE `asset_vulnerabilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_vulnerabilities_asset_id_foreign` (`asset_id`),
  ADD KEY `asset_vulnerabilities_vulnerability_id_foreign` (`vulnerability_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD KEY `audit_logs_user_id_foreign` (`user_id`);

--
-- Indexes for table `auto_notifies`
--
ALTER TABLE `auto_notifies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `autoNotify_settings_foreign` (`action_id`);

--
-- Indexes for table `awareness_surveys`
--
ALTER TABLE `awareness_surveys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `awareness_surveys_owner_id_foreign` (`owner_id`),
  ADD KEY `awareness_surveys_privacy_foreign` (`privacy`),
  ADD KEY `awareness_surveys_filter_status_foreign` (`filter_status`),
  ADD KEY `awareness_surveys_created_by_foreign` (`created_by`);

--
-- Indexes for table `backups`
--
ALTER TABLE `backups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `change_requests`
--
ALTER TABLE `change_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `change_requests_created_by_foreign` (`created_by`);

--
-- Indexes for table `close_reasons`
--
ALTER TABLE `close_reasons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `closures`
--
ALTER TABLE `closures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `closures_risk_id_foreign` (`risk_id`),
  ADD KEY `closures_user_id_foreign` (`user_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `compliance_files`
--
ALTER TABLE `compliance_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_questionnaires`
--
ALTER TABLE `contact_questionnaires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_questionnaires_user_id_foreign` (`user_id`),
  ADD KEY `contact_questionnaires_questionnaire_id_foreign` (`questionnaire_id`);

--
-- Indexes for table `contact_questionnaire_answers`
--
ALTER TABLE `contact_questionnaire_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_questionnaire_answers_asset_id_foreign` (`asset_id`),
  ADD KEY `contact_questionnaire_answers_contact_id_foreign` (`contact_id`),
  ADD KEY `contact_questionnaire_answers_questionnaire_id_foreign` (`questionnaire_id`);

--
-- Indexes for table `contact_questionnaire_answer_results`
--
ALTER TABLE `contact_questionnaire_answer_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_q_answer_id` (`contact_questionnaire_answer_id`),
  ADD KEY `contact_questionnaire_answer_results_question_id_foreign` (`question_id`),
  ADD KEY `contact_questionnaire_answer_results_answer_id_foreign` (`answer_id`);

--
-- Indexes for table `contributing_risks`
--
ALTER TABLE `contributing_risks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contributing_risks_impacts`
--
ALTER TABLE `contributing_risks_impacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contributing_risks_impacts_contributing_risks_id_foreign` (`contributing_risks_id`);

--
-- Indexes for table `contributing_risks_likelihoods`
--
ALTER TABLE `contributing_risks_likelihoods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `controls_control_objectives`
--
ALTER TABLE `controls_control_objectives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_controls_foreign` (`control_id`),
  ADD KEY `control_objectivess_foreign` (`objective_id`),
  ADD KEY `controls_control_objectives_responsible_id_foreign` (`responsible_id`),
  ADD KEY `controls_control_objectives_responsible_team_id_foreign` (`responsible_team_id`);

--
-- Indexes for table `control_audits_evidences`
--
ALTER TABLE `control_audits_evidences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `control_audits_evidences_evidence_id_foreign` (`evidence_id`),
  ADD KEY `fk_control_test_audit_objective_id` (`framework_control_test_audit_id`);

--
-- Indexes for table `control_audits_objectives`
--
ALTER TABLE `control_audits_objectives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `control_audits_objectives_control_control_objective_id_foreign` (`control_control_objective_id`),
  ADD KEY `fk_control_test_audit_id` (`framework_control_test_audit_id`);

--
-- Indexes for table `control_audit_policies`
--
ALTER TABLE `control_audit_policies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `control_audit_policies_document_id_foreign` (`document_id`),
  ADD KEY `control_audit_policies_framework_control_test_audit_id_foreign` (`framework_control_test_audit_id`);

--
-- Indexes for table `control_classes`
--
ALTER TABLE `control_classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_desired_maturities`
--
ALTER TABLE `control_desired_maturities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_maturities`
--
ALTER TABLE `control_maturities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_objectives`
--
ALTER TABLE `control_objectives`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `control_objectives_name_unique` (`name`);

--
-- Indexes for table `control_owners`
--
ALTER TABLE `control_owners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_phases`
--
ALTER TABLE `control_phases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_priorities`
--
ALTER TABLE `control_priorities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_types`
--
ALTER TABLE `control_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_risk_model_values`
--
ALTER TABLE `custom_risk_model_values`
  ADD UNIQUE KEY `impact_likelihood_unique` (`impact_id`,`likelihood_id`),
  ADD KEY `custom_risk_model_values_likelihood_id_foreign` (`likelihood_id`);

--
-- Indexes for table `cvss_scorings`
--
ALTER TABLE `cvss_scorings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_classifications`
--
ALTER TABLE `data_classifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `date_formats`
--
ALTER TABLE `date_formats`
  ADD PRIMARY KEY (`value`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `departments_code_unique` (`code`),
  ADD KEY `departments_parent_id_foreign` (`parent_id`),
  ADD KEY `departments_color_id_foreign` (`color_id`),
  ADD KEY `departments_manager_id_foreign` (`manager_id`);

--
-- Indexes for table `department_colors`
--
ALTER TABLE `department_colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `documents_document_type_foreign` (`document_type`),
  ADD KEY `documents_privacy_foreign` (`privacy`),
  ADD KEY `documents_document_owner_foreign` (`document_owner`),
  ADD KEY `documents_document_reviewer_foreign` (`document_reviewer`),
  ADD KEY `documents_created_by_foreign` (`created_by`);

--
-- Indexes for table `document_exceptions`
--
ALTER TABLE `document_exceptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_exceptions_statuses`
--
ALTER TABLE `document_exceptions_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_notes`
--
ALTER TABLE `document_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `document_notes_user_id_foreign` (`user_id`),
  ADD KEY `document_notes_document_id_foreign` (`document_id`);

--
-- Indexes for table `document_note_files`
--
ALTER TABLE `document_note_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `document_note_files_user_id_foreign` (`user_id`),
  ADD KEY `document_note_files_document_id_foreign` (`document_id`);

--
-- Indexes for table `document_statuses`
--
ALTER TABLE `document_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_types`
--
ALTER TABLE `document_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dynamic_saved_selections`
--
ALTER TABLE `dynamic_saved_selections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dynamic_saved_selections_user_id_foreign` (`user_id`);

--
-- Indexes for table `email_config`
--
ALTER TABLE `email_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evidences`
--
ALTER TABLE `evidences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `controls_control_objectives_foreign` (`control_control_objective_id`),
  ADD KEY `users_foreign` (`creator_id`);

--
-- Indexes for table `failed_login_attempts`
--
ALTER TABLE `failed_login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `failed_login_attempts_user_id_foreign` (`user_id`);

--
-- Indexes for table `families`
--
ALTER TABLE `families`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_parent_id_unique` (`order`,`parent_id`),
  ADD KEY `families_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `files_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `file_tasks`
--
ALTER TABLE `file_tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `file_tasks_task_id_foreign` (`task_id`);

--
-- Indexes for table `file_types`
--
ALTER TABLE `file_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `file_type_extensions`
--
ALTER TABLE `file_type_extensions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `frameworks`
--
ALTER TABLE `frameworks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `framework_controls`
--
ALTER TABLE `framework_controls`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_controls_family_foreign` (`family`),
  ADD KEY `framework_controls_control_owner_foreign` (`control_owner`),
  ADD KEY `framework_controls_desired_maturity_foreign` (`desired_maturity`),
  ADD KEY `framework_controls_control_priority_foreign` (`control_priority`),
  ADD KEY `framework_controls_control_class_foreign` (`control_class`),
  ADD KEY `framework_controls_control_maturity_foreign` (`control_maturity`),
  ADD KEY `framework_controls_control_phase_foreign` (`control_phase`),
  ADD KEY `framework_controls_control_type_foreign` (`control_type`),
  ADD KEY `framework_controls_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `framework_control_mappings`
--
ALTER TABLE `framework_control_mappings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_mappings_framework_control_id_foreign` (`framework_control_id`),
  ADD KEY `framework_control_mappings_framework_id_foreign` (`framework_id`);

--
-- Indexes for table `framework_control_tests`
--
ALTER TABLE `framework_control_tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_tests_tester_foreign` (`tester`),
  ADD KEY `framework_control_tests_framework_control_id_foreign` (`framework_control_id`);

--
-- Indexes for table `framework_control_test_audits`
--
ALTER TABLE `framework_control_test_audits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_audits_test_id_foreign` (`test_id`),
  ADD KEY `framework_control_test_audits_tester_foreign` (`tester`),
  ADD KEY `framework_control_test_audits_framework_control_id_foreign` (`framework_control_id`);

--
-- Indexes for table `framework_control_test_comments`
--
ALTER TABLE `framework_control_test_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_comments_test_audit_id_foreign` (`test_audit_id`),
  ADD KEY `framework_control_test_comments_user_foreign` (`user`);

--
-- Indexes for table `framework_control_test_results`
--
ALTER TABLE `framework_control_test_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_results_test_audit_id_foreign` (`test_audit_id`),
  ADD KEY `framework_control_test_results_test_result_foreign` (`test_result`);

--
-- Indexes for table `framework_control_test_results_to_risks`
--
ALTER TABLE `framework_control_test_results_to_risks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_results_to_risks_test_results_id_foreign` (`test_results_id`),
  ADD KEY `framework_control_test_results_to_risks_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `framework_control_to_frameworks`
--
ALTER TABLE `framework_control_to_frameworks`
  ADD PRIMARY KEY (`control_id`,`framework_id`),
  ADD KEY `framework_id` (`framework_id`,`control_id`);

--
-- Indexes for table `framework_control_type_mappings`
--
ALTER TABLE `framework_control_type_mappings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_type_mappings_control_id_foreign` (`control_id`),
  ADD KEY `framework_control_type_mappings_control_type_id_foreign` (`control_type_id`);

--
-- Indexes for table `framework_families`
--
ALTER TABLE `framework_families`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_families_framework_id_foreign` (`framework_id`),
  ADD KEY `framework_families_family_id_foreign` (`family_id`),
  ADD KEY `framework_families_parent_family_id_foreign` (`parent_family_id`);

--
-- Indexes for table `framework_icons`
--
ALTER TABLE `framework_icons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `impacts`
--
ALTER TABLE `impacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items_to_teams`
--
ALTER TABLE `items_to_teams`
  ADD UNIQUE KEY `item_team_unique` (`item_id`,`team_id`,`type`),
  ADD KEY `item_type` (`item_id`,`type`),
  ADD KEY `team_type` (`team_id`,`type`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `jobs_code_unique` (`code`);

--
-- Indexes for table `kpis`
--
ALTER TABLE `kpis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kpis_department_id_foreign` (`department_id`),
  ADD KEY `kpis_created_by_foreign` (`created_by`);

--
-- Indexes for table `kpi_assessments`
--
ALTER TABLE `kpi_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kpi_assessments_kpi_id_foreign` (`kpi_id`),
  ADD KEY `kpi_assessments_created_by_foreign` (`created_by`),
  ADD KEY `kpi_assessments_action_by_foreign` (`action_by`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likelihoods`
--
ALTER TABLE `likelihoods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mail_auto_notfies`
--
ALTER TABLE `mail_auto_notfies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mail_auto_notify_foreign` (`action_id`);

--
-- Indexes for table `mail_settings`
--
ALTER TABLE `mail_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mail_settings_foreign` (`action_id`);

--
-- Indexes for table `mgmt_reviews`
--
ALTER TABLE `mgmt_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mgmt_reviews_risk_id_foreign` (`risk_id`),
  ADD KEY `mgmt_reviews_review_foreign` (`review`),
  ADD KEY `mgmt_reviews_reviewer_foreign` (`reviewer`),
  ADD KEY `mgmt_reviews_next_step_id_foreign` (`next_step_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mitigations`
--
ALTER TABLE `mitigations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mitigations_planning_strategy_foreign` (`planning_strategy`),
  ADD KEY `mitigations_mitigation_effort_foreign` (`mitigation_effort`),
  ADD KEY `mitigations_mitigation_owner_foreign` (`mitigation_owner`),
  ADD KEY `mitigations_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `mitigation_accept_users`
--
ALTER TABLE `mitigation_accept_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mitigation_accept_users_risk_id_foreign` (`risk_id`),
  ADD KEY `mitigation_accept_users_user_id_foreign` (`user_id`);

--
-- Indexes for table `mitigation_efforts`
--
ALTER TABLE `mitigation_efforts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mitigation_to_controls`
--
ALTER TABLE `mitigation_to_controls`
  ADD PRIMARY KEY (`mitigation_id`,`control_id`),
  ADD KEY `control_id` (`control_id`,`mitigation_id`);

--
-- Indexes for table `mitigation_to_teams`
--
ALTER TABLE `mitigation_to_teams`
  ADD PRIMARY KEY (`mitigation_id`,`team_id`),
  ADD KEY `team_id` (`team_id`,`mitigation_id`);

--
-- Indexes for table `next_steps`
--
ALTER TABLE `next_steps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifiables`
--
ALTER TABLE `notifiables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifiables_foreign` (`user_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications_roles`
--
ALTER TABLE `notifications_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notify_at_date_models`
--
ALTER TABLE `notify_at_date_models`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pending_risks`
--
ALTER TABLE `pending_risks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pending_risks_assessment_id_foreign` (`assessment_id`),
  ADD KEY `pending_risks_assessment_answer_id_foreign` (`assessment_answer_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `permissions_subgroup_id_foreign` (`subgroup_id`);

--
-- Indexes for table `permission_groups`
--
ALTER TABLE `permission_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `permission_to_permission_groups`
--
ALTER TABLE `permission_to_permission_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_to_permission_groups_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_to_permission_groups_permission_group_id_foreign` (`permission_group_id`);

--
-- Indexes for table `permission_to_users`
--
ALTER TABLE `permission_to_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_to_users_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_to_users_user_id_foreign` (`user_id`);

--
-- Indexes for table `planning_strategies`
--
ALTER TABLE `planning_strategies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privacies`
--
ALTER TABLE `privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questionnaires`
--
ALTER TABLE `questionnaires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questionnaires_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `questionnaire_pending_risks`
--
ALTER TABLE `questionnaire_pending_risks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questionnaire_questions`
--
ALTER TABLE `questionnaire_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questionnaire_questions_questionnaire_id_foreign` (`questionnaire_id`),
  ADD KEY `questionnaire_questions_question_id_foreign` (`question_id`);

--
-- Indexes for table `questionnaire_risks`
--
ALTER TABLE `questionnaire_risks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questionnaire_risks_questionnaire_id_foreign` (`questionnaire_id`),
  ADD KEY `questionnaire_risks_answer_id_foreign` (`answer_id`),
  ADD KEY `questionnaire_risks_risk_scoring_method_id_foreign` (`risk_scoring_method_id`),
  ADD KEY `questionnaire_risks_likelihood_id_foreign` (`likelihood_id`),
  ADD KEY `questionnaire_risks_impact_id_foreign` (`impact_id`),
  ADD KEY `questionnaire_risks_owner_id_foreign` (`owner_id`),
  ADD KEY `questionnaire_risks_framework_controls_ids_foreign` (`framework_controls_ids`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questions_control_id_foreign` (`control_id`);

--
-- Indexes for table `regulations`
--
ALTER TABLE `regulations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `residual_risk_scoring_histories`
--
ALTER TABLE `residual_risk_scoring_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `residual_risk_scoring_histories_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review_levels`
--
ALTER TABLE `review_levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risks`
--
ALTER TABLE `risks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risks_control_id_foreign` (`control_id`),
  ADD KEY `risks_source_id_foreign` (`source_id`),
  ADD KEY `risks_category_id_foreign` (`category_id`),
  ADD KEY `risks_owner_id_foreign` (`owner_id`),
  ADD KEY `risks_manager_id_foreign` (`manager_id`),
  ADD KEY `risks_mitigation_id_foreign` (`mitigation_id`),
  ADD KEY `risks_project_id_foreign` (`project_id`),
  ADD KEY `status` (`status`),
  ADD KEY `regulation` (`regulation`),
  ADD KEY `mgmt_review` (`mgmt_review`),
  ADD KEY `close_id` (`close_id`),
  ADD KEY `submitted_by` (`submitted_by`);

--
-- Indexes for table `risks_to_assets`
--
ALTER TABLE `risks_to_assets`
  ADD UNIQUE KEY `risk_id` (`risk_id`,`asset_id`),
  ADD KEY `asset_id` (`asset_id`,`risk_id`);

--
-- Indexes for table `risks_to_asset_groups`
--
ALTER TABLE `risks_to_asset_groups`
  ADD UNIQUE KEY `risk_asset_group_unique` (`risk_id`,`asset_group_id`),
  ADD KEY `asset_group_id` (`asset_group_id`,`risk_id`);

--
-- Indexes for table `risk_catalogs`
--
ALTER TABLE `risk_catalogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_catalogs_risk_grouping_id_foreign` (`risk_grouping_id`),
  ADD KEY `risk_catalogs_risk_function_id_foreign` (`risk_function_id`);

--
-- Indexes for table `risk_functions`
--
ALTER TABLE `risk_functions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risk_groupings`
--
ALTER TABLE `risk_groupings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risk_levels`
--
ALTER TABLE `risk_levels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_levels_review_level_id_foreign` (`review_level_id`);

--
-- Indexes for table `risk_models`
--
ALTER TABLE `risk_models`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risk_scorings`
--
ALTER TABLE `risk_scorings`
  ADD KEY `risk_scorings_id_foreign` (`id`),
  ADD KEY `calculated_risk` (`calculated_risk`);

--
-- Indexes for table `risk_scoring_contributing_impacts`
--
ALTER TABLE `risk_scoring_contributing_impacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_scoring_contributing_impacts_risk_scoring_id_foreign` (`risk_scoring_id`),
  ADD KEY `risk_scoring_contributing_impacts_contributing_risk_id_foreign` (`contributing_risk_id`);

--
-- Indexes for table `risk_scoring_histories`
--
ALTER TABLE `risk_scoring_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_scoring_histories_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `risk_to_additional_stakeholders`
--
ALTER TABLE `risk_to_additional_stakeholders`
  ADD PRIMARY KEY (`risk_id`,`user_id`),
  ADD KEY `user_id` (`user_id`,`risk_id`);

--
-- Indexes for table `risk_to_locations`
--
ALTER TABLE `risk_to_locations`
  ADD PRIMARY KEY (`risk_id`,`location_id`),
  ADD KEY `location_id` (`location_id`,`risk_id`);

--
-- Indexes for table `risk_to_teams`
--
ALTER TABLE `risk_to_teams`
  ADD PRIMARY KEY (`risk_id`,`team_id`),
  ADD KEY `team_id` (`team_id`,`risk_id`);

--
-- Indexes for table `risk_to_technologies`
--
ALTER TABLE `risk_to_technologies`
  ADD PRIMARY KEY (`risk_id`,`technology_id`),
  ADD KEY `technology_id` (`technology_id`,`risk_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_responsibilities`
--
ALTER TABLE `role_responsibilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_responsibilities_role_id_foreign` (`role_id`),
  ADD KEY `role_responsibilities_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `scoring_methods`
--
ALTER TABLE `scoring_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `security_awarenesses`
--
ALTER TABLE `security_awarenesses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `security_awarenesses_privacy_foreign` (`privacy`),
  ADD KEY `security_awarenesses_file_id_foreign` (`file_id`),
  ADD KEY `security_awarenesses_owner_foreign` (`owner`),
  ADD KEY `security_awarenesses_reviewer_foreign` (`reviewer`),
  ADD KEY `security_awarenesses_created_by_foreign` (`created_by`);

--
-- Indexes for table `security_awareness_exams`
--
ALTER TABLE `security_awareness_exams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `security_awareness_exams_security_awareness_id_foreign` (`security_awareness_id`);

--
-- Indexes for table `security_awareness_exam_answers`
--
ALTER TABLE `security_awareness_exam_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `security_awareness_exam_answers_foreign` (`security_awareness_exams_id`),
  ADD KEY `security_awareness_exam_answers_examinee_foreign` (`examinee`);

--
-- Indexes for table `security_awareness_exam_questions`
--
ALTER TABLE `security_awareness_exam_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `security_awareness_exam_options_foreign` (`security_awareness_exams_id`);

--
-- Indexes for table `security_awareness_notes`
--
ALTER TABLE `security_awareness_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `security_awareness_notes_user_id_foreign` (`user_id`),
  ADD KEY `security_awareness_notes_security_awareness_id_foreign` (`security_awareness_id`);

--
-- Indexes for table `security_awareness_note_files`
--
ALTER TABLE `security_awareness_note_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `security_awareness_note_files_user_id_foreign` (`user_id`),
  ADD KEY `security_awareness_note_files_security_awareness_id_foreign` (`security_awareness_id`);

--
-- Indexes for table `service_descriptions`
--
ALTER TABLE `service_descriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `service_descriptions_route_unique` (`route`),
  ADD UNIQUE KEY `service_descriptions_key_unique` (`key`),
  ADD UNIQUE KEY `service_descriptions_name_key_unique` (`name_key`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_settings`
--
ALTER TABLE `sms_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sms_settings_foreign` (`action_id`);

--
-- Indexes for table `sources`
--
ALTER TABLE `sources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subgroups`
--
ALTER TABLE `subgroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subgroups_permission_group_id_foreign` (`permission_group_id`);

--
-- Indexes for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `survey_questions_survey_id_foreign` (`survey_id`);

--
-- Indexes for table `system_notifications_settings`
--
ALTER TABLE `system_notifications_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_notifications_settings_foreign` (`action_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag_unique` (`tag`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_created_by_foreign` (`created_by`),
  ADD KEY `tasks_action_by_foreign` (`action_by`);

--
-- Indexes for table `task_notes`
--
ALTER TABLE `task_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_notes_user_id_foreign` (`user_id`),
  ADD KEY `task_notes_task_id_foreign` (`task_id`);

--
-- Indexes for table `task_note_files`
--
ALTER TABLE `task_note_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_note_files_user_id_foreign` (`user_id`),
  ADD KEY `task_note_files_task_id_foreign` (`task_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_vulnerabilities`
--
ALTER TABLE `team_vulnerabilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_vulnerabilities_team_id_foreign` (`team_id`),
  ADD KEY `team_vulnerabilities_vulnerability_id_foreign` (`vulnerability_id`);

--
-- Indexes for table `technologies`
--
ALTER TABLE `technologies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_results`
--
ALTER TABLE `test_results`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- Indexes for table `test_statuses`
--
ALTER TABLE `test_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `threat_catalogs`
--
ALTER TABLE `threat_catalogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `threat_catalogs_threat_grouping_id_foreign` (`threat_grouping_id`);

--
-- Indexes for table `threat_groupings`
--
ALTER TABLE `threat_groupings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `translations_language_id_foreign` (`language_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`),
  ADD KEY `users_department_id_foreign` (`department_id`),
  ADD KEY `users_manager_id_foreign` (`manager_id`),
  ADD KEY `users_job_id_foreign` (`job_id`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_notifications_notification_id_foreign` (`notification_id`);

--
-- Indexes for table `user_out_side_cybers`
--
ALTER TABLE `user_out_side_cybers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_out_side_cybers_email_unique` (`email`);

--
-- Indexes for table `user_pass_histories`
--
ALTER TABLE `user_pass_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_pass_histories_user_id_foreign` (`user_id`);

--
-- Indexes for table `user_pass_reuse_histories`
--
ALTER TABLE `user_pass_reuse_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_pass_reuse_histories_user_id_foreign` (`user_id`);

--
-- Indexes for table `user_to_teams`
--
ALTER TABLE `user_to_teams`
  ADD PRIMARY KEY (`user_id`,`team_id`),
  ADD KEY `team_id` (`team_id`,`user_id`);

--
-- Indexes for table `validation_files`
--
ALTER TABLE `validation_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `validation_files_mitigation_id_foreign` (`mitigation_id`);

--
-- Indexes for table `vulnerabilities`
--
ALTER TABLE `vulnerabilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vulnerabilities_update_status_user_foreign` (`update_status_user`),
  ADD KEY `vulnerabilities_created_by_foreign` (`created_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `answer_question_surveys`
--
ALTER TABLE `answer_question_surveys`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `answer_sub_questions`
--
ALTER TABLE `answer_sub_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assessments`
--
ALTER TABLE `assessments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `assessment_answers`
--
ALTER TABLE `assessment_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `assessment_scorings`
--
ALTER TABLE `assessment_scorings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assessment_scoring_contributing_impacts`
--
ALTER TABLE `assessment_scoring_contributing_impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `asset_groups`
--
ALTER TABLE `asset_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `asset_values`
--
ALTER TABLE `asset_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `asset_vulnerabilities`
--
ALTER TABLE `asset_vulnerabilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `auto_notifies`
--
ALTER TABLE `auto_notifies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `awareness_surveys`
--
ALTER TABLE `awareness_surveys`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `backups`
--
ALTER TABLE `backups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `change_requests`
--
ALTER TABLE `change_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `close_reasons`
--
ALTER TABLE `close_reasons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `closures`
--
ALTER TABLE `closures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `compliance_files`
--
ALTER TABLE `compliance_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_questionnaires`
--
ALTER TABLE `contact_questionnaires`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact_questionnaire_answers`
--
ALTER TABLE `contact_questionnaire_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_questionnaire_answer_results`
--
ALTER TABLE `contact_questionnaire_answer_results`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contributing_risks`
--
ALTER TABLE `contributing_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contributing_risks_impacts`
--
ALTER TABLE `contributing_risks_impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `contributing_risks_likelihoods`
--
ALTER TABLE `contributing_risks_likelihoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `controls_control_objectives`
--
ALTER TABLE `controls_control_objectives`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `control_audits_evidences`
--
ALTER TABLE `control_audits_evidences`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `control_audits_objectives`
--
ALTER TABLE `control_audits_objectives`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `control_audit_policies`
--
ALTER TABLE `control_audit_policies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `control_classes`
--
ALTER TABLE `control_classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `control_desired_maturities`
--
ALTER TABLE `control_desired_maturities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `control_maturities`
--
ALTER TABLE `control_maturities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `control_objectives`
--
ALTER TABLE `control_objectives`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `control_owners`
--
ALTER TABLE `control_owners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `control_phases`
--
ALTER TABLE `control_phases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `control_priorities`
--
ALTER TABLE `control_priorities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `control_types`
--
ALTER TABLE `control_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cvss_scorings`
--
ALTER TABLE `cvss_scorings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data_classifications`
--
ALTER TABLE `data_classifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `department_colors`
--
ALTER TABLE `department_colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `document_exceptions`
--
ALTER TABLE `document_exceptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_exceptions_statuses`
--
ALTER TABLE `document_exceptions_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_notes`
--
ALTER TABLE `document_notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_note_files`
--
ALTER TABLE `document_note_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_statuses`
--
ALTER TABLE `document_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `document_types`
--
ALTER TABLE `document_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dynamic_saved_selections`
--
ALTER TABLE `dynamic_saved_selections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_config`
--
ALTER TABLE `email_config`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `evidences`
--
ALTER TABLE `evidences`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_login_attempts`
--
ALTER TABLE `failed_login_attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `families`
--
ALTER TABLE `families`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `fields`
--
ALTER TABLE `fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `file_tasks`
--
ALTER TABLE `file_tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `file_types`
--
ALTER TABLE `file_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `file_type_extensions`
--
ALTER TABLE `file_type_extensions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `frameworks`
--
ALTER TABLE `frameworks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `framework_controls`
--
ALTER TABLE `framework_controls`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=916;

--
-- AUTO_INCREMENT for table `framework_control_mappings`
--
ALTER TABLE `framework_control_mappings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1020;

--
-- AUTO_INCREMENT for table `framework_control_tests`
--
ALTER TABLE `framework_control_tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=916;

--
-- AUTO_INCREMENT for table `framework_control_test_audits`
--
ALTER TABLE `framework_control_test_audits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `framework_control_test_comments`
--
ALTER TABLE `framework_control_test_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `framework_control_test_results`
--
ALTER TABLE `framework_control_test_results`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `framework_control_test_results_to_risks`
--
ALTER TABLE `framework_control_test_results_to_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_control_type_mappings`
--
ALTER TABLE `framework_control_type_mappings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_families`
--
ALTER TABLE `framework_families`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `framework_icons`
--
ALTER TABLE `framework_icons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `impacts`
--
ALTER TABLE `impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `kpis`
--
ALTER TABLE `kpis`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kpi_assessments`
--
ALTER TABLE `kpi_assessments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `likelihoods`
--
ALTER TABLE `likelihoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `mail_auto_notfies`
--
ALTER TABLE `mail_auto_notfies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mail_settings`
--
ALTER TABLE `mail_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `mgmt_reviews`
--
ALTER TABLE `mgmt_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `mitigations`
--
ALTER TABLE `mitigations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `mitigation_accept_users`
--
ALTER TABLE `mitigation_accept_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mitigation_efforts`
--
ALTER TABLE `mitigation_efforts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `next_steps`
--
ALTER TABLE `next_steps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notifiables`
--
ALTER TABLE `notifiables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `notifications_roles`
--
ALTER TABLE `notifications_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;

--
-- AUTO_INCREMENT for table `notify_at_date_models`
--
ALTER TABLE `notify_at_date_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pending_risks`
--
ALTER TABLE `pending_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=198;

--
-- AUTO_INCREMENT for table `permission_groups`
--
ALTER TABLE `permission_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `permission_to_permission_groups`
--
ALTER TABLE `permission_to_permission_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `permission_to_users`
--
ALTER TABLE `permission_to_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1184;

--
-- AUTO_INCREMENT for table `planning_strategies`
--
ALTER TABLE `planning_strategies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `privacies`
--
ALTER TABLE `privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `questionnaires`
--
ALTER TABLE `questionnaires`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `questionnaire_pending_risks`
--
ALTER TABLE `questionnaire_pending_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questionnaire_questions`
--
ALTER TABLE `questionnaire_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `questionnaire_risks`
--
ALTER TABLE `questionnaire_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `regulations`
--
ALTER TABLE `regulations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `residual_risk_scoring_histories`
--
ALTER TABLE `residual_risk_scoring_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `review_levels`
--
ALTER TABLE `review_levels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `risks`
--
ALTER TABLE `risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `risk_catalogs`
--
ALTER TABLE `risk_catalogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `risk_functions`
--
ALTER TABLE `risk_functions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `risk_groupings`
--
ALTER TABLE `risk_groupings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `risk_levels`
--
ALTER TABLE `risk_levels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `risk_models`
--
ALTER TABLE `risk_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `risk_scoring_contributing_impacts`
--
ALTER TABLE `risk_scoring_contributing_impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `risk_scoring_histories`
--
ALTER TABLE `risk_scoring_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `role_responsibilities`
--
ALTER TABLE `role_responsibilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1027;

--
-- AUTO_INCREMENT for table `scoring_methods`
--
ALTER TABLE `scoring_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `security_awarenesses`
--
ALTER TABLE `security_awarenesses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `security_awareness_exams`
--
ALTER TABLE `security_awareness_exams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `security_awareness_exam_answers`
--
ALTER TABLE `security_awareness_exam_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `security_awareness_exam_questions`
--
ALTER TABLE `security_awareness_exam_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `security_awareness_notes`
--
ALTER TABLE `security_awareness_notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `security_awareness_note_files`
--
ALTER TABLE `security_awareness_note_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service_descriptions`
--
ALTER TABLE `service_descriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `sms_settings`
--
ALTER TABLE `sms_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sources`
--
ALTER TABLE `sources`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subgroups`
--
ALTER TABLE `subgroups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `survey_questions`
--
ALTER TABLE `survey_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `system_notifications_settings`
--
ALTER TABLE `system_notifications_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `task_notes`
--
ALTER TABLE `task_notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task_note_files`
--
ALTER TABLE `task_note_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `team_vulnerabilities`
--
ALTER TABLE `team_vulnerabilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `technologies`
--
ALTER TABLE `technologies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test_results`
--
ALTER TABLE `test_results`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `test_statuses`
--
ALTER TABLE `test_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `threat_catalogs`
--
ALTER TABLE `threat_catalogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `threat_groupings`
--
ALTER TABLE `threat_groupings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `user_out_side_cybers`
--
ALTER TABLE `user_out_side_cybers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_pass_histories`
--
ALTER TABLE `user_pass_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_pass_reuse_histories`
--
ALTER TABLE `user_pass_reuse_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `validation_files`
--
ALTER TABLE `validation_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vulnerabilities`
--
ALTER TABLE `vulnerabilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer_question_surveys`
--
ALTER TABLE `answer_question_surveys`
  ADD CONSTRAINT `answer_question_surveys_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `survey_questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `answer_question_surveys_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `awareness_surveys` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `answer_question_surveys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `answer_question_surveys_user_idout_foreign` FOREIGN KEY (`user_idOut`) REFERENCES `user_out_side_cybers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `answer_sub_questions`
--
ALTER TABLE `answer_sub_questions`
  ADD CONSTRAINT `answer_sub_questions_answer_id_foreign` FOREIGN KEY (`answer_id`) REFERENCES `assessment_answers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `answer_sub_questions_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `assessment_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `assessment_answers`
--
ALTER TABLE `assessment_answers`
  ADD CONSTRAINT `assessment_answers_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `assessment_answers_impact_id_foreign` FOREIGN KEY (`impact_id`) REFERENCES `impacts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `assessment_answers_likelihood_id_foreign` FOREIGN KEY (`likelihood_id`) REFERENCES `likelihoods` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `assessment_answers_maturity_control_id_foreign` FOREIGN KEY (`maturity_control_id`) REFERENCES `control_maturities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `assessment_answers_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `assessment_answers_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `assessment_answers_risk_scoring_method_id_foreign` FOREIGN KEY (`risk_scoring_method_id`) REFERENCES `scoring_methods` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `assessment_answers_sub_question_assessment_id_foreign` FOREIGN KEY (`sub_question_assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `assessment_answers_to_assets`
--
ALTER TABLE `assessment_answers_to_assets`
  ADD CONSTRAINT `assessment_answers_to_assets_assessment_answer_id_foreign` FOREIGN KEY (`assessment_answer_id`) REFERENCES `assessment_answers` (`id`),
  ADD CONSTRAINT `assessment_answers_to_assets_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `assessment_answers_to_asset_groups`
--
ALTER TABLE `assessment_answers_to_asset_groups`
  ADD CONSTRAINT `assessment_answers_to_asset_groups_assessment_answer_id_foreign` FOREIGN KEY (`assessment_answer_id`) REFERENCES `assessment_answers` (`id`),
  ADD CONSTRAINT `assessment_answers_to_asset_groups_asset_group_id_foreign` FOREIGN KEY (`asset_group_id`) REFERENCES `asset_groups` (`id`);

--
-- Constraints for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  ADD CONSTRAINT `assessment_questions_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `assessment_questions_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `assessment_scoring_contributing_impacts`
--
ALTER TABLE `assessment_scoring_contributing_impacts`
  ADD CONSTRAINT `A_S_C_I_A_S_id_foreign` FOREIGN KEY (`assessment_scoring_id`) REFERENCES `assessment_scorings` (`id`),
  ADD CONSTRAINT `A_S_C_I_C_R_id_foreign` FOREIGN KEY (`contributing_risk_id`) REFERENCES `contributing_risks` (`id`);

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_asset_value_id_foreign` FOREIGN KEY (`asset_value_id`) REFERENCES `asset_values` (`id`),
  ADD CONSTRAINT `assets_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`);

--
-- Constraints for table `asset_asset_groups`
--
ALTER TABLE `asset_asset_groups`
  ADD CONSTRAINT `asset_asset_groups_asset_group_id_foreign` FOREIGN KEY (`asset_group_id`) REFERENCES `asset_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_asset_groups_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `asset_vulnerabilities`
--
ALTER TABLE `asset_vulnerabilities`
  ADD CONSTRAINT `asset_vulnerabilities_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`),
  ADD CONSTRAINT `asset_vulnerabilities_vulnerability_id_foreign` FOREIGN KEY (`vulnerability_id`) REFERENCES `vulnerabilities` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `auto_notifies`
--
ALTER TABLE `auto_notifies`
  ADD CONSTRAINT `autoNotify_settings_foreign` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`);

--
-- Constraints for table `awareness_surveys`
--
ALTER TABLE `awareness_surveys`
  ADD CONSTRAINT `awareness_surveys_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `awareness_surveys_filter_status_foreign` FOREIGN KEY (`filter_status`) REFERENCES `document_statuses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `awareness_surveys_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `awareness_surveys_privacy_foreign` FOREIGN KEY (`privacy`) REFERENCES `privacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `change_requests`
--
ALTER TABLE `change_requests`
  ADD CONSTRAINT `change_requests_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `closures`
--
ALTER TABLE `closures`
  ADD CONSTRAINT `closures_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `closures_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contact_questionnaires`
--
ALTER TABLE `contact_questionnaires`
  ADD CONSTRAINT `contact_questionnaires_questionnaire_id_foreign` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaires` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contact_questionnaires_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contact_questionnaire_answers`
--
ALTER TABLE `contact_questionnaire_answers`
  ADD CONSTRAINT `contact_questionnaire_answers_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contact_questionnaire_answers_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contact_questionnaire_answers_questionnaire_id_foreign` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaires` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contact_questionnaire_answer_results`
--
ALTER TABLE `contact_questionnaire_answer_results`
  ADD CONSTRAINT `contact_q_answer_id` FOREIGN KEY (`contact_questionnaire_answer_id`) REFERENCES `contact_questionnaire_answers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contact_questionnaire_answer_results_answer_id_foreign` FOREIGN KEY (`answer_id`) REFERENCES `assessment_answers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contact_questionnaire_answer_results_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contributing_risks_impacts`
--
ALTER TABLE `contributing_risks_impacts`
  ADD CONSTRAINT `contributing_risks_impacts_contributing_risks_id_foreign` FOREIGN KEY (`contributing_risks_id`) REFERENCES `contributing_risks` (`id`);

--
-- Constraints for table `controls_control_objectives`
--
ALTER TABLE `controls_control_objectives`
  ADD CONSTRAINT `control_objectivess_foreign` FOREIGN KEY (`objective_id`) REFERENCES `control_objectives` (`id`),
  ADD CONSTRAINT `controls_control_objectives_responsible_id_foreign` FOREIGN KEY (`responsible_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `controls_control_objectives_responsible_team_id_foreign` FOREIGN KEY (`responsible_team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_controls_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`);

--
-- Constraints for table `control_audits_evidences`
--
ALTER TABLE `control_audits_evidences`
  ADD CONSTRAINT `control_audits_evidences_evidence_id_foreign` FOREIGN KEY (`evidence_id`) REFERENCES `evidences` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_control_test_audit_objective_id` FOREIGN KEY (`framework_control_test_audit_id`) REFERENCES `framework_control_test_audits` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `control_audits_objectives`
--
ALTER TABLE `control_audits_objectives`
  ADD CONSTRAINT `control_audits_objectives_control_control_objective_id_foreign` FOREIGN KEY (`control_control_objective_id`) REFERENCES `controls_control_objectives` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_control_test_audit_id` FOREIGN KEY (`framework_control_test_audit_id`) REFERENCES `framework_control_test_audits` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `control_audit_policies`
--
ALTER TABLE `control_audit_policies`
  ADD CONSTRAINT `control_audit_policies_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`),
  ADD CONSTRAINT `control_audit_policies_framework_control_test_audit_id_foreign` FOREIGN KEY (`framework_control_test_audit_id`) REFERENCES `framework_control_test_audits` (`id`);

--
-- Constraints for table `custom_risk_model_values`
--
ALTER TABLE `custom_risk_model_values`
  ADD CONSTRAINT `custom_risk_model_values_impact_id_foreign` FOREIGN KEY (`impact_id`) REFERENCES `impacts` (`id`),
  ADD CONSTRAINT `custom_risk_model_values_likelihood_id_foreign` FOREIGN KEY (`likelihood_id`) REFERENCES `likelihoods` (`id`);

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `department_colors` (`id`),
  ADD CONSTRAINT `departments_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `departments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `documents_document_owner_foreign` FOREIGN KEY (`document_owner`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `documents_document_reviewer_foreign` FOREIGN KEY (`document_reviewer`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `documents_document_type_foreign` FOREIGN KEY (`document_type`) REFERENCES `document_types` (`id`),
  ADD CONSTRAINT `documents_privacy_foreign` FOREIGN KEY (`privacy`) REFERENCES `privacies` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `document_notes`
--
ALTER TABLE `document_notes`
  ADD CONSTRAINT `document_notes_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `document_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `document_note_files`
--
ALTER TABLE `document_note_files`
  ADD CONSTRAINT `document_note_files_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `document_note_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `dynamic_saved_selections`
--
ALTER TABLE `dynamic_saved_selections`
  ADD CONSTRAINT `dynamic_saved_selections_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `evidences`
--
ALTER TABLE `evidences`
  ADD CONSTRAINT `controls_control_objectives_foreign` FOREIGN KEY (`control_control_objective_id`) REFERENCES `controls_control_objectives` (`id`),
  ADD CONSTRAINT `users_foreign` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `failed_login_attempts`
--
ALTER TABLE `failed_login_attempts`
  ADD CONSTRAINT `failed_login_attempts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `families`
--
ALTER TABLE `families`
  ADD CONSTRAINT `families_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `families` (`id`);

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `file_tasks`
--
ALTER TABLE `file_tasks`
  ADD CONSTRAINT `file_tasks_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `framework_controls`
--
ALTER TABLE `framework_controls`
  ADD CONSTRAINT `framework_controls_control_class_foreign` FOREIGN KEY (`control_class`) REFERENCES `control_classes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_maturity_foreign` FOREIGN KEY (`control_maturity`) REFERENCES `control_maturities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_owner_foreign` FOREIGN KEY (`control_owner`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_phase_foreign` FOREIGN KEY (`control_phase`) REFERENCES `control_phases` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_priority_foreign` FOREIGN KEY (`control_priority`) REFERENCES `control_priorities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_type_foreign` FOREIGN KEY (`control_type`) REFERENCES `control_types` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_desired_maturity_foreign` FOREIGN KEY (`desired_maturity`) REFERENCES `control_desired_maturities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_family_foreign` FOREIGN KEY (`family`) REFERENCES `families` (`id`),
  ADD CONSTRAINT `framework_controls_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `framework_controls` (`id`);

--
-- Constraints for table `framework_control_mappings`
--
ALTER TABLE `framework_control_mappings`
  ADD CONSTRAINT `framework_control_mappings_framework_control_id_foreign` FOREIGN KEY (`framework_control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `framework_control_mappings_framework_id_foreign` FOREIGN KEY (`framework_id`) REFERENCES `frameworks` (`id`);

--
-- Constraints for table `framework_control_tests`
--
ALTER TABLE `framework_control_tests`
  ADD CONSTRAINT `framework_control_tests_framework_control_id_foreign` FOREIGN KEY (`framework_control_id`) REFERENCES `framework_controls` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_control_tests_tester_foreign` FOREIGN KEY (`tester`) REFERENCES `users` (`id`);

--
-- Constraints for table `framework_control_test_audits`
--
ALTER TABLE `framework_control_test_audits`
  ADD CONSTRAINT `framework_control_test_audits_framework_control_id_foreign` FOREIGN KEY (`framework_control_id`) REFERENCES `framework_controls` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_control_test_audits_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `framework_control_tests` (`id`),
  ADD CONSTRAINT `framework_control_test_audits_tester_foreign` FOREIGN KEY (`tester`) REFERENCES `users` (`id`);

--
-- Constraints for table `framework_control_test_comments`
--
ALTER TABLE `framework_control_test_comments`
  ADD CONSTRAINT `framework_control_test_comments_test_audit_id_foreign` FOREIGN KEY (`test_audit_id`) REFERENCES `framework_control_test_audits` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_control_test_comments_user_foreign` FOREIGN KEY (`user`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `framework_control_test_results`
--
ALTER TABLE `framework_control_test_results`
  ADD CONSTRAINT `framework_control_test_results_test_audit_id_foreign` FOREIGN KEY (`test_audit_id`) REFERENCES `framework_control_test_audits` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_control_test_results_test_result_foreign` FOREIGN KEY (`test_result`) REFERENCES `test_results` (`id`);

--
-- Constraints for table `framework_control_test_results_to_risks`
--
ALTER TABLE `framework_control_test_results_to_risks`
  ADD CONSTRAINT `framework_control_test_results_to_risks_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`),
  ADD CONSTRAINT `framework_control_test_results_to_risks_test_results_id_foreign` FOREIGN KEY (`test_results_id`) REFERENCES `framework_control_test_results` (`id`);

--
-- Constraints for table `framework_control_to_frameworks`
--
ALTER TABLE `framework_control_to_frameworks`
  ADD CONSTRAINT `framework_control_to_frameworks_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `framework_control_to_frameworks_framework_id_foreign` FOREIGN KEY (`framework_id`) REFERENCES `frameworks` (`id`);

--
-- Constraints for table `framework_control_type_mappings`
--
ALTER TABLE `framework_control_type_mappings`
  ADD CONSTRAINT `framework_control_type_mappings_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `framework_control_type_mappings_control_type_id_foreign` FOREIGN KEY (`control_type_id`) REFERENCES `control_types` (`id`);

--
-- Constraints for table `framework_families`
--
ALTER TABLE `framework_families`
  ADD CONSTRAINT `framework_families_family_id_foreign` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`),
  ADD CONSTRAINT `framework_families_framework_id_foreign` FOREIGN KEY (`framework_id`) REFERENCES `frameworks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_families_parent_family_id_foreign` FOREIGN KEY (`parent_family_id`) REFERENCES `families` (`id`);

--
-- Constraints for table `items_to_teams`
--
ALTER TABLE `items_to_teams`
  ADD CONSTRAINT `items_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`);

--
-- Constraints for table `kpis`
--
ALTER TABLE `kpis`
  ADD CONSTRAINT `kpis_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `kpis_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `kpi_assessments`
--
ALTER TABLE `kpi_assessments`
  ADD CONSTRAINT `kpi_assessments_action_by_foreign` FOREIGN KEY (`action_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `kpi_assessments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `kpi_assessments_kpi_id_foreign` FOREIGN KEY (`kpi_id`) REFERENCES `kpis` (`id`);

--
-- Constraints for table `mail_auto_notfies`
--
ALTER TABLE `mail_auto_notfies`
  ADD CONSTRAINT `mail_auto_notify_foreign` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`);

--
-- Constraints for table `mail_settings`
--
ALTER TABLE `mail_settings`
  ADD CONSTRAINT `mail_settings_foreign` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`);

--
-- Constraints for table `mgmt_reviews`
--
ALTER TABLE `mgmt_reviews`
  ADD CONSTRAINT `mgmt_reviews_next_step_id_foreign` FOREIGN KEY (`next_step_id`) REFERENCES `next_steps` (`id`),
  ADD CONSTRAINT `mgmt_reviews_review_foreign` FOREIGN KEY (`review`) REFERENCES `reviews` (`id`),
  ADD CONSTRAINT `mgmt_reviews_reviewer_foreign` FOREIGN KEY (`reviewer`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `mgmt_reviews_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mitigations`
--
ALTER TABLE `mitigations`
  ADD CONSTRAINT `mitigations_mitigation_effort_foreign` FOREIGN KEY (`mitigation_effort`) REFERENCES `mitigation_efforts` (`id`),
  ADD CONSTRAINT `mitigations_mitigation_owner_foreign` FOREIGN KEY (`mitigation_owner`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `mitigations_planning_strategy_foreign` FOREIGN KEY (`planning_strategy`) REFERENCES `planning_strategies` (`id`),
  ADD CONSTRAINT `mitigations_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mitigation_accept_users`
--
ALTER TABLE `mitigation_accept_users`
  ADD CONSTRAINT `mitigation_accept_users_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mitigation_accept_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `mitigation_to_controls`
--
ALTER TABLE `mitigation_to_controls`
  ADD CONSTRAINT `mitigation_to_controls_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `mitigation_to_controls_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mitigation_to_teams`
--
ALTER TABLE `mitigation_to_teams`
  ADD CONSTRAINT `mitigation_to_teams_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mitigation_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`);

--
-- Constraints for table `notifiables`
--
ALTER TABLE `notifiables`
  ADD CONSTRAINT `notifiables_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `pending_risks`
--
ALTER TABLE `pending_risks`
  ADD CONSTRAINT `pending_risks_assessment_answer_id_foreign` FOREIGN KEY (`assessment_answer_id`) REFERENCES `assessment_answers` (`id`),
  ADD CONSTRAINT `pending_risks_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`);

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_subgroup_id_foreign` FOREIGN KEY (`subgroup_id`) REFERENCES `subgroups` (`id`);

--
-- Constraints for table `permission_to_permission_groups`
--
ALTER TABLE `permission_to_permission_groups`
  ADD CONSTRAINT `permission_to_permission_groups_permission_group_id_foreign` FOREIGN KEY (`permission_group_id`) REFERENCES `permission_groups` (`id`),
  ADD CONSTRAINT `permission_to_permission_groups_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`);

--
-- Constraints for table `permission_to_users`
--
ALTER TABLE `permission_to_users`
  ADD CONSTRAINT `permission_to_users_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `permission_to_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `questionnaires`
--
ALTER TABLE `questionnaires`
  ADD CONSTRAINT `questionnaires_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `questionnaire_questions`
--
ALTER TABLE `questionnaire_questions`
  ADD CONSTRAINT `questionnaire_questions_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `questionnaire_questions_questionnaire_id_foreign` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaires` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questionnaire_risks`
--
ALTER TABLE `questionnaire_risks`
  ADD CONSTRAINT `questionnaire_risks_answer_id_foreign` FOREIGN KEY (`answer_id`) REFERENCES `assessment_answers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questionnaire_risks_framework_controls_ids_foreign` FOREIGN KEY (`framework_controls_ids`) REFERENCES `framework_controls` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questionnaire_risks_impact_id_foreign` FOREIGN KEY (`impact_id`) REFERENCES `impacts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `questionnaire_risks_likelihood_id_foreign` FOREIGN KEY (`likelihood_id`) REFERENCES `likelihoods` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `questionnaire_risks_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `questionnaire_risks_questionnaire_id_foreign` FOREIGN KEY (`questionnaire_id`) REFERENCES `questionnaires` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questionnaire_risks_risk_scoring_method_id_foreign` FOREIGN KEY (`risk_scoring_method_id`) REFERENCES `scoring_methods` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `residual_risk_scoring_histories`
--
ALTER TABLE `residual_risk_scoring_histories`
  ADD CONSTRAINT `residual_risk_scoring_histories_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risks`
--
ALTER TABLE `risks`
  ADD CONSTRAINT `risks_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `risks_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `risks_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `risks_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`),
  ADD CONSTRAINT `risks_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `risks_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  ADD CONSTRAINT `risks_source_id_foreign` FOREIGN KEY (`source_id`) REFERENCES `sources` (`id`);

--
-- Constraints for table `risks_to_assets`
--
ALTER TABLE `risks_to_assets`
  ADD CONSTRAINT `risks_to_assets_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risks_to_assets_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risks_to_asset_groups`
--
ALTER TABLE `risks_to_asset_groups`
  ADD CONSTRAINT `risks_to_asset_groups_asset_group_id_foreign` FOREIGN KEY (`asset_group_id`) REFERENCES `asset_groups` (`id`),
  ADD CONSTRAINT `risks_to_asset_groups_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_catalogs`
--
ALTER TABLE `risk_catalogs`
  ADD CONSTRAINT `risk_catalogs_risk_function_id_foreign` FOREIGN KEY (`risk_function_id`) REFERENCES `risk_functions` (`id`),
  ADD CONSTRAINT `risk_catalogs_risk_grouping_id_foreign` FOREIGN KEY (`risk_grouping_id`) REFERENCES `risk_groupings` (`id`);

--
-- Constraints for table `risk_levels`
--
ALTER TABLE `risk_levels`
  ADD CONSTRAINT `risk_levels_review_level_id_foreign` FOREIGN KEY (`review_level_id`) REFERENCES `review_levels` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_scorings`
--
ALTER TABLE `risk_scorings`
  ADD CONSTRAINT `risk_scorings_id_foreign` FOREIGN KEY (`id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_scoring_contributing_impacts`
--
ALTER TABLE `risk_scoring_contributing_impacts`
  ADD CONSTRAINT `risk_scoring_contributing_impacts_contributing_risk_id_foreign` FOREIGN KEY (`contributing_risk_id`) REFERENCES `contributing_risks` (`id`),
  ADD CONSTRAINT `risk_scoring_contributing_impacts_risk_scoring_id_foreign` FOREIGN KEY (`risk_scoring_id`) REFERENCES `risk_scorings` (`id`);

--
-- Constraints for table `risk_scoring_histories`
--
ALTER TABLE `risk_scoring_histories`
  ADD CONSTRAINT `risk_scoring_histories_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_to_additional_stakeholders`
--
ALTER TABLE `risk_to_additional_stakeholders`
  ADD CONSTRAINT `risk_to_additional_stakeholders_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risk_to_additional_stakeholders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `risk_to_locations`
--
ALTER TABLE `risk_to_locations`
  ADD CONSTRAINT `risk_to_locations_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  ADD CONSTRAINT `risk_to_locations_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_to_teams`
--
ALTER TABLE `risk_to_teams`
  ADD CONSTRAINT `risk_to_teams_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risk_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`);

--
-- Constraints for table `risk_to_technologies`
--
ALTER TABLE `risk_to_technologies`
  ADD CONSTRAINT `risk_to_technologies_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risk_to_technologies_technology_id_foreign` FOREIGN KEY (`technology_id`) REFERENCES `technologies` (`id`);

--
-- Constraints for table `role_responsibilities`
--
ALTER TABLE `role_responsibilities`
  ADD CONSTRAINT `role_responsibilities_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `role_responsibilities_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `security_awarenesses`
--
ALTER TABLE `security_awarenesses`
  ADD CONSTRAINT `security_awarenesses_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `security_awarenesses_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`),
  ADD CONSTRAINT `security_awarenesses_owner_foreign` FOREIGN KEY (`owner`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `security_awarenesses_privacy_foreign` FOREIGN KEY (`privacy`) REFERENCES `privacies` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `security_awarenesses_reviewer_foreign` FOREIGN KEY (`reviewer`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `security_awareness_exams`
--
ALTER TABLE `security_awareness_exams`
  ADD CONSTRAINT `security_awareness_exams_security_awareness_id_foreign` FOREIGN KEY (`security_awareness_id`) REFERENCES `security_awarenesses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `security_awareness_exam_answers`
--
ALTER TABLE `security_awareness_exam_answers`
  ADD CONSTRAINT `security_awareness_exam_answers_examinee_foreign` FOREIGN KEY (`examinee`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `security_awareness_exam_answers_foreign` FOREIGN KEY (`security_awareness_exams_id`) REFERENCES `security_awareness_exams` (`id`);

--
-- Constraints for table `security_awareness_exam_questions`
--
ALTER TABLE `security_awareness_exam_questions`
  ADD CONSTRAINT `security_awareness_exam_options_foreign` FOREIGN KEY (`security_awareness_exams_id`) REFERENCES `security_awareness_exams` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `security_awareness_notes`
--
ALTER TABLE `security_awareness_notes`
  ADD CONSTRAINT `security_awareness_notes_security_awareness_id_foreign` FOREIGN KEY (`security_awareness_id`) REFERENCES `security_awarenesses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `security_awareness_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `security_awareness_note_files`
--
ALTER TABLE `security_awareness_note_files`
  ADD CONSTRAINT `security_awareness_note_files_security_awareness_id_foreign` FOREIGN KEY (`security_awareness_id`) REFERENCES `security_awarenesses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `security_awareness_note_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sms_settings`
--
ALTER TABLE `sms_settings`
  ADD CONSTRAINT `sms_settings_foreign` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`);

--
-- Constraints for table `subgroups`
--
ALTER TABLE `subgroups`
  ADD CONSTRAINT `subgroups_permission_group_id_foreign` FOREIGN KEY (`permission_group_id`) REFERENCES `permission_groups` (`id`);

--
-- Constraints for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD CONSTRAINT `survey_questions_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `awareness_surveys` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `system_notifications_settings`
--
ALTER TABLE `system_notifications_settings`
  ADD CONSTRAINT `system_notifications_settings_foreign` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`);

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_action_by_foreign` FOREIGN KEY (`action_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tasks_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `task_notes`
--
ALTER TABLE `task_notes`
  ADD CONSTRAINT `task_notes_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `task_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `task_note_files`
--
ALTER TABLE `task_note_files`
  ADD CONSTRAINT `task_note_files_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `task_note_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `team_vulnerabilities`
--
ALTER TABLE `team_vulnerabilities`
  ADD CONSTRAINT `team_vulnerabilities_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `team_vulnerabilities_vulnerability_id_foreign` FOREIGN KEY (`vulnerability_id`) REFERENCES `vulnerabilities` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `threat_catalogs`
--
ALTER TABLE `threat_catalogs`
  ADD CONSTRAINT `threat_catalogs_threat_grouping_id_foreign` FOREIGN KEY (`threat_grouping_id`) REFERENCES `threat_groupings` (`id`);

--
-- Constraints for table `translations`
--
ALTER TABLE `translations`
  ADD CONSTRAINT `translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `users_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  ADD CONSTRAINT `users_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD CONSTRAINT `user_notifications_notification_id_foreign` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `user_pass_histories`
--
ALTER TABLE `user_pass_histories`
  ADD CONSTRAINT `user_pass_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_pass_reuse_histories`
--
ALTER TABLE `user_pass_reuse_histories`
  ADD CONSTRAINT `user_pass_reuse_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_to_teams`
--
ALTER TABLE `user_to_teams`
  ADD CONSTRAINT `user_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `user_to_teams_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `validation_files`
--
ALTER TABLE `validation_files`
  ADD CONSTRAINT `validation_files_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`);

--
-- Constraints for table `vulnerabilities`
--
ALTER TABLE `vulnerabilities`
  ADD CONSTRAINT `vulnerabilities_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `vulnerabilities_update_status_user_foreign` FOREIGN KEY (`update_status_user`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
