-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2022 at 04:21 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grc3`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessments`
--

CREATE TABLE `assessments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_answers`
--

CREATE TABLE `assessment_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_id` bigint(20) UNSIGNED NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `submit_risk` tinyint(1) NOT NULL DEFAULT 0,
  `risk_subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `risk_score` double(8,2) NOT NULL,
  `assessment_scoring_id` bigint(20) UNSIGNED NOT NULL,
  `risk_owner` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 999999
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_answers_to_assets`
--

CREATE TABLE `assessment_answers_to_assets` (
  `assessment_answer_id` bigint(20) UNSIGNED NOT NULL,
  `asset_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_answers_to_asset_groups`
--

CREATE TABLE `assessment_answers_to_asset_groups` (
  `assessment_answer_id` bigint(20) UNSIGNED NOT NULL,
  `asset_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_questions`
--

CREATE TABLE `assessment_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT 999999
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_scorings`
--

CREATE TABLE `assessment_scorings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `scoring_method` int(11) NOT NULL,
  `calculated_risk` double(8,2) NOT NULL,
  `CLASSIC_likelihood` double(8,2) NOT NULL DEFAULT 5.00,
  `CLASSIC_impact` double(8,2) NOT NULL DEFAULT 5.00,
  `CVSS_AccessVector` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_AccessComplexity` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'L',
  `CVSS_Authentication` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_ConfImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_IntegImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_AvailImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_Exploitability` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_RemediationLevel` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ReportConfidence` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_CollateralDamagePotential` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_TargetDistribution` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ConfidentialityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_IntegrityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_AvailabilityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `DREAD_DamagePotential` int(11) NOT NULL DEFAULT 10,
  `DREAD_Reproducibility` int(11) NOT NULL DEFAULT 10,
  `DREAD_Exploitability` int(11) NOT NULL DEFAULT 10,
  `DREAD_AffectedUsers` int(11) NOT NULL DEFAULT 10,
  `DREAD_Discoverability` int(11) NOT NULL DEFAULT 10,
  `OWASP_SkillLevel` int(11) NOT NULL DEFAULT 10,
  `OWASP_Motive` int(11) NOT NULL DEFAULT 10,
  `OWASP_Opportunity` int(11) NOT NULL DEFAULT 10,
  `OWASP_Size` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfDiscovery` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfExploit` int(11) NOT NULL DEFAULT 10,
  `OWASP_Awareness` int(11) NOT NULL DEFAULT 10,
  `OWASP_IntrusionDetection` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfConfidentiality` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfIntegrity` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAvailability` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAccountability` int(11) NOT NULL DEFAULT 10,
  `OWASP_FinancialDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_ReputationDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_NonCompliance` int(11) NOT NULL DEFAULT 10,
  `OWASP_PrivacyViolation` int(11) NOT NULL DEFAULT 10,
  `Custom` double(8,2) NOT NULL DEFAULT 10.00,
  `Contributing_Likelihood` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_scoring_contributing_impacts`
--

CREATE TABLE `assessment_scoring_contributing_impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_scoring_id` bigint(20) UNSIGNED NOT NULL,
  `contributing_risk_id` bigint(20) UNSIGNED NOT NULL,
  `impact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_value_id` bigint(20) UNSIGNED NOT NULL,
  `location_id` bigint(20) UNSIGNED DEFAULT NULL,
  `teams` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified` tinyint(4) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `ip`, `name`, `asset_value_id`, `location_id`, `teams`, `details`, `created`, `verified`, `start_date`, `expiration_date`) VALUES
(1, '127.0.0.1', 'Asset1', 1, 1, '1,4', 'Details asset 1', '2019-07-01 06:32:43', 1, '2022-07-02', '2022-07-03'),
(2, '127.0.0.2', 'Asset2', 2, 2, '1,4', 'Details asset 2', '2019-07-01 06:32:43', 1, '2022-07-03', '2022-07-04'),
(3, '127.0.0.3', 'Asset3', 3, 3, '1,4', 'Details asset 3', '2019-07-01 06:32:43', 1, '2022-07-04', '2022-07-05'),
(4, '127.0.0.4', 'Asset4', 4, 4, '1,4', 'Details asset 4', '2019-07-01 06:32:43', 1, '2022-07-05', '2022-07-06'),
(5, '127.0.0.5', 'Asset5', 5, 5, '1,4', 'Details asset 5', '2019-07-01 06:32:43', 1, '2022-07-06', '2022-07-07'),
(6, '127.0.0.6', 'Asset6', 6, 6, '1,4', 'Details asset 6', '2019-07-01 06:32:43', 1, '2022-07-07', '2022-07-08'),
(7, '127.0.0.7', 'Asset7', 7, 7, '1,4', 'Details asset 7', '2019-07-01 06:32:43', 1, '2022-07-08', '2022-07-09'),
(8, '127.0.0.8', 'Asset8', 8, 8, '1,4', 'Details asset 8', '2019-07-01 06:32:43', 1, '2022-07-09', '2022-07-10'),
(9, '127.0.0.9', 'Asset9', 9, 9, '1,4', 'Details asset 9', '2019-07-01 06:32:43', 1, '2022-07-10', '2022-07-11'),
(10, '127.0.0.10', 'Asset10', 10, 10, '1,4', 'Details asset 10', '2019-07-01 06:32:43', 1, '2022-07-01', '2022-07-02'),
(11, '127.0.0.11', 'Asset11', 11, 11, '1,4', 'Details asset 11', '2019-07-01 06:32:43', 1, '2022-07-02', '2022-07-03'),
(12, '127.0.0.12', 'Asset12', 12, 12, '1,4', 'Details asset 12', '2019-07-01 06:32:43', 1, '2022-07-03', '2022-07-04'),
(13, '127.0.0.13', 'Asset13', 13, 13, '1,4', 'Details asset 13', '2019-07-01 06:32:43', 1, '2022-07-04', '2022-07-05'),
(14, '127.0.0.14', 'Asset14', 14, 14, '1,4', 'Details asset 14', '2019-07-01 06:32:43', 1, '2022-07-05', '2022-07-06'),
(15, '127.0.0.15', 'Asset15', 15, 15, '1,4', 'Details asset 15', '2019-07-01 06:32:43', 1, '2022-07-06', '2022-07-07'),
(16, '127.0.0.16', 'Asset16', 16, 16, '1,4', 'Details asset 16', '2019-07-01 06:32:43', 1, '2022-07-07', '2022-07-08'),
(17, '127.0.0.17', 'Asset17', 17, 17, '1,4', 'Details asset 17', '2019-07-01 06:32:43', 1, '2022-07-08', '2022-07-09'),
(18, '127.0.0.18', 'Asset18', 18, 18, '1,4', 'Details asset 18', '2019-07-01 06:32:43', 1, '2022-07-09', '2022-07-10'),
(19, '127.0.0.19', 'Asset19', 19, 19, '1,4', 'Details asset 19', '2019-07-01 06:32:43', 1, '2022-07-10', '2022-07-11'),
(20, '127.0.0.20', 'Asset20', 20, 20, '1,4', 'Details asset 20', '2019-07-01 06:32:43', 1, '2022-07-01', '2022-07-02');

-- --------------------------------------------------------

--
-- Table structure for table `asset_asset_groups`
--

CREATE TABLE `asset_asset_groups` (
  `asset_id` bigint(20) UNSIGNED NOT NULL,
  `asset_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_groups`
--

CREATE TABLE `asset_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_groups`
--

INSERT INTO `asset_groups` (`id`, `name`) VALUES
(1, 'Asset Group 1'),
(10, 'Asset Group 10'),
(11, 'Asset Group 11'),
(12, 'Asset Group 12'),
(13, 'Asset Group 13'),
(14, 'Asset Group 14'),
(15, 'Asset Group 15'),
(16, 'Asset Group 16'),
(17, 'Asset Group 17'),
(18, 'Asset Group 18'),
(19, 'Asset Group 19'),
(2, 'Asset Group 2'),
(20, 'Asset Group 20'),
(3, 'Asset Group 3'),
(4, 'Asset Group 4'),
(5, 'Asset Group 5'),
(6, 'Asset Group 6'),
(7, 'Asset Group 7'),
(8, 'Asset Group 8'),
(9, 'Asset Group 9');

-- --------------------------------------------------------

--
-- Table structure for table `asset_values`
--

CREATE TABLE `asset_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `min_value` int(11) NOT NULL,
  `max_value` int(11) DEFAULT NULL,
  `valuation_level_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_values`
--

INSERT INTO `asset_values` (`id`, `min_value`, `max_value`, `valuation_level_name`) VALUES
(1, 0, 100000, ''),
(2, 100001, 200000, ''),
(3, 200001, 300000, ''),
(4, 300001, 400000, ''),
(5, 400001, 500000, ''),
(6, 500001, 600000, ''),
(7, 600001, 700000, ''),
(8, 700001, 800000, ''),
(9, 800001, 900000, ''),
(10, 900001, 1000000, ''),
(11, 4194, 804957, 'natus'),
(12, 564, 512030, 'temporibus'),
(13, 1090, 497530, 'rerum'),
(14, 7602, 283248, 'perspiciatis'),
(15, 3722, 445830, 'illum'),
(16, 7931, 983778, 'rem'),
(17, 9053, 901141, 'sequi'),
(18, 8202, 861857, 'enim'),
(19, 5100, 382347, 'ut'),
(20, 5479, 225734, 'neque');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `risk_id` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'This is table name'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`timestamp`, `risk_id`, `user_id`, `message`, `log_type`) VALUES
('2022-08-14 12:00:07', 1, 1, 'A new risk ID \"1001\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:08', 2, 1, 'A new risk ID \"1002\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:09', 3, 1, 'A new risk ID \"1003\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:09', 4, 1, 'A new risk ID \"1004\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:10', 5, 1, 'A new risk ID \"1005\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:10', 6, 1, 'A new risk ID \"1006\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:10', 7, 1, 'A new risk ID \"1007\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:11', 8, 1, 'A new risk ID \"1008\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:12', 9, 1, 'A new risk ID \"1009\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:12', 10, 1, 'A new risk ID \"1010\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:12', 11, 1, 'A new risk ID \"1011\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:12', 12, 1, 'A new risk ID \"1012\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:13', 13, 1, 'A new risk ID \"1013\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:13', 14, 1, 'A new risk ID \"1014\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:13', 15, 1, 'A new risk ID \"1015\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:13', 16, 1, 'A new risk ID \"1016\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:13', 17, 1, 'A new risk ID \"1017\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:14', 18, 1, 'A new risk ID \"1018\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:14', 19, 1, 'A new risk ID \"1019\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:14', 20, 1, 'A new risk ID \"1020\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:14', 21, 1, 'A new risk ID \"1021\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:15', 22, 1, 'A new risk ID \"1022\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:15', 23, 1, 'A new risk ID \"1023\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:15', 24, 1, 'A new risk ID \"1024\" was submitted by username \"Admin\".', 'risk'),
('2022-08-14 12:00:15', 25, 1, 'A new risk ID \"1025\" was submitted by username \"Admin\".', 'risk');

-- --------------------------------------------------------

--
-- Table structure for table `backups`
--

CREATE TABLE `backups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `random_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `app_zip_file_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `db_zip_file_name` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Gestión de Acceso'),
(2, 'La Resistencia Ambiental'),
(3, 'Vigilancia'),
(4, 'Seguridad Física'),
(5, 'Politica y Procedimiento'),
(6, 'Gestión de datos sensibles'),
(7, 'Gestión de Tecnica de Vulnerabilidades'),
(8, 'Gestión de Terceros');

-- --------------------------------------------------------

--
-- Table structure for table `close_reasons`
--

CREATE TABLE `close_reasons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `close_reasons`
--

INSERT INTO `close_reasons` (`id`, `name`) VALUES
(1, 'Rejected'),
(2, 'Fully Mitigated'),
(3, 'System Retired'),
(4, 'Cancelled'),
(5, 'Too Insignificant');

-- --------------------------------------------------------

--
-- Table structure for table `closures`
--

CREATE TABLE `closures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `closure_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `close_reason` int(11) DEFAULT NULL,
  `note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `closures`
--

INSERT INTO `closures` (`id`, `risk_id`, `user_id`, `closure_date`, `close_reason`, `note`) VALUES
(1, 14, 1, '1978-02-16 18:11:37', 5, 'asd'),
(2, 5, 1, '1976-09-18 17:53:05', 2, 'asd'),
(3, 6, 1, '2022-06-16 01:07:53', 3, 'asd'),
(4, 12, 1, '2001-10-04 17:30:28', 3, 'asd'),
(5, 13, 1, '2014-05-23 18:16:12', 3, 'asd'),
(6, 10, 1, '1973-07-04 16:15:28', 3, 'asd'),
(7, 2, 1, '1982-06-07 22:29:25', 4, 'asd'),
(8, 16, 1, '1997-07-05 14:25:57', 2, 'asd'),
(9, 9, 1, '2012-10-24 12:24:41', 2, 'asd'),
(10, 20, 1, '2011-04-11 11:00:07', 5, 'asd'),
(11, 11, 1, '2005-02-07 06:36:24', 2, 'asd'),
(12, 7, 1, '2010-08-18 19:26:32', 4, 'asd'),
(13, 1, 1, '1993-08-31 08:20:36', 4, 'asd'),
(14, 19, 1, '1988-02-26 07:48:04', 3, 'asd'),
(15, 15, 1, '1984-01-07 03:41:06', 1, 'asd'),
(16, 8, 1, '1994-04-09 07:41:24', 1, 'asd'),
(17, 3, 1, '1973-11-12 12:46:28', 5, 'asd'),
(18, 4, 1, '2019-08-12 00:13:03', 3, 'asd'),
(19, 17, 1, '2006-04-23 06:14:00', 3, 'asd'),
(20, 18, 1, '1980-10-05 19:20:55', 5, 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `compliance_files`
--

CREATE TABLE `compliance_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ref_id` int(11) NOT NULL,
  `ref_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL,
  `content` longblob NOT NULL,
  `version` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contributing_risks`
--

CREATE TABLE `contributing_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contributing_risks`
--

INSERT INTO `contributing_risks` (`id`, `subject`, `weight`) VALUES
(1, 'Safety', 0.25),
(2, 'SLA', 0.25),
(3, 'Financial', 0.25),
(4, 'Reputation', 0.25);

-- --------------------------------------------------------

--
-- Table structure for table `contributing_risks_impacts`
--

CREATE TABLE `contributing_risks_impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contributing_risks_id` bigint(20) UNSIGNED NOT NULL,
  `value` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contributing_risks_impacts`
--

INSERT INTO `contributing_risks_impacts` (`id`, `contributing_risks_id`, `value`, `name`) VALUES
(1, 1, 1, 'Insignificante'),
(2, 2, 1, 'Insignificante'),
(3, 3, 1, 'Insignificante'),
(4, 4, 1, 'Insignificante'),
(5, 1, 2, 'Menor'),
(6, 2, 2, 'Menor'),
(7, 3, 2, 'Menor'),
(8, 4, 2, 'Menor'),
(9, 1, 3, 'Moderado'),
(10, 2, 3, 'Moderado'),
(11, 3, 3, 'Moderado'),
(12, 4, 3, 'Moderado'),
(13, 1, 4, 'Mayor'),
(14, 2, 4, 'Mayor'),
(15, 3, 4, 'Mayor'),
(16, 4, 4, 'Mayor'),
(17, 1, 5, 'Extremo/Catastrofico'),
(18, 2, 5, 'Extremo/Catastrofico'),
(19, 3, 5, 'Extremo/Catastrofico'),
(20, 4, 5, 'Extremo/Catastrofico');

-- --------------------------------------------------------

--
-- Table structure for table `contributing_risks_likelihoods`
--

CREATE TABLE `contributing_risks_likelihoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contributing_risks_likelihoods`
--

INSERT INTO `contributing_risks_likelihoods` (`id`, `value`, `name`) VALUES
(1, 1, 'Remota'),
(2, 2, 'Improbable'),
(3, 3, 'Creible'),
(4, 4, 'Probable'),
(5, 5, 'Casi Certero');

-- --------------------------------------------------------

--
-- Table structure for table `control_classes`
--

CREATE TABLE `control_classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_classes`
--

INSERT INTO `control_classes` (`id`, `name`) VALUES
(1, 'Technical'),
(2, 'Operational'),
(3, 'Management');

-- --------------------------------------------------------

--
-- Table structure for table `control_desired_maturities`
--

CREATE TABLE `control_desired_maturities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_desired_maturities`
--

INSERT INTO `control_desired_maturities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Not Performed', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(2, 'Performed', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(3, 'Documented', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(4, 'Managed', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(5, 'Reviewed', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(6, 'Optimizing', '2022-08-14 12:00:36', '2022-08-14 12:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `control_maturities`
--

CREATE TABLE `control_maturities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_maturities`
--

INSERT INTO `control_maturities` (`id`, `name`) VALUES
(1, 'Not Performed'),
(2, 'Performed'),
(3, 'Documented'),
(4, 'Managed'),
(5, 'Reviewed'),
(6, 'Optimizing');

-- --------------------------------------------------------

--
-- Table structure for table `control_owners`
--

CREATE TABLE `control_owners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_owners`
--

INSERT INTO `control_owners` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'in', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(2, 'rerum', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(3, 'dolorum', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(4, 'ex', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(5, 'aut', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(6, 'suscipit', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(7, 'deserunt', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(8, 'labore', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(9, 'placeat', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(10, 'similique', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(11, 'voluptatem', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(12, 'molestiae', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(13, 'esse', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(14, 'sunt', '2022-08-14 12:00:35', '2022-08-14 12:00:35'),
(15, 'ut', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(16, 'minus', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(17, 'ullam', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(18, 'quod', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(19, 'autem', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(20, 'illo', '2022-08-14 12:00:36', '2022-08-14 12:00:36'),
(21, 'vitae', '2022-08-14 12:00:36', '2022-08-14 12:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `control_phases`
--

CREATE TABLE `control_phases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_phases`
--

INSERT INTO `control_phases` (`id`, `name`) VALUES
(1, 'Physical'),
(2, 'Procedural'),
(3, 'Technical'),
(4, 'Legal and Regulatory or Compliance');

-- --------------------------------------------------------

--
-- Table structure for table `control_priorities`
--

CREATE TABLE `control_priorities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_priorities`
--

INSERT INTO `control_priorities` (`id`, `name`) VALUES
(1, 'P0'),
(2, 'P1'),
(3, 'P2'),
(4, 'P3');

-- --------------------------------------------------------

--
-- Table structure for table `control_types`
--

CREATE TABLE `control_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `control_types`
--

INSERT INTO `control_types` (`id`, `name`) VALUES
(1, 'Standalone'),
(2, 'Project'),
(3, 'Enterprise');

-- --------------------------------------------------------

--
-- Table structure for table `custom_risk_model_values`
--

CREATE TABLE `custom_risk_model_values` (
  `impact_id` bigint(20) UNSIGNED NOT NULL,
  `likelihood_id` bigint(20) UNSIGNED NOT NULL,
  `value` double(3,1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `custom_risk_model_values`
--

INSERT INTO `custom_risk_model_values` (`impact_id`, `likelihood_id`, `value`) VALUES
(1, 1, 0.4),
(1, 2, 0.8),
(1, 3, 1.2),
(1, 4, 1.6),
(1, 5, 2.0),
(2, 1, 0.8),
(2, 2, 1.6),
(2, 3, 2.4),
(2, 4, 3.2),
(2, 5, 4.0),
(3, 1, 1.2),
(3, 2, 2.4),
(3, 3, 3.6),
(3, 4, 4.8),
(3, 5, 6.0),
(4, 1, 1.6),
(4, 2, 3.2),
(4, 3, 4.8),
(4, 4, 6.4),
(4, 5, 8.0),
(5, 1, 2.0),
(5, 2, 4.0),
(5, 3, 6.0),
(5, 4, 8.0),
(5, 5, 10.0);

-- --------------------------------------------------------

--
-- Table structure for table `cvss_scorings`
--

CREATE TABLE `cvss_scorings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `metric_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abrv_metric_name` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric_value` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abrv_metric_value` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numeric_value` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cvss_scorings`
--

INSERT INTO `cvss_scorings` (`id`, `metric_name`, `abrv_metric_name`, `metric_value`, `abrv_metric_value`, `numeric_value`) VALUES
(1, 'AccessComplexity', 'AC', 'Alto', 'H', 0.35),
(2, 'AccessComplexity', 'AC', 'Medio', 'M', 0.61),
(3, 'AccessComplexity', 'AC', 'Bajo', 'L', 0.71),
(4, 'AccessVector', 'AV', 'Local', 'L', 0.40),
(5, 'AccessVector', 'AV', 'Red Adyacente', 'A', 0.65),
(6, 'AccessVector', 'AV', 'Red', 'N', 1.00),
(7, 'Authentication', 'Au', 'Ninguno', 'N', 0.70),
(8, 'Authentication', 'Au', 'Instancia', 'S', 0.56),
(9, 'Authentication', 'Au', 'Multiples Instancias', 'M', 0.45),
(10, 'AvailabilityRequirement', 'AR', 'No definido', 'ND', 1.00),
(11, 'AvailabilityRequirement', 'AR', 'Bajo', 'L', 0.50),
(12, 'AvailabilityRequirement', 'AR', 'Medio', 'M', 1.00),
(13, 'AvailabilityRequirement', 'AR', 'Alto', 'H', 1.51),
(14, 'AvailImpact', 'A', 'Ninguno', 'N', 0.00),
(15, 'AvailImpact', 'A', 'Parcial', 'P', 0.28),
(16, 'AvailImpact', 'A', 'Completado', 'C', 0.66),
(17, 'CollateralDamagePotential', 'CDP', 'No definido', 'ND', 0.00),
(18, 'CollateralDamagePotential', 'CDP', 'Ninguno', 'N', 0.00),
(19, 'CollateralDamagePotential', 'CDP', 'BAjo (Baja Perdida)', 'L', 0.10),
(20, 'CollateralDamagePotential', 'CDP', 'Medio-Bajo', 'LM', 0.30),
(21, 'CollateralDamagePotential', 'CDP', 'Medio-Alto', 'MH', 0.40),
(22, 'CollateralDamagePotential', 'CDP', 'Alto', 'H', 0.50),
(23, 'ConfidentialityRequirement', 'CR', 'No definido', 'ND', 1.00),
(24, 'ConfidentialityRequirement', 'CR', 'Bajo', 'L', 0.50),
(25, 'ConfidentialityRequirement', 'CR', 'Medio', 'M', 1.00),
(26, 'ConfidentialityRequirement', 'CR', 'Alto', 'H', 1.51),
(27, 'ConfImpact', 'C', 'Ninguno', 'N', 0.00),
(28, 'ConfImpact', 'C', 'Parcial', 'P', 0.28),
(29, 'ConfImpact', 'C', 'Completado', 'C', 0.66),
(30, 'Exploitability', 'E', 'No definido', 'ND', 1.00),
(31, 'Exploitability', 'E', 'No comporbadas Estas Funciones', 'U', 0.85),
(32, 'Exploitability', 'E', 'Prueba de Concepto', 'POC', 0.90),
(33, 'Exploitability', 'E', 'Explotar Funciones Existentes', 'F', 0.95),
(34, 'Exploitability', 'E', 'Extendido', 'H', 1.00),
(35, 'IntegImpact', 'I', 'Ninguno', 'N', 0.00),
(36, 'IntegImpact', 'I', 'Parcial', 'P', 0.28),
(37, 'IntegImpact', 'I', 'Completado', 'C', 0.66),
(38, 'IntegrityRequirement', 'IR', 'No definido', 'ND', 1.00),
(39, 'IntegrityRequirement', 'IR', 'Bajo', 'L', 0.50),
(40, 'IntegrityRequirement', 'IR', 'Medio', 'M', 1.00),
(41, 'IntegrityRequirement', 'IR', 'Alto', 'H', 1.51),
(42, 'RemediationLevel', 'RL', 'No definido', 'ND', 1.00),
(43, 'RemediationLevel', 'RL', 'Arreglo', 'OF', 0.87),
(44, 'RemediationLevel', 'RL', 'Arreglo Temporal', 'TF', 0.90),
(45, 'RemediationLevel', 'RL', 'Solucion', 'W', 0.95),
(46, 'RemediationLevel', 'RL', 'No disponible', 'U', 1.00),
(47, 'ReportConfidence', 'RC', 'No definido', 'ND', 1.00),
(48, 'ReportConfidence', 'RC', 'Sin Confirmar', 'UC', 0.90),
(49, 'ReportConfidence', 'RC', 'No corroborada', 'UR', 0.95),
(50, 'ReportConfidence', 'RC', 'Confirmada', 'C', 1.00),
(51, 'TargetDistribution', 'TD', 'No definido', 'ND', 1.00),
(52, 'TargetDistribution', 'TD', 'Ninguno (0%)', 'N', 0.00),
(53, 'TargetDistribution', 'TD', 'Bajo (0-25%)', 'L', 0.25),
(54, 'TargetDistribution', 'TD', 'Medio (26-75%)', 'M', 0.75),
(55, 'TargetDistribution', 'TD', 'Alto (76-100%)', 'H', 1.00);

-- --------------------------------------------------------

--
-- Table structure for table `data_classifications`
--

CREATE TABLE `data_classifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_classifications`
--

INSERT INTO `data_classifications` (`id`, `name`, `order`) VALUES
(1, 'Public', 1),
(2, 'Internal', 2),
(3, 'Confidential', 3),
(4, 'Restricted', 4);

-- --------------------------------------------------------

--
-- Table structure for table `date_formats`
--

CREATE TABLE `date_formats` (
  `value` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `date_formats`
--

INSERT INTO `date_formats` (`value`) VALUES
('DD MM YYYY'),
('DD-MM-YYYY'),
('DD.MM.YYYY'),
('DD/MM/YYYY'),
('MM DD YYYY'),
('MM-DD-YYYY'),
('MM.DD.YYYY'),
('MM/DD/YYYY'),
('YYYY DD MM'),
('YYYY MM DD'),
('YYYY-DD-MM'),
('YYYY-MM-DD'),
('YYYY.DD.MM'),
('YYYY.MM.DD'),
('YYYY/DD/MM'),
('YYYY/MM/DD');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_id` bigint(20) UNSIGNED DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `required_num_emplyees` int(11) DEFAULT NULL,
  `color_id` bigint(20) UNSIGNED NOT NULL,
  `vision` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `mission` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `objectives` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsibilities` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `code`, `manager_id`, `parent_id`, `required_num_emplyees`, `color_id`, `vision`, `message`, `mission`, `objectives`, `responsibilities`, `created_at`, `updated_at`) VALUES
(1, 'الرئيس التنفيذى', '#000001', 2, NULL, NULL, 1, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:32', '2022-08-14 11:59:35'),
(2, 'اﻹدارة العامة ﻷمن المعلومات', '#000002', 3, 1, NULL, 2, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:32', '2022-08-14 11:59:36'),
(3, 'نائب المدير العام', '#000003', 4, 2, NULL, 3, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:32', '2022-08-14 11:59:36'),
(4, 'المكتب اﻹدارى', '#000004', 5, 2, 6, 4, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:32', '2022-08-14 11:59:36'),
(5, 'الحوكمة والمخاطر والالتزام', '#000005', 6, 2, 21, 5, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:36'),
(6, 'المراقبة اﻷمنية والاستجابة والتحليل', '#000006', 7, 2, 43, 6, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:36'),
(7, 'إدارة الحلول اﻷمنية', '#000007', 8, 2, 11, 7, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:37'),
(8, 'المعمارية والتخطيط', '#000008', 9, 2, 8, 8, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:37'),
(9, 'الحوكمة', '#000009', 10, 5, NULL, 9, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:37'),
(10, 'المخاطر', '#000010', 11, 5, NULL, 10, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:37'),
(11, 'الالتزام', '#000011', 12, 5, NULL, 11, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:37'),
(12, 'المراقبة اﻷمنية', '#000012', 13, 6, NULL, 12, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:38'),
(13, 'التحليل الرقمى والاستجابة للحوادث', '#000013', 14, 6, NULL, 13, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:38'),
(14, 'المعلومات الاستخباراتية والتهديدات', '#000014', 15, 6, NULL, 14, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:38'),
(15, 'تحليل التهديدات والثغرات', '#000015', 16, 6, NULL, 15, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:38');
INSERT INTO `departments` (`id`, `name`, `code`, `manager_id`, `parent_id`, `required_num_emplyees`, `color_id`, `vision`, `message`, `mission`, `objectives`, `responsibilities`, `created_at`, `updated_at`) VALUES
(16, 'إدارة الضوابط التقنية اﻷمنية', '#000016', 17, 7, NULL, 16, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:38'),
(17, 'تطوير واختبار الحلول اﻷمنية', '#000017', 18, 7, NULL, 17, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:33', '2022-08-14 11:59:38'),
(18, 'إدارة الهويات والصلاحيات', '#000018', 19, 7, NULL, 18, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:34', '2022-08-14 11:59:39'),
(19, 'التخطيط والتطوير', '#000019', 20, 8, NULL, 19, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:34', '2022-08-14 11:59:39'),
(20, 'المعمارية اﻷمنية', '#000020', 21, 8, NULL, 20, '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رؤية\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"رسالة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مهمة\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"أهداف\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '{\"ops\":[{\"attributes\":{\"color\":\"#5e5873\",\"bold\":true},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"},{\"attributes\":{\"color\":\"#5e5873\"},\"insert\":\"مسئوليات\"},{\"attributes\":{\"list\":\"bullet\"},\"insert\":\"\\n\"}]}', '2022-08-14 11:59:34', '2022-08-14 11:59:39');

-- --------------------------------------------------------

--
-- Table structure for table `department_colors`
--

CREATE TABLE `department_colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `department_colors`
--

INSERT INTO `department_colors` (`id`, `name`, `value`) VALUES
(1, 'الرئيس التنفيذى', '#557B83'),
(2, 'اﻹدارة العامة ﻷمن المعلومات', '#39AEA9'),
(3, 'نائب المدير العام', '#A2D5AB'),
(4, 'المكتب اﻹدارى', '#E5EFC1'),
(5, 'الحوكمة والمخاطر والالتزام', '#46244C'),
(6, 'المراقبة اﻷمنية والاستجابة والتحليل', '#C74B50'),
(7, 'إدارة الحلول اﻷمنية', '#D49B54'),
(8, 'المعمارية والتخطيط', '#712B75'),
(9, 'الحوكمة', '#332FD0'),
(10, 'المخاطر', '#F0A500'),
(11, 'الالتزام', '#874356'),
(12, 'المراقبة اﻷمنية', '#019267'),
(13, 'التحليل الرقمى والاستجابة للحوادث', '#9ADCFF'),
(14, 'المعلومات الاستخباراتية والتهديدات', '#008E89'),
(15, 'تحليل التهديدات والثغرات', '#313552'),
(16, 'إدارة الضوابط التقنية اﻷمنية', '#FF5959'),
(17, 'تطوير واختبار الحلول اﻷمنية', '#161853'),
(18, 'إدارة الهويات والصلاحيات', '#544179'),
(19, 'التخطيط والتطوير', '#125C13'),
(20, 'المعمارية اﻷمنية', '#557B83');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `document_type` bigint(20) UNSIGNED DEFAULT NULL,
  `privacy` bigint(20) UNSIGNED DEFAULT NULL,
  `document_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `document_status` int(11) NOT NULL DEFAULT 1,
  `file_id` int(11) NOT NULL,
  `creation_date` date DEFAULT NULL,
  `last_review_date` date DEFAULT NULL,
  `review_frequency` int(11) DEFAULT NULL,
  `next_review_date` date DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `control_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `framework_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_owner` int(11) DEFAULT NULL,
  `document_reviewer` bigint(20) UNSIGNED DEFAULT NULL,
  `additional_stakeholders` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `team_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `document_type`, `privacy`, `document_name`, `parent`, `document_status`, `file_id`, `creation_date`, `last_review_date`, `review_frequency`, `next_review_date`, `approval_date`, `control_ids`, `framework_ids`, `document_owner`, `document_reviewer`, `additional_stakeholders`, `approver`, `team_ids`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'doc1', NULL, 2, 1, '2022-08-14', '2022-08-03', 4, '2022-08-07', NULL, 'Control8', 'Mr. Lavern Ferry', NULL, 29, '1', NULL, '2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `document_exceptions`
--

CREATE TABLE `document_exceptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_document_id` int(11) DEFAULT NULL,
  `control_framework_id` int(11) DEFAULT NULL,
  `owner` int(11) DEFAULT NULL,
  `additional_stakeholders` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_date` date NOT NULL DEFAULT '0000-00-00',
  `review_frequency` int(11) NOT NULL DEFAULT 0,
  `next_review_date` date NOT NULL DEFAULT '0000-00-00',
  `approval_date` date NOT NULL DEFAULT '0000-00-00',
  `approver` int(11) DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `justification` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `associated_risks` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_exceptions_statuses`
--

CREATE TABLE `document_exceptions_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `document_exceptions_statuses`
--

INSERT INTO `document_exceptions_statuses` (`id`, `name`) VALUES
(1, 'Open'),
(2, 'Closed');

-- --------------------------------------------------------

--
-- Table structure for table `document_notes`
--

CREATE TABLE `document_notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `document_id` bigint(20) UNSIGNED NOT NULL,
  `note` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `document_notes`
--

INSERT INTO `document_notes` (`id`, `user_id`, `document_id`, `note`, `created_at`) VALUES
(11, 1, 1, 'ss', '2022-08-18 10:08:23'),
(12, 1, 1, 'hjj', '2022-08-18 10:10:04'),
(13, 1, 1, 'dvd', '2022-08-18 10:10:39'),
(14, 1, 1, 'ddd', '2022-08-18 10:13:27'),
(15, 1, 1, 'f', '2022-08-18 10:13:56'),
(16, 1, 1, 'ff', '2022-08-18 10:14:41'),
(17, 1, 1, 'd', '2022-08-18 10:15:44'),
(18, 1, 1, 'd', '2022-08-18 10:17:19'),
(19, 1, 1, 'x', '2022-08-18 10:24:42');

-- --------------------------------------------------------

--
-- Table structure for table `document_note_files`
--

CREATE TABLE `document_note_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `document_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `document_note_files`
--

INSERT INTO `document_note_files` (`id`, `user_id`, `document_id`, `display_name`, `unique_name`, `created_at`) VALUES
(1, 1, 1, 'ozone (4).zip', 'document/1/notes/DD1KVKV54Q0ujpLLSWcAO5TQrsMyXpKdIekpWSfP.zip', '2022-08-18 10:18:55'),
(2, 1, 1, 'statisics_stat.txt', 'document/1/notes/S4B6WCgTFgw2xeZJoiM7GfJiLNKxyCub9CjEtzVq.txt', '2022-08-18 10:25:20'),
(3, 1, 1, 'ozone (1).zip', 'document/1/notes/JFI8AUkwh2gsbxrbSSq08burl8CIS3Ay492wsgxf.zip', '2022-08-18 10:38:55'),
(4, 1, 1, 'ozone updated.zip', 'document/1/notes/LQuJsq43b2k0slv4E3TZ0EpXVfXaqSBpIMDyK60R.zip', '2022-08-18 10:41:00');

-- --------------------------------------------------------

--
-- Table structure for table `document_statuses`
--

CREATE TABLE `document_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `document_statuses`
--

INSERT INTO `document_statuses` (`id`, `name`) VALUES
(1, 'Draft'),
(2, 'In Review'),
(3, 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `document_types`
--

CREATE TABLE `document_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `document_types`
--

INSERT INTO `document_types` (`id`, `name`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'cat1', 'fas fa-ban', '2022-08-14 12:29:20', '2022-08-14 12:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `dynamic_saved_selections`
--

CREATE TABLE `dynamic_saved_selections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('private','public') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_display_settings` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_selection_settings` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_column_filters` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_login_attempts`
--

CREATE TABLE `failed_login_attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `expired` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `families`
--

CREATE TABLE `families` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `families`
--

INSERT INTO `families` (`id`, `name`) VALUES
(1, 'Eladio Buckridge'),
(2, 'Mr. Ephraim Kautzer DDS'),
(3, 'Kiera Wintheiser'),
(4, 'Nella Leuschke'),
(5, 'Mae Balistreri'),
(6, 'Otilia McDermott'),
(7, 'Arely Stokes'),
(8, 'Dr. Stone Heaney II'),
(9, 'Cleora Nienow'),
(10, 'Mrs. Stephany Rowe I'),
(11, 'Glen Goodwin'),
(12, 'Velma Padberg'),
(13, 'Petra Pfeffer'),
(14, 'Dallin Nienow'),
(15, 'Ms. Annetta Skiles'),
(16, 'Brain Pacocha'),
(17, 'Cole Powlowski PhD'),
(18, 'Della McDermott'),
(19, 'Khalid White'),
(20, 'Ms. Vickie Littel');

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED DEFAULT NULL,
  `view_type` int(11) NOT NULL DEFAULT 1,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `risk_id`, `view_type`, `name`, `unique_name`, `type`, `size`, `timestamp`, `user`) VALUES
(1, NULL, 1, 'app (2) (1).zip', '73f04720-1bc4-11ed-bb21-2702b7e13a1d', NULL, 0, '2022-08-14 11:30:09', 0);

-- --------------------------------------------------------

--
-- Table structure for table `file_tasks`
--

CREATE TABLE `file_tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `file_tasks`
--

INSERT INTO `file_tasks` (`id`, `task_id`, `display_name`, `unique_name`) VALUES
(1, 1, 'image1.png', 'task/1/aPyqSQJoKkGGBrghLXA7lV25wW8DOiGE9WPN1ude.png'),
(2, 1, 'image2.png', 'task/1/LD9pe8s3hnVfV3zKjLU5J3GItQaY9LNecEOc7dei.png');

-- --------------------------------------------------------

--
-- Table structure for table `file_types`
--

CREATE TABLE `file_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `file_types`
--

INSERT INTO `file_types` (`id`, `name`) VALUES
(21, 'application/csv'),
(18, 'application/force-download'),
(16, 'application/msword'),
(11, 'application/octet-stream'),
(19, 'application/pdf'),
(15, 'application/vnd.ms-excel'),
(8, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
(7, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(17, 'application/x-gzip'),
(6, 'application/x-pdf'),
(9, 'application/zip'),
(1, 'image/gif'),
(5, 'image/jpeg'),
(2, 'image/jpg'),
(3, 'image/png'),
(4, 'image/x-png'),
(14, 'text/comma-separated-values'),
(20, 'text/csv'),
(12, 'text/plain'),
(10, 'text/rtf'),
(13, 'text/xml');

-- --------------------------------------------------------

--
-- Table structure for table `file_type_extensions`
--

CREATE TABLE `file_type_extensions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `file_type_extensions`
--

INSERT INTO `file_type_extensions` (`id`, `name`) VALUES
(12, 'csv'),
(14, 'doc'),
(16, 'dot'),
(6, 'dotx'),
(1, 'gif'),
(15, 'gz'),
(4, 'jpeg'),
(2, 'jpg'),
(5, 'pdf'),
(3, 'png'),
(9, 'rtf'),
(10, 'txt'),
(18, 'xla'),
(13, 'xls'),
(7, 'xlsx'),
(17, 'xlt'),
(11, 'xml'),
(8, 'zip');

-- --------------------------------------------------------

--
-- Table structure for table `frameworks`
--

CREATE TABLE `frameworks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `order` int(11) DEFAULT NULL,
  `last_audit_date` date DEFAULT NULL,
  `next_audit_date` date DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frameworks`
--

INSERT INTO `frameworks` (`id`, `parent`, `name`, `description`, `icon`, `status`, `order`, `last_audit_date`, `next_audit_date`, `desired_frequency`, `created_at`, `updated_at`) VALUES
(1, 0, 'Wilmer Nitzsche', 'Impedit rerum similique dolore mollitia in provident itaque.', NULL, 1, 1, '2002-07-21', '1988-02-18', 0, NULL, NULL),
(2, 0, 'Mr. Lavern Ferry', 'Sapiente iure cupiditate ut.', NULL, 1, 1, '1979-11-17', '2001-02-08', 0, NULL, NULL),
(3, 0, 'Douglas Parker MD', 'Repellat adipisci officia hic temporibus.', NULL, 1, 1, '1971-02-24', '2014-12-28', 0, NULL, NULL),
(4, 0, 'Alf Gibson', 'Nisi repudiandae quos quasi.', NULL, 1, 1, '1997-05-14', '2009-04-14', 0, NULL, NULL),
(5, 0, 'Deven McClure', 'Molestiae modi pariatur ut ducimus sed molestias inventore et.', NULL, 1, 1, '2008-12-08', '2002-03-25', 0, NULL, NULL),
(6, 0, 'Augustus Harber', 'Quisquam est voluptatem nesciunt qui et velit.', NULL, 1, 1, '2009-03-10', '2007-09-21', 0, NULL, NULL),
(7, 0, 'Roxanne Gorczany', 'Fugiat eaque sit qui qui ad odio.', NULL, 1, 1, '1975-12-04', '2014-07-10', 0, NULL, NULL),
(8, 0, 'Monroe Wunsch', 'Dolorum veniam ut incidunt eius optio qui.', NULL, 1, 1, '1973-04-23', '1975-06-01', 0, NULL, NULL),
(9, 0, 'Merle Farrell', 'Sunt consequatur ut aliquam facilis totam esse voluptatem.', NULL, 1, 1, '1998-12-05', '2007-02-17', 0, NULL, NULL),
(10, 0, 'Ms. Nikki Johns MD', 'Facere placeat sit non laudantium.', NULL, 1, 1, '1986-05-18', '2018-08-17', 0, NULL, NULL),
(11, 0, 'Aliyah Cole', 'Earum perferendis voluptas amet sed voluptates rerum.', NULL, 1, 1, '1999-06-15', '1983-08-15', 0, NULL, NULL),
(12, 0, 'Yasmine Wisoky', 'Nulla corporis est quod velit.', NULL, 1, 1, '2008-10-05', '2000-08-26', 0, NULL, NULL),
(13, 0, 'Liana Maggio MD', 'Porro autem voluptatem enim eligendi.', NULL, 1, 1, '1987-09-19', '2021-11-29', 0, NULL, NULL),
(14, 0, 'Juanita Boyer Jr.', 'Neque et nobis error quaerat perspiciatis quia.', NULL, 1, 1, '2013-05-22', '2014-10-19', 0, NULL, NULL),
(15, 0, 'Leonel Kertzmann', 'Iusto et harum deleniti saepe laboriosam ab.', NULL, 1, 1, '2003-06-22', '1977-10-24', 0, NULL, NULL),
(16, 0, 'Constantin Goldner', 'Optio quo libero hic dolores vitae dignissimos.', NULL, 1, 1, '1977-06-18', '2013-11-25', 0, NULL, NULL),
(17, 0, 'Dr. Jeramie Nikolaus IV', 'Nam ratione deserunt quam non voluptatibus voluptates eum.', NULL, 1, 1, '2013-06-29', '1978-07-20', 0, NULL, NULL),
(18, 0, 'Darlene Senger', 'Nihil occaecati odit commodi nulla ratione aut alias.', NULL, 1, 1, '1993-03-26', '2010-06-04', 0, NULL, NULL),
(19, 0, 'Mrs. Shanel Larson', 'Dolores sed explicabo et qui.', NULL, 1, 1, '1985-12-15', '1977-08-06', 0, NULL, NULL),
(20, 0, 'Jameson Daniel', 'Soluta quam neque velit ut nulla iusto aut.', NULL, 1, 1, '2022-01-23', '1987-06-22', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `framework_controls`
--

CREATE TABLE `framework_controls` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `short_name` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `long_name` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplemental_guidance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `control_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `control_status` tinyint(1) DEFAULT 1,
  `family` bigint(20) UNSIGNED DEFAULT NULL,
  `control_owner` bigint(20) UNSIGNED DEFAULT NULL,
  `desired_maturity` bigint(20) UNSIGNED DEFAULT NULL,
  `control_priority` bigint(20) UNSIGNED DEFAULT NULL,
  `control_class` bigint(20) UNSIGNED DEFAULT NULL,
  `control_maturity` bigint(20) UNSIGNED DEFAULT 1,
  `control_phase` bigint(20) UNSIGNED DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_audit_date` date DEFAULT NULL,
  `next_audit_date` date DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `mitigation_percent` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `deleted` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_controls`
--

INSERT INTO `framework_controls` (`id`, `short_name`, `long_name`, `description`, `supplemental_guidance`, `control_number`, `control_status`, `family`, `control_owner`, `desired_maturity`, `control_priority`, `control_class`, `control_maturity`, `control_phase`, `submission_date`, `last_audit_date`, `next_audit_date`, `desired_frequency`, `mitigation_percent`, `status`, `deleted`, `created_at`, `updated_at`) VALUES
(1, 'Control1', 'long name Control1', 'Fuga nisi quas qui.', 'Magnam quia distinctio ut hic et dolor in.', '1', 1, 7, 14, 1, NULL, 1, 3, 3, '2013-06-12 09:31:06', '1978-11-05', '1978-07-06', 9, 6, 1, 0, NULL, NULL),
(2, 'Control2', 'long name Control2', 'Voluptatum sint dolorem quia.', 'Ea id est aspernatur eaque est ut.', '2', 1, 7, 15, 1, NULL, 2, 3, 3, '1977-05-26 02:37:16', '1984-12-06', '2010-03-02', 2, 7, 5, 0, NULL, NULL),
(3, 'Control3', 'long name Control3', 'Aut tenetur veritatis sit sed porro.', 'Perspiciatis error dolor exercitationem occaecati eius iste corrupti.', '3', 1, 7, 7, 3, NULL, 1, 4, 4, '1979-07-15 10:55:37', '1989-11-06', '1993-02-11', 0, 6, 1, 0, NULL, NULL),
(4, 'Control4', 'long name Control4', 'Vel aut dolor fuga perspiciatis itaque animi.', 'Reiciendis ut impedit quidem.', '4', 1, 7, 7, 5, NULL, 2, 3, 4, '1974-11-06 19:05:14', '1977-04-08', '2013-12-28', 4, 1, 6, 0, NULL, NULL),
(5, 'Control5', 'long name Control5', 'Minus officiis fugiat qui dolor adipisci illo non.', 'Quas reiciendis enim consequuntur laboriosam tempora dicta ratione.', '5', 1, 19, 4, 2, NULL, 3, 6, 2, '1996-01-06 02:10:57', '1984-04-04', '2013-12-03', 5, 2, 5, 0, NULL, NULL),
(6, 'Control6', 'long name Control6', 'Incidunt animi fugit qui ab itaque commodi.', 'Aspernatur perferendis voluptates commodi est.', '6', 1, 18, 20, 5, NULL, 3, 2, 4, '1985-11-13 05:03:50', '1976-01-29', '1990-01-15', 7, 6, 6, 0, NULL, NULL),
(7, 'Control7', 'long name Control7', 'Aut aperiam occaecati enim inventore id.', 'Dolor illum ea tempora eligendi ratione consequatur.', '7', 1, 13, 5, 6, NULL, 2, 4, 1, '1995-08-05 01:06:26', '2022-02-13', '2021-06-27', 5, 0, 2, 0, NULL, NULL),
(8, 'Control8', 'long name Control8', 'Corrupti autem dolor quis dolorum exercitationem.', 'Praesentium quas soluta expedita aut non.', '8', 1, 13, 9, 4, NULL, 2, 4, 3, '2018-01-05 02:34:31', '2012-08-13', '1989-03-13', 8, 6, 3, 0, NULL, NULL),
(9, 'Control9', 'long name Control9', 'Adipisci qui vel tempore id.', 'Veniam repellat omnis voluptatem repellendus nulla omnis incidunt.', '9', 1, 2, 7, 6, NULL, 1, 4, 3, '2005-06-05 13:16:41', '2014-07-01', '2012-01-24', 5, 3, 7, 0, NULL, NULL),
(10, 'Control10', 'long name Control10', 'Velit ipsum aliquid distinctio quod omnis quaerat.', 'Molestiae quasi blanditiis minus doloribus.', '10', 1, 16, 15, 6, NULL, 2, 5, 2, '2001-12-20 03:12:41', '1983-12-02', '2015-05-30', 8, 7, 5, 0, NULL, NULL),
(11, 'Control11', 'long name Control11', 'Suscipit nemo quisquam ipsam error ab.', 'A et qui unde inventore qui.', '11', 1, 11, 10, 1, NULL, 3, 1, 3, '2009-09-17 06:53:46', '2004-08-15', '1972-06-24', 9, 1, 9, 0, NULL, NULL),
(12, 'Control12', 'long name Control12', 'Similique velit beatae aut ut qui est rerum.', 'Minima perspiciatis explicabo ipsum quae inventore.', '12', 1, 7, 15, 5, NULL, 3, 2, 1, '2002-01-10 22:04:57', '1987-04-16', '1974-11-16', 3, 8, 3, 0, NULL, NULL),
(13, 'Control13', 'long name Control13', 'Quisquam facilis eveniet ducimus incidunt ipsam.', 'Voluptas quam autem molestias qui delectus consequuntur illo.', '13', 1, 6, 1, 6, NULL, 1, 4, 2, '1979-09-19 11:44:26', '2019-11-02', '1971-02-20', 5, 5, 8, 0, NULL, NULL),
(14, 'Control14', 'long name Control14', 'Similique omnis id tempora qui nemo omnis quas aliquam.', 'Itaque aperiam vel consequuntur blanditiis sapiente itaque.', '14', 1, 12, 9, 3, NULL, 2, 5, 2, '2013-06-27 09:34:33', '2002-06-05', '2021-07-03', 6, 3, 6, 0, NULL, NULL),
(15, 'Control15', 'long name Control15', 'Tempora harum iure inventore eveniet iusto.', 'Delectus deleniti in et hic nesciunt architecto.', '15', 1, 8, 4, 3, NULL, 1, 2, 2, '1996-06-10 21:33:13', '2019-02-20', '1985-10-08', 4, 8, 6, 0, NULL, NULL),
(16, 'Control16', 'long name Control16', 'Reprehenderit ut velit expedita recusandae eum voluptatibus.', 'Voluptatem qui similique qui.', '16', 1, 19, 12, 3, NULL, 3, 4, 3, '1975-12-13 09:30:36', '2008-03-27', '2002-09-25', 7, 6, 4, 0, NULL, NULL),
(17, 'Control17', 'long name Control17', 'Molestiae deserunt libero incidunt maiores velit at.', 'Aut libero et velit cum.', '17', 1, 17, 10, 2, NULL, 1, 6, 3, '1980-02-23 00:54:49', '2011-07-08', '2014-10-04', 6, 0, 6, 0, NULL, NULL),
(18, 'Control18', 'long name Control18', 'Voluptate rerum doloribus optio minus vero.', 'Enim nam molestias eos beatae.', '18', 1, 13, 9, 6, NULL, 3, 1, 4, '1983-02-14 14:32:59', '1996-01-26', '2009-10-18', 0, 5, 1, 0, NULL, NULL),
(19, 'Control19', 'long name Control19', 'Qui cum perspiciatis rem exercitationem id aut.', 'Nulla quam commodi impedit rerum rerum.', '19', 1, 18, 20, 1, NULL, 3, 2, 2, '2017-08-02 23:39:21', '2018-05-31', '1999-06-21', 7, 1, 7, 0, NULL, NULL),
(20, 'Control20', 'long name Control20', 'Iure cum eum ea.', 'At tempore nemo totam et.', '20', 1, 1, 20, 6, NULL, 1, 3, 2, '1990-05-27 19:21:24', '2007-12-08', '2005-08-08', 3, 0, 6, 0, NULL, NULL),
(21, 'Control21', 'long name Control21', 'Repellendus odit quas reiciendis eos fuga sit.', 'Recusandae voluptatem eaque voluptatibus quam fuga corrupti ad tempore.', '21', 1, 16, 5, 1, NULL, 3, 3, 3, '2006-07-31 09:40:55', '1997-10-10', '1976-06-28', 1, 0, 4, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_mappings`
--

CREATE TABLE `framework_control_mappings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `framework_control_id` bigint(20) UNSIGNED NOT NULL,
  `framework_id` bigint(20) UNSIGNED NOT NULL,
  `reference_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `framework_control_mappings`
--

INSERT INTO `framework_control_mappings` (`id`, `framework_control_id`, `framework_id`, `reference_name`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'dolorem', NULL, NULL),
(2, 2, 2, 'harum', NULL, NULL),
(3, 3, 3, 'autem', NULL, NULL),
(4, 4, 1, 'libero', NULL, NULL),
(5, 5, 2, 'autem', NULL, NULL),
(6, 6, 3, 'dolorum', NULL, NULL),
(7, 7, 1, 'temporibus', NULL, NULL),
(8, 8, 2, 'id', NULL, NULL),
(9, 9, 3, 'ipsam', NULL, NULL),
(10, 10, 1, 'qui', NULL, NULL),
(11, 11, 2, 'eius', NULL, NULL),
(12, 12, 3, 'repellendus', NULL, NULL),
(13, 13, 1, 'dolores', NULL, NULL),
(14, 14, 2, 'voluptatem', NULL, NULL),
(15, 15, 3, 'dolore', NULL, NULL),
(16, 16, 1, 'quae', NULL, NULL),
(17, 17, 2, 'sit', NULL, NULL),
(18, 18, 3, 'ut', NULL, NULL),
(19, 19, 1, 'quo', NULL, NULL),
(20, 20, 2, 'et', NULL, NULL),
(21, 21, 3, 'fugiat', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_tests`
--

CREATE TABLE `framework_control_tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tester` int(11) DEFAULT NULL,
  `test_frequency` int(11) DEFAULT 0,
  `last_date` date DEFAULT NULL,
  `next_date` date DEFAULT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `objective` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_steps` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approximate_time` int(11) DEFAULT NULL,
  `expected_results` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `framework_control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `additional_stakeholders` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_audits`
--

CREATE TABLE `framework_control_test_audits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_id` bigint(20) UNSIGNED NOT NULL,
  `tester` int(11) DEFAULT NULL,
  `test_frequency` int(11) DEFAULT 0,
  `last_date` date DEFAULT NULL,
  `next_date` date DEFAULT NULL,
  `name` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `objective` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_steps` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approximate_time` int(11) DEFAULT NULL,
  `expected_results` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `framework_control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `desired_frequency` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_comments`
--

CREATE TABLE `framework_control_test_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_audit_id` bigint(20) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_results`
--

CREATE TABLE `framework_control_test_results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_audit_id` bigint(20) UNSIGNED NOT NULL,
  `test_result` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_date` date NOT NULL,
  `submitted_by` int(11) NOT NULL,
  `submission_date` datetime NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_test_results_to_risks`
--

CREATE TABLE `framework_control_test_results_to_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_results_id` bigint(20) UNSIGNED DEFAULT NULL,
  `risk_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_to_frameworks`
--

CREATE TABLE `framework_control_to_frameworks` (
  `control_id` bigint(20) UNSIGNED NOT NULL,
  `framework_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_control_type_mappings`
--

CREATE TABLE `framework_control_type_mappings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `control_id` bigint(20) UNSIGNED NOT NULL,
  `control_type_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `framework_icons`
--

CREATE TABLE `framework_icons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `impacts`
--

CREATE TABLE `impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `impacts`
--

INSERT INTO `impacts` (`id`, `name`) VALUES
(1, 'Insignificant'),
(2, 'Minor'),
(3, 'Moderate'),
(4, 'Major'),
(5, 'Extreme/Catastrophic');

-- --------------------------------------------------------

--
-- Table structure for table `items_to_teams`
--

CREATE TABLE `items_to_teams` (
  `item_id` int(11) NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `name`, `description`, `code`, `created_at`, `updated_at`) VALUES
(1, 'CEO', 'This job for CEO', '#00001', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(2, 'Department manager', 'This job for department manager', '#00003', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(3, 'Job1', 'Job description1', '#11111', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(4, 'Job2', 'Job description2', '#22222', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(5, 'Job3', 'Job description3', '#33333', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(6, 'Job4', 'Job description4', '#44444', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(7, 'Job5', 'Job description5', '#55555', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(8, 'Job6', 'Job description6', '#66666', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(9, 'Job7', 'Job description7', '#77777', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(10, 'Job8', 'Job description8', '#88888', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(11, 'Job9', 'Job description9', '#99999', '2022-08-14 11:59:34', '2022-08-14 11:59:34'),
(12, 'Job10', 'Job description10', '#101010101', '2022-08-14 11:59:34', '2022-08-14 11:59:34');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `full`) VALUES
(1, 'en', 'English'),
(2, 'bp', 'Brazilian Portuguese'),
(3, 'es', 'Espanol'),
(4, 'ar', 'Arabic'),
(5, 'ca', 'Catalan'),
(6, 'cs', 'Czech'),
(7, 'da', 'Danish'),
(8, 'de', 'German'),
(9, 'el', 'Greek'),
(10, 'fi', 'Finnish'),
(11, 'fr', 'French'),
(12, 'he', 'Hebrew'),
(13, 'hi', 'Hindi'),
(14, 'hu', 'Hungarian'),
(15, 'it', 'Italian'),
(16, 'ja', 'Japanese'),
(17, 'ko', 'Korean'),
(18, 'nl', 'Dutch'),
(19, 'no', 'Norwegian'),
(20, 'pl', 'Polish'),
(21, 'pt', 'Portuguese'),
(22, 'ro', 'Romanian'),
(23, 'ru', 'Russian'),
(24, 'sr', 'Serbian'),
(25, 'sv', 'Swedish'),
(26, 'tr', 'Turkish'),
(27, 'uk', 'Ukranian'),
(28, 'vi', 'Vietnamese'),
(29, 'zh-CN', 'Chinese Simplified'),
(30, 'zh-TW', 'Chinese Traditional'),
(31, 'bg', 'Bulgarian'),
(32, 'sk', 'Slovak'),
(33, 'mn', 'Mongolian'),
(34, 'si', 'Sinhala');

-- --------------------------------------------------------

--
-- Table structure for table `likelihoods`
--

CREATE TABLE `likelihoods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likelihoods`
--

INSERT INTO `likelihoods` (`id`, `name`) VALUES
(1, 'Remote'),
(2, 'Unlikely'),
(3, 'Credible'),
(4, 'Likely'),
(5, 'Almost Certain');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`) VALUES
(1, 'Location 1'),
(2, 'Location 2'),
(3, 'Location 3'),
(4, 'Location 4'),
(5, 'Location 5'),
(6, 'Location 6'),
(7, 'Location 7'),
(8, 'Location 8'),
(9, 'Location 9'),
(10, 'Location 10'),
(11, 'Location 11'),
(12, 'Location 12'),
(13, 'Location 13'),
(14, 'Location 14'),
(15, 'Location 15'),
(16, 'Location 16'),
(17, 'Location 17'),
(18, 'Location 18'),
(19, 'Location 19'),
(20, 'Location 20');

-- --------------------------------------------------------

--
-- Table structure for table `mgmt_reviews`
--

CREATE TABLE `mgmt_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `review` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewer` bigint(20) UNSIGNED DEFAULT NULL,
  `next_step_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comments` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_review` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2021_04_04_122425_create_notifications_table', 1),
(2, '2021_04_04_122525_create_user_notifications_table', 1),
(3, '2022_02_16_001499_create_permission_groups_table', 1),
(4, '2022_02_16_001500_create_subgroups_table', 1),
(5, '2022_02_16_001501_create_permissions_table', 1),
(6, '2022_02_16_001503_create_permission_to_permission_groups_table', 1),
(7, '2022_02_16_001504_create_permission_to_users_table', 1),
(8, '2022_02_16_001509_create_roles_table', 1),
(9, '2022_02_16_001510_create_role_responsibilities_table', 1),
(10, '2022_02_16_001601_create_department_colors_table', 1),
(11, '2022_02_16_001602_create_departments_table', 1),
(12, '2022_02_16_001603_create_jobs_table', 1),
(13, '2022_02_16_001700_create_users_table', 1),
(14, '2022_02_16_001702_add_manager_id_to_departments', 1),
(15, '2022_02_16_001703_add_user_id_to_permission_to_users', 1),
(16, '2022_02_16_001800_create_assessments_table', 1),
(17, '2022_02_16_001810_create_assessment_questions_table', 1),
(18, '2022_02_16_001811_create_contributing_risks_likelihood_table', 1),
(19, '2022_02_16_001812_create_scoring_methods_table', 1),
(20, '2022_02_16_001819_create_assessment_scorings_table', 1),
(21, '2022_02_16_001820_create_assessment_answers_table', 1),
(22, '2022_02_16_001830_create_asset_groups_table', 1),
(23, '2022_02_16_001840_create_assessment_answers_to_asset_groups_table', 1),
(24, '2022_02_16_001840_create_asset_values_table', 1),
(25, '2022_02_16_001840_create_locations_table', 1),
(26, '2022_02_16_001841_create_assets_table', 1),
(27, '2022_02_16_001850_create_assessment_answers_to_assets_table', 1),
(28, '2022_02_16_001851_create_contributing_risks_table', 1),
(29, '2022_02_16_001860_create_assessment_scoring_contributing_impacts_table', 1),
(30, '2022_02_16_091810_create_asset_asset_groups_table', 1),
(31, '2022_02_16_091811_create_projects_table', 1),
(32, '2022_02_16_091812_create_close_reasons_table', 1),
(33, '2022_02_16_091813_create_sources_table', 1),
(34, '2022_02_16_091814_create_categories_table', 1),
(35, '2022_02_16_091815_create_mitigation_efforts_table', 1),
(36, '2022_02_16_091815_create_planning_strategies_table', 1),
(37, '2022_02_16_091816_create_mitigations_table', 1),
(38, '2022_02_16_091820_create_audit_logs_table', 1),
(39, '2022_02_16_091830_create_backups_table', 1),
(40, '2022_02_16_091880_create_compliance_files_table', 1),
(41, '2022_02_16_091890_create_contributing_risks_impact_table', 1),
(42, '2022_02_16_091905_create_control_classes_table', 1),
(43, '2022_02_16_091906_create_control_maturities_table', 1),
(44, '2022_02_16_091907_create_control_phases_table', 1),
(45, '2022_02_16_091908_create_control_priorities_table', 1),
(46, '2022_02_16_091909_create_impacts_table', 1),
(47, '2022_02_16_091909_create_likelihoods_table', 1),
(48, '2022_02_16_091910_create_custom_risk_model_values_table', 1),
(49, '2022_02_16_091911_create_cvss_scorings_table', 1),
(50, '2022_02_16_091912_create_data_classifications_table', 1),
(51, '2022_02_16_091913_create_date_formats_table', 1),
(52, '2022_02_16_091914_create_document_exceptions_table', 1),
(53, '2022_02_16_091915_create_document_exceptions_statuses_table', 1),
(54, '2022_02_16_091916_create_document_statuses_table', 1),
(55, '2022_02_16_091916_create_document_types_table', 1),
(56, '2022_02_16_091918_create_dynamic_saved_selections_table', 1),
(57, '2022_02_16_091919_create_failed_login_attempts_table', 1),
(58, '2022_02_16_091920_create_families_table', 1),
(59, '2022_02_16_091921_create_fields_table', 1),
(60, '2022_02_16_091922_create_file_type_extensions_table', 1),
(61, '2022_02_16_091923_create_control_desired_maturities_table', 1),
(62, '2022_02_16_091923_create_control_owners_table', 1),
(63, '2022_02_16_091923_create_file_types_table', 1),
(64, '2022_02_16_091924_create_framework_controls_table', 1),
(65, '2022_02_16_091924_create_frameworks_table', 1),
(66, '2022_02_16_091925_create_framework_control_mappings_table', 1),
(67, '2022_02_16_091925_create_framework_control_tests_table', 1),
(68, '2022_02_16_091925_create_risks_table', 1),
(69, '2022_02_16_091926_add_risk_id_to_mitigations_table', 1),
(70, '2022_02_16_091926_create_closures_table', 1),
(71, '2022_02_16_091926_create_comments_table', 1),
(72, '2022_02_16_091926_create_files_table', 1),
(73, '2022_02_16_091926_create_framework_control_test_audits_table', 1),
(74, '2022_02_16_091926_create_privacies_table', 1),
(75, '2022_02_16_091927_create_documents_table', 1),
(76, '2022_02_16_091927_create_framework_control_test_comments_table', 1),
(77, '2022_02_16_091928_create_framework_control_test_results_table', 1),
(78, '2022_02_16_091929_create_framework_control_test_results_to_risks_table', 1),
(79, '2022_02_16_091931_create_control_types_table', 1),
(80, '2022_02_16_091931_create_framework_control_to_frameworks_table', 1),
(81, '2022_02_16_091932_create_framework_control_type_mappings_table', 1),
(82, '2022_02_16_091935_create_teams_table', 1),
(83, '2022_02_16_091936_create_items_to_teams_table', 1),
(84, '2022_02_16_091937_create_languages_table', 1),
(85, '2022_02_16_091939_create_next_steps_table', 1),
(86, '2022_02_16_091939_create_reviews_table', 1),
(87, '2022_02_16_091940_create_mgmt_reviews_table', 1),
(88, '2022_02_16_091941_create_mitigation_accept_users_table', 1),
(89, '2022_02_16_091943_create_mitigation_to_controls_table', 1),
(90, '2022_02_16_091944_create_mitigation_to_teams_table', 1),
(91, '2022_02_16_091947_create_password_resets_table', 1),
(92, '2022_02_16_091948_create_pending_risks_table', 1),
(93, '2022_02_16_091955_create_questionnaire_pending_risks_table', 1),
(94, '2022_02_16_091956_create_regulations_table', 1),
(95, '2022_02_16_091957_create_residual_risk_scoring_histories_table', 1),
(96, '2022_02_16_091959_create_review_levels_table', 1),
(97, '2022_02_16_092000_create_risk_functions_table', 1),
(98, '2022_02_16_092001_create_risk_groupings_table', 1),
(99, '2022_02_16_092002_create_risk_catalogs_table', 1),
(100, '2022_02_16_092003_create_risk_levels_table', 1),
(101, '2022_02_16_092004_create_risk_models_table', 1),
(102, '2022_02_16_092005_create_risk_scorings_table', 1),
(103, '2022_02_16_092006_create_risk_scoring_contributing_impacts_table', 1),
(104, '2022_02_16_092007_create_risk_scoring_histories_table', 1),
(105, '2022_02_16_092008_create_risk_to_additional_stakeholders_table', 1),
(106, '2022_02_16_092009_create_risk_to_locations_table', 1),
(107, '2022_02_16_092010_create_risk_to_teams_table', 1),
(108, '2022_02_16_092010_create_technologies_table', 1),
(109, '2022_02_16_092011_create_risk_to_technologies_table', 1),
(110, '2022_02_16_092013_create_risks_to_asset_groups_table', 1),
(111, '2022_02_16_092014_create_risks_to_assets_table', 1),
(112, '2022_02_16_092018_create_sessions_table', 1),
(113, '2022_02_16_092019_create_settings_table', 1),
(114, '2022_02_16_092021_create_statuses_table', 1),
(115, '2022_02_16_092022_create_tags_table', 1),
(116, '2022_02_16_092023_create_taggables_table', 1),
(117, '2022_02_16_092026_create_test_results_table', 1),
(118, '2022_02_16_092027_create_test_statuses_table', 1),
(119, '2022_02_16_092027_create_threat_groupings_table', 1),
(120, '2022_02_16_092028_create_threat_catalogs_table', 1),
(121, '2022_02_16_092031_create_user_pass_histories_table', 1),
(122, '2022_02_16_092032_create_user_pass_reuse_histories_table', 1),
(123, '2022_02_16_092033_create_user_to_teams_table', 1),
(124, '2022_02_16_092034_create_validation_files_table', 1),
(125, '2022_03_13_065913_create_tests_table', 1),
(126, '2022_05_17_122632_create_framework_icons_table', 1),
(127, '2022_06_16_123929_create_tasks_table', 1),
(128, '2022_06_16_132507_create_file_tasks_table', 1),
(129, '2022_07_26_145432_create_task_notes_table', 1),
(130, '2022_07_28_105734_create_task_note_files_table', 1),
(131, '2022_07_26_145432_create_document_notes_table', 2),
(132, '2022_07_28_105734_create_document_note_files_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `mitigations`
--

CREATE TABLE `mitigations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_update` timestamp NULL DEFAULT NULL,
  `planning_strategy` bigint(20) UNSIGNED DEFAULT NULL,
  `mitigation_effort` bigint(20) UNSIGNED DEFAULT NULL,
  `mitigation_cost` int(11) DEFAULT NULL,
  `mitigation_owner` bigint(20) UNSIGNED DEFAULT NULL,
  `current_solution` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_requirements` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_recommendations` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_by` int(11) NOT NULL DEFAULT 1,
  `planning_date` date NOT NULL,
  `mitigation_percent` int(11) NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mitigations`
--

INSERT INTO `mitigations` (`id`, `submission_date`, `last_update`, `planning_strategy`, `mitigation_effort`, `mitigation_cost`, `mitigation_owner`, `current_solution`, `security_requirements`, `security_recommendations`, `submitted_by`, `planning_date`, `mitigation_percent`, `risk_id`) VALUES
(1, '2017-02-01 00:24:44', '1993-10-05 07:27:36', 4, 4, 90, 1, 'ut', 'sapiente', 'ut', 1, '1976-03-25', 53, 18),
(2, '1972-10-18 14:48:51', '1994-05-20 10:51:57', 4, 2, 80, 1, 'est', 'exercitationem', 'est', 1, '2005-05-01', 61, 9),
(3, '1997-06-15 08:26:52', '1972-12-14 16:20:13', 2, 2, 34, 1, 'eveniet', 'quia', 'molestiae', 1, '1999-06-09', 41, 8),
(4, '2020-04-08 17:03:38', '1995-11-08 22:10:12', 4, 3, 99, 1, 'illo', 'aperiam', 'suscipit', 1, '1975-06-03', 4, 15),
(5, '1996-06-14 20:28:54', '1993-10-27 04:51:20', 1, 5, 17, 1, 'reprehenderit', 'eius', 'molestias', 1, '2016-07-02', 70, 14),
(6, '2009-12-11 08:04:22', '2005-11-30 23:54:37', 4, 2, 5, 1, 'et', 'necessitatibus', 'et', 1, '1981-11-23', 24, 14),
(7, '1988-10-23 17:14:24', '1977-12-12 03:59:14', 4, 5, 18, 1, 'in', 'distinctio', 'voluptatum', 1, '2004-10-12', 21, 4),
(8, '1986-02-25 20:27:18', '2011-08-26 15:37:21', 3, 2, 19, 1, 'vitae', 'quod', 'quaerat', 1, '2011-06-30', 7, 1),
(9, '1984-07-15 17:46:45', '1989-11-15 20:14:12', 4, 1, 34, 1, 'est', 'delectus', 'sed', 1, '2008-07-03', 84, 17),
(10, '1990-01-08 21:28:23', '1986-05-02 12:00:01', 3, 1, 54, 1, 'eaque', 'dignissimos', 'illo', 1, '2015-02-13', 78, 13),
(11, '2003-07-27 22:43:50', '2022-04-24 04:14:08', 1, 1, 16, 1, 'nobis', 'expedita', 'similique', 1, '1988-12-04', 61, 19),
(12, '2007-09-20 23:18:28', '1997-01-03 00:30:32', 5, 3, 99, 1, 'ad', 'voluptatem', 'reprehenderit', 1, '2008-10-10', 68, 4),
(13, '1986-04-27 12:20:28', '1995-11-29 14:44:35', 5, 5, 19, 1, 'rerum', 'minus', 'ut', 1, '2017-01-20', 72, 19),
(14, '1981-11-07 14:14:14', '1984-06-14 14:50:35', 1, 2, 60, 1, 'sit', 'repellat', 'blanditiis', 1, '2015-07-16', 30, 20),
(15, '2000-12-10 10:52:50', '2017-06-19 09:47:15', 5, 3, 42, 1, 'adipisci', 'illum', 'rerum', 1, '2012-05-19', 12, 5),
(16, '1995-10-06 14:54:59', '2022-08-04 14:03:36', 3, 3, 23, 1, 'a', 'dolor', 'occaecati', 1, '2013-12-02', 32, 9),
(17, '2017-05-16 14:24:29', '2000-08-06 14:43:30', 5, 5, 2, 1, 'voluptatibus', 'est', 'dolor', 1, '1997-12-28', 3, 19),
(18, '1971-01-27 11:35:37', '1974-06-25 20:08:39', 1, 3, 38, 1, 'sit', 'esse', 'neque', 1, '2006-09-21', 27, 13),
(19, '1979-02-04 09:09:35', '1981-03-29 07:49:18', 4, 2, 53, 1, 'sit', 'laborum', 'necessitatibus', 1, '1997-07-18', 31, 13),
(20, '2015-02-06 20:35:20', '1981-07-31 08:03:07', 1, 5, 43, 1, 'nostrum', 'nulla', 'sed', 1, '2015-03-11', 45, 12);

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_accept_users`
--

CREATE TABLE `mitigation_accept_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_efforts`
--

CREATE TABLE `mitigation_efforts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mitigation_efforts`
--

INSERT INTO `mitigation_efforts` (`id`, `name`) VALUES
(1, 'Insignificante'),
(2, 'Menor'),
(3, 'Considerable'),
(4, 'Significante'),
(5, 'Excepcional');

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_to_controls`
--

CREATE TABLE `mitigation_to_controls` (
  `mitigation_id` bigint(20) UNSIGNED NOT NULL,
  `control_id` bigint(20) UNSIGNED NOT NULL,
  `validation_details` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_owner` int(11) NOT NULL,
  `validation_mitigation_percent` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mitigation_to_controls`
--

INSERT INTO `mitigation_to_controls` (`mitigation_id`, `control_id`, `validation_details`, `validation_owner`, `validation_mitigation_percent`) VALUES
(1, 1, 'qui', 1, 40),
(2, 2, 'nihil', 1, 53),
(3, 3, 'ea', 1, 35),
(4, 4, 'velit', 1, 57),
(5, 5, 'voluptatem', 1, 25),
(6, 6, 'est', 1, 94),
(7, 7, 'rem', 1, 7),
(8, 8, 'tenetur', 1, 85),
(9, 9, 'rerum', 1, 91),
(10, 10, 'consectetur', 1, 17),
(11, 11, 'officia', 1, 37),
(12, 12, 'molestiae', 1, 31),
(13, 13, 'aut', 1, 87),
(14, 14, 'qui', 1, 52),
(15, 15, 'voluptatem', 1, 9),
(16, 16, 'quam', 1, 39),
(17, 17, 'possimus', 1, 70),
(18, 18, 'aut', 1, 59),
(19, 19, 'quis', 1, 86),
(20, 20, 'soluta', 1, 90);

-- --------------------------------------------------------

--
-- Table structure for table `mitigation_to_teams`
--

CREATE TABLE `mitigation_to_teams` (
  `mitigation_id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `next_steps`
--

CREATE TABLE `next_steps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `next_steps`
--

INSERT INTO `next_steps` (`id`, `name`) VALUES
(1, 'Accept Until Next Review'),
(3, 'Submit as a Production Issue');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `message`, `notification_type`, `meta`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 11:59:59', NULL),
(2, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 11:59:59', NULL),
(3, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:00', NULL),
(4, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:00', NULL),
(5, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:00', NULL),
(6, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(7, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(8, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(9, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(10, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(11, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(12, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(13, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:01', NULL),
(14, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:02', NULL),
(15, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:02', NULL),
(16, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:02', NULL),
(17, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:02', NULL),
(18, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:02', NULL),
(19, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:02', NULL),
(20, 'Successfully created new Asset', 'notification', 'a:1:{s:4:\"link\";s:39:\"http://localhost/admin/asset-management\";}', 14, '2022-08-14 12:00:02', NULL),
(21, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:54', NULL),
(22, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:54', NULL),
(23, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:55', NULL),
(24, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:55', NULL),
(25, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:55', NULL),
(26, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(27, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(28, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(29, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(30, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(31, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(32, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(33, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(34, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(35, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:56', NULL),
(36, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:57', NULL),
(37, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:57', NULL),
(38, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:57', NULL),
(39, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:57', NULL),
(40, 'Successfully created new Risk', 'notification', 'a:0:{}', 14, '2022-08-14 12:00:57', NULL),
(41, 'Employee admin create and assign task (title 1) to you', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:03', NULL),
(42, 'Employee admin create and assign task (title 2) to you', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:04', NULL),
(43, 'Employee admin create and assign task (title 3) to your team (Team 1)', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:04', NULL),
(44, 'Employee admin create and assign task (title 4) to you', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:05', NULL),
(45, 'Employee admin create and assign task (title 5) to you', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:05', NULL),
(46, 'Employee admin create and assign task (title 6) to your team (Team 1)', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:05', NULL),
(47, 'Employee admin create and assign task (title 7) to you', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:05', NULL),
(48, 'Employee admin create and assign task (title 8) to you', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:05', NULL),
(49, 'Employee admin create and assign task (title 9) to your team (Team 1)', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:05', NULL),
(50, 'Employee admin create and assign task (title 10) to you', 'notification', 'a:1:{s:4:\"link\";s:42:\"http://localhost/admin/task/assigned-to-me\";}', 14, '2022-08-14 12:01:06', NULL),
(51, 'Employee admin create and assign task (gggg) to you', 'notification', 'a:1:{s:4:\"link\";s:47:\"http://127.0.0.1:8000/admin/task/assigned-to-me\";}', 14, '2022-08-14 15:35:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `username` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pending_risks`
--

CREATE TABLE `pending_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assessment_id` bigint(20) UNSIGNED NOT NULL,
  `assessment_answer_id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` double(8,2) NOT NULL,
  `owner` int(11) DEFAULT NULL,
  `affected_assets` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subgroup_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `name`, `subgroup_id`, `created_at`, `updated_at`) VALUES
(1, 'framework.list', 'list', 1, NULL, NULL),
(2, 'framework.view', 'view', 1, NULL, NULL),
(3, 'framework.create', 'create', 1, NULL, NULL),
(4, 'framework.update', 'update', 1, NULL, NULL),
(5, 'framework.delete', 'delete', 1, NULL, NULL),
(6, 'framework.print', 'print', 1, NULL, NULL),
(7, 'framework.export', 'export', 1, NULL, NULL),
(8, 'control.list', 'list', 2, NULL, NULL),
(9, 'control.view', 'view', 2, NULL, NULL),
(10, 'control.create', 'create', 2, NULL, NULL),
(11, 'control.update', 'update', 2, NULL, NULL),
(12, 'control.delete', 'delete', 2, NULL, NULL),
(13, 'control.print', 'print', 2, NULL, NULL),
(14, 'control.export', 'export', 2, NULL, NULL),
(15, 'document.list', 'list', 3, NULL, NULL),
(16, 'document.view', 'view', 3, NULL, NULL),
(17, 'document.create', 'create', 3, NULL, NULL),
(18, 'document.update', 'update', 3, NULL, NULL),
(19, 'document.delete', 'delete', 3, NULL, NULL),
(20, 'document.print', 'print', 3, NULL, NULL),
(21, 'document.export', 'export', 3, NULL, NULL),
(22, 'document.download', 'download', 3, NULL, NULL),
(23, 'riskmanagement.list', 'list', 5, NULL, NULL),
(24, 'riskmanagement.view', 'view', 5, NULL, NULL),
(25, 'riskmanagement.create', 'create', 5, NULL, NULL),
(26, 'riskmanagement.update', 'update', 5, NULL, NULL),
(27, 'riskmanagement.delete', 'delete', 5, NULL, NULL),
(28, 'riskmanagement.print', 'print', 5, NULL, NULL),
(29, 'riskmanagement.export', 'export', 5, NULL, NULL),
(30, 'riskmanagement.AbleToCommentRiskManagement', 'AbleToCommentRiskManagement', 5, NULL, NULL),
(31, 'riskmanagement.AbleToCloseRisks', 'AbleToCloseRisks', 5, NULL, NULL),
(32, 'audits.list', 'list', 9, NULL, NULL),
(33, 'audits.create', 'create', 9, NULL, NULL),
(34, 'audits.delete', 'delete', 9, NULL, NULL),
(35, 'audits.result', 'result', 9, NULL, NULL),
(36, 'asset.list', 'list', 10, NULL, NULL),
(37, 'asset.view', 'view', 10, NULL, NULL),
(38, 'asset.create', 'create', 10, NULL, NULL),
(39, 'asset.update', 'update', 10, NULL, NULL),
(40, 'asset.delete', 'delete', 10, NULL, NULL),
(41, 'asset.print', 'print', 10, NULL, NULL),
(42, 'asset.export', 'export', 10, NULL, NULL),
(43, 'roles.list', 'list', 12, NULL, NULL),
(44, 'roles.view', 'view', 12, NULL, NULL),
(45, 'roles.create', 'create', 12, NULL, NULL),
(46, 'roles.update', 'update', 12, NULL, NULL),
(47, 'roles.delete', 'delete', 12, NULL, NULL),
(48, 'roles.print', 'print', 12, NULL, NULL),
(49, 'roles.export', 'export', 12, NULL, NULL),
(50, 'values.list', 'list', 13, NULL, NULL),
(51, 'values.view', 'view', 13, NULL, NULL),
(52, 'values.create', 'create', 13, NULL, NULL),
(53, 'values.update', 'update', 13, NULL, NULL),
(54, 'values.delete', 'delete', 13, NULL, NULL),
(55, 'values.print', 'print', 13, NULL, NULL),
(56, 'values.export', 'export', 13, NULL, NULL),
(57, 'logs.list', 'list', 14, NULL, NULL),
(58, 'logs.view', 'view', 14, NULL, NULL),
(59, 'logs.create', 'create', 14, NULL, NULL),
(60, 'logs.update', 'update', 14, NULL, NULL),
(61, 'logs.delete', 'delete', 14, NULL, NULL),
(62, 'logs.print', 'print', 14, NULL, NULL),
(63, 'logs.export', 'export', 14, NULL, NULL),
(64, 'hierarchy.list', 'view', 15, NULL, NULL),
(65, 'hierarchy.view', 'view', 15, NULL, NULL),
(66, 'hierarchy.update', 'update', 15, NULL, NULL),
(67, 'department.list', 'list', 16, NULL, NULL),
(68, 'department.view', 'view', 16, NULL, NULL),
(69, 'department.create', 'create', 16, NULL, NULL),
(70, 'department.update', 'update', 16, NULL, NULL),
(71, 'department.delete', 'delete', 16, NULL, NULL),
(72, 'department.print', 'print', 16, NULL, NULL),
(73, 'department.export', 'export', 16, NULL, NULL),
(74, 'job.list', 'list', 17, NULL, NULL),
(75, 'job.view', 'view', 17, NULL, NULL),
(76, 'job.create', 'create', 17, NULL, NULL),
(77, 'job.update', 'update', 17, NULL, NULL),
(78, 'job.delete', 'delete', 17, NULL, NULL),
(79, 'job.print', 'print', 17, NULL, NULL),
(80, 'job.export', 'export', 17, NULL, NULL),
(81, 'plan_mitigation.create', 'create', 19, NULL, NULL),
(82, 'plan_mitigation.accept', 'accept', 19, NULL, NULL),
(83, 'perform_reviews.create', 'create', 20, NULL, NULL),
(84, 'asset_group.list', 'list', 21, NULL, NULL),
(85, 'asset_group.view', 'view', 21, NULL, NULL),
(86, 'asset_group.create', 'create', 21, NULL, NULL),
(87, 'asset_group.update', 'update', 21, NULL, NULL),
(88, 'asset_group.delete', 'delete', 21, NULL, NULL),
(89, 'asset_group.print', 'print', 21, NULL, NULL),
(90, 'asset_group.export', 'export', 21, NULL, NULL),
(91, 'category.list', 'list', 22, NULL, NULL),
(92, 'category.view', 'view', 22, NULL, NULL),
(93, 'category.create', 'create', 22, NULL, NULL),
(94, 'category.update', 'update', 22, NULL, NULL),
(95, 'category.delete', 'delete', 22, NULL, NULL),
(96, 'category.print', 'print', 22, NULL, NULL),
(97, 'category.export', 'export', 22, NULL, NULL),
(98, 'user_management.list', 'list', 23, NULL, NULL),
(99, 'user_management.view', 'view', 23, NULL, NULL),
(100, 'user_management.create', 'create', 23, NULL, NULL),
(101, 'user_management.update', 'update', 23, NULL, NULL),
(102, 'user_management.delete', 'delete', 23, NULL, NULL),
(103, 'user_management.print', 'print', 23, NULL, NULL),
(104, 'user_management.export', 'export', 23, NULL, NULL),
(105, 'settings.list', 'list', 24, NULL, NULL),
(106, 'settings.view', 'view', 24, NULL, NULL),
(107, 'settings.create', 'create', 24, NULL, NULL),
(108, 'settings.update', 'update', 24, NULL, NULL),
(109, 'settings.delete', 'delete', 24, NULL, NULL),
(110, 'settings.print', 'print', 24, NULL, NULL),
(111, 'settings.export', 'export', 24, NULL, NULL),
(112, 'classic_risk_formula.list', 'list', 25, NULL, NULL),
(113, 'classic_risk_formula.view', 'view', 25, NULL, NULL),
(114, 'classic_risk_formula.create', 'create', 25, NULL, NULL),
(115, 'classic_risk_formula.update', 'update', 25, NULL, NULL),
(116, 'classic_risk_formula.delete', 'delete', 25, NULL, NULL),
(117, 'classic_risk_formula.print', 'print', 25, NULL, NULL),
(118, 'classic_risk_formula.export', 'export', 25, NULL, NULL),
(119, 'import_and_export.list', 'list', 26, NULL, NULL),
(120, 'import_and_export.import', 'import', 26, NULL, NULL),
(121, 'import_and_export.export', 'export', 26, NULL, NULL),
(122, 'LDAP.list', 'list', 27, NULL, NULL),
(123, 'LDAP.test', 'test', 27, NULL, NULL),
(124, 'LDAP.update', 'update', 27, NULL, NULL),
(125, 'reporting.Overview', 'Overview', 28, NULL, NULL),
(126, 'reporting.Risk Dashboard', 'Risk Dashboard', 28, NULL, NULL),
(127, 'reporting.Control Gap Analysis', 'Control Gap Analysis', 28, NULL, NULL),
(128, 'reporting.Likelihood And Impact', 'Likelihood And Impact', 28, NULL, NULL),
(129, 'reporting.All Open Risks Assigne To Me', 'All Open Risks Assigne To Me', 28, NULL, NULL),
(130, 'reporting.Dynamic Risk Report', 'Dynamic Risk Report', 28, NULL, NULL),
(131, 'reporting.Risks and Controls', 'Risks and Controls', 28, NULL, NULL),
(132, 'reporting.Risks and Assets', 'Risks and Assets', 28, NULL, NULL),
(133, 'task.list', 'list', 29, NULL, NULL),
(134, 'task.create', 'create', 29, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_groups`
--

CREATE TABLE `permission_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_groups`
--

INSERT INTO `permission_groups` (`id`, `name`, `description`, `order`) VALUES
(1, 'Governance', '', 1),
(2, 'Risk Management', '', 2),
(3, 'Compliance', '', 3),
(4, 'Asset Management', '', 4),
(5, 'Assessments', '', 5),
(6, 'Configure', '', 6),
(7, 'Hierarchy', '', 7),
(8, 'Reporting', '', 8),
(9, 'Task', '', 9);

-- --------------------------------------------------------

--
-- Table structure for table `permission_to_permission_groups`
--

CREATE TABLE `permission_to_permission_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `permission_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_to_permission_groups`
--

INSERT INTO `permission_to_permission_groups` (`id`, `permission_id`, `permission_group_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(9, 9, 1),
(10, 10, 1),
(11, 11, 1),
(12, 12, 1),
(13, 13, 1),
(14, 14, 1),
(15, 15, 1),
(16, 16, 2),
(17, 17, 2),
(18, 18, 2),
(19, 19, 2),
(20, 20, 2),
(21, 21, 2),
(22, 22, 2),
(23, 23, 2),
(24, 24, 2),
(25, 25, 2),
(26, 26, 2),
(27, 27, 2),
(28, 28, 2),
(29, 29, 2),
(30, 30, 2),
(31, 31, 3),
(32, 32, 3),
(33, 33, 3),
(34, 34, 3),
(35, 35, 3),
(36, 36, 3),
(37, 37, 3),
(38, 38, 3),
(39, 39, 3),
(40, 40, 4),
(41, 41, 5);

-- --------------------------------------------------------

--
-- Table structure for table `permission_to_users`
--

CREATE TABLE `permission_to_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_to_users`
--

INSERT INTO `permission_to_users` (`id`, `permission_id`, `user_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(9, 9, 1),
(10, 10, 1),
(11, 11, 1),
(12, 12, 1),
(13, 13, 1),
(14, 14, 1),
(15, 15, 1),
(16, 16, 1),
(17, 17, 1),
(18, 18, 1),
(19, 19, 1),
(20, 20, 1),
(21, 21, 1),
(22, 22, 1),
(23, 23, 1),
(24, 24, 1),
(25, 25, 1),
(26, 26, 1),
(27, 27, 1),
(28, 28, 1),
(29, 29, 1),
(30, 30, 1),
(31, 31, 1),
(32, 32, 1),
(33, 33, 1),
(34, 34, 1),
(35, 35, 1),
(36, 36, 1),
(37, 37, 1),
(38, 38, 1),
(39, 39, 1),
(40, 40, 1),
(41, 41, 1);

-- --------------------------------------------------------

--
-- Table structure for table `planning_strategies`
--

CREATE TABLE `planning_strategies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `planning_strategies`
--

INSERT INTO `planning_strategies` (`id`, `name`) VALUES
(1, 'Investigar'),
(2, 'Acceptado'),
(3, 'Mitigado'),
(4, 'Ver'),
(5, 'Transferencia');

-- --------------------------------------------------------

--
-- Table structure for table `privacies`
--

CREATE TABLE `privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_date` timestamp NULL DEFAULT NULL,
  `consultant` int(11) DEFAULT NULL,
  `business_owner` int(11) DEFAULT NULL,
  `data_classification` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 999999,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire_pending_risks`
--

CREATE TABLE `questionnaire_pending_risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `questionnaire_tracking_id` int(11) NOT NULL,
  `questionnaire_scoring_id` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` int(11) DEFAULT NULL,
  `asset` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `regulations`
--

CREATE TABLE `regulations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regulations`
--

INSERT INTO `regulations` (`id`, `name`) VALUES
(1, 'PCI DSS 3.2'),
(2, 'Sarbanes-Oxley (SOX)'),
(3, 'HIPAA'),
(4, 'ISO 27001');

-- --------------------------------------------------------

--
-- Table structure for table `residual_risk_scoring_histories`
--

CREATE TABLE `residual_risk_scoring_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `residual_risk` double(8,2) NOT NULL,
  `last_update` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `residual_risk_scoring_histories`
--

INSERT INTO `residual_risk_scoring_histories` (`id`, `risk_id`, `residual_risk`, `last_update`) VALUES
(1, 1, 1.20, '2022-08-14 14:00:08'),
(2, 2, 1.20, '2022-08-14 14:00:08'),
(3, 3, 1.20, '2022-08-14 14:00:09'),
(4, 4, 1.20, '2022-08-14 14:00:10'),
(5, 5, 1.20, '2022-08-14 14:00:10'),
(6, 6, 1.20, '2022-08-14 14:00:10'),
(7, 7, 1.20, '2022-08-14 14:00:11'),
(8, 8, 1.20, '2022-08-14 14:00:12'),
(9, 9, 1.20, '2022-08-14 14:00:12'),
(10, 10, 1.20, '2022-08-14 14:00:12'),
(11, 11, 1.20, '2022-08-14 14:00:12'),
(12, 12, 1.20, '2022-08-14 14:00:13'),
(13, 13, 1.20, '2022-08-14 14:00:13'),
(14, 14, 1.20, '2022-08-14 14:00:13'),
(15, 15, 1.20, '2022-08-14 14:00:13'),
(16, 16, 1.20, '2022-08-14 14:00:13'),
(17, 17, 1.20, '2022-08-14 14:00:14'),
(18, 18, 1.20, '2022-08-14 14:00:14'),
(19, 19, 1.20, '2022-08-14 14:00:14'),
(20, 20, 1.20, '2022-08-14 14:00:14'),
(21, 21, 0.40, '2022-08-14 14:00:14'),
(22, 22, 1.60, '2022-08-14 14:00:15'),
(23, 23, 3.60, '2022-08-14 14:00:15'),
(24, 24, 6.40, '2022-08-14 14:00:15'),
(25, 25, 10.00, '2022-08-14 14:00:15');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `name`) VALUES
(1, 'Approve Risk'),
(2, 'Reject Risk and Close');

-- --------------------------------------------------------

--
-- Table structure for table `review_levels`
--

CREATE TABLE `review_levels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `review_levels`
--

INSERT INTO `review_levels` (`id`, `value`, `name`) VALUES
(1, 360, 'Insignificant'),
(2, 360, 'Low'),
(3, 180, 'Medium'),
(4, 90, 'High'),
(5, 90, 'Very High');

-- --------------------------------------------------------

--
-- Table structure for table `risks`
--

CREATE TABLE `risks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'New',
  `subject` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regulation` int(11) DEFAULT NULL,
  `control_id` bigint(20) UNSIGNED DEFAULT NULL,
  `source_id` bigint(20) UNSIGNED DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `manager_id` bigint(20) UNSIGNED DEFAULT NULL,
  `assessment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mitigation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `mgmt_review` int(11) DEFAULT NULL,
  `project_id` bigint(20) UNSIGNED DEFAULT NULL,
  `close_id` int(11) DEFAULT NULL,
  `submitted_by` int(11) NOT NULL DEFAULT 1,
  `risk_catalog_mapping` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `threat_catalog_mapping` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_group_id` int(11) NOT NULL DEFAULT 1,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risks`
--

INSERT INTO `risks` (`id`, `status`, `subject`, `reference_id`, `regulation`, `control_id`, `source_id`, `category_id`, `owner_id`, `manager_id`, `assessment`, `notes`, `review_date`, `mitigation_id`, `mgmt_review`, `project_id`, `close_id`, `submitted_by`, `risk_catalog_mapping`, `threat_catalog_mapping`, `template_group_id`, `submission_date`, `created_at`, `updated_at`) VALUES
(1, 'Opened', 'et', NULL, NULL, NULL, 4, 5, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 1, 1, NULL, NULL, 1, '2022-08-14 11:00:05', '2022-08-14 12:00:05', '2022-08-14 12:00:05'),
(2, 'Closed', 'ipsum', NULL, NULL, NULL, 2, 3, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 2, 1, NULL, NULL, 1, '2022-08-14 11:00:08', '2022-08-14 12:00:08', '2022-08-14 12:00:08'),
(3, 'Opened', 'velit', NULL, NULL, NULL, 2, 1, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 3, 1, NULL, NULL, 1, '2022-08-14 11:00:09', '2022-08-14 12:00:08', '2022-08-14 12:00:08'),
(4, 'Closed', 'repellat', NULL, NULL, NULL, 2, 4, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 4, 1, NULL, NULL, 1, '2022-08-14 11:00:09', '2022-08-14 12:00:09', '2022-08-14 12:00:09'),
(5, 'Opened', 'at', NULL, NULL, NULL, 3, 8, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 5, 1, NULL, NULL, 1, '2022-08-14 11:00:10', '2022-08-14 12:00:10', '2022-08-14 12:00:10'),
(6, 'Opened', 'voluptates', NULL, NULL, NULL, 2, 2, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 6, 1, NULL, NULL, 1, '2022-08-14 11:00:10', '2022-08-14 12:00:10', '2022-08-14 12:00:10'),
(7, 'Opened', 'et', NULL, NULL, NULL, 4, 4, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 7, 1, NULL, NULL, 1, '2022-08-14 11:00:10', '2022-08-14 12:00:10', '2022-08-14 12:00:10'),
(8, 'Opened', 'non', NULL, NULL, NULL, 2, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 8, 1, NULL, NULL, 1, '2022-08-14 11:00:11', '2022-08-14 12:00:11', '2022-08-14 12:00:11'),
(9, 'Opened', 'est', NULL, NULL, NULL, 2, 5, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 9, 1, NULL, NULL, 1, '2022-08-14 11:00:12', '2022-08-14 12:00:12', '2022-08-14 12:00:12'),
(10, 'Closed', 'nostrum', NULL, NULL, NULL, 2, 2, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 10, 1, NULL, NULL, 1, '2022-08-14 11:00:12', '2022-08-14 12:00:12', '2022-08-14 12:00:12'),
(11, 'Closed', 'rerum', NULL, NULL, NULL, 3, 5, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 11, 1, NULL, NULL, 1, '2022-08-14 11:00:12', '2022-08-14 12:00:12', '2022-08-14 12:00:12'),
(12, 'Closed', 'velit', NULL, NULL, NULL, 4, 4, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 12, 1, NULL, NULL, 1, '2022-08-14 11:00:12', '2022-08-14 12:00:12', '2022-08-14 12:00:12'),
(13, 'Opened', 'rem', NULL, NULL, NULL, 2, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 13, 1, NULL, NULL, 1, '2022-08-14 11:00:13', '2022-08-14 12:00:13', '2022-08-14 12:00:13'),
(14, 'Closed', 'nobis', NULL, NULL, NULL, 4, 6, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 14, 1, NULL, NULL, 1, '2022-08-14 11:00:13', '2022-08-14 12:00:13', '2022-08-14 12:00:13'),
(15, 'Closed', 'quo', NULL, NULL, NULL, 4, 8, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 15, 1, NULL, NULL, 1, '2022-08-14 11:00:13', '2022-08-14 12:00:13', '2022-08-14 12:00:13'),
(16, 'Closed', 'at', NULL, NULL, NULL, 3, 4, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 16, 1, NULL, NULL, 1, '2022-08-14 11:00:13', '2022-08-14 12:00:13', '2022-08-14 12:00:13'),
(17, 'Opened', 'magnam', NULL, NULL, NULL, 3, 5, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 17, 1, NULL, NULL, 1, '2022-08-14 11:00:13', '2022-08-14 12:00:13', '2022-08-14 12:00:13'),
(18, 'Opened', 'porro', NULL, NULL, NULL, 4, 3, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 18, 1, NULL, NULL, 1, '2022-08-14 11:00:14', '2022-08-14 12:00:14', '2022-08-14 12:00:14'),
(19, 'Closed', 'sint', NULL, NULL, NULL, 4, 8, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 19, 1, NULL, NULL, 1, '2022-08-14 11:00:14', '2022-08-14 12:00:14', '2022-08-14 12:00:14'),
(20, 'Closed', 'quia', NULL, NULL, NULL, 4, 4, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, 20, 1, NULL, NULL, 1, '2022-08-14 11:00:14', '2022-08-14 12:00:14', '2022-08-14 12:00:14'),
(21, 'New', 'Risk 1 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2022-08-14 11:00:14', '2022-08-14 12:00:14', '2022-08-14 12:00:14'),
(22, 'New', 'Risk 2 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2022-08-14 11:00:14', '2022-08-14 12:00:14', '2022-08-14 12:00:14'),
(23, 'New', 'Risk 3 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2022-08-14 11:00:15', '2022-08-14 12:00:15', '2022-08-14 12:00:15'),
(24, 'New', 'Risk 4 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2022-08-14 11:00:15', '2022-08-14 12:00:15', '2022-08-14 12:00:15'),
(25, 'New', 'Risk 5 Subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, '2022-08-14 11:00:15', '2022-08-14 12:00:15', '2022-08-14 12:00:15');

-- --------------------------------------------------------

--
-- Table structure for table `risks_to_assets`
--

CREATE TABLE `risks_to_assets` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `asset_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `risks_to_asset_groups`
--

CREATE TABLE `risks_to_asset_groups` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `asset_group_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `risk_catalogs`
--

CREATE TABLE `risk_catalogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `risk_grouping_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `risk_function_id` bigint(20) UNSIGNED NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_catalogs`
--

INSERT INTO `risk_catalogs` (`id`, `number`, `risk_grouping_id`, `name`, `description`, `risk_function_id`, `order`) VALUES
(1, 'R-AC-1', 1, 'Inability to maintain individual accountability', 'There is a failure to maintain asset ownership and it is not possible to have non-repudiation of actions or inactions.', 2, 1),
(2, 'R-AC-2', 1, 'Improper assignment of privileged risk_function_ids', 'There is a failure to implement least privileges.', 2, 2),
(3, 'R-AC-3', 1, 'Privilege escalation', 'Access to privileged risk_function_ids is inadequate or cannot be controlled.', 2, 3),
(4, 'R-AC-4', 1, 'Unauthorized access', 'Access is granted to unauthorized individuals, groups or services.', 2, 4),
(5, 'R-AM-1', 2, 'Lost, damaged or stolen asset(s)', 'Asset(s) is/are lost, damaged or stolen.', 2, 5),
(6, 'R-AM-2', 2, 'Loss of integrity through unauthorized changes ', 'Unauthorized changes corrupt the integrity of the system / application / service.', 2, 6),
(7, 'R-BC-1', 3, 'Business interruption ', 'There is increased latency or a service outage that negatively impacts business operations.', 5, 7),
(8, 'R-BC-2', 3, 'Data loss / corruption ', 'There is a failure to maintain the confidentiality of the data (compromise) or data is corrupted (loss).', 5, 8),
(12, 'R-BC-3', 3, 'Reduction in productivity', 'User productivity is negatively affected by the incident.', 2, 12),
(13, 'R-EX-1', 4, 'Loss of revenue ', 'A financial loss occures from either a loss of clients or inability to generate future revenue.', 5, 13),
(14, 'R-EX-2', 4, 'Cancelled contract', 'A contract is cancelled due to a violation of a contract clause.', 5, 14),
(15, 'R-EX-3', 4, 'Diminished competitive advantage', 'The competitive advantage of the organization is jeapordized.', 5, 15),
(16, 'R-EX-4', 4, 'Diminished reputation ', 'Negative publicity tarnishes the organization\'s reputation.', 5, 16),
(17, 'R-EX-5', 4, 'Fines and judgements', 'Legal and/or financial damages result from statutory / regulatory / contractual non-compliance.', 5, 17),
(18, 'R-EX-6', 4, 'Unmitigated vulnerabilities', 'Umitigated technical vulnerabilities exist without compensating controls or other mitigation actions.', 2, 18),
(19, 'R-EX-7', 4, 'System compromise', 'System / application / service is compromised affects its confidentiality, integrity,  availability and/or safety.', 2, 19),
(20, 'R-BC-4', 3, 'Information loss / corruption or system compromise due to technical attack', 'Malware, phishing, hacking or other technical attacks compromise data, systems, applications or services.', 2, 20),
(21, 'R-BC-5', 3, 'Information loss / corruption or system compromise due to non‐technical attack ', 'Social engineering, sabotage or other non-technical attack compromises data, systems, applications or services.', 2, 21),
(22, 'R-GV-1', 5, 'Inability to support business processes', 'Implemented security /privacy practices are insufficient to support the organization\'s secure technologies & processes requirements.', 2, 1),
(24, 'R-GV-4', 5, 'Inadequate internal practices ', 'Internal practices do not exist or are inadequate. Procedures fail to meet \\\"reasonable practices\\\" expected by industry standards.', 2, 4),
(25, 'R-GV-5', 5, 'Inadequate third-party practices', 'Third-party practices do not exist or are inadequate. Procedures fail to meet \\\"reasonable practices\\\" expected by industry standards.', 2, 5),
(26, 'R-GV-3', 5, 'Lack of roles & responsibilities', 'Documented security / privacy roles & responsibilities do not exist or are inadequate.', 1, 3),
(27, 'R-GV-2', 5, 'Incorrect controls scoping', 'There is incorrect or inadequate controls scoping, which leads to a potential gap or lapse in security / privacy controls coverage.', 1, 2),
(28, 'R-GV-8', 5, 'Illegal content or abusive action', 'There is abusive content / harmful speech / threats of violence / illegal content that negatively affect business operations.', 1, 8),
(29, 'R-SA-1', 6, 'Inability to maintain situational awareness', 'There is an inability to detect incidents.', 3, 29),
(30, 'R-SA-2', 6, 'Lack of a security-minded workforce', 'The workforce lacks user-level understanding about security & privacy principles.', 2, 30),
(31, 'R-GV-6', 5, 'Lack of oversight of internal controls', 'There is a lack of due diligence / due care in overseeing the organization\'s internal security / privacy controls.', 1, 6),
(32, 'R-GV-7', 5, 'Lack of oversight of third-party controls', 'There is a lack of due diligence / due care in overseeing security / privacy controls operated by third-party service providers.', 1, 7),
(33, 'R-IR-1', 7, 'Inability to investigate / prosecute incidents', 'Response actions either corrupt evidence or impede the ability to prosecute incidents.', 4, 1),
(34, 'R-IR-2', 7, 'Improper response to incidents', 'Response actions fail to act appropriately in a timely manner to properly address the incident.', 4, 2),
(35, 'R-IR-3', 7, 'Ineffective remediation actions', 'There is no oversight to ensure remediation actions are correct and/or effective.', 2, 3),
(36, 'R-IR-4', 7, 'Expense associated with managing a loss event', 'There are financial repercussions from responding to an incident or loss.', 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `risk_functions`
--

CREATE TABLE `risk_functions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_functions`
--

INSERT INTO `risk_functions` (`id`, `name`) VALUES
(1, 'Identify'),
(2, 'Protect'),
(3, 'Detect'),
(4, 'Respond'),
(5, 'Recover');

-- --------------------------------------------------------

--
-- Table structure for table `risk_groupings`
--

CREATE TABLE `risk_groupings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_groupings`
--

INSERT INTO `risk_groupings` (`id`, `name`) VALUES
(1, 'Access Control'),
(2, 'Asset Management'),
(3, 'Business Continuity'),
(4, 'Exposure'),
(5, 'Governance'),
(6, 'Situational Awareness'),
(7, 'Incident Response');

-- --------------------------------------------------------

--
-- Table structure for table `risk_levels`
--

CREATE TABLE `risk_levels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` decimal(3,1) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_level_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_levels`
--

INSERT INTO `risk_levels` (`id`, `value`, `name`, `color`, `display_name`, `review_level_id`) VALUES
(1, '0.0', 'Low', '#fff', 'Low', 2),
(2, '4.0', 'Medium', 'orange', 'Medium', 3),
(3, '7.0', 'High', 'orangered', 'High', 4),
(4, '10.1', 'Very High', 'red', 'Very High', 5);

-- --------------------------------------------------------

--
-- Table structure for table `risk_models`
--

CREATE TABLE `risk_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_models`
--

INSERT INTO `risk_models` (`id`, `name`) VALUES
(1, 'Likelihood x Impact + 2(Impact)'),
(2, 'Likelihood x Impact + Impact'),
(3, 'Likelihood x Impact'),
(4, 'Likelihood x Impact + Likelihood'),
(5, 'Likelihood x Impact + 2(Likelihood)'),
(6, 'Custom');

-- --------------------------------------------------------

--
-- Table structure for table `risk_scorings`
--

CREATE TABLE `risk_scorings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `scoring_method` int(11) NOT NULL,
  `calculated_risk` double(8,2) NOT NULL,
  `CLASSIC_likelihood` double(8,2) NOT NULL DEFAULT 5.00,
  `CLASSIC_impact` double(8,2) NOT NULL DEFAULT 5.00,
  `CVSS_AccessVector` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_AccessComplexity` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'L',
  `CVSS_Authentication` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `CVSS_ConfImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_IntegImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_AvailImpact` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `CVSS_Exploitability` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_RemediationLevel` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ReportConfidence` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_CollateralDamagePotential` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_TargetDistribution` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_ConfidentialityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_IntegrityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `CVSS_AvailabilityRequirement` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `DREAD_DamagePotential` int(11) NOT NULL DEFAULT 10,
  `DREAD_Reproducibility` int(11) NOT NULL DEFAULT 10,
  `DREAD_Exploitability` int(11) NOT NULL DEFAULT 10,
  `DREAD_AffectedUsers` int(11) NOT NULL DEFAULT 10,
  `DREAD_Discoverability` int(11) NOT NULL DEFAULT 10,
  `OWASP_SkillLevel` int(11) NOT NULL DEFAULT 10,
  `OWASP_Motive` int(11) NOT NULL DEFAULT 10,
  `OWASP_Opportunity` int(11) NOT NULL DEFAULT 10,
  `OWASP_Size` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfDiscovery` int(11) NOT NULL DEFAULT 10,
  `OWASP_EaseOfExploit` int(11) NOT NULL DEFAULT 10,
  `OWASP_Awareness` int(11) NOT NULL DEFAULT 10,
  `OWASP_IntrusionDetection` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfConfidentiality` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfIntegrity` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAvailability` int(11) NOT NULL DEFAULT 10,
  `OWASP_LossOfAccountability` int(11) NOT NULL DEFAULT 10,
  `OWASP_FinancialDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_ReputationDamage` int(11) NOT NULL DEFAULT 10,
  `OWASP_NonCompliance` int(11) NOT NULL DEFAULT 10,
  `OWASP_PrivacyViolation` int(11) NOT NULL DEFAULT 10,
  `Custom` double(8,2) NOT NULL DEFAULT 10.00,
  `Contributing_Likelihood` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_scorings`
--

INSERT INTO `risk_scorings` (`id`, `scoring_method`, `calculated_risk`, `CLASSIC_likelihood`, `CLASSIC_impact`, `CVSS_AccessVector`, `CVSS_AccessComplexity`, `CVSS_Authentication`, `CVSS_ConfImpact`, `CVSS_IntegImpact`, `CVSS_AvailImpact`, `CVSS_Exploitability`, `CVSS_RemediationLevel`, `CVSS_ReportConfidence`, `CVSS_CollateralDamagePotential`, `CVSS_TargetDistribution`, `CVSS_ConfidentialityRequirement`, `CVSS_IntegrityRequirement`, `CVSS_AvailabilityRequirement`, `DREAD_DamagePotential`, `DREAD_Reproducibility`, `DREAD_Exploitability`, `DREAD_AffectedUsers`, `DREAD_Discoverability`, `OWASP_SkillLevel`, `OWASP_Motive`, `OWASP_Opportunity`, `OWASP_Size`, `OWASP_EaseOfDiscovery`, `OWASP_EaseOfExploit`, `OWASP_Awareness`, `OWASP_IntrusionDetection`, `OWASP_LossOfConfidentiality`, `OWASP_LossOfIntegrity`, `OWASP_LossOfAvailability`, `OWASP_LossOfAccountability`, `OWASP_FinancialDamage`, `OWASP_ReputationDamage`, `OWASP_NonCompliance`, `OWASP_PrivacyViolation`, `Custom`, `Contributing_Likelihood`) VALUES
(1, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(2, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(3, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(4, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(5, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(6, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(7, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(8, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(9, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(10, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(11, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(12, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(13, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(14, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(15, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(16, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(17, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(18, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(19, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(20, 1, 1.20, 3.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(21, 1, 0.40, 1.00, 1.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(22, 1, 1.60, 2.00, 2.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(23, 1, 3.60, 3.00, 3.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(24, 1, 6.40, 4.00, 4.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0),
(25, 1, 10.00, 5.00, 5.00, 'N', 'L', 'N', 'C', 'C', 'C', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 'ND', 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `risk_scoring_contributing_impacts`
--

CREATE TABLE `risk_scoring_contributing_impacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_scoring_id` bigint(20) UNSIGNED NOT NULL,
  `contributing_risk_id` bigint(20) UNSIGNED NOT NULL,
  `impact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `risk_scoring_histories`
--

CREATE TABLE `risk_scoring_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `calculated_risk` double(8,2) NOT NULL,
  `last_update` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_scoring_histories`
--

INSERT INTO `risk_scoring_histories` (`id`, `risk_id`, `calculated_risk`, `last_update`) VALUES
(1, 1, 1.20, '2022-08-14 14:00:07'),
(2, 2, 1.20, '2022-08-14 14:00:08'),
(3, 3, 1.20, '2022-08-14 14:00:09'),
(4, 4, 1.20, '2022-08-14 14:00:10'),
(5, 5, 1.20, '2022-08-14 14:00:10'),
(6, 6, 1.20, '2022-08-14 14:00:10'),
(7, 7, 1.20, '2022-08-14 14:00:11'),
(8, 8, 1.20, '2022-08-14 14:00:12'),
(9, 9, 1.20, '2022-08-14 14:00:12'),
(10, 10, 1.20, '2022-08-14 14:00:12'),
(11, 11, 1.20, '2022-08-14 14:00:12'),
(12, 12, 1.20, '2022-08-14 14:00:12'),
(13, 13, 1.20, '2022-08-14 14:00:13'),
(14, 14, 1.20, '2022-08-14 14:00:13'),
(15, 15, 1.20, '2022-08-14 14:00:13'),
(16, 16, 1.20, '2022-08-14 14:00:13'),
(17, 17, 1.20, '2022-08-14 14:00:14'),
(18, 18, 1.20, '2022-08-14 14:00:14'),
(19, 19, 1.20, '2022-08-14 14:00:14'),
(20, 20, 1.20, '2022-08-14 14:00:14'),
(21, 21, 0.40, '2022-08-14 14:00:14'),
(22, 22, 1.60, '2022-08-14 14:00:15'),
(23, 23, 3.60, '2022-08-14 14:00:15'),
(24, 24, 6.40, '2022-08-14 14:00:15'),
(25, 25, 10.00, '2022-08-14 14:00:15');

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_additional_stakeholders`
--

CREATE TABLE `risk_to_additional_stakeholders` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_locations`
--

CREATE TABLE `risk_to_locations` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `location_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_to_locations`
--

INSERT INTO `risk_to_locations` (`risk_id`, `location_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20);

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_teams`
--

CREATE TABLE `risk_to_teams` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_to_teams`
--

INSERT INTO `risk_to_teams` (`risk_id`, `team_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20);

-- --------------------------------------------------------

--
-- Table structure for table `risk_to_technologies`
--

CREATE TABLE `risk_to_technologies` (
  `risk_id` bigint(20) UNSIGNED NOT NULL,
  `technology_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'Administrator'),
(2, 'employee');

-- --------------------------------------------------------

--
-- Table structure for table `role_responsibilities`
--

CREATE TABLE `role_responsibilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_responsibilities`
--

INSERT INTO `role_responsibilities` (`id`, `role_id`, `permission_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 1, 12),
(13, 1, 13),
(14, 1, 14),
(15, 1, 15),
(16, 1, 16),
(17, 1, 17),
(18, 1, 18),
(19, 1, 19),
(20, 1, 20),
(21, 1, 21),
(22, 1, 22),
(23, 1, 23),
(24, 1, 24),
(25, 1, 25),
(26, 1, 26),
(27, 1, 27),
(28, 1, 28),
(29, 1, 29),
(30, 1, 30),
(31, 1, 31),
(32, 1, 32),
(33, 1, 33),
(34, 1, 34),
(35, 1, 35),
(36, 1, 36),
(37, 1, 37),
(38, 1, 38),
(39, 1, 39),
(40, 1, 40),
(41, 1, 41),
(42, 1, 42),
(43, 1, 43),
(44, 1, 44),
(45, 1, 45),
(46, 1, 46),
(47, 1, 47),
(48, 1, 48),
(49, 1, 49),
(50, 1, 50),
(51, 1, 51),
(52, 1, 52),
(53, 1, 53),
(54, 1, 54),
(55, 1, 55),
(56, 1, 56),
(57, 1, 57),
(58, 1, 58),
(59, 1, 59),
(60, 1, 60),
(61, 1, 61),
(62, 1, 62),
(63, 1, 63),
(64, 1, 64),
(65, 1, 65),
(66, 1, 66),
(67, 1, 67),
(68, 1, 68),
(69, 1, 69),
(70, 1, 70),
(71, 1, 71),
(72, 1, 72),
(73, 1, 73),
(74, 1, 74),
(75, 1, 75),
(76, 1, 76),
(77, 1, 77),
(78, 1, 78),
(79, 1, 79),
(80, 1, 80),
(81, 1, 81),
(82, 1, 82),
(83, 1, 83),
(84, 1, 84),
(85, 1, 85),
(86, 1, 86),
(87, 1, 87),
(88, 1, 88),
(89, 1, 89),
(90, 1, 90),
(91, 1, 91),
(92, 1, 92),
(93, 1, 93),
(94, 1, 94),
(95, 1, 95),
(96, 1, 96),
(97, 1, 97),
(98, 1, 98),
(99, 1, 99),
(100, 1, 100),
(101, 1, 101),
(102, 1, 102),
(103, 1, 103),
(104, 1, 104),
(105, 1, 105),
(106, 1, 106),
(107, 1, 107),
(108, 1, 108),
(109, 1, 109),
(110, 1, 110),
(111, 1, 111),
(112, 1, 112),
(113, 1, 113),
(114, 1, 114),
(115, 1, 115),
(116, 1, 116),
(117, 1, 117),
(118, 1, 118),
(119, 1, 119),
(120, 1, 120),
(121, 1, 121),
(122, 1, 122),
(123, 1, 123),
(124, 1, 124),
(125, 1, 125),
(126, 1, 126),
(127, 1, 127),
(128, 1, 128),
(129, 1, 129),
(130, 1, 130),
(131, 1, 131),
(132, 1, 132),
(133, 1, 133),
(134, 1, 134),
(135, 2, 1),
(136, 2, 2),
(137, 2, 8),
(138, 2, 9),
(139, 2, 15),
(140, 2, 16),
(141, 2, 23),
(142, 2, 24),
(143, 2, 32),
(144, 2, 36),
(145, 2, 37),
(146, 2, 43),
(147, 2, 44),
(148, 2, 50),
(149, 2, 51),
(150, 2, 57),
(151, 2, 58),
(152, 2, 64),
(153, 2, 65),
(154, 2, 67),
(155, 2, 68),
(156, 2, 74),
(157, 2, 75),
(158, 2, 84),
(159, 2, 85),
(160, 2, 91),
(161, 2, 92),
(162, 2, 98),
(163, 2, 99),
(164, 2, 105),
(165, 2, 106),
(166, 2, 112),
(167, 2, 113),
(168, 2, 119),
(169, 2, 122),
(170, 2, 133);

-- --------------------------------------------------------

--
-- Table structure for table `scoring_methods`
--

CREATE TABLE `scoring_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `scoring_methods`
--

INSERT INTO `scoring_methods` (`id`, `name`) VALUES
(1, 'Classic');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` int(10) UNSIGNED DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `access`, `data`) VALUES
('6bj9dpmvnspkije86u619fe0qs', 1642430487, '7.71867878695E+30'),
('8ok8njqcf5t63br81g8qr5p4p0', 1642430179, 'INF'),
('midllcs1qvf6pf0h374i11ogrt', 1642432257, 'INF'),
('rm67us66590qs0mf7fit2bbgpl', 1642431450, 'INF');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`) VALUES
(1, 'alert_timeout', '5'),
(2, 'allow_ownermanager_to_risk', '1'),
(3, 'allow_owner_to_risk', '1'),
(4, 'allow_stakeholder_to_risk', '1'),
(5, 'allow_submitter_to_risk', '1'),
(6, 'allow_team_member_to_risk', '1'),
(7, 'auto_verify_new_assets', '0'),
(8, 'backup_auto', 'true'),
(9, 'backup_remove', '1'),
(10, 'backup_schedule', 'daily'),
(11, 'bootstrap_delivery_method', 'cdn'),
(12, 'closed_audit_status', '5'),
(13, 'content_security_policy', '0'),
(14, 'currency', '$'),
(15, 'db_version', '20211115-001'),
(16, 'debug_logging', '0'),
(17, 'debug_log_file', '/tmp/debug_log'),
(18, 'default_asset_valuation', '5'),
(19, 'default_current_maturity', '0'),
(20, 'default_date_format', 'MM/DD/YYYY'),
(21, 'default_desired_maturity', '3'),
(22, 'default_language', 'en'),
(23, 'default_risk_score', '10'),
(24, 'default_timezone', 'Asia/Riyadh'),
(25, 'highcharts_delivery_method', 'cdn'),
(26, 'instance_id', 'WtrZ7UYyt7XdoRsTKftzHI9uv5mdXFKPCRcZf83ZoUYRu0pxXZ'),
(27, 'jquery_delivery_method', 'cdn'),
(28, 'maximum_risk_subject_length', '300'),
(29, 'max_upload_size', '5120000'),
(30, 'next_review_date_uses', 'InherentRisk'),
(31, 'NOTIFY_ADDITIONAL_STAKEHOLDERS', 'true'),
(32, 'pass_policy_alpha_required', '1'),
(33, 'pass_policy_attempt_lockout', '0'),
(34, 'pass_policy_attempt_lockout_time', '10'),
(35, 'pass_policy_digits_required', '1'),
(36, 'pass_policy_enabled', '1'),
(37, 'pass_policy_lower_required', '1'),
(38, 'pass_policy_max_age', '0'),
(39, 'pass_policy_min_age', '0'),
(40, 'pass_policy_min_chars', '8'),
(41, 'pass_policy_reuse_limit', '0'),
(42, 'pass_policy_re_use_tracking', '0'),
(43, 'pass_policy_special_required', '1'),
(44, 'pass_policy_upper_required', '1'),
(45, 'phpmailer_from_email', 'noreply@simplerisk.it'),
(46, 'phpmailer_from_name', 'SimpleRisk'),
(47, 'phpmailer_host', 'smtp1.example.com'),
(48, 'phpmailer_password', 'secret'),
(49, 'phpmailer_port', '587'),
(50, 'phpmailer_prepend', '[SIMPLERISK]'),
(51, 'phpmailer_replyto_email', 'noreply@simplerisk.it'),
(52, 'phpmailer_replyto_name', 'SimpleRisk'),
(53, 'phpmailer_smtpauth', 'false'),
(54, 'phpmailer_smtpautotls', 'true'),
(55, 'phpmailer_smtpsecure', 'none'),
(56, 'phpmailer_transport', 'sendmail'),
(57, 'phpmailer_username', 'user@example.com'),
(58, 'plan_projects_show_all', '0'),
(59, 'registration_registered', '0'),
(60, 'risk_appetite', '0'),
(61, 'risk_mapping_required', '0'),
(62, 'risk_model', '3'),
(63, 'session_absolute_timeout', '28800'),
(64, 'session_activity_timeout', '3600'),
(65, 'simplerisk_base_url', 'http://localhost:8000'),
(66, 'strict_user_validation', '1'),
(67, 'LDAP_DEFAULT_HOSTS', 'www.zflexldap.com'),
(68, 'LDAP_DEFAULT_PORT', '389'),
(69, 'LDAP_DEFAULT_BASE_DN', 'dc=zflexsoftware,dc=com'),
(70, 'LDAP_DEFAULT_USERNAME', 'cn=ro_admin,ou=sysadmins,dc=zflexsoftware,dc=com'),
(71, 'LDAP_USER_FLITER', ''),
(72, 'LDAP_DEFAULT_PASSWORD', 'zflexpass'),
(73, 'LDAP_DEFAULT_SSL', 'false'),
(74, 'LDAP_DEFAULT_TLS', 'false'),
(75, 'LDAP_DEFAULT_VSERSION', '3'),
(76, 'LDAP_DEFAULT_TIMEOUT', '5'),
(77, 'LDAP_DEFAULT_Follow', 'false'),
(78, 'LDAP_name', ''),
(79, 'LDAP_email', ''),
(80, 'LDAP_username', ''),
(81, 'LDAP_password', ''),
(82, 'LDAP_dapartment', '');

-- --------------------------------------------------------

--
-- Table structure for table `sources`
--

CREATE TABLE `sources` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sources`
--

INSERT INTO `sources` (`id`, `name`) VALUES
(1, 'People'),
(2, 'Process'),
(3, 'System'),
(4, 'External');

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`) VALUES
(1, 'New'),
(2, 'Mitigation Planned'),
(3, 'Mgmt Reviewed'),
(4, 'Closed'),
(5, 'Reopened'),
(6, 'Untreated'),
(7, 'Treated');

-- --------------------------------------------------------

--
-- Table structure for table `subgroups`
--

CREATE TABLE `subgroups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_group_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subgroups`
--

INSERT INTO `subgroups` (`id`, `name`, `permission_group_id`, `created_at`, `updated_at`) VALUES
(1, 'Frameworks', 1, '2022-08-14 11:59:11', '2022-08-14 11:59:11'),
(2, 'Controls', 1, '2022-08-14 11:59:11', '2022-08-14 11:59:11'),
(3, 'Document', 1, '2022-08-14 11:59:11', '2022-08-14 11:59:11'),
(4, 'Exception', 1, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(5, 'Risks', 2, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(6, 'Projects', 2, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(7, 'Compliance', 3, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(8, 'Tests', 3, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(9, 'Audits', 3, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(10, 'Assets', 4, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(11, 'Assessments', 5, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(12, 'RoleManagement', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(13, 'Add Values', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(14, 'Audit Logs', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(15, 'Hierarchy', 7, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(16, 'Department', 7, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(17, 'Job', 7, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(18, 'Employee', 7, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(19, 'Plan Mitigation', 2, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(20, 'Perform Reviews', 2, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(21, 'AssetGroups', 4, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(22, 'Categories', 1, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(23, 'User Management', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(24, 'Settings', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(25, 'ClassicRiskFormula', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(26, 'Import And Export', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(27, 'LDAP', 6, '2022-08-14 11:59:12', '2022-08-14 11:59:12'),
(28, 'Reporting', 8, '2022-08-14 11:59:13', '2022-08-14 11:59:13'),
(29, 'Task', 9, '2022-08-14 11:59:13', '2022-08-14 11:59:13');

-- --------------------------------------------------------

--
-- Table structure for table `taggables`
--

CREATE TABLE `taggables` (
  `tag_id` bigint(20) UNSIGNED NOT NULL,
  `taggable_id` bigint(20) UNSIGNED NOT NULL,
  `taggable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `taggables`
--

INSERT INTO `taggables` (`tag_id`, `taggable_id`, `taggable_type`) VALUES
(1, 1, 'App\\Models\\Asset'),
(2, 1, 'App\\Models\\Asset'),
(3, 1, 'App\\Models\\Asset'),
(4, 1, 'App\\Models\\Asset'),
(5, 1, 'App\\Models\\Asset'),
(2, 2, 'App\\Models\\Asset'),
(3, 3, 'App\\Models\\Asset'),
(4, 4, 'App\\Models\\Asset'),
(5, 5, 'App\\Models\\Asset'),
(6, 6, 'App\\Models\\Asset'),
(7, 7, 'App\\Models\\Asset'),
(8, 8, 'App\\Models\\Asset'),
(9, 9, 'App\\Models\\Asset'),
(10, 10, 'App\\Models\\Asset');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tag` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `tag`) VALUES
(1, 'Tag 1'),
(10, 'Tag 10'),
(2, 'Tag 2'),
(3, 'Tag 3'),
(4, 'Tag 4'),
(5, 'Tag 5'),
(6, 'Tag 6'),
(7, 'Tag 7'),
(8, 'Tag 8'),
(9, 'Tag 9');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` enum('Urgent','High','Normal','Low','No Priority') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Open','In Progress','Completed','Accepted','Closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `completed_date` timestamp NULL DEFAULT NULL,
  `accepted_date` timestamp NULL DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT 0,
  `assignable_id` bigint(20) UNSIGNED NOT NULL,
  `assignable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `action_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `description`, `priority`, `status`, `start_date`, `due_date`, `completed_date`, `accepted_date`, `completed`, `assignable_id`, `assignable_type`, `created_by`, `action_by`, `created_at`, `updated_at`) VALUES
(1, 'title 1', 'description 1', 'No Priority', 'Open', '2022-06-01', '2022-06-02', NULL, NULL, 1, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 12:01:03', '2022-08-14 12:01:03'),
(2, 'title 2', 'description 2', 'Low', 'Open', '2022-06-02', '2022-06-04', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 12:01:04', '2022-08-14 12:01:04'),
(3, 'title 3', 'description 3', 'Normal', 'Open', '2022-06-03', '2022-06-06', NULL, NULL, 1, 1, 'App\\Models\\Team', 1, NULL, '2022-08-14 12:01:04', '2022-08-14 12:01:04'),
(4, 'title 4', 'description 4', 'High', 'Open', '2022-06-04', '2022-06-08', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 12:01:04', '2022-08-14 12:01:04'),
(5, 'title 5', 'description 5', 'Urgent', 'Open', '2022-06-05', '2022-06-10', NULL, NULL, 1, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 12:01:05', '2022-08-14 12:01:05'),
(6, 'title 6', 'description 6', 'No Priority', 'Open', '2022-06-06', '2022-06-12', NULL, NULL, 0, 1, 'App\\Models\\Team', 1, NULL, '2022-08-14 12:01:05', '2022-08-14 12:01:05'),
(7, 'title 7', 'description 7', 'Low', 'Open', '2022-06-07', '2022-06-14', NULL, NULL, 1, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 12:01:05', '2022-08-14 12:01:05'),
(8, 'title 8', 'description 8', 'Normal', 'Open', '2022-06-08', '2022-06-16', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 12:01:05', '2022-08-14 12:01:05'),
(9, 'title 9', 'description 9', 'High', 'Open', '2022-06-09', '2022-06-18', NULL, NULL, 1, 1, 'App\\Models\\Team', 1, NULL, '2022-08-14 12:01:05', '2022-08-14 12:01:05'),
(10, 'title 10', 'description 10', 'Urgent', 'Open', '2022-06-10', '2022-06-20', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 12:01:06', '2022-08-14 12:01:06'),
(11, 'gggg', '<p>ggg</p>', 'Normal', 'Open', '2022-08-14', '2022-08-24', NULL, NULL, 0, 1, 'App\\Models\\User', 1, NULL, '2022-08-14 15:35:58', '2022-08-14 15:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `task_notes`
--

CREATE TABLE `task_notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `note` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `task_notes`
--

INSERT INTO `task_notes` (`id`, `user_id`, `task_id`, `note`, `created_at`) VALUES
(1, 1, 11, 'gggfghfghgh', '2022-08-14 14:36:31'),
(2, 1, 1, 'ytuyu', '2022-08-17 11:16:58');

-- --------------------------------------------------------

--
-- Table structure for table `task_note_files`
--

CREATE TABLE `task_note_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `task_note_files`
--

INSERT INTO `task_note_files` (`id`, `user_id`, `task_id`, `display_name`, `unique_name`, `created_at`) VALUES
(1, 1, 1, 'app (2) (1).zip', 'task/1/notes/vgV2Uwd4fGlCaDaXzWk9R8gFJGxoECWE9c0iClyB.zip', '2022-08-17 11:17:01'),
(2, 1, 1, 'grc3.txt', 'task/1/notes/uKPiXSQq1VAwMNwDBnjDc1bSgL2XMPN7hmJDrQiS.txt', '2022-08-17 15:44:35');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`) VALUES
(1, 'Team 1'),
(2, 'Team 2'),
(3, 'Team 3'),
(4, 'Team 4'),
(5, 'Team 5'),
(6, 'Team 6'),
(7, 'Team 7'),
(8, 'Team 8'),
(9, 'Team 9'),
(10, 'Team 10'),
(11, 'Team 11'),
(12, 'Team 12'),
(13, 'Team 13'),
(14, 'Team 14'),
(15, 'Team 15'),
(16, 'Team 16'),
(17, 'Team 17'),
(18, 'Team 18'),
(19, 'Team 19'),
(20, 'Team 20');

-- --------------------------------------------------------

--
-- Table structure for table `technologies`
--

CREATE TABLE `technologies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `technologies`
--

INSERT INTO `technologies` (`id`, `name`) VALUES
(1, 'Todos'),
(2, 'Anti-Virus'),
(3, 'Backups'),
(4, 'Blackberry'),
(5, 'Citrix'),
(6, 'Datacenter'),
(7, 'Mail Routing'),
(8, 'Live Collaboration'),
(9, 'Mesajeria'),
(10, 'Mobile'),
(11, 'Network'),
(12, 'Power'),
(13, 'Remote Access'),
(14, 'SAN'),
(15, 'Telecom'),
(16, 'Unix'),
(17, 'VMWare'),
(18, 'Web'),
(19, 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_results`
--

CREATE TABLE `test_results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `background_class` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `test_results`
--

INSERT INTO `test_results` (`id`, `name`, `background_class`) VALUES
(1, 'Pass', 'green-background'),
(2, 'Inconclusive', 'white-background'),
(3, 'Fail', 'red-background');

-- --------------------------------------------------------

--
-- Table structure for table `test_statuses`
--

CREATE TABLE `test_statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `test_statuses`
--

INSERT INTO `test_statuses` (`id`, `name`) VALUES
(1, 'Pending Evidence from Control Owner'),
(2, 'Evidence Submitted / Pending Review'),
(3, 'Passed Internal QA'),
(4, 'Remediation Required'),
(5, 'Closed');

-- --------------------------------------------------------

--
-- Table structure for table `threat_catalogs`
--

CREATE TABLE `threat_catalogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `threat_grouping_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `threat_catalogs`
--

INSERT INTO `threat_catalogs` (`id`, `number`, `threat_grouping_id`, `name`, `description`, `order`) VALUES
(1, 'NT-1', 1, 'Drought & Water Shortage', 'Regardless of geographic location, periods of reduced rainfall are expected. For non-agricultural industries, drought may not be impactful to operations until it reaches the extent of water rationing.', 1),
(2, 'NT-2', 1, 'Earthquakes', 'Earthquakes are sudden rolling or shaking events caused by movement under the earth’s surface. Although earthquakes usually last less than one minute, the scope of devastation can be widespread and have long-lasting impact.', 2),
(3, 'NT-3', 1, 'Fire & Wildfires', 'Regardless of geographic location or even building material, fire is a concern for every business. When thinking of a fire in a building, envision a total loss to all technology hardware, including backup tapes, and all paper files being consumed in the fire.', 3),
(4, 'NT-4', 1, 'Floods', 'Flooding is the most common of natural hazards and requires an understanding of the local environment, including floodplains and the frequency of flooding events. Location of critical technologies should be considered (e.g., server room is in the basement or first floor of the facility).', 4),
(5, 'NT-5', 1, 'Hurricanes & Tropical Storms', 'Hurricanes and tropical storms are among the most powerful natural disasters because of their size and destructive potential. In addition to high winds, regional flooding and infrastructure damage should be considered when assessing hurricanes and tropical storms.', 5),
(6, 'NT-6', 1, 'Landslides & Debris Flow', 'Landslides occur throughout the world and can be caused by a variety of factors including earthquakes, storms, volcanic eruptions, fire, and by human modification of land. Landslides can occur quickly, often with little notice. Location of critical technologies should be considered (e.g., server room is in the basement or first floor of the facility).', 6),
(7, 'NT-7', 1, 'Pandemic (Disease) Outbreaks', 'Due to the wide variety of possible scenarios, consideration should be given both to the magnitude of what can reasonably happen during a pandemic outbreak (e.g., COVID-19, Influenza, SARS, Ebola, etc.) and what actions the business can be taken to help lessen the impact of a  pandemic on operations.', 7),
(8, 'NT-8', 1, 'Severe Weather', 'Severe weather is a broad category of meteorological events that include events that range from damaging winds to hail.', 8),
(9, 'NT-9', 1, 'Space Weather', 'Space weather includes natural events in space that can affect the near-earth environment and satellites. Most commonly, this is associated with solar flares from the Sun, so an understanding of how solar flares may impact the business is of critical importance in assessing this threat.', 9),
(10, 'NT-10', 1, 'Thunderstorms & Lightning', 'Thunderstorms are most prevalent in the spring and summer months and generally occur during the afternoon and evening hours, but they can occur year-round and at all hours. Many hazardous weather events are associated with thunderstorms. Under the right conditions, rainfall from thunderstorms causes flash flooding and lightning is responsible for equipment damage, fires and fatalities.', 10),
(11, 'NT-11', 1, 'Tornadoes', 'Tornadoes occur in many parts of the world, including the US, Australia, Europe, Africa, Asia, and South America. Tornadoes can happen at any time of year and occur at any time of day or night, but most tornadoes occur between 4–9 p.m. Tornadoes (with winds up to about 300 mph) can destroy all but the best-built man-made structures.', 11),
(12, 'NT-12', 1, 'Tsunamis', 'All tsunamis are potentially dangerous, even though they may not damage every coastline they strike. A tsunami can strike anywhere along most of the US coastline. The most destructive tsunamis have occurred along the coasts of California, Oregon, Washington, Alaska and Hawaii.', 12),
(13, 'NT-13', 1, 'Volcanoes', 'While volcanoes are geographically fixed objects, volcanic fallout can have significant downwind impacts for thousands of miles. Far outside of the blast zone, volcanoes can significantly damage or degrade transportation systems and also cause electrical grids to fail.', 13),
(14, 'NT-14', 1, 'Winter Storms & Extreme Cold', 'Winter storms is a broad category of meteorological events that include events that range from ice storms, to heavy snowfall, to unseasonably (e.g., record breaking) cold temperatures. Winter storms can significantly impact business operations and transportation systems over a wide geographic region.', 14),
(15, 'MT-1', 2, 'Civil or Political Unrest', 'Civil or political unrest can be singular or wide-spread events that can be unexpected and unpredictable. These events can occur anywhere, at any time.', 15),
(16, 'MT-2', 2, 'Hacking & Other Cybersecurity Crimes', 'Unlike physical threats that prompt immediate action (e.g., \\\"stop, drop, and roll\\\" in the event of a fire), cyber incidents are often difficult to identify as the incident is occurring. Detection generally occurs after the incident has occurred, with the exception of \\\"denial of service\\\" attacks. The spectrum of cybersecurity risks is limitless and threats can have wide-ranging effects on the individual, organizational, geographic, and national levels.', 16),
(17, 'MT-3', 2, 'Hazardous Materials Emergencies', 'Hazardous materials emergencies are focused on accidental disasters that occur in industrialized nations. These incidents can range from industrial chemical spills to groundwater contamination.', 17),
(18, 'MT-4', 2, 'Nuclear, Biological and Chemical (NBC) Weapons', 'The use of NBC weapons are in the possible arsenals of international terrorists and it must be a consideration. Terrorist use of a “dirty bomb” — is considered far more likely than use of a traditional nuclear explosive device. This may be a combination a conventional explosive device with radioactive / chemical / biological material and be designed to scatter lethal and sub-lethal amounts of material over a wide area.', 18),
(19, 'MT-5', 2, 'Physical Crime', 'Physical crime includes \\\"traditional\\\" crimes of opportunity. These incidents can range from theft, to vandalism, riots, looting, arson and other forms of criminal activities.', 19),
(20, 'MT-6', 2, 'Terrorism & Armed Attacks', 'Armed attacks, regardless of the motivation of the attacker, can impact a businesses. Scenarios can range from single actors (e.g., \\\"disgruntled\\\" employee) all the way to a coordinated terrorist attack by multiple assailants. These incidents can range from the use of blade weapons (e.g., knives), blunt objects (e.g., clubs), to firearms and explosives.', 20),
(21, 'MT-7', 2, 'Utility Service Disruption', 'Utility service disruptions are focused on the sustained loss of electricity, Internet, natural gas, water, and/or sanitation services. These incidents can have a variety of causes but  directly impact the fulfillment of utility services that your business needs to operate.', 21);

-- --------------------------------------------------------

--
-- Table structure for table `threat_groupings`
--

CREATE TABLE `threat_groupings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `threat_groupings`
--

INSERT INTO `threat_groupings` (`id`, `name`) VALUES
(1, 'Natural Threat'),
(2, 'Man-Made Threat');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `lockout` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'grc',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salt` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `lang` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `multi_factor` int(11) NOT NULL DEFAULT 1,
  `ldap_department` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_password` tinyint(1) NOT NULL DEFAULT 0,
  `custom_display_settings` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `manager_id` bigint(20) UNSIGNED DEFAULT NULL,
  `job_id` bigint(20) UNSIGNED DEFAULT NULL,
  `custom_plan_mitigation_display_settings` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{"risk_colums":[["id","1"],["risk_status","1"],["subject","1"],["calculated_risk","1"],["submission_date","1"]],"mitigation_colums":[["mitigation_planned","1"]],"review_colums":[["management_review","1"]]}\n',
  `custom_perform_reviews_display_settings` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{"risk_colums":[["id","1"],["risk_status","1"],["subject","1"],["calculated_risk","1"],["submission_date","1"]],"mitigation_colums":[["mitigation_planned","1"]],"review_colums":[["management_review","1"]]}\n',
  `custom_reviewregularly_display_settings` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{"risk_colums":[["id","1"],["risk_status","1"],["subject","1"],["calculated_risk","1"],["days_open","1"]],"review_colums":[["management_review","0"],["review_date","0"],["next_step","0"],["next_review_date","1"],["comments","0"]]}'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `enabled`, `lockout`, `type`, `username`, `name`, `email`, `salt`, `password`, `last_login`, `last_password_change_date`, `role_id`, `lang`, `admin`, `multi_factor`, `ldap_department`, `change_password`, `custom_display_settings`, `department_id`, `manager_id`, `job_id`, `custom_plan_mitigation_display_settings`, `custom_perform_reviews_display_settings`, `custom_reviewregularly_display_settings`) VALUES
(1, 1, 0, 'grc', 'admin', 'Admin', 'admin@gmail.com', 'qCJpnAe5S6k61Pqh3SFG', '$2y$10$Rggt4jd0gUaU6Q4uKrHlzOFoGcVjo7A0gRgERnU6xbs7WrmoEE7YW', '2022-01-17 09:00:33', '2017-01-08 07:58:20', 1, NULL, 1, 1, NULL, 0, '[\\\"id\\\",\\\"subject\\\",\\\"calculated_risk\\\",\\\"submission_date\\\",\\\"mitigation_planned\\\",\\\"management_review\\\"]', 1, NULL, 1, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}', '{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"submission_date\\\",\\\"1\\\"]],\\\"mitigation_colums\\\":[[\\\"mitigation_planned\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"1\\\"]]}\\n', '{\\\"risk_colums\\\":[[\\\"id\\\",\\\"1\\\"],[\\\"risk_status\\\",\\\"1\\\"],[\\\"subject\\\",\\\"1\\\"],[\\\"calculated_risk\\\",\\\"1\\\"],[\\\"days_open\\\",\\\"1\\\"]],\\\"review_colums\\\":[[\\\"management_review\\\",\\\"0\\\"],[\\\"review_date\\\",\\\"0\\\"],[\\\"next_step\\\",\\\"0\\\"],[\\\"next_review_date\\\",\\\"1\\\"],[\\\"comments\\\",\\\"0\\\"]]}'),
(2, 1, 0, 'grc', 'Department1Manager', 'Department1Manager', 'department1manager@mail.com', NULL, '$2y$10$80424kelTqv/wxVNVJ5WIOT.kcC27orR98SLi/n2KD5G0CyM.Dk2O', NULL, '2022-08-14 10:59:35', 1, NULL, 0, 1, NULL, 0, '', 1, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(3, 1, 0, 'grc', 'Department2Manager', 'Department2Manager', 'department2manager@mail.com', NULL, '$2y$10$bsbRupPIscKlmNwFw8sAJu4d5uB/F2JxuVuYDS.5Ir1hIHx9YU1uq', NULL, '2022-08-14 10:59:36', 1, NULL, 0, 1, NULL, 0, '', 2, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(4, 1, 0, 'grc', 'Department3Manager', 'Department3Manager', 'department3manager@mail.com', NULL, '$2y$10$IHu2/5Bs6S7VzSz9dJNEOuo7kLZEXjeugsYz4e5oV723fE0mmvgF6', NULL, '2022-08-14 10:59:36', 1, NULL, 0, 1, NULL, 0, '', 3, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(5, 1, 0, 'grc', 'Department4Manager', 'Department4Manager', 'department4manager@mail.com', NULL, '$2y$10$qAiLExPJlbiWGGAtEtqjOujulb3uvkVU25SzhhgTRsI70UO4v20/W', NULL, '2022-08-14 10:59:36', 1, NULL, 0, 1, NULL, 0, '', 4, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(6, 1, 0, 'grc', 'Department5Manager', 'Department5Manager', 'department5manager@mail.com', NULL, '$2y$10$KQOu9UpkAPrTk4KBFrsW7.aHPksktp0ddst6A0SU5LnI6/9dYWq9m', NULL, '2022-08-14 10:59:36', 1, NULL, 0, 1, NULL, 0, '', 5, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(7, 1, 0, 'grc', 'Department6Manager', 'Department6Manager', 'department6manager@mail.com', NULL, '$2y$10$vt0djdAMoD59YfkLdQEhlu7tU7b1OsbFe0Fiwmp.M8UBqwHiLMWr2', NULL, '2022-08-14 10:59:36', 1, NULL, 0, 1, NULL, 0, '', 6, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(8, 1, 0, 'grc', 'Department7Manager', 'Department7Manager', 'department7manager@mail.com', NULL, '$2y$10$QfZBgGGRoJeaKrlTX8lJZOIOCTqCbvSfStkbXBgTjhKjxoD.gAX5K', NULL, '2022-08-14 10:59:36', 1, NULL, 0, 1, NULL, 0, '', 7, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(9, 1, 0, 'grc', 'Department8Manager', 'Department8Manager', 'department8manager@mail.com', NULL, '$2y$10$IiDyvD2vLOAQBPRqJr/oNea/9/ZrdfKS32Ll5NOG4fwkIs7BWIu5q', NULL, '2022-08-14 10:59:37', 1, NULL, 0, 1, NULL, 0, '', 8, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(10, 1, 0, 'grc', 'Department9Manager', 'Department9Manager', 'department9manager@mail.com', NULL, '$2y$10$QZs/TRrfGEGpUdqvvSUYjuUSXSIxH0cXQfD1Ne9EKLHbVbYnYzOzi', NULL, '2022-08-14 10:59:37', 1, NULL, 0, 1, NULL, 0, '', 9, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(11, 1, 0, 'grc', 'Department10Manager', 'Department10Manager', 'department10manager@mail.com', NULL, '$2y$10$WXizEY9cNEfYNiKJAspIzu6itqHpSRSS30qp/k34zwOU6reS5pfcy', NULL, '2022-08-14 10:59:37', 1, NULL, 0, 1, NULL, 0, '', 10, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(12, 1, 0, 'grc', 'Department11Manager', 'Department11Manager', 'department11manager@mail.com', NULL, '$2y$10$UDueEy7tcdOyMJYrRTVGtOV7RX5tYsLIHr3vTGMJyed/b4wWjSarq', NULL, '2022-08-14 10:59:37', 1, NULL, 0, 1, NULL, 0, '', 11, 1, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(13, 1, 0, 'grc', 'Department12Manager', 'Department12Manager', 'department12manager@mail.com', NULL, '$2y$10$irov6t7SHjXLUMKp7ZPv5Okh6dbG4pXwW3mpmKE8loQFibCLJHSKm', NULL, '2022-08-14 10:59:37', 1, NULL, 0, 1, NULL, 0, '', 12, 2, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(14, 1, 0, 'grc', 'Department13Manager', 'Department13Manager', 'department13manager@mail.com', NULL, '$2y$10$i2MIRfoLDhAZff/AvtEZ7.YeKqFPuJZyArO/VzIbzJCxLUxowzNAO', NULL, '2022-08-14 10:59:38', 1, NULL, 0, 1, NULL, 0, '', 13, 3, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(15, 1, 0, 'grc', 'Department14Manager', 'Department14Manager', 'department14manager@mail.com', NULL, '$2y$10$mokV0OLwXsrTPttxWojr7e1mZT2IFWvAVs0OHE9pHiL.uWRcfcvIa', NULL, '2022-08-14 10:59:38', 1, NULL, 0, 1, NULL, 0, '', 14, 4, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(16, 1, 0, 'grc', 'Department15Manager', 'Department15Manager', 'department15manager@mail.com', NULL, '$2y$10$j4X9PTOPEEYS7yL9tMmlqe6DaWJ6Y8gMk6XXQVQCHuCsh3.3Ivv5G', NULL, '2022-08-14 10:59:38', 1, NULL, 0, 1, NULL, 0, '', 15, 5, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(17, 1, 0, 'grc', 'Department16Manager', 'Department16Manager', 'department16manager@mail.com', NULL, '$2y$10$4PK43hFKdrOhMvMyKU8Bqex8Yf4xd9lCNR5YeH/6om7WzT/hvmRI2', NULL, '2022-08-14 10:59:38', 1, NULL, 0, 1, NULL, 0, '', 16, 6, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(18, 1, 0, 'grc', 'Department17Manager', 'Department17Manager', 'department17manager@mail.com', NULL, '$2y$10$jo0H/V35.KOj0RFTJ7AWtuHNi5qPhiPpHwp7uf/36pjjDuiauKc82', NULL, '2022-08-14 10:59:38', 1, NULL, 0, 1, NULL, 0, '', 17, 7, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(19, 1, 0, 'grc', 'Department18Manager', 'Department18Manager', 'department18manager@mail.com', NULL, '$2y$10$YNFfzCM5Ko1iefU0yUXo9uLKw4fSJpWzIsxUd.i5KrqyZl5XGNlDa', NULL, '2022-08-14 10:59:39', 1, NULL, 0, 1, NULL, 0, '', 18, 8, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(20, 1, 0, 'grc', 'Department19Manager', 'Department19Manager', 'department19manager@mail.com', NULL, '$2y$10$pzSn9bD63cDoubwnS5r7IOekLwIxN7bYLouP0Uy9JJHIT7ae2PKwe', NULL, '2022-08-14 10:59:39', 1, NULL, 0, 1, NULL, 0, '', 19, 9, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(21, 1, 0, 'grc', 'Department20Manager', 'Department20Manager', 'department20manager@mail.com', NULL, '$2y$10$nBwbGnHrtf6vzLo.8koHFehTD3wp9xmPzJqwN12GvjZ5PmwsFBAgS', NULL, '2022-08-14 10:59:39', 1, NULL, 0, 1, NULL, 0, '', 20, 10, 2, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(22, 1, 0, 'grc', 'Employee1Manager', 'Employee1Manager', 'employee1manager@mail.com', NULL, '$2y$10$G545hzfm9ZV3BzBAIoHrw.EyVu0gHQpYtOUuOK1ZXQ/wN02WhLIe2', NULL, '2022-08-14 10:59:39', 1, NULL, 0, 1, NULL, 0, '', 2, 3, 4, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(23, 1, 0, 'grc', 'Employee2Manager', 'Employee2Manager', 'employee2manager@mail.com', NULL, '$2y$10$6CcGMqx8ly7zkJBg.RtCYuz55rehr0wnSus5MKZ0PMkPSME9NmMmi', NULL, '2022-08-14 10:59:39', 1, NULL, 0, 1, NULL, 0, '', 4, 5, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(24, 1, 0, 'grc', 'Employee3Manager', 'Employee3Manager', 'employee3manager@mail.com', NULL, '$2y$10$5v3yG6G6KvFysGF22BRyqu.PadJ8RmlAEOcqflB82jGHp9Ud/UNsO', NULL, '2022-08-14 10:59:39', 1, NULL, 0, 1, NULL, 0, '', 6, 7, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(25, 1, 0, 'grc', 'Employee4Manager', 'Employee4Manager', 'employee4manager@mail.com', NULL, '$2y$10$zO/5EAqXbZ1/VEvGnYpT0eaIHZNSWIkHySAMVWY9CgKkr.6mzplU.', NULL, '2022-08-14 10:59:40', 1, NULL, 0, 1, NULL, 0, '', 8, 9, 10, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(26, 1, 0, 'grc', 'Employee5Manager', 'Employee5Manager', 'employee5manager@mail.com', NULL, '$2y$10$vxpuqhHDr4aca6tgmI.vBOSq6jYPVMVx.3P71u2JAo5tWYC7EHsZW', NULL, '2022-08-14 10:59:40', 1, NULL, 0, 1, NULL, 0, '', 10, 11, 12, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(27, 1, 0, 'grc', 'Employee6Manager', 'Employee6Manager', 'employee6manager@mail.com', NULL, '$2y$10$qRG.l3fEMW0XlLtCgWl8aO5DUJOBBYfZrT0FMOYX/le0wj1kdt0IK', NULL, '2022-08-14 10:59:40', 1, NULL, 0, 1, NULL, 0, '', 12, 13, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(28, 1, 0, 'grc', 'Employee7Manager', 'Employee7Manager', 'employee7manager@mail.com', NULL, '$2y$10$WNkSfOcD6mNRp8U7R0uDZ.9KbDQmttar2.bKqf63mPsNdFYox9f5u', NULL, '2022-08-14 10:59:40', 1, NULL, 0, 1, NULL, 0, '', 14, 15, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(29, 1, 0, 'grc', 'Employee8Manager', 'Employee8Manager', 'employee8manager@mail.com', NULL, '$2y$10$i9GjOAq8U.SXBu.T292WoOqo8tv5Zu2UlhK4qnT20Kv57E61NDuKi', NULL, '2022-08-14 10:59:40', 1, NULL, 0, 1, NULL, 0, '', 16, 17, 11, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(30, 1, 0, 'grc', 'Employee9Manager', 'Employee9Manager', 'employee9manager@mail.com', NULL, '$2y$10$Lfq7PyPre2ifkIj.wB8xhuhU4dpunoVLdTSOX4PxAcfTJYO9Y3k72', NULL, '2022-08-14 10:59:40', 1, NULL, 0, 1, NULL, 0, '', 18, 19, 4, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(31, 1, 0, 'grc', 'Employee10Manager', 'Employee10Manager', 'employee10manager@mail.com', NULL, '$2y$10$VM6Yit08YqWbwmuzkKjc5O67ENagFlaml4lVgNqVmBfiKSOP2biwG', NULL, '2022-08-14 10:59:40', 1, NULL, 0, 1, NULL, 0, '', 20, 21, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(32, 1, 0, 'grc', 'Employee1', 'Employee1', 'employee1@mail.com', NULL, '$2y$10$K4BdL7AIoZ.gB2mjD3/esOZnHL1uPGuqzGuO6.DDY5BJ64i8xHtHC', NULL, '2022-08-14 10:59:41', 1, NULL, 0, 1, NULL, 0, '', 1, 2, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(33, 1, 0, 'grc', 'Employee2', 'Employee2', 'employee2@mail.com', NULL, '$2y$10$ImdAnT3vUk3o87rIJ/d5Nua6A63OCZEy.ujv8AsoIXhL7uKoLTAO6', NULL, '2022-08-14 10:59:41', 1, NULL, 0, 1, NULL, 0, '', 2, 3, 11, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(34, 1, 0, 'grc', 'Employee3', 'Employee3', 'employee3@mail.com', NULL, '$2y$10$2wjbyAZbJNuPqnvCTTZ3tu4rT8pN/hIT873eEPBtDhr9NbszA7/b6', NULL, '2022-08-14 10:59:41', 1, NULL, 0, 1, NULL, 0, '', 3, 4, 9, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(35, 1, 0, 'grc', 'Employee4', 'Employee4', 'employee4@mail.com', NULL, '$2y$10$aIiLAXNp8o3owUGrNxbpBuHRH8jPAkv8s6N6gX2dhnJ75HfZ1.JFq', NULL, '2022-08-14 10:59:42', 1, NULL, 0, 1, NULL, 0, '', 4, 5, 12, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(36, 1, 0, 'grc', 'Employee5', 'Employee5', 'employee5@mail.com', NULL, '$2y$10$TDXymCbKuW44av49AVCZ8OA3DCWG4b.0OI4oQ6nZoJnopMwjmWgpG', NULL, '2022-08-14 10:59:42', 1, NULL, 0, 1, NULL, 0, '', 5, 6, 11, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(37, 1, 0, 'grc', 'Employee6', 'Employee6', 'employee6@mail.com', NULL, '$2y$10$boECml7Okjx3HqOsC6A4wOrrryV/ykFPXtlL5SCjY5AHH.ioPcgt2', NULL, '2022-08-14 10:59:42', 1, NULL, 0, 1, NULL, 0, '', 6, 7, 8, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(38, 1, 0, 'grc', 'Employee7', 'Employee7', 'employee7@mail.com', NULL, '$2y$10$3oLa1VLKMiKtOubYtWqgheHDvUJyQnWN7qdayA8bFnkp2926Rz/V2', NULL, '2022-08-14 10:59:42', 1, NULL, 0, 1, NULL, 0, '', 7, 8, 8, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(39, 1, 0, 'grc', 'Employee8', 'Employee8', 'employee8@mail.com', NULL, '$2y$10$P44421wbFNU.72U1y3lUR.C6457PzAuACGkOIoeyxwb.CoPwoO.xi', NULL, '2022-08-14 10:59:42', 1, NULL, 0, 1, NULL, 0, '', 8, 9, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(40, 1, 0, 'grc', 'Employee9', 'Employee9', 'employee9@mail.com', NULL, '$2y$10$MFzIGOUmeF514STM4lx8Hei2RPa2dfQ5tbjLZEPMSBjlL1eIX6kBG', NULL, '2022-08-14 10:59:42', 1, NULL, 0, 1, NULL, 0, '', 9, 10, 3, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(41, 1, 0, 'grc', 'Employee10', 'Employee10', 'employee10@mail.com', NULL, '$2y$10$YdJnQB5HAXLUi1uYg5dMM.0zT.FUG92/1G0LW3Hf0yPb39LkIsjKa', NULL, '2022-08-14 10:59:43', 1, NULL, 0, 1, NULL, 0, '', 10, 11, 6, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(42, 1, 0, 'grc', 'Employee11', 'Employee11', 'employee11@mail.com', NULL, '$2y$10$EL8HyRR86AuMv3kQIBU5sel5shsnvA0/jMVc54p24ScpOqf78kBIy', NULL, '2022-08-14 10:59:43', 1, NULL, 0, 1, NULL, 0, '', 11, 12, 4, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(43, 1, 0, 'grc', 'Employee12', 'Employee12', 'employee12@mail.com', NULL, '$2y$10$lzl.wcAp/ZHUIHBtLPv88uZ0kIND.9nIoSWfiym9eD6wN0EZAR4vi', NULL, '2022-08-14 10:59:43', 1, NULL, 0, 1, NULL, 0, '', 12, 13, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(44, 1, 0, 'grc', 'Employee13', 'Employee13', 'employee13@mail.com', NULL, '$2y$10$Bbg/fJc8d5tT1aeYEGvRfeY2FZAV4IgRo9hDenYs4o5Oht/nP29tS', NULL, '2022-08-14 10:59:43', 1, NULL, 0, 1, NULL, 0, '', 13, 14, 9, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(45, 1, 0, 'grc', 'Employee14', 'Employee14', 'employee14@mail.com', NULL, '$2y$10$mfSRFVyCz.8SzPhgjW78KeU2yvSoJCNWTSZ81MBgUCD4B0xG/34k.', NULL, '2022-08-14 10:59:43', 1, NULL, 0, 1, NULL, 0, '', 14, 15, 10, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(46, 1, 0, 'grc', 'Employee15', 'Employee15', 'employee15@mail.com', NULL, '$2y$10$aQvut6TwtMs.Usyl3j91B./rJWRPuApvOQUPfMjRst3Z1L67Tw1XO', NULL, '2022-08-14 10:59:43', 1, NULL, 0, 1, NULL, 0, '', 15, 16, 7, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(47, 1, 0, 'grc', 'Employee16', 'Employee16', 'employee16@mail.com', NULL, '$2y$10$S/k7.IVFXlkIH/rfdTG1wedL4aAG4IEOqNsEK5eij0k07Ku3ObDcq', NULL, '2022-08-14 10:59:43', 1, NULL, 0, 1, NULL, 0, '', 16, 17, 11, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(48, 1, 0, 'grc', 'Employee17', 'Employee17', 'employee17@mail.com', NULL, '$2y$10$BGpj.PH6ZpzGW0KHLz8vu.hD9KJp.ZjUiz3tf6tD1ND5IaimfKn.2', NULL, '2022-08-14 10:59:44', 1, NULL, 0, 1, NULL, 0, '', 17, 18, 5, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(49, 1, 0, 'grc', 'Employee18', 'Employee18', 'employee18@mail.com', NULL, '$2y$10$kqPjG3e/ozb1zVMaeaS9Levk9lmG74KE8sWcvF0My4Fh3eFJemwh2', NULL, '2022-08-14 10:59:44', 1, NULL, 0, 1, NULL, 0, '', 18, 19, 3, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}');
INSERT INTO `users` (`id`, `enabled`, `lockout`, `type`, `username`, `name`, `email`, `salt`, `password`, `last_login`, `last_password_change_date`, `role_id`, `lang`, `admin`, `multi_factor`, `ldap_department`, `change_password`, `custom_display_settings`, `department_id`, `manager_id`, `job_id`, `custom_plan_mitigation_display_settings`, `custom_perform_reviews_display_settings`, `custom_reviewregularly_display_settings`) VALUES
(50, 1, 0, 'grc', 'Employee19', 'Employee19', 'employee19@mail.com', NULL, '$2y$10$tfsX0kKF1h7uUPyMln0z6eFH4KOVHUPt8pT5Pcl3XaU9S0laNRtEe', NULL, '2022-08-14 10:59:44', 1, NULL, 0, 1, NULL, 0, '', 19, 20, 6, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}'),
(51, 1, 0, 'grc', 'Employee20', 'Employee20', 'employee20@mail.com', NULL, '$2y$10$jKIAZNeQD0BlHBxcDoabWegxtkJDLW/yf.XaFPisa5TRPmb84JS3O', NULL, '2022-08-14 10:59:44', 1, NULL, 0, 1, NULL, 0, '', 20, 21, 6, '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"submission_date\",\"1\"]],\"mitigation_colums\":[[\"mitigation_planned\",\"1\"]],\"review_colums\":[[\"management_review\",\"1\"]]}\n', '{\"risk_colums\":[[\"id\",\"1\"],[\"risk_status\",\"1\"],[\"subject\",\"1\"],[\"calculated_risk\",\"1\"],[\"days_open\",\"1\"]],\"review_colums\":[[\"management_review\",\"0\"],[\"review_date\",\"0\"],[\"next_step\",\"0\"],[\"next_review_date\",\"1\"],[\"comments\",\"0\"]]}');

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `is_read` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_notifications`
--

INSERT INTO `user_notifications` (`id`, `user_id`, `notification_id`, `is_read`, `created_at`, `updated_at`) VALUES
(1, 1, 41, 0, NULL, NULL),
(2, 1, 42, 0, NULL, NULL),
(3, 1, 44, 0, NULL, NULL),
(4, 1, 45, 0, NULL, NULL),
(5, 1, 47, 0, NULL, NULL),
(6, 1, 48, 0, NULL, NULL),
(7, 1, 50, 0, NULL, NULL),
(8, 1, 51, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_pass_histories`
--

CREATE TABLE `user_pass_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `salt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_pass_reuse_histories`
--

CREATE TABLE `user_pass_reuse_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `counts` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_to_teams`
--

CREATE TABLE `user_to_teams` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_to_teams`
--

INSERT INTO `user_to_teams` (`user_id`, `team_id`) VALUES
(51, 1),
(51, 3);

-- --------------------------------------------------------

--
-- Table structure for table `validation_files`
--

CREATE TABLE `validation_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `mitigation_id` bigint(20) UNSIGNED NOT NULL,
  `control_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `user` int(11) NOT NULL,
  `content` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessments`
--
ALTER TABLE `assessments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assessment_answers`
--
ALTER TABLE `assessment_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_answers_assessment_id_foreign` (`assessment_id`),
  ADD KEY `assessment_answers_assessment_scoring_id_foreign` (`assessment_scoring_id`);

--
-- Indexes for table `assessment_answers_to_assets`
--
ALTER TABLE `assessment_answers_to_assets`
  ADD UNIQUE KEY `assessment_answer_asset_unique` (`assessment_answer_id`,`asset_id`),
  ADD KEY `assessment_answers_to_assets_asset_id_foreign` (`asset_id`);

--
-- Indexes for table `assessment_answers_to_asset_groups`
--
ALTER TABLE `assessment_answers_to_asset_groups`
  ADD UNIQUE KEY `assessment_answer_asset_group_unique` (`assessment_answer_id`,`asset_group_id`),
  ADD KEY `assessment_answers_to_asset_groups_asset_group_id_foreign` (`asset_group_id`);

--
-- Indexes for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_questions_assessment_id_foreign` (`assessment_id`);

--
-- Indexes for table `assessment_scorings`
--
ALTER TABLE `assessment_scorings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assessment_scoring_contributing_impacts`
--
ALTER TABLE `assessment_scoring_contributing_impacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `A_S_C_I_A_S_id_foreign` (`assessment_scoring_id`),
  ADD KEY `A_S_C_I_C_R_id_foreign` (`contributing_risk_id`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `assets_asset_value_id_foreign` (`asset_value_id`),
  ADD KEY `assets_location_id_foreign` (`location_id`);

--
-- Indexes for table `asset_asset_groups`
--
ALTER TABLE `asset_asset_groups`
  ADD UNIQUE KEY `asset_asset_group_unique` (`asset_id`,`asset_group_id`),
  ADD KEY `asset_asset_groups_asset_group_id_foreign` (`asset_group_id`);

--
-- Indexes for table `asset_groups`
--
ALTER TABLE `asset_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- Indexes for table `asset_values`
--
ALTER TABLE `asset_values`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD KEY `audit_logs_user_id_foreign` (`user_id`);

--
-- Indexes for table `backups`
--
ALTER TABLE `backups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `close_reasons`
--
ALTER TABLE `close_reasons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `closures`
--
ALTER TABLE `closures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `closures_risk_id_foreign` (`risk_id`),
  ADD KEY `closures_user_id_foreign` (`user_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `compliance_files`
--
ALTER TABLE `compliance_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contributing_risks`
--
ALTER TABLE `contributing_risks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contributing_risks_impacts`
--
ALTER TABLE `contributing_risks_impacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contributing_risks_impacts_contributing_risks_id_foreign` (`contributing_risks_id`);

--
-- Indexes for table `contributing_risks_likelihoods`
--
ALTER TABLE `contributing_risks_likelihoods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_classes`
--
ALTER TABLE `control_classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_desired_maturities`
--
ALTER TABLE `control_desired_maturities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_maturities`
--
ALTER TABLE `control_maturities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_owners`
--
ALTER TABLE `control_owners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_phases`
--
ALTER TABLE `control_phases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_priorities`
--
ALTER TABLE `control_priorities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control_types`
--
ALTER TABLE `control_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_risk_model_values`
--
ALTER TABLE `custom_risk_model_values`
  ADD UNIQUE KEY `impact_likelihood_unique` (`impact_id`,`likelihood_id`),
  ADD KEY `custom_risk_model_values_likelihood_id_foreign` (`likelihood_id`);

--
-- Indexes for table `cvss_scorings`
--
ALTER TABLE `cvss_scorings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_classifications`
--
ALTER TABLE `data_classifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `date_formats`
--
ALTER TABLE `date_formats`
  ADD PRIMARY KEY (`value`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `departments_code_unique` (`code`),
  ADD KEY `departments_parent_id_foreign` (`parent_id`),
  ADD KEY `departments_color_id_foreign` (`color_id`),
  ADD KEY `departments_manager_id_foreign` (`manager_id`);

--
-- Indexes for table `department_colors`
--
ALTER TABLE `department_colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `documents_document_type_foreign` (`document_type`),
  ADD KEY `documents_privacy_foreign` (`privacy`),
  ADD KEY `documents_document_reviewer_foreign` (`document_reviewer`);

--
-- Indexes for table `document_exceptions`
--
ALTER TABLE `document_exceptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_exceptions_statuses`
--
ALTER TABLE `document_exceptions_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_notes`
--
ALTER TABLE `document_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `document_notes_user_id_foreign` (`user_id`),
  ADD KEY `document_notes_document_id_foreign` (`document_id`);

--
-- Indexes for table `document_note_files`
--
ALTER TABLE `document_note_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `document_note_files_user_id_foreign` (`user_id`),
  ADD KEY `document_note_files_document_id_foreign` (`document_id`);

--
-- Indexes for table `document_statuses`
--
ALTER TABLE `document_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_types`
--
ALTER TABLE `document_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dynamic_saved_selections`
--
ALTER TABLE `dynamic_saved_selections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dynamic_saved_selections_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_login_attempts`
--
ALTER TABLE `failed_login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `failed_login_attempts_user_id_foreign` (`user_id`);

--
-- Indexes for table `families`
--
ALTER TABLE `families`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `files_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `file_tasks`
--
ALTER TABLE `file_tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `file_tasks_task_id_foreign` (`task_id`);

--
-- Indexes for table `file_types`
--
ALTER TABLE `file_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `file_type_extensions`
--
ALTER TABLE `file_type_extensions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `frameworks`
--
ALTER TABLE `frameworks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `framework_controls`
--
ALTER TABLE `framework_controls`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_controls_family_foreign` (`family`),
  ADD KEY `framework_controls_control_owner_foreign` (`control_owner`),
  ADD KEY `framework_controls_desired_maturity_foreign` (`desired_maturity`),
  ADD KEY `framework_controls_control_priority_foreign` (`control_priority`),
  ADD KEY `framework_controls_control_class_foreign` (`control_class`),
  ADD KEY `framework_controls_control_maturity_foreign` (`control_maturity`),
  ADD KEY `framework_controls_control_phase_foreign` (`control_phase`);

--
-- Indexes for table `framework_control_mappings`
--
ALTER TABLE `framework_control_mappings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_mappings_framework_control_id_foreign` (`framework_control_id`),
  ADD KEY `framework_control_mappings_framework_id_foreign` (`framework_id`);

--
-- Indexes for table `framework_control_tests`
--
ALTER TABLE `framework_control_tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_tests_framework_control_id_foreign` (`framework_control_id`);

--
-- Indexes for table `framework_control_test_audits`
--
ALTER TABLE `framework_control_test_audits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_audits_test_id_foreign` (`test_id`),
  ADD KEY `framework_control_test_audits_framework_control_id_foreign` (`framework_control_id`);

--
-- Indexes for table `framework_control_test_comments`
--
ALTER TABLE `framework_control_test_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_comments_test_audit_id_foreign` (`test_audit_id`);

--
-- Indexes for table `framework_control_test_results`
--
ALTER TABLE `framework_control_test_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_results_test_audit_id_foreign` (`test_audit_id`);

--
-- Indexes for table `framework_control_test_results_to_risks`
--
ALTER TABLE `framework_control_test_results_to_risks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_test_results_to_risks_test_results_id_foreign` (`test_results_id`),
  ADD KEY `framework_control_test_results_to_risks_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `framework_control_to_frameworks`
--
ALTER TABLE `framework_control_to_frameworks`
  ADD PRIMARY KEY (`control_id`,`framework_id`),
  ADD KEY `framework_id` (`framework_id`,`control_id`);

--
-- Indexes for table `framework_control_type_mappings`
--
ALTER TABLE `framework_control_type_mappings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `framework_control_type_mappings_control_id_foreign` (`control_id`),
  ADD KEY `framework_control_type_mappings_control_type_id_foreign` (`control_type_id`);

--
-- Indexes for table `framework_icons`
--
ALTER TABLE `framework_icons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `impacts`
--
ALTER TABLE `impacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items_to_teams`
--
ALTER TABLE `items_to_teams`
  ADD UNIQUE KEY `item_team_unique` (`item_id`,`team_id`,`type`),
  ADD KEY `item_type` (`item_id`,`type`),
  ADD KEY `team_type` (`team_id`,`type`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `jobs_code_unique` (`code`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likelihoods`
--
ALTER TABLE `likelihoods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mgmt_reviews`
--
ALTER TABLE `mgmt_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mgmt_reviews_risk_id_foreign` (`risk_id`),
  ADD KEY `mgmt_reviews_review_foreign` (`review`),
  ADD KEY `mgmt_reviews_reviewer_foreign` (`reviewer`),
  ADD KEY `mgmt_reviews_next_step_id_foreign` (`next_step_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mitigations`
--
ALTER TABLE `mitigations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mitigations_planning_strategy_foreign` (`planning_strategy`),
  ADD KEY `mitigations_mitigation_effort_foreign` (`mitigation_effort`),
  ADD KEY `mitigations_mitigation_owner_foreign` (`mitigation_owner`),
  ADD KEY `mitigations_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `mitigation_accept_users`
--
ALTER TABLE `mitigation_accept_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mitigation_accept_users_risk_id_foreign` (`risk_id`),
  ADD KEY `mitigation_accept_users_user_id_foreign` (`user_id`);

--
-- Indexes for table `mitigation_efforts`
--
ALTER TABLE `mitigation_efforts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mitigation_to_controls`
--
ALTER TABLE `mitigation_to_controls`
  ADD PRIMARY KEY (`mitigation_id`,`control_id`),
  ADD KEY `control_id` (`control_id`,`mitigation_id`);

--
-- Indexes for table `mitigation_to_teams`
--
ALTER TABLE `mitigation_to_teams`
  ADD PRIMARY KEY (`mitigation_id`,`team_id`),
  ADD KEY `team_id` (`team_id`,`mitigation_id`);

--
-- Indexes for table `next_steps`
--
ALTER TABLE `next_steps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pending_risks`
--
ALTER TABLE `pending_risks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pending_risks_assessment_id_foreign` (`assessment_id`),
  ADD KEY `pending_risks_assessment_answer_id_foreign` (`assessment_answer_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `permissions_subgroup_id_foreign` (`subgroup_id`);

--
-- Indexes for table `permission_groups`
--
ALTER TABLE `permission_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `permission_to_permission_groups`
--
ALTER TABLE `permission_to_permission_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_to_permission_groups_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_to_permission_groups_permission_group_id_foreign` (`permission_group_id`);

--
-- Indexes for table `permission_to_users`
--
ALTER TABLE `permission_to_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_to_users_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_to_users_user_id_foreign` (`user_id`);

--
-- Indexes for table `planning_strategies`
--
ALTER TABLE `planning_strategies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privacies`
--
ALTER TABLE `privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questionnaire_pending_risks`
--
ALTER TABLE `questionnaire_pending_risks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regulations`
--
ALTER TABLE `regulations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `residual_risk_scoring_histories`
--
ALTER TABLE `residual_risk_scoring_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `residual_risk_scoring_histories_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review_levels`
--
ALTER TABLE `review_levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risks`
--
ALTER TABLE `risks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risks_control_id_foreign` (`control_id`),
  ADD KEY `risks_source_id_foreign` (`source_id`),
  ADD KEY `risks_category_id_foreign` (`category_id`),
  ADD KEY `risks_owner_id_foreign` (`owner_id`),
  ADD KEY `risks_manager_id_foreign` (`manager_id`),
  ADD KEY `risks_mitigation_id_foreign` (`mitigation_id`),
  ADD KEY `risks_project_id_foreign` (`project_id`),
  ADD KEY `status` (`status`),
  ADD KEY `regulation` (`regulation`),
  ADD KEY `mgmt_review` (`mgmt_review`),
  ADD KEY `close_id` (`close_id`),
  ADD KEY `submitted_by` (`submitted_by`);

--
-- Indexes for table `risks_to_assets`
--
ALTER TABLE `risks_to_assets`
  ADD UNIQUE KEY `risk_id` (`risk_id`,`asset_id`),
  ADD KEY `asset_id` (`asset_id`,`risk_id`);

--
-- Indexes for table `risks_to_asset_groups`
--
ALTER TABLE `risks_to_asset_groups`
  ADD UNIQUE KEY `risk_asset_group_unique` (`risk_id`,`asset_group_id`),
  ADD KEY `asset_group_id` (`asset_group_id`,`risk_id`);

--
-- Indexes for table `risk_catalogs`
--
ALTER TABLE `risk_catalogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_catalogs_risk_grouping_id_foreign` (`risk_grouping_id`),
  ADD KEY `risk_catalogs_risk_function_id_foreign` (`risk_function_id`);

--
-- Indexes for table `risk_functions`
--
ALTER TABLE `risk_functions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risk_groupings`
--
ALTER TABLE `risk_groupings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risk_levels`
--
ALTER TABLE `risk_levels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_levels_review_level_id_foreign` (`review_level_id`);

--
-- Indexes for table `risk_models`
--
ALTER TABLE `risk_models`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `risk_scorings`
--
ALTER TABLE `risk_scorings`
  ADD KEY `risk_scorings_id_foreign` (`id`),
  ADD KEY `calculated_risk` (`calculated_risk`);

--
-- Indexes for table `risk_scoring_contributing_impacts`
--
ALTER TABLE `risk_scoring_contributing_impacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_scoring_contributing_impacts_risk_scoring_id_foreign` (`risk_scoring_id`),
  ADD KEY `risk_scoring_contributing_impacts_contributing_risk_id_foreign` (`contributing_risk_id`);

--
-- Indexes for table `risk_scoring_histories`
--
ALTER TABLE `risk_scoring_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `risk_scoring_histories_risk_id_foreign` (`risk_id`);

--
-- Indexes for table `risk_to_additional_stakeholders`
--
ALTER TABLE `risk_to_additional_stakeholders`
  ADD PRIMARY KEY (`risk_id`,`user_id`),
  ADD KEY `user_id` (`user_id`,`risk_id`);

--
-- Indexes for table `risk_to_locations`
--
ALTER TABLE `risk_to_locations`
  ADD PRIMARY KEY (`risk_id`,`location_id`),
  ADD KEY `location_id` (`location_id`,`risk_id`);

--
-- Indexes for table `risk_to_teams`
--
ALTER TABLE `risk_to_teams`
  ADD PRIMARY KEY (`risk_id`,`team_id`),
  ADD KEY `team_id` (`team_id`,`risk_id`);

--
-- Indexes for table `risk_to_technologies`
--
ALTER TABLE `risk_to_technologies`
  ADD PRIMARY KEY (`risk_id`,`technology_id`),
  ADD KEY `technology_id` (`technology_id`,`risk_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_responsibilities`
--
ALTER TABLE `role_responsibilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_responsibilities_role_id_foreign` (`role_id`),
  ADD KEY `role_responsibilities_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `scoring_methods`
--
ALTER TABLE `scoring_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sources`
--
ALTER TABLE `sources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subgroups`
--
ALTER TABLE `subgroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subgroups_permission_group_id_foreign` (`permission_group_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag_unique` (`tag`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_created_by_foreign` (`created_by`),
  ADD KEY `tasks_action_by_foreign` (`action_by`);

--
-- Indexes for table `task_notes`
--
ALTER TABLE `task_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_notes_user_id_foreign` (`user_id`),
  ADD KEY `task_notes_task_id_foreign` (`task_id`);

--
-- Indexes for table `task_note_files`
--
ALTER TABLE `task_note_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_note_files_user_id_foreign` (`user_id`),
  ADD KEY `task_note_files_task_id_foreign` (`task_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `technologies`
--
ALTER TABLE `technologies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_results`
--
ALTER TABLE `test_results`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- Indexes for table `test_statuses`
--
ALTER TABLE `test_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `threat_catalogs`
--
ALTER TABLE `threat_catalogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `threat_catalogs_threat_grouping_id_foreign` (`threat_grouping_id`);

--
-- Indexes for table `threat_groupings`
--
ALTER TABLE `threat_groupings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`),
  ADD KEY `users_department_id_foreign` (`department_id`),
  ADD KEY `users_manager_id_foreign` (`manager_id`),
  ADD KEY `users_job_id_foreign` (`job_id`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_notifications_notification_id_foreign` (`notification_id`);

--
-- Indexes for table `user_pass_histories`
--
ALTER TABLE `user_pass_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_pass_histories_user_id_foreign` (`user_id`);

--
-- Indexes for table `user_pass_reuse_histories`
--
ALTER TABLE `user_pass_reuse_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_pass_reuse_histories_user_id_foreign` (`user_id`);

--
-- Indexes for table `user_to_teams`
--
ALTER TABLE `user_to_teams`
  ADD PRIMARY KEY (`user_id`,`team_id`),
  ADD KEY `team_id` (`team_id`,`user_id`);

--
-- Indexes for table `validation_files`
--
ALTER TABLE `validation_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `validation_files_mitigation_id_foreign` (`mitigation_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assessments`
--
ALTER TABLE `assessments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assessment_answers`
--
ALTER TABLE `assessment_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assessment_scorings`
--
ALTER TABLE `assessment_scorings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assessment_scoring_contributing_impacts`
--
ALTER TABLE `assessment_scoring_contributing_impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `asset_groups`
--
ALTER TABLE `asset_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `asset_values`
--
ALTER TABLE `asset_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `backups`
--
ALTER TABLE `backups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `close_reasons`
--
ALTER TABLE `close_reasons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `closures`
--
ALTER TABLE `closures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `compliance_files`
--
ALTER TABLE `compliance_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contributing_risks`
--
ALTER TABLE `contributing_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contributing_risks_impacts`
--
ALTER TABLE `contributing_risks_impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `contributing_risks_likelihoods`
--
ALTER TABLE `contributing_risks_likelihoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `control_classes`
--
ALTER TABLE `control_classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `control_desired_maturities`
--
ALTER TABLE `control_desired_maturities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `control_maturities`
--
ALTER TABLE `control_maturities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `control_owners`
--
ALTER TABLE `control_owners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `control_phases`
--
ALTER TABLE `control_phases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `control_priorities`
--
ALTER TABLE `control_priorities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `control_types`
--
ALTER TABLE `control_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cvss_scorings`
--
ALTER TABLE `cvss_scorings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `data_classifications`
--
ALTER TABLE `data_classifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `department_colors`
--
ALTER TABLE `department_colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `document_exceptions`
--
ALTER TABLE `document_exceptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_exceptions_statuses`
--
ALTER TABLE `document_exceptions_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `document_notes`
--
ALTER TABLE `document_notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `document_note_files`
--
ALTER TABLE `document_note_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `document_statuses`
--
ALTER TABLE `document_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `document_types`
--
ALTER TABLE `document_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dynamic_saved_selections`
--
ALTER TABLE `dynamic_saved_selections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_login_attempts`
--
ALTER TABLE `failed_login_attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `families`
--
ALTER TABLE `families`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `fields`
--
ALTER TABLE `fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `file_tasks`
--
ALTER TABLE `file_tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `file_types`
--
ALTER TABLE `file_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `file_type_extensions`
--
ALTER TABLE `file_type_extensions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `frameworks`
--
ALTER TABLE `frameworks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `framework_controls`
--
ALTER TABLE `framework_controls`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `framework_control_mappings`
--
ALTER TABLE `framework_control_mappings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `framework_control_tests`
--
ALTER TABLE `framework_control_tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_control_test_audits`
--
ALTER TABLE `framework_control_test_audits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_control_test_comments`
--
ALTER TABLE `framework_control_test_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_control_test_results`
--
ALTER TABLE `framework_control_test_results`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_control_test_results_to_risks`
--
ALTER TABLE `framework_control_test_results_to_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_control_type_mappings`
--
ALTER TABLE `framework_control_type_mappings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `framework_icons`
--
ALTER TABLE `framework_icons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `impacts`
--
ALTER TABLE `impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `likelihoods`
--
ALTER TABLE `likelihoods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `mgmt_reviews`
--
ALTER TABLE `mgmt_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `mitigations`
--
ALTER TABLE `mitigations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `mitigation_accept_users`
--
ALTER TABLE `mitigation_accept_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mitigation_efforts`
--
ALTER TABLE `mitigation_efforts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `next_steps`
--
ALTER TABLE `next_steps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `pending_risks`
--
ALTER TABLE `pending_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `permission_groups`
--
ALTER TABLE `permission_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `permission_to_permission_groups`
--
ALTER TABLE `permission_to_permission_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `permission_to_users`
--
ALTER TABLE `permission_to_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `planning_strategies`
--
ALTER TABLE `planning_strategies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `privacies`
--
ALTER TABLE `privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questionnaire_pending_risks`
--
ALTER TABLE `questionnaire_pending_risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `regulations`
--
ALTER TABLE `regulations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `residual_risk_scoring_histories`
--
ALTER TABLE `residual_risk_scoring_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `review_levels`
--
ALTER TABLE `review_levels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `risks`
--
ALTER TABLE `risks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `risk_catalogs`
--
ALTER TABLE `risk_catalogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `risk_functions`
--
ALTER TABLE `risk_functions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `risk_groupings`
--
ALTER TABLE `risk_groupings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `risk_levels`
--
ALTER TABLE `risk_levels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `risk_models`
--
ALTER TABLE `risk_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `risk_scoring_contributing_impacts`
--
ALTER TABLE `risk_scoring_contributing_impacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `risk_scoring_histories`
--
ALTER TABLE `risk_scoring_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `role_responsibilities`
--
ALTER TABLE `role_responsibilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `scoring_methods`
--
ALTER TABLE `scoring_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `sources`
--
ALTER TABLE `sources`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subgroups`
--
ALTER TABLE `subgroups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `task_notes`
--
ALTER TABLE `task_notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `task_note_files`
--
ALTER TABLE `task_note_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `technologies`
--
ALTER TABLE `technologies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test_results`
--
ALTER TABLE `test_results`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `test_statuses`
--
ALTER TABLE `test_statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `threat_catalogs`
--
ALTER TABLE `threat_catalogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `threat_groupings`
--
ALTER TABLE `threat_groupings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_pass_histories`
--
ALTER TABLE `user_pass_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_pass_reuse_histories`
--
ALTER TABLE `user_pass_reuse_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `validation_files`
--
ALTER TABLE `validation_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assessment_answers`
--
ALTER TABLE `assessment_answers`
  ADD CONSTRAINT `assessment_answers_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`),
  ADD CONSTRAINT `assessment_answers_assessment_scoring_id_foreign` FOREIGN KEY (`assessment_scoring_id`) REFERENCES `assessment_scorings` (`id`);

--
-- Constraints for table `assessment_answers_to_assets`
--
ALTER TABLE `assessment_answers_to_assets`
  ADD CONSTRAINT `assessment_answers_to_assets_assessment_answer_id_foreign` FOREIGN KEY (`assessment_answer_id`) REFERENCES `assessment_answers` (`id`),
  ADD CONSTRAINT `assessment_answers_to_assets_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `assessment_answers_to_asset_groups`
--
ALTER TABLE `assessment_answers_to_asset_groups`
  ADD CONSTRAINT `assessment_answers_to_asset_groups_assessment_answer_id_foreign` FOREIGN KEY (`assessment_answer_id`) REFERENCES `assessment_answers` (`id`),
  ADD CONSTRAINT `assessment_answers_to_asset_groups_asset_group_id_foreign` FOREIGN KEY (`asset_group_id`) REFERENCES `asset_groups` (`id`);

--
-- Constraints for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  ADD CONSTRAINT `assessment_questions_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`);

--
-- Constraints for table `assessment_scoring_contributing_impacts`
--
ALTER TABLE `assessment_scoring_contributing_impacts`
  ADD CONSTRAINT `A_S_C_I_A_S_id_foreign` FOREIGN KEY (`assessment_scoring_id`) REFERENCES `assessment_scorings` (`id`),
  ADD CONSTRAINT `A_S_C_I_C_R_id_foreign` FOREIGN KEY (`contributing_risk_id`) REFERENCES `contributing_risks` (`id`);

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_asset_value_id_foreign` FOREIGN KEY (`asset_value_id`) REFERENCES `asset_values` (`id`),
  ADD CONSTRAINT `assets_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`);

--
-- Constraints for table `asset_asset_groups`
--
ALTER TABLE `asset_asset_groups`
  ADD CONSTRAINT `asset_asset_groups_asset_group_id_foreign` FOREIGN KEY (`asset_group_id`) REFERENCES `asset_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_asset_groups_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `closures`
--
ALTER TABLE `closures`
  ADD CONSTRAINT `closures_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `closures_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contributing_risks_impacts`
--
ALTER TABLE `contributing_risks_impacts`
  ADD CONSTRAINT `contributing_risks_impacts_contributing_risks_id_foreign` FOREIGN KEY (`contributing_risks_id`) REFERENCES `contributing_risks` (`id`);

--
-- Constraints for table `custom_risk_model_values`
--
ALTER TABLE `custom_risk_model_values`
  ADD CONSTRAINT `custom_risk_model_values_impact_id_foreign` FOREIGN KEY (`impact_id`) REFERENCES `impacts` (`id`),
  ADD CONSTRAINT `custom_risk_model_values_likelihood_id_foreign` FOREIGN KEY (`likelihood_id`) REFERENCES `likelihoods` (`id`);

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `department_colors` (`id`),
  ADD CONSTRAINT `departments_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `departments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_document_reviewer_foreign` FOREIGN KEY (`document_reviewer`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `documents_document_type_foreign` FOREIGN KEY (`document_type`) REFERENCES `document_types` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `documents_privacy_foreign` FOREIGN KEY (`privacy`) REFERENCES `privacies` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `document_notes`
--
ALTER TABLE `document_notes`
  ADD CONSTRAINT `document_notes_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `document_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `document_note_files`
--
ALTER TABLE `document_note_files`
  ADD CONSTRAINT `document_note_files_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `document_note_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `dynamic_saved_selections`
--
ALTER TABLE `dynamic_saved_selections`
  ADD CONSTRAINT `dynamic_saved_selections_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `failed_login_attempts`
--
ALTER TABLE `failed_login_attempts`
  ADD CONSTRAINT `failed_login_attempts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `file_tasks`
--
ALTER TABLE `file_tasks`
  ADD CONSTRAINT `file_tasks_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `framework_controls`
--
ALTER TABLE `framework_controls`
  ADD CONSTRAINT `framework_controls_control_class_foreign` FOREIGN KEY (`control_class`) REFERENCES `control_classes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_maturity_foreign` FOREIGN KEY (`control_maturity`) REFERENCES `control_maturities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_owner_foreign` FOREIGN KEY (`control_owner`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_phase_foreign` FOREIGN KEY (`control_phase`) REFERENCES `control_phases` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_control_priority_foreign` FOREIGN KEY (`control_priority`) REFERENCES `control_priorities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_desired_maturity_foreign` FOREIGN KEY (`desired_maturity`) REFERENCES `control_desired_maturities` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `framework_controls_family_foreign` FOREIGN KEY (`family`) REFERENCES `families` (`id`);

--
-- Constraints for table `framework_control_mappings`
--
ALTER TABLE `framework_control_mappings`
  ADD CONSTRAINT `framework_control_mappings_framework_control_id_foreign` FOREIGN KEY (`framework_control_id`) REFERENCES `framework_controls` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_control_mappings_framework_id_foreign` FOREIGN KEY (`framework_id`) REFERENCES `frameworks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `framework_control_tests`
--
ALTER TABLE `framework_control_tests`
  ADD CONSTRAINT `framework_control_tests_framework_control_id_foreign` FOREIGN KEY (`framework_control_id`) REFERENCES `framework_controls` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `framework_control_test_audits`
--
ALTER TABLE `framework_control_test_audits`
  ADD CONSTRAINT `framework_control_test_audits_framework_control_id_foreign` FOREIGN KEY (`framework_control_id`) REFERENCES `framework_controls` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `framework_control_test_audits_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `framework_control_tests` (`id`);

--
-- Constraints for table `framework_control_test_comments`
--
ALTER TABLE `framework_control_test_comments`
  ADD CONSTRAINT `framework_control_test_comments_test_audit_id_foreign` FOREIGN KEY (`test_audit_id`) REFERENCES `framework_control_test_audits` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `framework_control_test_results`
--
ALTER TABLE `framework_control_test_results`
  ADD CONSTRAINT `framework_control_test_results_test_audit_id_foreign` FOREIGN KEY (`test_audit_id`) REFERENCES `framework_control_test_audits` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `framework_control_test_results_to_risks`
--
ALTER TABLE `framework_control_test_results_to_risks`
  ADD CONSTRAINT `framework_control_test_results_to_risks_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`),
  ADD CONSTRAINT `framework_control_test_results_to_risks_test_results_id_foreign` FOREIGN KEY (`test_results_id`) REFERENCES `framework_control_test_results` (`id`);

--
-- Constraints for table `framework_control_to_frameworks`
--
ALTER TABLE `framework_control_to_frameworks`
  ADD CONSTRAINT `framework_control_to_frameworks_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `framework_control_to_frameworks_framework_id_foreign` FOREIGN KEY (`framework_id`) REFERENCES `frameworks` (`id`);

--
-- Constraints for table `framework_control_type_mappings`
--
ALTER TABLE `framework_control_type_mappings`
  ADD CONSTRAINT `framework_control_type_mappings_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `framework_control_type_mappings_control_type_id_foreign` FOREIGN KEY (`control_type_id`) REFERENCES `control_types` (`id`);

--
-- Constraints for table `items_to_teams`
--
ALTER TABLE `items_to_teams`
  ADD CONSTRAINT `items_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`);

--
-- Constraints for table `mgmt_reviews`
--
ALTER TABLE `mgmt_reviews`
  ADD CONSTRAINT `mgmt_reviews_next_step_id_foreign` FOREIGN KEY (`next_step_id`) REFERENCES `next_steps` (`id`),
  ADD CONSTRAINT `mgmt_reviews_review_foreign` FOREIGN KEY (`review`) REFERENCES `reviews` (`id`),
  ADD CONSTRAINT `mgmt_reviews_reviewer_foreign` FOREIGN KEY (`reviewer`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `mgmt_reviews_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mitigations`
--
ALTER TABLE `mitigations`
  ADD CONSTRAINT `mitigations_mitigation_effort_foreign` FOREIGN KEY (`mitigation_effort`) REFERENCES `mitigation_efforts` (`id`),
  ADD CONSTRAINT `mitigations_mitigation_owner_foreign` FOREIGN KEY (`mitigation_owner`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `mitigations_planning_strategy_foreign` FOREIGN KEY (`planning_strategy`) REFERENCES `planning_strategies` (`id`),
  ADD CONSTRAINT `mitigations_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mitigation_accept_users`
--
ALTER TABLE `mitigation_accept_users`
  ADD CONSTRAINT `mitigation_accept_users_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mitigation_accept_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `mitigation_to_controls`
--
ALTER TABLE `mitigation_to_controls`
  ADD CONSTRAINT `mitigation_to_controls_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `mitigation_to_controls_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mitigation_to_teams`
--
ALTER TABLE `mitigation_to_teams`
  ADD CONSTRAINT `mitigation_to_teams_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mitigation_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`);

--
-- Constraints for table `pending_risks`
--
ALTER TABLE `pending_risks`
  ADD CONSTRAINT `pending_risks_assessment_answer_id_foreign` FOREIGN KEY (`assessment_answer_id`) REFERENCES `assessment_answers` (`id`),
  ADD CONSTRAINT `pending_risks_assessment_id_foreign` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`);

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_subgroup_id_foreign` FOREIGN KEY (`subgroup_id`) REFERENCES `subgroups` (`id`);

--
-- Constraints for table `permission_to_permission_groups`
--
ALTER TABLE `permission_to_permission_groups`
  ADD CONSTRAINT `permission_to_permission_groups_permission_group_id_foreign` FOREIGN KEY (`permission_group_id`) REFERENCES `permission_groups` (`id`),
  ADD CONSTRAINT `permission_to_permission_groups_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`);

--
-- Constraints for table `permission_to_users`
--
ALTER TABLE `permission_to_users`
  ADD CONSTRAINT `permission_to_users_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `permission_to_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `residual_risk_scoring_histories`
--
ALTER TABLE `residual_risk_scoring_histories`
  ADD CONSTRAINT `residual_risk_scoring_histories_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risks`
--
ALTER TABLE `risks`
  ADD CONSTRAINT `risks_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `risks_control_id_foreign` FOREIGN KEY (`control_id`) REFERENCES `framework_controls` (`id`),
  ADD CONSTRAINT `risks_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `risks_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`),
  ADD CONSTRAINT `risks_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `risks_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  ADD CONSTRAINT `risks_source_id_foreign` FOREIGN KEY (`source_id`) REFERENCES `sources` (`id`);

--
-- Constraints for table `risks_to_assets`
--
ALTER TABLE `risks_to_assets`
  ADD CONSTRAINT `risks_to_assets_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risks_to_assets_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risks_to_asset_groups`
--
ALTER TABLE `risks_to_asset_groups`
  ADD CONSTRAINT `risks_to_asset_groups_asset_group_id_foreign` FOREIGN KEY (`asset_group_id`) REFERENCES `asset_groups` (`id`),
  ADD CONSTRAINT `risks_to_asset_groups_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_catalogs`
--
ALTER TABLE `risk_catalogs`
  ADD CONSTRAINT `risk_catalogs_risk_function_id_foreign` FOREIGN KEY (`risk_function_id`) REFERENCES `risk_functions` (`id`),
  ADD CONSTRAINT `risk_catalogs_risk_grouping_id_foreign` FOREIGN KEY (`risk_grouping_id`) REFERENCES `risk_groupings` (`id`);

--
-- Constraints for table `risk_levels`
--
ALTER TABLE `risk_levels`
  ADD CONSTRAINT `risk_levels_review_level_id_foreign` FOREIGN KEY (`review_level_id`) REFERENCES `review_levels` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_scorings`
--
ALTER TABLE `risk_scorings`
  ADD CONSTRAINT `risk_scorings_id_foreign` FOREIGN KEY (`id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_scoring_contributing_impacts`
--
ALTER TABLE `risk_scoring_contributing_impacts`
  ADD CONSTRAINT `risk_scoring_contributing_impacts_contributing_risk_id_foreign` FOREIGN KEY (`contributing_risk_id`) REFERENCES `contributing_risks` (`id`),
  ADD CONSTRAINT `risk_scoring_contributing_impacts_risk_scoring_id_foreign` FOREIGN KEY (`risk_scoring_id`) REFERENCES `risk_scorings` (`id`);

--
-- Constraints for table `risk_scoring_histories`
--
ALTER TABLE `risk_scoring_histories`
  ADD CONSTRAINT `risk_scoring_histories_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_to_additional_stakeholders`
--
ALTER TABLE `risk_to_additional_stakeholders`
  ADD CONSTRAINT `risk_to_additional_stakeholders_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risk_to_additional_stakeholders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `risk_to_locations`
--
ALTER TABLE `risk_to_locations`
  ADD CONSTRAINT `risk_to_locations_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  ADD CONSTRAINT `risk_to_locations_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_to_teams`
--
ALTER TABLE `risk_to_teams`
  ADD CONSTRAINT `risk_to_teams_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risk_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`);

--
-- Constraints for table `risk_to_technologies`
--
ALTER TABLE `risk_to_technologies`
  ADD CONSTRAINT `risk_to_technologies_risk_id_foreign` FOREIGN KEY (`risk_id`) REFERENCES `risks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risk_to_technologies_technology_id_foreign` FOREIGN KEY (`technology_id`) REFERENCES `technologies` (`id`);

--
-- Constraints for table `role_responsibilities`
--
ALTER TABLE `role_responsibilities`
  ADD CONSTRAINT `role_responsibilities_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `role_responsibilities_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `subgroups`
--
ALTER TABLE `subgroups`
  ADD CONSTRAINT `subgroups_permission_group_id_foreign` FOREIGN KEY (`permission_group_id`) REFERENCES `permission_groups` (`id`);

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_action_by_foreign` FOREIGN KEY (`action_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tasks_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `task_notes`
--
ALTER TABLE `task_notes`
  ADD CONSTRAINT `task_notes_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `task_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `task_note_files`
--
ALTER TABLE `task_note_files`
  ADD CONSTRAINT `task_note_files_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `task_note_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `threat_catalogs`
--
ALTER TABLE `threat_catalogs`
  ADD CONSTRAINT `threat_catalogs_threat_grouping_id_foreign` FOREIGN KEY (`threat_grouping_id`) REFERENCES `threat_groupings` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `users_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  ADD CONSTRAINT `users_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD CONSTRAINT `user_notifications_notification_id_foreign` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `user_pass_histories`
--
ALTER TABLE `user_pass_histories`
  ADD CONSTRAINT `user_pass_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_pass_reuse_histories`
--
ALTER TABLE `user_pass_reuse_histories`
  ADD CONSTRAINT `user_pass_reuse_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_to_teams`
--
ALTER TABLE `user_to_teams`
  ADD CONSTRAINT `user_to_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `user_to_teams_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `validation_files`
--
ALTER TABLE `validation_files`
  ADD CONSTRAINT `validation_files_mitigation_id_foreign` FOREIGN KEY (`mitigation_id`) REFERENCES `mitigations` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
